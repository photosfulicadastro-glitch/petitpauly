(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const r of document.querySelectorAll('link[rel="modulepreload"]'))a(r);new MutationObserver(r=>{for(const l of r)if(l.type==="childList")for(const u of l.addedNodes)u.tagName==="LINK"&&u.rel==="modulepreload"&&a(u)}).observe(document,{childList:!0,subtree:!0});function n(r){const l={};return r.integrity&&(l.integrity=r.integrity),r.referrerPolicy&&(l.referrerPolicy=r.referrerPolicy),r.crossOrigin==="use-credentials"?l.credentials="include":r.crossOrigin==="anonymous"?l.credentials="omit":l.credentials="same-origin",l}function a(r){if(r.ep)return;r.ep=!0;const l=n(r);fetch(r.href,l)}})();var Om={exports:{}},nu={};var gy;function vA(){if(gy)return nu;gy=1;var o=Symbol.for("react.transitional.element"),e=Symbol.for("react.fragment");function n(a,r,l){var u=null;if(l!==void 0&&(u=""+l),r.key!==void 0&&(u=""+r.key),"key"in r){l={};for(var f in r)f!=="key"&&(l[f]=r[f])}else l=r;return r=l.ref,{$$typeof:o,type:a,key:u,ref:r!==void 0?r:null,props:l}}return nu.Fragment=e,nu.jsx=n,nu.jsxs=n,nu}var vy;function xA(){return vy||(vy=1,Om.exports=vA()),Om.exports}var ge=xA(),Pm={exports:{}},iu={},Fm={exports:{}},zm={};var xy;function SA(){return xy||(xy=1,(function(o){function e(z,B){var J=z.length;z.push(B);e:for(;0<J;){var fe=J-1>>>1,G=z[fe];if(0<r(G,B))z[fe]=B,z[J]=G,J=fe;else break e}}function n(z){return z.length===0?null:z[0]}function a(z){if(z.length===0)return null;var B=z[0],J=z.pop();if(J!==B){z[0]=J;e:for(var fe=0,G=z.length,I=G>>>1;fe<I;){var K=2*(fe+1)-1,Se=z[K],be=K+1,Ue=z[be];if(0>r(Se,J))be<G&&0>r(Ue,Se)?(z[fe]=Ue,z[be]=J,fe=be):(z[fe]=Se,z[K]=J,fe=K);else if(be<G&&0>r(Ue,J))z[fe]=Ue,z[be]=J,fe=be;else break e}}return B}function r(z,B){var J=z.sortIndex-B.sortIndex;return J!==0?J:z.id-B.id}if(o.unstable_now=void 0,typeof performance=="object"&&typeof performance.now=="function"){var l=performance;o.unstable_now=function(){return l.now()}}else{var u=Date,f=u.now();o.unstable_now=function(){return u.now()-f}}var d=[],p=[],_=1,v=null,g=3,x=!1,M=!1,E=!1,S=!1,y=typeof setTimeout=="function"?setTimeout:null,R=typeof clearTimeout=="function"?clearTimeout:null,U=typeof setImmediate<"u"?setImmediate:null;function C(z){for(var B=n(p);B!==null;){if(B.callback===null)a(p);else if(B.startTime<=z)a(p),B.sortIndex=B.expirationTime,e(d,B);else break;B=n(p)}}function F(z){if(E=!1,C(z),!M)if(n(d)!==null)M=!0,O||(O=!0,k());else{var B=n(p);B!==null&&W(F,B.startTime-z)}}var O=!1,D=-1,T=5,L=-1;function H(){return S?!0:!(o.unstable_now()-L<T)}function V(){if(S=!1,O){var z=o.unstable_now();L=z;var B=!0;try{e:{M=!1,E&&(E=!1,R(D),D=-1),x=!0;var J=g;try{t:{for(C(z),v=n(d);v!==null&&!(v.expirationTime>z&&H());){var fe=v.callback;if(typeof fe=="function"){v.callback=null,g=v.priorityLevel;var G=fe(v.expirationTime<=z);if(z=o.unstable_now(),typeof G=="function"){v.callback=G,C(z),B=!0;break t}v===n(d)&&a(d),C(z)}else a(d);v=n(d)}if(v!==null)B=!0;else{var I=n(p);I!==null&&W(F,I.startTime-z),B=!1}}break e}finally{v=null,g=J,x=!1}B=void 0}}finally{B?k():O=!1}}}var k;if(typeof U=="function")k=function(){U(V)};else if(typeof MessageChannel<"u"){var te=new MessageChannel,ie=te.port2;te.port1.onmessage=V,k=function(){ie.postMessage(null)}}else k=function(){y(V,0)};function W(z,B){D=y(function(){z(o.unstable_now())},B)}o.unstable_IdlePriority=5,o.unstable_ImmediatePriority=1,o.unstable_LowPriority=4,o.unstable_NormalPriority=3,o.unstable_Profiling=null,o.unstable_UserBlockingPriority=2,o.unstable_cancelCallback=function(z){z.callback=null},o.unstable_forceFrameRate=function(z){0>z||125<z?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):T=0<z?Math.floor(1e3/z):5},o.unstable_getCurrentPriorityLevel=function(){return g},o.unstable_next=function(z){switch(g){case 1:case 2:case 3:var B=3;break;default:B=g}var J=g;g=B;try{return z()}finally{g=J}},o.unstable_requestPaint=function(){S=!0},o.unstable_runWithPriority=function(z,B){switch(z){case 1:case 2:case 3:case 4:case 5:break;default:z=3}var J=g;g=z;try{return B()}finally{g=J}},o.unstable_scheduleCallback=function(z,B,J){var fe=o.unstable_now();switch(typeof J=="object"&&J!==null?(J=J.delay,J=typeof J=="number"&&0<J?fe+J:fe):J=fe,z){case 1:var G=-1;break;case 2:G=250;break;case 5:G=1073741823;break;case 4:G=1e4;break;default:G=5e3}return G=J+G,z={id:_++,callback:B,priorityLevel:z,startTime:J,expirationTime:G,sortIndex:-1},J>fe?(z.sortIndex=J,e(p,z),n(d)===null&&z===n(p)&&(E?(R(D),D=-1):E=!0,W(F,J-fe))):(z.sortIndex=G,e(d,z),M||x||(M=!0,O||(O=!0,k()))),z},o.unstable_shouldYield=H,o.unstable_wrapCallback=function(z){var B=g;return function(){var J=g;g=B;try{return z.apply(this,arguments)}finally{g=J}}}})(zm)),zm}var Sy;function yA(){return Sy||(Sy=1,Fm.exports=SA()),Fm.exports}var Im={exports:{}},yt={};var yy;function MA(){if(yy)return yt;yy=1;var o=Symbol.for("react.transitional.element"),e=Symbol.for("react.portal"),n=Symbol.for("react.fragment"),a=Symbol.for("react.strict_mode"),r=Symbol.for("react.profiler"),l=Symbol.for("react.consumer"),u=Symbol.for("react.context"),f=Symbol.for("react.forward_ref"),d=Symbol.for("react.suspense"),p=Symbol.for("react.memo"),_=Symbol.for("react.lazy"),v=Symbol.for("react.activity"),g=Symbol.iterator;function x(I){return I===null||typeof I!="object"?null:(I=g&&I[g]||I["@@iterator"],typeof I=="function"?I:null)}var M={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},E=Object.assign,S={};function y(I,K,Se){this.props=I,this.context=K,this.refs=S,this.updater=Se||M}y.prototype.isReactComponent={},y.prototype.setState=function(I,K){if(typeof I!="object"&&typeof I!="function"&&I!=null)throw Error("takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,I,K,"setState")},y.prototype.forceUpdate=function(I){this.updater.enqueueForceUpdate(this,I,"forceUpdate")};function R(){}R.prototype=y.prototype;function U(I,K,Se){this.props=I,this.context=K,this.refs=S,this.updater=Se||M}var C=U.prototype=new R;C.constructor=U,E(C,y.prototype),C.isPureReactComponent=!0;var F=Array.isArray;function O(){}var D={H:null,A:null,T:null,S:null},T=Object.prototype.hasOwnProperty;function L(I,K,Se){var be=Se.ref;return{$$typeof:o,type:I,key:K,ref:be!==void 0?be:null,props:Se}}function H(I,K){return L(I.type,K,I.props)}function V(I){return typeof I=="object"&&I!==null&&I.$$typeof===o}function k(I){var K={"=":"=0",":":"=2"};return"$"+I.replace(/[=:]/g,function(Se){return K[Se]})}var te=/\/+/g;function ie(I,K){return typeof I=="object"&&I!==null&&I.key!=null?k(""+I.key):K.toString(36)}function W(I){switch(I.status){case"fulfilled":return I.value;case"rejected":throw I.reason;default:switch(typeof I.status=="string"?I.then(O,O):(I.status="pending",I.then(function(K){I.status==="pending"&&(I.status="fulfilled",I.value=K)},function(K){I.status==="pending"&&(I.status="rejected",I.reason=K)})),I.status){case"fulfilled":return I.value;case"rejected":throw I.reason}}throw I}function z(I,K,Se,be,Ue){var ne=typeof I;(ne==="undefined"||ne==="boolean")&&(I=null);var xe=!1;if(I===null)xe=!0;else switch(ne){case"bigint":case"string":case"number":xe=!0;break;case"object":switch(I.$$typeof){case o:case e:xe=!0;break;case _:return xe=I._init,z(xe(I._payload),K,Se,be,Ue)}}if(xe)return Ue=Ue(I),xe=be===""?"."+ie(I,0):be,F(Ue)?(Se="",xe!=null&&(Se=xe.replace(te,"$&/")+"/"),z(Ue,K,Se,"",function(nt){return nt})):Ue!=null&&(V(Ue)&&(Ue=H(Ue,Se+(Ue.key==null||I&&I.key===Ue.key?"":(""+Ue.key).replace(te,"$&/")+"/")+xe)),K.push(Ue)),1;xe=0;var Ee=be===""?".":be+":";if(F(I))for(var Ie=0;Ie<I.length;Ie++)be=I[Ie],ne=Ee+ie(be,Ie),xe+=z(be,K,Se,ne,Ue);else if(Ie=x(I),typeof Ie=="function")for(I=Ie.call(I),Ie=0;!(be=I.next()).done;)be=be.value,ne=Ee+ie(be,Ie++),xe+=z(be,K,Se,ne,Ue);else if(ne==="object"){if(typeof I.then=="function")return z(W(I),K,Se,be,Ue);throw K=String(I),Error("Objects are not valid as a React child (found: "+(K==="[object Object]"?"object with keys {"+Object.keys(I).join(", ")+"}":K)+"). If you meant to render a collection of children, use an array instead.")}return xe}function B(I,K,Se){if(I==null)return I;var be=[],Ue=0;return z(I,be,"","",function(ne){return K.call(Se,ne,Ue++)}),be}function J(I){if(I._status===-1){var K=I._result;K=K(),K.then(function(Se){(I._status===0||I._status===-1)&&(I._status=1,I._result=Se)},function(Se){(I._status===0||I._status===-1)&&(I._status=2,I._result=Se)}),I._status===-1&&(I._status=0,I._result=K)}if(I._status===1)return I._result.default;throw I._result}var fe=typeof reportError=="function"?reportError:function(I){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var K=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof I=="object"&&I!==null&&typeof I.message=="string"?String(I.message):String(I),error:I});if(!window.dispatchEvent(K))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",I);return}console.error(I)},G={map:B,forEach:function(I,K,Se){B(I,function(){K.apply(this,arguments)},Se)},count:function(I){var K=0;return B(I,function(){K++}),K},toArray:function(I){return B(I,function(K){return K})||[]},only:function(I){if(!V(I))throw Error("React.Children.only expected to receive a single React element child.");return I}};return yt.Activity=v,yt.Children=G,yt.Component=y,yt.Fragment=n,yt.Profiler=r,yt.PureComponent=U,yt.StrictMode=a,yt.Suspense=d,yt.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=D,yt.__COMPILER_RUNTIME={__proto__:null,c:function(I){return D.H.useMemoCache(I)}},yt.cache=function(I){return function(){return I.apply(null,arguments)}},yt.cacheSignal=function(){return null},yt.cloneElement=function(I,K,Se){if(I==null)throw Error("The argument must be a React element, but you passed "+I+".");var be=E({},I.props),Ue=I.key;if(K!=null)for(ne in K.key!==void 0&&(Ue=""+K.key),K)!T.call(K,ne)||ne==="key"||ne==="__self"||ne==="__source"||ne==="ref"&&K.ref===void 0||(be[ne]=K[ne]);var ne=arguments.length-2;if(ne===1)be.children=Se;else if(1<ne){for(var xe=Array(ne),Ee=0;Ee<ne;Ee++)xe[Ee]=arguments[Ee+2];be.children=xe}return L(I.type,Ue,be)},yt.createContext=function(I){return I={$$typeof:u,_currentValue:I,_currentValue2:I,_threadCount:0,Provider:null,Consumer:null},I.Provider=I,I.Consumer={$$typeof:l,_context:I},I},yt.createElement=function(I,K,Se){var be,Ue={},ne=null;if(K!=null)for(be in K.key!==void 0&&(ne=""+K.key),K)T.call(K,be)&&be!=="key"&&be!=="__self"&&be!=="__source"&&(Ue[be]=K[be]);var xe=arguments.length-2;if(xe===1)Ue.children=Se;else if(1<xe){for(var Ee=Array(xe),Ie=0;Ie<xe;Ie++)Ee[Ie]=arguments[Ie+2];Ue.children=Ee}if(I&&I.defaultProps)for(be in xe=I.defaultProps,xe)Ue[be]===void 0&&(Ue[be]=xe[be]);return L(I,ne,Ue)},yt.createRef=function(){return{current:null}},yt.forwardRef=function(I){return{$$typeof:f,render:I}},yt.isValidElement=V,yt.lazy=function(I){return{$$typeof:_,_payload:{_status:-1,_result:I},_init:J}},yt.memo=function(I,K){return{$$typeof:p,type:I,compare:K===void 0?null:K}},yt.startTransition=function(I){var K=D.T,Se={};D.T=Se;try{var be=I(),Ue=D.S;Ue!==null&&Ue(Se,be),typeof be=="object"&&be!==null&&typeof be.then=="function"&&be.then(O,fe)}catch(ne){fe(ne)}finally{K!==null&&Se.types!==null&&(K.types=Se.types),D.T=K}},yt.unstable_useCacheRefresh=function(){return D.H.useCacheRefresh()},yt.use=function(I){return D.H.use(I)},yt.useActionState=function(I,K,Se){return D.H.useActionState(I,K,Se)},yt.useCallback=function(I,K){return D.H.useCallback(I,K)},yt.useContext=function(I){return D.H.useContext(I)},yt.useDebugValue=function(){},yt.useDeferredValue=function(I,K){return D.H.useDeferredValue(I,K)},yt.useEffect=function(I,K){return D.H.useEffect(I,K)},yt.useEffectEvent=function(I){return D.H.useEffectEvent(I)},yt.useId=function(){return D.H.useId()},yt.useImperativeHandle=function(I,K,Se){return D.H.useImperativeHandle(I,K,Se)},yt.useInsertionEffect=function(I,K){return D.H.useInsertionEffect(I,K)},yt.useLayoutEffect=function(I,K){return D.H.useLayoutEffect(I,K)},yt.useMemo=function(I,K){return D.H.useMemo(I,K)},yt.useOptimistic=function(I,K){return D.H.useOptimistic(I,K)},yt.useReducer=function(I,K,Se){return D.H.useReducer(I,K,Se)},yt.useRef=function(I){return D.H.useRef(I)},yt.useState=function(I){return D.H.useState(I)},yt.useSyncExternalStore=function(I,K,Se){return D.H.useSyncExternalStore(I,K,Se)},yt.useTransition=function(){return D.H.useTransition()},yt.version="19.2.3",yt}var My;function Z0(){return My||(My=1,Im.exports=MA()),Im.exports}var Bm={exports:{}},yi={};var by;function bA(){if(by)return yi;by=1;var o=Z0();function e(d){var p="https://react.dev/errors/"+d;if(1<arguments.length){p+="?args[]="+encodeURIComponent(arguments[1]);for(var _=2;_<arguments.length;_++)p+="&args[]="+encodeURIComponent(arguments[_])}return"Minified React error #"+d+"; visit "+p+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function n(){}var a={d:{f:n,r:function(){throw Error(e(522))},D:n,C:n,L:n,m:n,X:n,S:n,M:n},p:0,findDOMNode:null},r=Symbol.for("react.portal");function l(d,p,_){var v=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:r,key:v==null?null:""+v,children:d,containerInfo:p,implementation:_}}var u=o.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;function f(d,p){if(d==="font")return"";if(typeof p=="string")return p==="use-credentials"?p:""}return yi.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE=a,yi.createPortal=function(d,p){var _=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!p||p.nodeType!==1&&p.nodeType!==9&&p.nodeType!==11)throw Error(e(299));return l(d,p,null,_)},yi.flushSync=function(d){var p=u.T,_=a.p;try{if(u.T=null,a.p=2,d)return d()}finally{u.T=p,a.p=_,a.d.f()}},yi.preconnect=function(d,p){typeof d=="string"&&(p?(p=p.crossOrigin,p=typeof p=="string"?p==="use-credentials"?p:"":void 0):p=null,a.d.C(d,p))},yi.prefetchDNS=function(d){typeof d=="string"&&a.d.D(d)},yi.preinit=function(d,p){if(typeof d=="string"&&p&&typeof p.as=="string"){var _=p.as,v=f(_,p.crossOrigin),g=typeof p.integrity=="string"?p.integrity:void 0,x=typeof p.fetchPriority=="string"?p.fetchPriority:void 0;_==="style"?a.d.S(d,typeof p.precedence=="string"?p.precedence:void 0,{crossOrigin:v,integrity:g,fetchPriority:x}):_==="script"&&a.d.X(d,{crossOrigin:v,integrity:g,fetchPriority:x,nonce:typeof p.nonce=="string"?p.nonce:void 0})}},yi.preinitModule=function(d,p){if(typeof d=="string")if(typeof p=="object"&&p!==null){if(p.as==null||p.as==="script"){var _=f(p.as,p.crossOrigin);a.d.M(d,{crossOrigin:_,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0})}}else p==null&&a.d.M(d)},yi.preload=function(d,p){if(typeof d=="string"&&typeof p=="object"&&p!==null&&typeof p.as=="string"){var _=p.as,v=f(_,p.crossOrigin);a.d.L(d,_,{crossOrigin:v,integrity:typeof p.integrity=="string"?p.integrity:void 0,nonce:typeof p.nonce=="string"?p.nonce:void 0,type:typeof p.type=="string"?p.type:void 0,fetchPriority:typeof p.fetchPriority=="string"?p.fetchPriority:void 0,referrerPolicy:typeof p.referrerPolicy=="string"?p.referrerPolicy:void 0,imageSrcSet:typeof p.imageSrcSet=="string"?p.imageSrcSet:void 0,imageSizes:typeof p.imageSizes=="string"?p.imageSizes:void 0,media:typeof p.media=="string"?p.media:void 0})}},yi.preloadModule=function(d,p){if(typeof d=="string")if(p){var _=f(p.as,p.crossOrigin);a.d.m(d,{as:typeof p.as=="string"&&p.as!=="script"?p.as:void 0,crossOrigin:_,integrity:typeof p.integrity=="string"?p.integrity:void 0})}else a.d.m(d)},yi.requestFormReset=function(d){a.d.r(d)},yi.unstable_batchedUpdates=function(d,p){return d(p)},yi.useFormState=function(d,p,_){return u.H.useFormState(d,p,_)},yi.useFormStatus=function(){return u.H.useHostTransitionStatus()},yi.version="19.2.3",yi}var Ey;function EA(){if(Ey)return Bm.exports;Ey=1;function o(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(o)}catch(e){console.error(e)}}return o(),Bm.exports=bA(),Bm.exports}var Ty;function TA(){if(Ty)return iu;Ty=1;var o=yA(),e=Z0(),n=EA();function a(t){var i="https://react.dev/errors/"+t;if(1<arguments.length){i+="?args[]="+encodeURIComponent(arguments[1]);for(var s=2;s<arguments.length;s++)i+="&args[]="+encodeURIComponent(arguments[s])}return"Minified React error #"+t+"; visit "+i+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}function r(t){return!(!t||t.nodeType!==1&&t.nodeType!==9&&t.nodeType!==11)}function l(t){var i=t,s=t;if(t.alternate)for(;i.return;)i=i.return;else{t=i;do i=t,(i.flags&4098)!==0&&(s=i.return),t=i.return;while(t)}return i.tag===3?s:null}function u(t){if(t.tag===13){var i=t.memoizedState;if(i===null&&(t=t.alternate,t!==null&&(i=t.memoizedState)),i!==null)return i.dehydrated}return null}function f(t){if(t.tag===31){var i=t.memoizedState;if(i===null&&(t=t.alternate,t!==null&&(i=t.memoizedState)),i!==null)return i.dehydrated}return null}function d(t){if(l(t)!==t)throw Error(a(188))}function p(t){var i=t.alternate;if(!i){if(i=l(t),i===null)throw Error(a(188));return i!==t?null:t}for(var s=t,c=i;;){var h=s.return;if(h===null)break;var m=h.alternate;if(m===null){if(c=h.return,c!==null){s=c;continue}break}if(h.child===m.child){for(m=h.child;m;){if(m===s)return d(h),t;if(m===c)return d(h),i;m=m.sibling}throw Error(a(188))}if(s.return!==c.return)s=h,c=m;else{for(var b=!1,N=h.child;N;){if(N===s){b=!0,s=h,c=m;break}if(N===c){b=!0,c=h,s=m;break}N=N.sibling}if(!b){for(N=m.child;N;){if(N===s){b=!0,s=m,c=h;break}if(N===c){b=!0,c=m,s=h;break}N=N.sibling}if(!b)throw Error(a(189))}}if(s.alternate!==c)throw Error(a(190))}if(s.tag!==3)throw Error(a(188));return s.stateNode.current===s?t:i}function _(t){var i=t.tag;if(i===5||i===26||i===27||i===6)return t;for(t=t.child;t!==null;){if(i=_(t),i!==null)return i;t=t.sibling}return null}var v=Object.assign,g=Symbol.for("react.element"),x=Symbol.for("react.transitional.element"),M=Symbol.for("react.portal"),E=Symbol.for("react.fragment"),S=Symbol.for("react.strict_mode"),y=Symbol.for("react.profiler"),R=Symbol.for("react.consumer"),U=Symbol.for("react.context"),C=Symbol.for("react.forward_ref"),F=Symbol.for("react.suspense"),O=Symbol.for("react.suspense_list"),D=Symbol.for("react.memo"),T=Symbol.for("react.lazy"),L=Symbol.for("react.activity"),H=Symbol.for("react.memo_cache_sentinel"),V=Symbol.iterator;function k(t){return t===null||typeof t!="object"?null:(t=V&&t[V]||t["@@iterator"],typeof t=="function"?t:null)}var te=Symbol.for("react.client.reference");function ie(t){if(t==null)return null;if(typeof t=="function")return t.$$typeof===te?null:t.displayName||t.name||null;if(typeof t=="string")return t;switch(t){case E:return"Fragment";case y:return"Profiler";case S:return"StrictMode";case F:return"Suspense";case O:return"SuspenseList";case L:return"Activity"}if(typeof t=="object")switch(t.$$typeof){case M:return"Portal";case U:return t.displayName||"Context";case R:return(t._context.displayName||"Context")+".Consumer";case C:var i=t.render;return t=t.displayName,t||(t=i.displayName||i.name||"",t=t!==""?"ForwardRef("+t+")":"ForwardRef"),t;case D:return i=t.displayName||null,i!==null?i:ie(t.type)||"Memo";case T:i=t._payload,t=t._init;try{return ie(t(i))}catch{}}return null}var W=Array.isArray,z=e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,B=n.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,J={pending:!1,data:null,method:null,action:null},fe=[],G=-1;function I(t){return{current:t}}function K(t){0>G||(t.current=fe[G],fe[G]=null,G--)}function Se(t,i){G++,fe[G]=t.current,t.current=i}var be=I(null),Ue=I(null),ne=I(null),xe=I(null);function Ee(t,i){switch(Se(ne,i),Se(Ue,t),Se(be,null),i.nodeType){case 9:case 11:t=(t=i.documentElement)&&(t=t.namespaceURI)?HS(t):0;break;default:if(t=i.tagName,i=i.namespaceURI)i=HS(i),t=GS(i,t);else switch(t){case"svg":t=1;break;case"math":t=2;break;default:t=0}}K(be),Se(be,t)}function Ie(){K(be),K(Ue),K(ne)}function nt(t){t.memoizedState!==null&&Se(xe,t);var i=be.current,s=GS(i,t.type);i!==s&&(Se(Ue,t),Se(be,s))}function Ze(t){Ue.current===t&&(K(be),K(Ue)),xe.current===t&&(K(xe),Jc._currentValue=J)}var Mt,Ye;function it(t){if(Mt===void 0)try{throw Error()}catch(s){var i=s.stack.trim().match(/\n( *(at )?)/);Mt=i&&i[1]||"",Ye=-1<s.stack.indexOf(`
    at`)?" (<anonymous>)":-1<s.stack.indexOf("@")?"@unknown:0:0":""}return`
`+Mt+t+Ye}var xt=!1;function st(t,i){if(!t||xt)return"";xt=!0;var s=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{var c={DetermineComponentFrameRoot:function(){try{if(i){var Me=function(){throw Error()};if(Object.defineProperty(Me.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(Me,[])}catch(he){var ce=he}Reflect.construct(t,[],Me)}else{try{Me.call()}catch(he){ce=he}t.call(Me.prototype)}}else{try{throw Error()}catch(he){ce=he}(Me=t())&&typeof Me.catch=="function"&&Me.catch(function(){})}}catch(he){if(he&&ce&&typeof he.stack=="string")return[he.stack,ce.stack]}return[null,null]}};c.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";var h=Object.getOwnPropertyDescriptor(c.DetermineComponentFrameRoot,"name");h&&h.configurable&&Object.defineProperty(c.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});var m=c.DetermineComponentFrameRoot(),b=m[0],N=m[1];if(b&&N){var X=b.split(`
`),oe=N.split(`
`);for(h=c=0;c<X.length&&!X[c].includes("DetermineComponentFrameRoot");)c++;for(;h<oe.length&&!oe[h].includes("DetermineComponentFrameRoot");)h++;if(c===X.length||h===oe.length)for(c=X.length-1,h=oe.length-1;1<=c&&0<=h&&X[c]!==oe[h];)h--;for(;1<=c&&0<=h;c--,h--)if(X[c]!==oe[h]){if(c!==1||h!==1)do if(c--,h--,0>h||X[c]!==oe[h]){var ve=`
`+X[c].replace(" at new "," at ");return t.displayName&&ve.includes("<anonymous>")&&(ve=ve.replace("<anonymous>",t.displayName)),ve}while(1<=c&&0<=h);break}}}finally{xt=!1,Error.prepareStackTrace=s}return(s=t?t.displayName||t.name:"")?it(s):""}function le(t,i){switch(t.tag){case 26:case 27:case 5:return it(t.type);case 16:return it("Lazy");case 13:return t.child!==i&&i!==null?it("Suspense Fallback"):it("Suspense");case 19:return it("SuspenseList");case 0:case 15:return st(t.type,!1);case 11:return st(t.type.render,!1);case 1:return st(t.type,!0);case 31:return it("Activity");default:return""}}function Dt(t){try{var i="",s=null;do i+=le(t,s),s=t,t=t.return;while(t);return i}catch(c){return`
Error generating stack: `+c.message+`
`+c.stack}}var mn=Object.prototype.hasOwnProperty,j=o.unstable_scheduleCallback,gt=o.unstable_cancelCallback,mt=o.unstable_shouldYield,Ft=o.unstable_requestPaint,Le=o.unstable_now,bt=o.unstable_getCurrentPriorityLevel,P=o.unstable_ImmediatePriority,A=o.unstable_UserBlockingPriority,Q=o.unstable_NormalPriority,_e=o.unstable_LowPriority,Te=o.unstable_IdlePriority,Fe=o.log,De=o.unstable_setDisableYieldValue,de=null,pe=null;function Be(t){if(typeof Fe=="function"&&De(t),pe&&typeof pe.setStrictMode=="function")try{pe.setStrictMode(de,t)}catch{}}var He=Math.clz32?Math.clz32:Ge,ze=Math.log,Oe=Math.LN2;function Ge(t){return t>>>=0,t===0?32:31-(ze(t)/Oe|0)|0}var ut=256,dt=262144,q=4194304;function Re(t){var i=t&42;if(i!==0)return i;switch(t&-t){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:return 64;case 128:return 128;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:return t&261888;case 262144:case 524288:case 1048576:case 2097152:return t&3932160;case 4194304:case 8388608:case 16777216:case 33554432:return t&62914560;case 67108864:return 67108864;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 0;default:return t}}function me(t,i,s){var c=t.pendingLanes;if(c===0)return 0;var h=0,m=t.suspendedLanes,b=t.pingedLanes;t=t.warmLanes;var N=c&134217727;return N!==0?(c=N&~m,c!==0?h=Re(c):(b&=N,b!==0?h=Re(b):s||(s=N&~t,s!==0&&(h=Re(s))))):(N=c&~m,N!==0?h=Re(N):b!==0?h=Re(b):s||(s=c&~t,s!==0&&(h=Re(s)))),h===0?0:i!==0&&i!==h&&(i&m)===0&&(m=h&-h,s=i&-i,m>=s||m===32&&(s&4194048)!==0)?i:h}function Ve(t,i){return(t.pendingLanes&~(t.suspendedLanes&~t.pingedLanes)&i)===0}function Pe(t,i){switch(t){case 1:case 2:case 4:case 8:case 64:return i+250;case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return i+5e3;case 4194304:case 8388608:case 16777216:case 33554432:return-1;case 67108864:case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Ae(){var t=q;return q<<=1,(q&62914560)===0&&(q=4194304),t}function Ce(t){for(var i=[],s=0;31>s;s++)i.push(t);return i}function Ne(t,i){t.pendingLanes|=i,i!==268435456&&(t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0)}function ot(t,i,s,c,h,m){var b=t.pendingLanes;t.pendingLanes=s,t.suspendedLanes=0,t.pingedLanes=0,t.warmLanes=0,t.expiredLanes&=s,t.entangledLanes&=s,t.errorRecoveryDisabledLanes&=s,t.shellSuspendCounter=0;var N=t.entanglements,X=t.expirationTimes,oe=t.hiddenUpdates;for(s=b&~s;0<s;){var ve=31-He(s),Me=1<<ve;N[ve]=0,X[ve]=-1;var ce=oe[ve];if(ce!==null)for(oe[ve]=null,ve=0;ve<ce.length;ve++){var he=ce[ve];he!==null&&(he.lane&=-536870913)}s&=~Me}c!==0&&we(t,c,0),m!==0&&h===0&&t.tag!==0&&(t.suspendedLanes|=m&~(b&~i))}function we(t,i,s){t.pendingLanes|=i,t.suspendedLanes&=~i;var c=31-He(i);t.entangledLanes|=i,t.entanglements[c]=t.entanglements[c]|1073741824|s&261930}function rt(t,i){var s=t.entangledLanes|=i;for(t=t.entanglements;s;){var c=31-He(s),h=1<<c;h&i|t[c]&i&&(t[c]|=i),s&=~h}}function Qe(t,i){var s=i&-i;return s=(s&42)!==0?1:ft(s),(s&(t.suspendedLanes|i))!==0?0:s}function ft(t){switch(t){case 2:t=1;break;case 8:t=4;break;case 32:t=16;break;case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:t=128;break;case 268435456:t=134217728;break;default:t=0}return t}function Rn(t){return t&=-t,2<t?8<t?(t&134217727)!==0?32:268435456:8:2}function Ct(){var t=B.p;return t!==0?t:(t=window.event,t===void 0?32:uy(t.type))}function _n(t,i){var s=B.p;try{return B.p=t,i()}finally{B.p=s}}var Yt=Math.random().toString(36).slice(2),St="__reactFiber$"+Yt,Tt="__reactProps$"+Yt,zt="__reactContainer$"+Yt,Xn="__reactEvents$"+Yt,un="__reactListeners$"+Yt,Wn="__reactHandles$"+Yt,vi="__reactResources$"+Yt,Mn="__reactMarker$"+Yt;function Nn(t){delete t[St],delete t[Tt],delete t[Xn],delete t[un],delete t[Wn]}function bn(t){var i=t[St];if(i)return i;for(var s=t.parentNode;s;){if(i=s[zt]||s[St]){if(s=i.alternate,i.child!==null||s!==null&&s.child!==null)for(t=jS(t);t!==null;){if(s=t[St])return s;t=jS(t)}return i}t=s,s=t.parentNode}return null}function xi(t){if(t=t[St]||t[zt]){var i=t.tag;if(i===5||i===6||i===13||i===31||i===26||i===27||i===3)return t}return null}function Ea(t){var i=t.tag;if(i===5||i===26||i===27||i===6)return t.stateNode;throw Error(a(33))}function En(t){var i=t[vi];return i||(i=t[vi]={hoistableStyles:new Map,hoistableScripts:new Map}),i}function Ut(t){t[Mn]=!0}var Di=new Set,w={};function Z(t,i){se(t,i),se(t+"Capture",i)}function se(t,i){for(w[t]=i,t=0;t<i.length;t++)Di.add(i[t])}var ee=RegExp("^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$"),ae={},ke={};function We(t){return mn.call(ke,t)?!0:mn.call(ae,t)?!1:ee.test(t)?ke[t]=!0:(ae[t]=!0,!1)}function Xe(t,i,s){if(We(i))if(s===null)t.removeAttribute(i);else{switch(typeof s){case"undefined":case"function":case"symbol":t.removeAttribute(i);return;case"boolean":var c=i.toLowerCase().slice(0,5);if(c!=="data-"&&c!=="aria-"){t.removeAttribute(i);return}}t.setAttribute(i,""+s)}}function Je(t,i,s){if(s===null)t.removeAttribute(i);else{switch(typeof s){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(i);return}t.setAttribute(i,""+s)}}function Ke(t,i,s,c){if(c===null)t.removeAttribute(s);else{switch(typeof c){case"undefined":case"function":case"symbol":case"boolean":t.removeAttribute(s);return}t.setAttributeNS(i,s,""+c)}}function lt(t){switch(typeof t){case"bigint":case"boolean":case"number":case"string":case"undefined":return t;case"object":return t;default:return""}}function At(t){var i=t.type;return(t=t.nodeName)&&t.toLowerCase()==="input"&&(i==="checkbox"||i==="radio")}function at(t,i,s){var c=Object.getOwnPropertyDescriptor(t.constructor.prototype,i);if(!t.hasOwnProperty(i)&&typeof c<"u"&&typeof c.get=="function"&&typeof c.set=="function"){var h=c.get,m=c.set;return Object.defineProperty(t,i,{configurable:!0,get:function(){return h.call(this)},set:function(b){s=""+b,m.call(this,b)}}),Object.defineProperty(t,i,{enumerable:c.enumerable}),{getValue:function(){return s},setValue:function(b){s=""+b},stopTracking:function(){t._valueTracker=null,delete t[i]}}}}function Zt(t){if(!t._valueTracker){var i=At(t)?"checked":"value";t._valueTracker=at(t,i,""+t[i])}}function Cn(t){if(!t)return!1;var i=t._valueTracker;if(!i)return!0;var s=i.getValue(),c="";return t&&(c=At(t)?t.checked?"true":"false":t.value),t=c,t!==s?(i.setValue(t),!0):!1}function gn(t){if(t=t||(typeof document<"u"?document:void 0),typeof t>"u")return null;try{return t.activeElement||t.body}catch{return t.body}}var nn=/[\n"\\]/g;function an(t){return t.replace(nn,function(i){return"\\"+i.charCodeAt(0).toString(16)+" "})}function je(t,i,s,c,h,m,b,N){t.name="",b!=null&&typeof b!="function"&&typeof b!="symbol"&&typeof b!="boolean"?t.type=b:t.removeAttribute("type"),i!=null?b==="number"?(i===0&&t.value===""||t.value!=i)&&(t.value=""+lt(i)):t.value!==""+lt(i)&&(t.value=""+lt(i)):b!=="submit"&&b!=="reset"||t.removeAttribute("value"),i!=null?It(t,b,lt(i)):s!=null?It(t,b,lt(s)):c!=null&&t.removeAttribute("value"),h==null&&m!=null&&(t.defaultChecked=!!m),h!=null&&(t.checked=h&&typeof h!="function"&&typeof h!="symbol"),N!=null&&typeof N!="function"&&typeof N!="symbol"&&typeof N!="boolean"?t.name=""+lt(N):t.removeAttribute("name")}function Si(t,i,s,c,h,m,b,N){if(m!=null&&typeof m!="function"&&typeof m!="symbol"&&typeof m!="boolean"&&(t.type=m),i!=null||s!=null){if(!(m!=="submit"&&m!=="reset"||i!=null)){Zt(t);return}s=s!=null?""+lt(s):"",i=i!=null?""+lt(i):s,N||i===t.value||(t.value=i),t.defaultValue=i}c=c??h,c=typeof c!="function"&&typeof c!="symbol"&&!!c,t.checked=N?t.checked:!!c,t.defaultChecked=!!c,b!=null&&typeof b!="function"&&typeof b!="symbol"&&typeof b!="boolean"&&(t.name=b),Zt(t)}function It(t,i,s){i==="number"&&gn(t.ownerDocument)===t||t.defaultValue===""+s||(t.defaultValue=""+s)}function $n(t,i,s,c){if(t=t.options,i){i={};for(var h=0;h<s.length;h++)i["$"+s[h]]=!0;for(s=0;s<t.length;s++)h=i.hasOwnProperty("$"+t[s].value),t[s].selected!==h&&(t[s].selected=h),h&&c&&(t[s].defaultSelected=!0)}else{for(s=""+lt(s),i=null,h=0;h<t.length;h++){if(t[h].value===s){t[h].selected=!0,c&&(t[h].defaultSelected=!0);return}i!==null||t[h].disabled||(i=t[h])}i!==null&&(i.selected=!0)}}function ta(t,i,s){if(i!=null&&(i=""+lt(i),i!==t.value&&(t.value=i),s==null)){t.defaultValue!==i&&(t.defaultValue=i);return}t.defaultValue=s!=null?""+lt(s):""}function ka(t,i,s,c){if(i==null){if(c!=null){if(s!=null)throw Error(a(92));if(W(c)){if(1<c.length)throw Error(a(93));c=c[0]}s=c}s==null&&(s=""),i=s}s=lt(i),t.defaultValue=s,c=t.textContent,c===s&&c!==""&&c!==null&&(t.value=c),Zt(t)}function na(t,i){if(i){var s=t.firstChild;if(s&&s===t.lastChild&&s.nodeType===3){s.nodeValue=i;return}}t.textContent=i}var rn=new Set("animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp".split(" "));function wn(t,i,s){var c=i.indexOf("--")===0;s==null||typeof s=="boolean"||s===""?c?t.setProperty(i,""):i==="float"?t.cssFloat="":t[i]="":c?t.setProperty(i,s):typeof s!="number"||s===0||rn.has(i)?i==="float"?t.cssFloat=s:t[i]=(""+s).trim():t[i]=s+"px"}function Xa(t,i,s){if(i!=null&&typeof i!="object")throw Error(a(62));if(t=t.style,s!=null){for(var c in s)!s.hasOwnProperty(c)||i!=null&&i.hasOwnProperty(c)||(c.indexOf("--")===0?t.setProperty(c,""):c==="float"?t.cssFloat="":t[c]="");for(var h in i)c=i[h],i.hasOwnProperty(h)&&s[h]!==c&&wn(t,h,c)}else for(var m in i)i.hasOwnProperty(m)&&wn(t,m,i[m])}function en(t){if(t.indexOf("-")===-1)return!1;switch(t){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var ir=new Map([["acceptCharset","accept-charset"],["htmlFor","for"],["httpEquiv","http-equiv"],["crossOrigin","crossorigin"],["accentHeight","accent-height"],["alignmentBaseline","alignment-baseline"],["arabicForm","arabic-form"],["baselineShift","baseline-shift"],["capHeight","cap-height"],["clipPath","clip-path"],["clipRule","clip-rule"],["colorInterpolation","color-interpolation"],["colorInterpolationFilters","color-interpolation-filters"],["colorProfile","color-profile"],["colorRendering","color-rendering"],["dominantBaseline","dominant-baseline"],["enableBackground","enable-background"],["fillOpacity","fill-opacity"],["fillRule","fill-rule"],["floodColor","flood-color"],["floodOpacity","flood-opacity"],["fontFamily","font-family"],["fontSize","font-size"],["fontSizeAdjust","font-size-adjust"],["fontStretch","font-stretch"],["fontStyle","font-style"],["fontVariant","font-variant"],["fontWeight","font-weight"],["glyphName","glyph-name"],["glyphOrientationHorizontal","glyph-orientation-horizontal"],["glyphOrientationVertical","glyph-orientation-vertical"],["horizAdvX","horiz-adv-x"],["horizOriginX","horiz-origin-x"],["imageRendering","image-rendering"],["letterSpacing","letter-spacing"],["lightingColor","lighting-color"],["markerEnd","marker-end"],["markerMid","marker-mid"],["markerStart","marker-start"],["overlinePosition","overline-position"],["overlineThickness","overline-thickness"],["paintOrder","paint-order"],["panose-1","panose-1"],["pointerEvents","pointer-events"],["renderingIntent","rendering-intent"],["shapeRendering","shape-rendering"],["stopColor","stop-color"],["stopOpacity","stop-opacity"],["strikethroughPosition","strikethrough-position"],["strikethroughThickness","strikethrough-thickness"],["strokeDasharray","stroke-dasharray"],["strokeDashoffset","stroke-dashoffset"],["strokeLinecap","stroke-linecap"],["strokeLinejoin","stroke-linejoin"],["strokeMiterlimit","stroke-miterlimit"],["strokeOpacity","stroke-opacity"],["strokeWidth","stroke-width"],["textAnchor","text-anchor"],["textDecoration","text-decoration"],["textRendering","text-rendering"],["transformOrigin","transform-origin"],["underlinePosition","underline-position"],["underlineThickness","underline-thickness"],["unicodeBidi","unicode-bidi"],["unicodeRange","unicode-range"],["unitsPerEm","units-per-em"],["vAlphabetic","v-alphabetic"],["vHanging","v-hanging"],["vIdeographic","v-ideographic"],["vMathematical","v-mathematical"],["vectorEffect","vector-effect"],["vertAdvY","vert-adv-y"],["vertOriginX","vert-origin-x"],["vertOriginY","vert-origin-y"],["wordSpacing","word-spacing"],["writingMode","writing-mode"],["xmlnsXlink","xmlns:xlink"],["xHeight","x-height"]]),ss=/^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;function $s(t){return ss.test(""+t)?"javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')":t}function Er(){}var Ud=null;function Nd(t){return t=t.target||t.srcElement||window,t.correspondingUseElement&&(t=t.correspondingUseElement),t.nodeType===3?t.parentNode:t}var jo=null,Zo=null;function Bg(t){var i=xi(t);if(i&&(t=i.stateNode)){var s=t[Tt]||null;e:switch(t=i.stateNode,i.type){case"input":if(je(t,s.value,s.defaultValue,s.defaultValue,s.checked,s.defaultChecked,s.type,s.name),i=s.name,s.type==="radio"&&i!=null){for(s=t;s.parentNode;)s=s.parentNode;for(s=s.querySelectorAll('input[name="'+an(""+i)+'"][type="radio"]'),i=0;i<s.length;i++){var c=s[i];if(c!==t&&c.form===t.form){var h=c[Tt]||null;if(!h)throw Error(a(90));je(c,h.value,h.defaultValue,h.defaultValue,h.checked,h.defaultChecked,h.type,h.name)}}for(i=0;i<s.length;i++)c=s[i],c.form===t.form&&Cn(c)}break e;case"textarea":ta(t,s.value,s.defaultValue);break e;case"select":i=s.value,i!=null&&$n(t,!!s.multiple,i,!1)}}}var Ld=!1;function Hg(t,i,s){if(Ld)return t(i,s);Ld=!0;try{var c=t(i);return c}finally{if(Ld=!1,(jo!==null||Zo!==null)&&(Bf(),jo&&(i=jo,t=Zo,Zo=jo=null,Bg(i),t)))for(i=0;i<t.length;i++)Bg(t[i])}}function mc(t,i){var s=t.stateNode;if(s===null)return null;var c=s[Tt]||null;if(c===null)return null;s=c[i];e:switch(i){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(c=!c.disabled)||(t=t.type,c=!(t==="button"||t==="input"||t==="select"||t==="textarea")),t=!c;break e;default:t=!1}if(t)return null;if(s&&typeof s!="function")throw Error(a(231,i,typeof s));return s}var Tr=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Od=!1;if(Tr)try{var _c={};Object.defineProperty(_c,"passive",{get:function(){Od=!0}}),window.addEventListener("test",_c,_c),window.removeEventListener("test",_c,_c)}catch{Od=!1}var os=null,Pd=null,Ju=null;function Gg(){if(Ju)return Ju;var t,i=Pd,s=i.length,c,h="value"in os?os.value:os.textContent,m=h.length;for(t=0;t<s&&i[t]===h[t];t++);var b=s-t;for(c=1;c<=b&&i[s-c]===h[m-c];c++);return Ju=h.slice(t,1<c?1-c:void 0)}function $u(t){var i=t.keyCode;return"charCode"in t?(t=t.charCode,t===0&&i===13&&(t=13)):t=i,t===10&&(t=13),32<=t||t===13?t:0}function ef(){return!0}function Vg(){return!1}function Hi(t){function i(s,c,h,m,b){this._reactName=s,this._targetInst=h,this.type=c,this.nativeEvent=m,this.target=b,this.currentTarget=null;for(var N in t)t.hasOwnProperty(N)&&(s=t[N],this[N]=s?s(m):m[N]);return this.isDefaultPrevented=(m.defaultPrevented!=null?m.defaultPrevented:m.returnValue===!1)?ef:Vg,this.isPropagationStopped=Vg,this}return v(i.prototype,{preventDefault:function(){this.defaultPrevented=!0;var s=this.nativeEvent;s&&(s.preventDefault?s.preventDefault():typeof s.returnValue!="unknown"&&(s.returnValue=!1),this.isDefaultPrevented=ef)},stopPropagation:function(){var s=this.nativeEvent;s&&(s.stopPropagation?s.stopPropagation():typeof s.cancelBubble!="unknown"&&(s.cancelBubble=!0),this.isPropagationStopped=ef)},persist:function(){},isPersistent:ef}),i}var eo={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(t){return t.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},tf=Hi(eo),gc=v({},eo,{view:0,detail:0}),_E=Hi(gc),Fd,zd,vc,nf=v({},gc,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Bd,button:0,buttons:0,relatedTarget:function(t){return t.relatedTarget===void 0?t.fromElement===t.srcElement?t.toElement:t.fromElement:t.relatedTarget},movementX:function(t){return"movementX"in t?t.movementX:(t!==vc&&(vc&&t.type==="mousemove"?(Fd=t.screenX-vc.screenX,zd=t.screenY-vc.screenY):zd=Fd=0,vc=t),Fd)},movementY:function(t){return"movementY"in t?t.movementY:zd}}),kg=Hi(nf),gE=v({},nf,{dataTransfer:0}),vE=Hi(gE),xE=v({},gc,{relatedTarget:0}),Id=Hi(xE),SE=v({},eo,{animationName:0,elapsedTime:0,pseudoElement:0}),yE=Hi(SE),ME=v({},eo,{clipboardData:function(t){return"clipboardData"in t?t.clipboardData:window.clipboardData}}),bE=Hi(ME),EE=v({},eo,{data:0}),Xg=Hi(EE),TE={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},AE={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},RE={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function CE(t){var i=this.nativeEvent;return i.getModifierState?i.getModifierState(t):(t=RE[t])?!!i[t]:!1}function Bd(){return CE}var wE=v({},gc,{key:function(t){if(t.key){var i=TE[t.key]||t.key;if(i!=="Unidentified")return i}return t.type==="keypress"?(t=$u(t),t===13?"Enter":String.fromCharCode(t)):t.type==="keydown"||t.type==="keyup"?AE[t.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Bd,charCode:function(t){return t.type==="keypress"?$u(t):0},keyCode:function(t){return t.type==="keydown"||t.type==="keyup"?t.keyCode:0},which:function(t){return t.type==="keypress"?$u(t):t.type==="keydown"||t.type==="keyup"?t.keyCode:0}}),DE=Hi(wE),UE=v({},nf,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Wg=Hi(UE),NE=v({},gc,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Bd}),LE=Hi(NE),OE=v({},eo,{propertyName:0,elapsedTime:0,pseudoElement:0}),PE=Hi(OE),FE=v({},nf,{deltaX:function(t){return"deltaX"in t?t.deltaX:"wheelDeltaX"in t?-t.wheelDeltaX:0},deltaY:function(t){return"deltaY"in t?t.deltaY:"wheelDeltaY"in t?-t.wheelDeltaY:"wheelDelta"in t?-t.wheelDelta:0},deltaZ:0,deltaMode:0}),zE=Hi(FE),IE=v({},eo,{newState:0,oldState:0}),BE=Hi(IE),HE=[9,13,27,32],Hd=Tr&&"CompositionEvent"in window,xc=null;Tr&&"documentMode"in document&&(xc=document.documentMode);var GE=Tr&&"TextEvent"in window&&!xc,qg=Tr&&(!Hd||xc&&8<xc&&11>=xc),Yg=" ",jg=!1;function Zg(t,i){switch(t){case"keyup":return HE.indexOf(i.keyCode)!==-1;case"keydown":return i.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Kg(t){return t=t.detail,typeof t=="object"&&"data"in t?t.data:null}var Ko=!1;function VE(t,i){switch(t){case"compositionend":return Kg(i);case"keypress":return i.which!==32?null:(jg=!0,Yg);case"textInput":return t=i.data,t===Yg&&jg?null:t;default:return null}}function kE(t,i){if(Ko)return t==="compositionend"||!Hd&&Zg(t,i)?(t=Gg(),Ju=Pd=os=null,Ko=!1,t):null;switch(t){case"paste":return null;case"keypress":if(!(i.ctrlKey||i.altKey||i.metaKey)||i.ctrlKey&&i.altKey){if(i.char&&1<i.char.length)return i.char;if(i.which)return String.fromCharCode(i.which)}return null;case"compositionend":return qg&&i.locale!=="ko"?null:i.data;default:return null}}var XE={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Qg(t){var i=t&&t.nodeName&&t.nodeName.toLowerCase();return i==="input"?!!XE[t.type]:i==="textarea"}function Jg(t,i,s,c){jo?Zo?Zo.push(c):Zo=[c]:jo=c,i=qf(i,"onChange"),0<i.length&&(s=new tf("onChange","change",null,s,c),t.push({event:s,listeners:i}))}var Sc=null,yc=null;function WE(t){OS(t,0)}function af(t){var i=Ea(t);if(Cn(i))return t}function $g(t,i){if(t==="change")return i}var ev=!1;if(Tr){var Gd;if(Tr){var Vd="oninput"in document;if(!Vd){var tv=document.createElement("div");tv.setAttribute("oninput","return;"),Vd=typeof tv.oninput=="function"}Gd=Vd}else Gd=!1;ev=Gd&&(!document.documentMode||9<document.documentMode)}function nv(){Sc&&(Sc.detachEvent("onpropertychange",iv),yc=Sc=null)}function iv(t){if(t.propertyName==="value"&&af(yc)){var i=[];Jg(i,yc,t,Nd(t)),Hg(WE,i)}}function qE(t,i,s){t==="focusin"?(nv(),Sc=i,yc=s,Sc.attachEvent("onpropertychange",iv)):t==="focusout"&&nv()}function YE(t){if(t==="selectionchange"||t==="keyup"||t==="keydown")return af(yc)}function jE(t,i){if(t==="click")return af(i)}function ZE(t,i){if(t==="input"||t==="change")return af(i)}function KE(t,i){return t===i&&(t!==0||1/t===1/i)||t!==t&&i!==i}var ia=typeof Object.is=="function"?Object.is:KE;function Mc(t,i){if(ia(t,i))return!0;if(typeof t!="object"||t===null||typeof i!="object"||i===null)return!1;var s=Object.keys(t),c=Object.keys(i);if(s.length!==c.length)return!1;for(c=0;c<s.length;c++){var h=s[c];if(!mn.call(i,h)||!ia(t[h],i[h]))return!1}return!0}function av(t){for(;t&&t.firstChild;)t=t.firstChild;return t}function rv(t,i){var s=av(t);t=0;for(var c;s;){if(s.nodeType===3){if(c=t+s.textContent.length,t<=i&&c>=i)return{node:s,offset:i-t};t=c}e:{for(;s;){if(s.nextSibling){s=s.nextSibling;break e}s=s.parentNode}s=void 0}s=av(s)}}function sv(t,i){return t&&i?t===i?!0:t&&t.nodeType===3?!1:i&&i.nodeType===3?sv(t,i.parentNode):"contains"in t?t.contains(i):t.compareDocumentPosition?!!(t.compareDocumentPosition(i)&16):!1:!1}function ov(t){t=t!=null&&t.ownerDocument!=null&&t.ownerDocument.defaultView!=null?t.ownerDocument.defaultView:window;for(var i=gn(t.document);i instanceof t.HTMLIFrameElement;){try{var s=typeof i.contentWindow.location.href=="string"}catch{s=!1}if(s)t=i.contentWindow;else break;i=gn(t.document)}return i}function kd(t){var i=t&&t.nodeName&&t.nodeName.toLowerCase();return i&&(i==="input"&&(t.type==="text"||t.type==="search"||t.type==="tel"||t.type==="url"||t.type==="password")||i==="textarea"||t.contentEditable==="true")}var QE=Tr&&"documentMode"in document&&11>=document.documentMode,Qo=null,Xd=null,bc=null,Wd=!1;function lv(t,i,s){var c=s.window===s?s.document:s.nodeType===9?s:s.ownerDocument;Wd||Qo==null||Qo!==gn(c)||(c=Qo,"selectionStart"in c&&kd(c)?c={start:c.selectionStart,end:c.selectionEnd}:(c=(c.ownerDocument&&c.ownerDocument.defaultView||window).getSelection(),c={anchorNode:c.anchorNode,anchorOffset:c.anchorOffset,focusNode:c.focusNode,focusOffset:c.focusOffset}),bc&&Mc(bc,c)||(bc=c,c=qf(Xd,"onSelect"),0<c.length&&(i=new tf("onSelect","select",null,i,s),t.push({event:i,listeners:c}),i.target=Qo)))}function to(t,i){var s={};return s[t.toLowerCase()]=i.toLowerCase(),s["Webkit"+t]="webkit"+i,s["Moz"+t]="moz"+i,s}var Jo={animationend:to("Animation","AnimationEnd"),animationiteration:to("Animation","AnimationIteration"),animationstart:to("Animation","AnimationStart"),transitionrun:to("Transition","TransitionRun"),transitionstart:to("Transition","TransitionStart"),transitioncancel:to("Transition","TransitionCancel"),transitionend:to("Transition","TransitionEnd")},qd={},cv={};Tr&&(cv=document.createElement("div").style,"AnimationEvent"in window||(delete Jo.animationend.animation,delete Jo.animationiteration.animation,delete Jo.animationstart.animation),"TransitionEvent"in window||delete Jo.transitionend.transition);function no(t){if(qd[t])return qd[t];if(!Jo[t])return t;var i=Jo[t],s;for(s in i)if(i.hasOwnProperty(s)&&s in cv)return qd[t]=i[s];return t}var uv=no("animationend"),fv=no("animationiteration"),hv=no("animationstart"),JE=no("transitionrun"),$E=no("transitionstart"),eT=no("transitioncancel"),dv=no("transitionend"),pv=new Map,Yd="abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");Yd.push("scrollEnd");function Wa(t,i){pv.set(t,i),Z(i,[t])}var rf=typeof reportError=="function"?reportError:function(t){if(typeof window=="object"&&typeof window.ErrorEvent=="function"){var i=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:typeof t=="object"&&t!==null&&typeof t.message=="string"?String(t.message):String(t),error:t});if(!window.dispatchEvent(i))return}else if(typeof process=="object"&&typeof process.emit=="function"){process.emit("uncaughtException",t);return}console.error(t)},Ta=[],$o=0,jd=0;function sf(){for(var t=$o,i=jd=$o=0;i<t;){var s=Ta[i];Ta[i++]=null;var c=Ta[i];Ta[i++]=null;var h=Ta[i];Ta[i++]=null;var m=Ta[i];if(Ta[i++]=null,c!==null&&h!==null){var b=c.pending;b===null?h.next=h:(h.next=b.next,b.next=h),c.pending=h}m!==0&&mv(s,h,m)}}function of(t,i,s,c){Ta[$o++]=t,Ta[$o++]=i,Ta[$o++]=s,Ta[$o++]=c,jd|=c,t.lanes|=c,t=t.alternate,t!==null&&(t.lanes|=c)}function Zd(t,i,s,c){return of(t,i,s,c),lf(t)}function io(t,i){return of(t,null,null,i),lf(t)}function mv(t,i,s){t.lanes|=s;var c=t.alternate;c!==null&&(c.lanes|=s);for(var h=!1,m=t.return;m!==null;)m.childLanes|=s,c=m.alternate,c!==null&&(c.childLanes|=s),m.tag===22&&(t=m.stateNode,t===null||t._visibility&1||(h=!0)),t=m,m=m.return;return t.tag===3?(m=t.stateNode,h&&i!==null&&(h=31-He(s),t=m.hiddenUpdates,c=t[h],c===null?t[h]=[i]:c.push(i),i.lane=s|536870912),m):null}function lf(t){if(50<Wc)throw Wc=0,am=null,Error(a(185));for(var i=t.return;i!==null;)t=i,i=t.return;return t.tag===3?t.stateNode:null}var el={};function tT(t,i,s,c){this.tag=t,this.key=s,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=i,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=c,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function aa(t,i,s,c){return new tT(t,i,s,c)}function Kd(t){return t=t.prototype,!(!t||!t.isReactComponent)}function Ar(t,i){var s=t.alternate;return s===null?(s=aa(t.tag,i,t.key,t.mode),s.elementType=t.elementType,s.type=t.type,s.stateNode=t.stateNode,s.alternate=t,t.alternate=s):(s.pendingProps=i,s.type=t.type,s.flags=0,s.subtreeFlags=0,s.deletions=null),s.flags=t.flags&65011712,s.childLanes=t.childLanes,s.lanes=t.lanes,s.child=t.child,s.memoizedProps=t.memoizedProps,s.memoizedState=t.memoizedState,s.updateQueue=t.updateQueue,i=t.dependencies,s.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext},s.sibling=t.sibling,s.index=t.index,s.ref=t.ref,s.refCleanup=t.refCleanup,s}function _v(t,i){t.flags&=65011714;var s=t.alternate;return s===null?(t.childLanes=0,t.lanes=i,t.child=null,t.subtreeFlags=0,t.memoizedProps=null,t.memoizedState=null,t.updateQueue=null,t.dependencies=null,t.stateNode=null):(t.childLanes=s.childLanes,t.lanes=s.lanes,t.child=s.child,t.subtreeFlags=0,t.deletions=null,t.memoizedProps=s.memoizedProps,t.memoizedState=s.memoizedState,t.updateQueue=s.updateQueue,t.type=s.type,i=s.dependencies,t.dependencies=i===null?null:{lanes:i.lanes,firstContext:i.firstContext}),t}function cf(t,i,s,c,h,m){var b=0;if(c=t,typeof t=="function")Kd(t)&&(b=1);else if(typeof t=="string")b=sA(t,s,be.current)?26:t==="html"||t==="head"||t==="body"?27:5;else e:switch(t){case L:return t=aa(31,s,i,h),t.elementType=L,t.lanes=m,t;case E:return ao(s.children,h,m,i);case S:b=8,h|=24;break;case y:return t=aa(12,s,i,h|2),t.elementType=y,t.lanes=m,t;case F:return t=aa(13,s,i,h),t.elementType=F,t.lanes=m,t;case O:return t=aa(19,s,i,h),t.elementType=O,t.lanes=m,t;default:if(typeof t=="object"&&t!==null)switch(t.$$typeof){case U:b=10;break e;case R:b=9;break e;case C:b=11;break e;case D:b=14;break e;case T:b=16,c=null;break e}b=29,s=Error(a(130,t===null?"null":typeof t,"")),c=null}return i=aa(b,s,i,h),i.elementType=t,i.type=c,i.lanes=m,i}function ao(t,i,s,c){return t=aa(7,t,c,i),t.lanes=s,t}function Qd(t,i,s){return t=aa(6,t,null,i),t.lanes=s,t}function gv(t){var i=aa(18,null,null,0);return i.stateNode=t,i}function Jd(t,i,s){return i=aa(4,t.children!==null?t.children:[],t.key,i),i.lanes=s,i.stateNode={containerInfo:t.containerInfo,pendingChildren:null,implementation:t.implementation},i}var vv=new WeakMap;function Aa(t,i){if(typeof t=="object"&&t!==null){var s=vv.get(t);return s!==void 0?s:(i={value:t,source:i,stack:Dt(i)},vv.set(t,i),i)}return{value:t,source:i,stack:Dt(i)}}var tl=[],nl=0,uf=null,Ec=0,Ra=[],Ca=0,ls=null,ar=1,rr="";function Rr(t,i){tl[nl++]=Ec,tl[nl++]=uf,uf=t,Ec=i}function xv(t,i,s){Ra[Ca++]=ar,Ra[Ca++]=rr,Ra[Ca++]=ls,ls=t;var c=ar;t=rr;var h=32-He(c)-1;c&=~(1<<h),s+=1;var m=32-He(i)+h;if(30<m){var b=h-h%5;m=(c&(1<<b)-1).toString(32),c>>=b,h-=b,ar=1<<32-He(i)+h|s<<h|c,rr=m+t}else ar=1<<m|s<<h|c,rr=t}function $d(t){t.return!==null&&(Rr(t,1),xv(t,1,0))}function ep(t){for(;t===uf;)uf=tl[--nl],tl[nl]=null,Ec=tl[--nl],tl[nl]=null;for(;t===ls;)ls=Ra[--Ca],Ra[Ca]=null,rr=Ra[--Ca],Ra[Ca]=null,ar=Ra[--Ca],Ra[Ca]=null}function Sv(t,i){Ra[Ca++]=ar,Ra[Ca++]=rr,Ra[Ca++]=ls,ar=i.id,rr=i.overflow,ls=t}var fi=null,Tn=null,kt=!1,cs=null,wa=!1,tp=Error(a(519));function us(t){var i=Error(a(418,1<arguments.length&&arguments[1]!==void 0&&arguments[1]?"text":"HTML",""));throw Tc(Aa(i,t)),tp}function yv(t){var i=t.stateNode,s=t.type,c=t.memoizedProps;switch(i[St]=t,i[Tt]=c,s){case"dialog":Ht("cancel",i),Ht("close",i);break;case"iframe":case"object":case"embed":Ht("load",i);break;case"video":case"audio":for(s=0;s<Yc.length;s++)Ht(Yc[s],i);break;case"source":Ht("error",i);break;case"img":case"image":case"link":Ht("error",i),Ht("load",i);break;case"details":Ht("toggle",i);break;case"input":Ht("invalid",i),Si(i,c.value,c.defaultValue,c.checked,c.defaultChecked,c.type,c.name,!0);break;case"select":Ht("invalid",i);break;case"textarea":Ht("invalid",i),ka(i,c.value,c.defaultValue,c.children)}s=c.children,typeof s!="string"&&typeof s!="number"&&typeof s!="bigint"||i.textContent===""+s||c.suppressHydrationWarning===!0||IS(i.textContent,s)?(c.popover!=null&&(Ht("beforetoggle",i),Ht("toggle",i)),c.onScroll!=null&&Ht("scroll",i),c.onScrollEnd!=null&&Ht("scrollend",i),c.onClick!=null&&(i.onclick=Er),i=!0):i=!1,i||us(t,!0)}function Mv(t){for(fi=t.return;fi;)switch(fi.tag){case 5:case 31:case 13:wa=!1;return;case 27:case 3:wa=!0;return;default:fi=fi.return}}function il(t){if(t!==fi)return!1;if(!kt)return Mv(t),kt=!0,!1;var i=t.tag,s;if((s=i!==3&&i!==27)&&((s=i===5)&&(s=t.type,s=!(s!=="form"&&s!=="button")||xm(t.type,t.memoizedProps)),s=!s),s&&Tn&&us(t),Mv(t),i===13){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(a(317));Tn=YS(t)}else if(i===31){if(t=t.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(a(317));Tn=YS(t)}else i===27?(i=Tn,Es(t.type)?(t=Em,Em=null,Tn=t):Tn=i):Tn=fi?Ua(t.stateNode.nextSibling):null;return!0}function ro(){Tn=fi=null,kt=!1}function np(){var t=cs;return t!==null&&(Xi===null?Xi=t:Xi.push.apply(Xi,t),cs=null),t}function Tc(t){cs===null?cs=[t]:cs.push(t)}var ip=I(null),so=null,Cr=null;function fs(t,i,s){Se(ip,i._currentValue),i._currentValue=s}function wr(t){t._currentValue=ip.current,K(ip)}function ap(t,i,s){for(;t!==null;){var c=t.alternate;if((t.childLanes&i)!==i?(t.childLanes|=i,c!==null&&(c.childLanes|=i)):c!==null&&(c.childLanes&i)!==i&&(c.childLanes|=i),t===s)break;t=t.return}}function rp(t,i,s,c){var h=t.child;for(h!==null&&(h.return=t);h!==null;){var m=h.dependencies;if(m!==null){var b=h.child;m=m.firstContext;e:for(;m!==null;){var N=m;m=h;for(var X=0;X<i.length;X++)if(N.context===i[X]){m.lanes|=s,N=m.alternate,N!==null&&(N.lanes|=s),ap(m.return,s,t),c||(b=null);break e}m=N.next}}else if(h.tag===18){if(b=h.return,b===null)throw Error(a(341));b.lanes|=s,m=b.alternate,m!==null&&(m.lanes|=s),ap(b,s,t),b=null}else b=h.child;if(b!==null)b.return=h;else for(b=h;b!==null;){if(b===t){b=null;break}if(h=b.sibling,h!==null){h.return=b.return,b=h;break}b=b.return}h=b}}function al(t,i,s,c){t=null;for(var h=i,m=!1;h!==null;){if(!m){if((h.flags&524288)!==0)m=!0;else if((h.flags&262144)!==0)break}if(h.tag===10){var b=h.alternate;if(b===null)throw Error(a(387));if(b=b.memoizedProps,b!==null){var N=h.type;ia(h.pendingProps.value,b.value)||(t!==null?t.push(N):t=[N])}}else if(h===xe.current){if(b=h.alternate,b===null)throw Error(a(387));b.memoizedState.memoizedState!==h.memoizedState.memoizedState&&(t!==null?t.push(Jc):t=[Jc])}h=h.return}t!==null&&rp(i,t,s,c),i.flags|=262144}function ff(t){for(t=t.firstContext;t!==null;){if(!ia(t.context._currentValue,t.memoizedValue))return!0;t=t.next}return!1}function oo(t){so=t,Cr=null,t=t.dependencies,t!==null&&(t.firstContext=null)}function hi(t){return bv(so,t)}function hf(t,i){return so===null&&oo(t),bv(t,i)}function bv(t,i){var s=i._currentValue;if(i={context:i,memoizedValue:s,next:null},Cr===null){if(t===null)throw Error(a(308));Cr=i,t.dependencies={lanes:0,firstContext:i},t.flags|=524288}else Cr=Cr.next=i;return s}var nT=typeof AbortController<"u"?AbortController:function(){var t=[],i=this.signal={aborted:!1,addEventListener:function(s,c){t.push(c)}};this.abort=function(){i.aborted=!0,t.forEach(function(s){return s()})}},iT=o.unstable_scheduleCallback,aT=o.unstable_NormalPriority,qn={$$typeof:U,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0};function sp(){return{controller:new nT,data:new Map,refCount:0}}function Ac(t){t.refCount--,t.refCount===0&&iT(aT,function(){t.controller.abort()})}var Rc=null,op=0,rl=0,sl=null;function rT(t,i){if(Rc===null){var s=Rc=[];op=0,rl=um(),sl={status:"pending",value:void 0,then:function(c){s.push(c)}}}return op++,i.then(Ev,Ev),i}function Ev(){if(--op===0&&Rc!==null){sl!==null&&(sl.status="fulfilled");var t=Rc;Rc=null,rl=0,sl=null;for(var i=0;i<t.length;i++)(0,t[i])()}}function sT(t,i){var s=[],c={status:"pending",value:null,reason:null,then:function(h){s.push(h)}};return t.then(function(){c.status="fulfilled",c.value=i;for(var h=0;h<s.length;h++)(0,s[h])(i)},function(h){for(c.status="rejected",c.reason=h,h=0;h<s.length;h++)(0,s[h])(void 0)}),c}var Tv=z.S;z.S=function(t,i){lS=Le(),typeof i=="object"&&i!==null&&typeof i.then=="function"&&rT(t,i),Tv!==null&&Tv(t,i)};var lo=I(null);function lp(){var t=lo.current;return t!==null?t:vn.pooledCache}function df(t,i){i===null?Se(lo,lo.current):Se(lo,i.pool)}function Av(){var t=lp();return t===null?null:{parent:qn._currentValue,pool:t}}var ol=Error(a(460)),cp=Error(a(474)),pf=Error(a(542)),mf={then:function(){}};function Rv(t){return t=t.status,t==="fulfilled"||t==="rejected"}function Cv(t,i,s){switch(s=t[s],s===void 0?t.push(i):s!==i&&(i.then(Er,Er),i=s),i.status){case"fulfilled":return i.value;case"rejected":throw t=i.reason,Dv(t),t;default:if(typeof i.status=="string")i.then(Er,Er);else{if(t=vn,t!==null&&100<t.shellSuspendCounter)throw Error(a(482));t=i,t.status="pending",t.then(function(c){if(i.status==="pending"){var h=i;h.status="fulfilled",h.value=c}},function(c){if(i.status==="pending"){var h=i;h.status="rejected",h.reason=c}})}switch(i.status){case"fulfilled":return i.value;case"rejected":throw t=i.reason,Dv(t),t}throw uo=i,ol}}function co(t){try{var i=t._init;return i(t._payload)}catch(s){throw s!==null&&typeof s=="object"&&typeof s.then=="function"?(uo=s,ol):s}}var uo=null;function wv(){if(uo===null)throw Error(a(459));var t=uo;return uo=null,t}function Dv(t){if(t===ol||t===pf)throw Error(a(483))}var ll=null,Cc=0;function _f(t){var i=Cc;return Cc+=1,ll===null&&(ll=[]),Cv(ll,t,i)}function wc(t,i){i=i.props.ref,t.ref=i!==void 0?i:null}function gf(t,i){throw i.$$typeof===g?Error(a(525)):(t=Object.prototype.toString.call(i),Error(a(31,t==="[object Object]"?"object with keys {"+Object.keys(i).join(", ")+"}":t)))}function Uv(t){function i($,Y){if(t){var re=$.deletions;re===null?($.deletions=[Y],$.flags|=16):re.push(Y)}}function s($,Y){if(!t)return null;for(;Y!==null;)i($,Y),Y=Y.sibling;return null}function c($){for(var Y=new Map;$!==null;)$.key!==null?Y.set($.key,$):Y.set($.index,$),$=$.sibling;return Y}function h($,Y){return $=Ar($,Y),$.index=0,$.sibling=null,$}function m($,Y,re){return $.index=re,t?(re=$.alternate,re!==null?(re=re.index,re<Y?($.flags|=67108866,Y):re):($.flags|=67108866,Y)):($.flags|=1048576,Y)}function b($){return t&&$.alternate===null&&($.flags|=67108866),$}function N($,Y,re,ye){return Y===null||Y.tag!==6?(Y=Qd(re,$.mode,ye),Y.return=$,Y):(Y=h(Y,re),Y.return=$,Y)}function X($,Y,re,ye){var ct=re.type;return ct===E?ve($,Y,re.props.children,ye,re.key):Y!==null&&(Y.elementType===ct||typeof ct=="object"&&ct!==null&&ct.$$typeof===T&&co(ct)===Y.type)?(Y=h(Y,re.props),wc(Y,re),Y.return=$,Y):(Y=cf(re.type,re.key,re.props,null,$.mode,ye),wc(Y,re),Y.return=$,Y)}function oe($,Y,re,ye){return Y===null||Y.tag!==4||Y.stateNode.containerInfo!==re.containerInfo||Y.stateNode.implementation!==re.implementation?(Y=Jd(re,$.mode,ye),Y.return=$,Y):(Y=h(Y,re.children||[]),Y.return=$,Y)}function ve($,Y,re,ye,ct){return Y===null||Y.tag!==7?(Y=ao(re,$.mode,ye,ct),Y.return=$,Y):(Y=h(Y,re),Y.return=$,Y)}function Me($,Y,re){if(typeof Y=="string"&&Y!==""||typeof Y=="number"||typeof Y=="bigint")return Y=Qd(""+Y,$.mode,re),Y.return=$,Y;if(typeof Y=="object"&&Y!==null){switch(Y.$$typeof){case x:return re=cf(Y.type,Y.key,Y.props,null,$.mode,re),wc(re,Y),re.return=$,re;case M:return Y=Jd(Y,$.mode,re),Y.return=$,Y;case T:return Y=co(Y),Me($,Y,re)}if(W(Y)||k(Y))return Y=ao(Y,$.mode,re,null),Y.return=$,Y;if(typeof Y.then=="function")return Me($,_f(Y),re);if(Y.$$typeof===U)return Me($,hf($,Y),re);gf($,Y)}return null}function ce($,Y,re,ye){var ct=Y!==null?Y.key:null;if(typeof re=="string"&&re!==""||typeof re=="number"||typeof re=="bigint")return ct!==null?null:N($,Y,""+re,ye);if(typeof re=="object"&&re!==null){switch(re.$$typeof){case x:return re.key===ct?X($,Y,re,ye):null;case M:return re.key===ct?oe($,Y,re,ye):null;case T:return re=co(re),ce($,Y,re,ye)}if(W(re)||k(re))return ct!==null?null:ve($,Y,re,ye,null);if(typeof re.then=="function")return ce($,Y,_f(re),ye);if(re.$$typeof===U)return ce($,Y,hf($,re),ye);gf($,re)}return null}function he($,Y,re,ye,ct){if(typeof ye=="string"&&ye!==""||typeof ye=="number"||typeof ye=="bigint")return $=$.get(re)||null,N(Y,$,""+ye,ct);if(typeof ye=="object"&&ye!==null){switch(ye.$$typeof){case x:return $=$.get(ye.key===null?re:ye.key)||null,X(Y,$,ye,ct);case M:return $=$.get(ye.key===null?re:ye.key)||null,oe(Y,$,ye,ct);case T:return ye=co(ye),he($,Y,re,ye,ct)}if(W(ye)||k(ye))return $=$.get(re)||null,ve(Y,$,ye,ct,null);if(typeof ye.then=="function")return he($,Y,re,_f(ye),ct);if(ye.$$typeof===U)return he($,Y,re,hf(Y,ye),ct);gf(Y,ye)}return null}function $e($,Y,re,ye){for(var ct=null,Kt=null,tt=Y,wt=Y=0,Vt=null;tt!==null&&wt<re.length;wt++){tt.index>wt?(Vt=tt,tt=null):Vt=tt.sibling;var Qt=ce($,tt,re[wt],ye);if(Qt===null){tt===null&&(tt=Vt);break}t&&tt&&Qt.alternate===null&&i($,tt),Y=m(Qt,Y,wt),Kt===null?ct=Qt:Kt.sibling=Qt,Kt=Qt,tt=Vt}if(wt===re.length)return s($,tt),kt&&Rr($,wt),ct;if(tt===null){for(;wt<re.length;wt++)tt=Me($,re[wt],ye),tt!==null&&(Y=m(tt,Y,wt),Kt===null?ct=tt:Kt.sibling=tt,Kt=tt);return kt&&Rr($,wt),ct}for(tt=c(tt);wt<re.length;wt++)Vt=he(tt,$,wt,re[wt],ye),Vt!==null&&(t&&Vt.alternate!==null&&tt.delete(Vt.key===null?wt:Vt.key),Y=m(Vt,Y,wt),Kt===null?ct=Vt:Kt.sibling=Vt,Kt=Vt);return t&&tt.forEach(function(ws){return i($,ws)}),kt&&Rr($,wt),ct}function ht($,Y,re,ye){if(re==null)throw Error(a(151));for(var ct=null,Kt=null,tt=Y,wt=Y=0,Vt=null,Qt=re.next();tt!==null&&!Qt.done;wt++,Qt=re.next()){tt.index>wt?(Vt=tt,tt=null):Vt=tt.sibling;var ws=ce($,tt,Qt.value,ye);if(ws===null){tt===null&&(tt=Vt);break}t&&tt&&ws.alternate===null&&i($,tt),Y=m(ws,Y,wt),Kt===null?ct=ws:Kt.sibling=ws,Kt=ws,tt=Vt}if(Qt.done)return s($,tt),kt&&Rr($,wt),ct;if(tt===null){for(;!Qt.done;wt++,Qt=re.next())Qt=Me($,Qt.value,ye),Qt!==null&&(Y=m(Qt,Y,wt),Kt===null?ct=Qt:Kt.sibling=Qt,Kt=Qt);return kt&&Rr($,wt),ct}for(tt=c(tt);!Qt.done;wt++,Qt=re.next())Qt=he(tt,$,wt,Qt.value,ye),Qt!==null&&(t&&Qt.alternate!==null&&tt.delete(Qt.key===null?wt:Qt.key),Y=m(Qt,Y,wt),Kt===null?ct=Qt:Kt.sibling=Qt,Kt=Qt);return t&&tt.forEach(function(gA){return i($,gA)}),kt&&Rr($,wt),ct}function dn($,Y,re,ye){if(typeof re=="object"&&re!==null&&re.type===E&&re.key===null&&(re=re.props.children),typeof re=="object"&&re!==null){switch(re.$$typeof){case x:e:{for(var ct=re.key;Y!==null;){if(Y.key===ct){if(ct=re.type,ct===E){if(Y.tag===7){s($,Y.sibling),ye=h(Y,re.props.children),ye.return=$,$=ye;break e}}else if(Y.elementType===ct||typeof ct=="object"&&ct!==null&&ct.$$typeof===T&&co(ct)===Y.type){s($,Y.sibling),ye=h(Y,re.props),wc(ye,re),ye.return=$,$=ye;break e}s($,Y);break}else i($,Y);Y=Y.sibling}re.type===E?(ye=ao(re.props.children,$.mode,ye,re.key),ye.return=$,$=ye):(ye=cf(re.type,re.key,re.props,null,$.mode,ye),wc(ye,re),ye.return=$,$=ye)}return b($);case M:e:{for(ct=re.key;Y!==null;){if(Y.key===ct)if(Y.tag===4&&Y.stateNode.containerInfo===re.containerInfo&&Y.stateNode.implementation===re.implementation){s($,Y.sibling),ye=h(Y,re.children||[]),ye.return=$,$=ye;break e}else{s($,Y);break}else i($,Y);Y=Y.sibling}ye=Jd(re,$.mode,ye),ye.return=$,$=ye}return b($);case T:return re=co(re),dn($,Y,re,ye)}if(W(re))return $e($,Y,re,ye);if(k(re)){if(ct=k(re),typeof ct!="function")throw Error(a(150));return re=ct.call(re),ht($,Y,re,ye)}if(typeof re.then=="function")return dn($,Y,_f(re),ye);if(re.$$typeof===U)return dn($,Y,hf($,re),ye);gf($,re)}return typeof re=="string"&&re!==""||typeof re=="number"||typeof re=="bigint"?(re=""+re,Y!==null&&Y.tag===6?(s($,Y.sibling),ye=h(Y,re),ye.return=$,$=ye):(s($,Y),ye=Qd(re,$.mode,ye),ye.return=$,$=ye),b($)):s($,Y)}return function($,Y,re,ye){try{Cc=0;var ct=dn($,Y,re,ye);return ll=null,ct}catch(tt){if(tt===ol||tt===pf)throw tt;var Kt=aa(29,tt,null,$.mode);return Kt.lanes=ye,Kt.return=$,Kt}}}var fo=Uv(!0),Nv=Uv(!1),hs=!1;function up(t){t.updateQueue={baseState:t.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}}function fp(t,i){t=t.updateQueue,i.updateQueue===t&&(i.updateQueue={baseState:t.baseState,firstBaseUpdate:t.firstBaseUpdate,lastBaseUpdate:t.lastBaseUpdate,shared:t.shared,callbacks:null})}function ds(t){return{lane:t,tag:0,payload:null,callback:null,next:null}}function ps(t,i,s){var c=t.updateQueue;if(c===null)return null;if(c=c.shared,($t&2)!==0){var h=c.pending;return h===null?i.next=i:(i.next=h.next,h.next=i),c.pending=i,i=lf(t),mv(t,null,s),i}return of(t,c,i,s),lf(t)}function Dc(t,i,s){if(i=i.updateQueue,i!==null&&(i=i.shared,(s&4194048)!==0)){var c=i.lanes;c&=t.pendingLanes,s|=c,i.lanes=s,rt(t,s)}}function hp(t,i){var s=t.updateQueue,c=t.alternate;if(c!==null&&(c=c.updateQueue,s===c)){var h=null,m=null;if(s=s.firstBaseUpdate,s!==null){do{var b={lane:s.lane,tag:s.tag,payload:s.payload,callback:null,next:null};m===null?h=m=b:m=m.next=b,s=s.next}while(s!==null);m===null?h=m=i:m=m.next=i}else h=m=i;s={baseState:c.baseState,firstBaseUpdate:h,lastBaseUpdate:m,shared:c.shared,callbacks:c.callbacks},t.updateQueue=s;return}t=s.lastBaseUpdate,t===null?s.firstBaseUpdate=i:t.next=i,s.lastBaseUpdate=i}var dp=!1;function Uc(){if(dp){var t=sl;if(t!==null)throw t}}function Nc(t,i,s,c){dp=!1;var h=t.updateQueue;hs=!1;var m=h.firstBaseUpdate,b=h.lastBaseUpdate,N=h.shared.pending;if(N!==null){h.shared.pending=null;var X=N,oe=X.next;X.next=null,b===null?m=oe:b.next=oe,b=X;var ve=t.alternate;ve!==null&&(ve=ve.updateQueue,N=ve.lastBaseUpdate,N!==b&&(N===null?ve.firstBaseUpdate=oe:N.next=oe,ve.lastBaseUpdate=X))}if(m!==null){var Me=h.baseState;b=0,ve=oe=X=null,N=m;do{var ce=N.lane&-536870913,he=ce!==N.lane;if(he?(Gt&ce)===ce:(c&ce)===ce){ce!==0&&ce===rl&&(dp=!0),ve!==null&&(ve=ve.next={lane:0,tag:N.tag,payload:N.payload,callback:null,next:null});e:{var $e=t,ht=N;ce=i;var dn=s;switch(ht.tag){case 1:if($e=ht.payload,typeof $e=="function"){Me=$e.call(dn,Me,ce);break e}Me=$e;break e;case 3:$e.flags=$e.flags&-65537|128;case 0:if($e=ht.payload,ce=typeof $e=="function"?$e.call(dn,Me,ce):$e,ce==null)break e;Me=v({},Me,ce);break e;case 2:hs=!0}}ce=N.callback,ce!==null&&(t.flags|=64,he&&(t.flags|=8192),he=h.callbacks,he===null?h.callbacks=[ce]:he.push(ce))}else he={lane:ce,tag:N.tag,payload:N.payload,callback:N.callback,next:null},ve===null?(oe=ve=he,X=Me):ve=ve.next=he,b|=ce;if(N=N.next,N===null){if(N=h.shared.pending,N===null)break;he=N,N=he.next,he.next=null,h.lastBaseUpdate=he,h.shared.pending=null}}while(!0);ve===null&&(X=Me),h.baseState=X,h.firstBaseUpdate=oe,h.lastBaseUpdate=ve,m===null&&(h.shared.lanes=0),xs|=b,t.lanes=b,t.memoizedState=Me}}function Lv(t,i){if(typeof t!="function")throw Error(a(191,t));t.call(i)}function Ov(t,i){var s=t.callbacks;if(s!==null)for(t.callbacks=null,t=0;t<s.length;t++)Lv(s[t],i)}var cl=I(null),vf=I(0);function Pv(t,i){t=Ir,Se(vf,t),Se(cl,i),Ir=t|i.baseLanes}function pp(){Se(vf,Ir),Se(cl,cl.current)}function mp(){Ir=vf.current,K(cl),K(vf)}var ra=I(null),Da=null;function ms(t){var i=t.alternate;Se(Bn,Bn.current&1),Se(ra,t),Da===null&&(i===null||cl.current!==null||i.memoizedState!==null)&&(Da=t)}function _p(t){Se(Bn,Bn.current),Se(ra,t),Da===null&&(Da=t)}function Fv(t){t.tag===22?(Se(Bn,Bn.current),Se(ra,t),Da===null&&(Da=t)):_s()}function _s(){Se(Bn,Bn.current),Se(ra,ra.current)}function sa(t){K(ra),Da===t&&(Da=null),K(Bn)}var Bn=I(0);function xf(t){for(var i=t;i!==null;){if(i.tag===13){var s=i.memoizedState;if(s!==null&&(s=s.dehydrated,s===null||Mm(s)||bm(s)))return i}else if(i.tag===19&&(i.memoizedProps.revealOrder==="forwards"||i.memoizedProps.revealOrder==="backwards"||i.memoizedProps.revealOrder==="unstable_legacy-backwards"||i.memoizedProps.revealOrder==="together")){if((i.flags&128)!==0)return i}else if(i.child!==null){i.child.return=i,i=i.child;continue}if(i===t)break;for(;i.sibling===null;){if(i.return===null||i.return===t)return null;i=i.return}i.sibling.return=i.return,i=i.sibling}return null}var Dr=0,Rt=null,fn=null,Yn=null,Sf=!1,ul=!1,ho=!1,yf=0,Lc=0,fl=null,oT=0;function Fn(){throw Error(a(321))}function gp(t,i){if(i===null)return!1;for(var s=0;s<i.length&&s<t.length;s++)if(!ia(t[s],i[s]))return!1;return!0}function vp(t,i,s,c,h,m){return Dr=m,Rt=i,i.memoizedState=null,i.updateQueue=null,i.lanes=0,z.H=t===null||t.memoizedState===null?xx:Lp,ho=!1,m=s(c,h),ho=!1,ul&&(m=Iv(i,s,c,h)),zv(t),m}function zv(t){z.H=Fc;var i=fn!==null&&fn.next!==null;if(Dr=0,Yn=fn=Rt=null,Sf=!1,Lc=0,fl=null,i)throw Error(a(300));t===null||jn||(t=t.dependencies,t!==null&&ff(t)&&(jn=!0))}function Iv(t,i,s,c){Rt=t;var h=0;do{if(ul&&(fl=null),Lc=0,ul=!1,25<=h)throw Error(a(301));if(h+=1,Yn=fn=null,t.updateQueue!=null){var m=t.updateQueue;m.lastEffect=null,m.events=null,m.stores=null,m.memoCache!=null&&(m.memoCache.index=0)}z.H=Sx,m=i(s,c)}while(ul);return m}function lT(){var t=z.H,i=t.useState()[0];return i=typeof i.then=="function"?Oc(i):i,t=t.useState()[0],(fn!==null?fn.memoizedState:null)!==t&&(Rt.flags|=1024),i}function xp(){var t=yf!==0;return yf=0,t}function Sp(t,i,s){i.updateQueue=t.updateQueue,i.flags&=-2053,t.lanes&=~s}function yp(t){if(Sf){for(t=t.memoizedState;t!==null;){var i=t.queue;i!==null&&(i.pending=null),t=t.next}Sf=!1}Dr=0,Yn=fn=Rt=null,ul=!1,Lc=yf=0,fl=null}function Ui(){var t={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return Yn===null?Rt.memoizedState=Yn=t:Yn=Yn.next=t,Yn}function Hn(){if(fn===null){var t=Rt.alternate;t=t!==null?t.memoizedState:null}else t=fn.next;var i=Yn===null?Rt.memoizedState:Yn.next;if(i!==null)Yn=i,fn=t;else{if(t===null)throw Rt.alternate===null?Error(a(467)):Error(a(310));fn=t,t={memoizedState:fn.memoizedState,baseState:fn.baseState,baseQueue:fn.baseQueue,queue:fn.queue,next:null},Yn===null?Rt.memoizedState=Yn=t:Yn=Yn.next=t}return Yn}function Mf(){return{lastEffect:null,events:null,stores:null,memoCache:null}}function Oc(t){var i=Lc;return Lc+=1,fl===null&&(fl=[]),t=Cv(fl,t,i),i=Rt,(Yn===null?i.memoizedState:Yn.next)===null&&(i=i.alternate,z.H=i===null||i.memoizedState===null?xx:Lp),t}function bf(t){if(t!==null&&typeof t=="object"){if(typeof t.then=="function")return Oc(t);if(t.$$typeof===U)return hi(t)}throw Error(a(438,String(t)))}function Mp(t){var i=null,s=Rt.updateQueue;if(s!==null&&(i=s.memoCache),i==null){var c=Rt.alternate;c!==null&&(c=c.updateQueue,c!==null&&(c=c.memoCache,c!=null&&(i={data:c.data.map(function(h){return h.slice()}),index:0})))}if(i==null&&(i={data:[],index:0}),s===null&&(s=Mf(),Rt.updateQueue=s),s.memoCache=i,s=i.data[i.index],s===void 0)for(s=i.data[i.index]=Array(t),c=0;c<t;c++)s[c]=H;return i.index++,s}function Ur(t,i){return typeof i=="function"?i(t):i}function Ef(t){var i=Hn();return bp(i,fn,t)}function bp(t,i,s){var c=t.queue;if(c===null)throw Error(a(311));c.lastRenderedReducer=s;var h=t.baseQueue,m=c.pending;if(m!==null){if(h!==null){var b=h.next;h.next=m.next,m.next=b}i.baseQueue=h=m,c.pending=null}if(m=t.baseState,h===null)t.memoizedState=m;else{i=h.next;var N=b=null,X=null,oe=i,ve=!1;do{var Me=oe.lane&-536870913;if(Me!==oe.lane?(Gt&Me)===Me:(Dr&Me)===Me){var ce=oe.revertLane;if(ce===0)X!==null&&(X=X.next={lane:0,revertLane:0,gesture:null,action:oe.action,hasEagerState:oe.hasEagerState,eagerState:oe.eagerState,next:null}),Me===rl&&(ve=!0);else if((Dr&ce)===ce){oe=oe.next,ce===rl&&(ve=!0);continue}else Me={lane:0,revertLane:oe.revertLane,gesture:null,action:oe.action,hasEagerState:oe.hasEagerState,eagerState:oe.eagerState,next:null},X===null?(N=X=Me,b=m):X=X.next=Me,Rt.lanes|=ce,xs|=ce;Me=oe.action,ho&&s(m,Me),m=oe.hasEagerState?oe.eagerState:s(m,Me)}else ce={lane:Me,revertLane:oe.revertLane,gesture:oe.gesture,action:oe.action,hasEagerState:oe.hasEagerState,eagerState:oe.eagerState,next:null},X===null?(N=X=ce,b=m):X=X.next=ce,Rt.lanes|=Me,xs|=Me;oe=oe.next}while(oe!==null&&oe!==i);if(X===null?b=m:X.next=N,!ia(m,t.memoizedState)&&(jn=!0,ve&&(s=sl,s!==null)))throw s;t.memoizedState=m,t.baseState=b,t.baseQueue=X,c.lastRenderedState=m}return h===null&&(c.lanes=0),[t.memoizedState,c.dispatch]}function Ep(t){var i=Hn(),s=i.queue;if(s===null)throw Error(a(311));s.lastRenderedReducer=t;var c=s.dispatch,h=s.pending,m=i.memoizedState;if(h!==null){s.pending=null;var b=h=h.next;do m=t(m,b.action),b=b.next;while(b!==h);ia(m,i.memoizedState)||(jn=!0),i.memoizedState=m,i.baseQueue===null&&(i.baseState=m),s.lastRenderedState=m}return[m,c]}function Bv(t,i,s){var c=Rt,h=Hn(),m=kt;if(m){if(s===void 0)throw Error(a(407));s=s()}else s=i();var b=!ia((fn||h).memoizedState,s);if(b&&(h.memoizedState=s,jn=!0),h=h.queue,Rp(Vv.bind(null,c,h,t),[t]),h.getSnapshot!==i||b||Yn!==null&&Yn.memoizedState.tag&1){if(c.flags|=2048,hl(9,{destroy:void 0},Gv.bind(null,c,h,s,i),null),vn===null)throw Error(a(349));m||(Dr&127)!==0||Hv(c,i,s)}return s}function Hv(t,i,s){t.flags|=16384,t={getSnapshot:i,value:s},i=Rt.updateQueue,i===null?(i=Mf(),Rt.updateQueue=i,i.stores=[t]):(s=i.stores,s===null?i.stores=[t]:s.push(t))}function Gv(t,i,s,c){i.value=s,i.getSnapshot=c,kv(i)&&Xv(t)}function Vv(t,i,s){return s(function(){kv(i)&&Xv(t)})}function kv(t){var i=t.getSnapshot;t=t.value;try{var s=i();return!ia(t,s)}catch{return!0}}function Xv(t){var i=io(t,2);i!==null&&Wi(i,t,2)}function Tp(t){var i=Ui();if(typeof t=="function"){var s=t;if(t=s(),ho){Be(!0);try{s()}finally{Be(!1)}}}return i.memoizedState=i.baseState=t,i.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ur,lastRenderedState:t},i}function Wv(t,i,s,c){return t.baseState=s,bp(t,fn,typeof c=="function"?c:Ur)}function cT(t,i,s,c,h){if(Rf(t))throw Error(a(485));if(t=i.action,t!==null){var m={payload:h,action:t,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(b){m.listeners.push(b)}};z.T!==null?s(!0):m.isTransition=!1,c(m),s=i.pending,s===null?(m.next=i.pending=m,qv(i,m)):(m.next=s.next,i.pending=s.next=m)}}function qv(t,i){var s=i.action,c=i.payload,h=t.state;if(i.isTransition){var m=z.T,b={};z.T=b;try{var N=s(h,c),X=z.S;X!==null&&X(b,N),Yv(t,i,N)}catch(oe){Ap(t,i,oe)}finally{m!==null&&b.types!==null&&(m.types=b.types),z.T=m}}else try{m=s(h,c),Yv(t,i,m)}catch(oe){Ap(t,i,oe)}}function Yv(t,i,s){s!==null&&typeof s=="object"&&typeof s.then=="function"?s.then(function(c){jv(t,i,c)},function(c){return Ap(t,i,c)}):jv(t,i,s)}function jv(t,i,s){i.status="fulfilled",i.value=s,Zv(i),t.state=s,i=t.pending,i!==null&&(s=i.next,s===i?t.pending=null:(s=s.next,i.next=s,qv(t,s)))}function Ap(t,i,s){var c=t.pending;if(t.pending=null,c!==null){c=c.next;do i.status="rejected",i.reason=s,Zv(i),i=i.next;while(i!==c)}t.action=null}function Zv(t){t=t.listeners;for(var i=0;i<t.length;i++)(0,t[i])()}function Kv(t,i){return i}function Qv(t,i){if(kt){var s=vn.formState;if(s!==null){e:{var c=Rt;if(kt){if(Tn){t:{for(var h=Tn,m=wa;h.nodeType!==8;){if(!m){h=null;break t}if(h=Ua(h.nextSibling),h===null){h=null;break t}}m=h.data,h=m==="F!"||m==="F"?h:null}if(h){Tn=Ua(h.nextSibling),c=h.data==="F!";break e}}us(c)}c=!1}c&&(i=s[0])}}return s=Ui(),s.memoizedState=s.baseState=i,c={pending:null,lanes:0,dispatch:null,lastRenderedReducer:Kv,lastRenderedState:i},s.queue=c,s=_x.bind(null,Rt,c),c.dispatch=s,c=Tp(!1),m=Np.bind(null,Rt,!1,c.queue),c=Ui(),h={state:i,dispatch:null,action:t,pending:null},c.queue=h,s=cT.bind(null,Rt,h,m,s),h.dispatch=s,c.memoizedState=t,[i,s,!1]}function Jv(t){var i=Hn();return $v(i,fn,t)}function $v(t,i,s){if(i=bp(t,i,Kv)[0],t=Ef(Ur)[0],typeof i=="object"&&i!==null&&typeof i.then=="function")try{var c=Oc(i)}catch(b){throw b===ol?pf:b}else c=i;i=Hn();var h=i.queue,m=h.dispatch;return s!==i.memoizedState&&(Rt.flags|=2048,hl(9,{destroy:void 0},uT.bind(null,h,s),null)),[c,m,t]}function uT(t,i){t.action=i}function ex(t){var i=Hn(),s=fn;if(s!==null)return $v(i,s,t);Hn(),i=i.memoizedState,s=Hn();var c=s.queue.dispatch;return s.memoizedState=t,[i,c,!1]}function hl(t,i,s,c){return t={tag:t,create:s,deps:c,inst:i,next:null},i=Rt.updateQueue,i===null&&(i=Mf(),Rt.updateQueue=i),s=i.lastEffect,s===null?i.lastEffect=t.next=t:(c=s.next,s.next=t,t.next=c,i.lastEffect=t),t}function tx(){return Hn().memoizedState}function Tf(t,i,s,c){var h=Ui();Rt.flags|=t,h.memoizedState=hl(1|i,{destroy:void 0},s,c===void 0?null:c)}function Af(t,i,s,c){var h=Hn();c=c===void 0?null:c;var m=h.memoizedState.inst;fn!==null&&c!==null&&gp(c,fn.memoizedState.deps)?h.memoizedState=hl(i,m,s,c):(Rt.flags|=t,h.memoizedState=hl(1|i,m,s,c))}function nx(t,i){Tf(8390656,8,t,i)}function Rp(t,i){Af(2048,8,t,i)}function fT(t){Rt.flags|=4;var i=Rt.updateQueue;if(i===null)i=Mf(),Rt.updateQueue=i,i.events=[t];else{var s=i.events;s===null?i.events=[t]:s.push(t)}}function ix(t){var i=Hn().memoizedState;return fT({ref:i,nextImpl:t}),function(){if(($t&2)!==0)throw Error(a(440));return i.impl.apply(void 0,arguments)}}function ax(t,i){return Af(4,2,t,i)}function rx(t,i){return Af(4,4,t,i)}function sx(t,i){if(typeof i=="function"){t=t();var s=i(t);return function(){typeof s=="function"?s():i(null)}}if(i!=null)return t=t(),i.current=t,function(){i.current=null}}function ox(t,i,s){s=s!=null?s.concat([t]):null,Af(4,4,sx.bind(null,i,t),s)}function Cp(){}function lx(t,i){var s=Hn();i=i===void 0?null:i;var c=s.memoizedState;return i!==null&&gp(i,c[1])?c[0]:(s.memoizedState=[t,i],t)}function cx(t,i){var s=Hn();i=i===void 0?null:i;var c=s.memoizedState;if(i!==null&&gp(i,c[1]))return c[0];if(c=t(),ho){Be(!0);try{t()}finally{Be(!1)}}return s.memoizedState=[c,i],c}function wp(t,i,s){return s===void 0||(Dr&1073741824)!==0&&(Gt&261930)===0?t.memoizedState=i:(t.memoizedState=s,t=uS(),Rt.lanes|=t,xs|=t,s)}function ux(t,i,s,c){return ia(s,i)?s:cl.current!==null?(t=wp(t,s,c),ia(t,i)||(jn=!0),t):(Dr&42)===0||(Dr&1073741824)!==0&&(Gt&261930)===0?(jn=!0,t.memoizedState=s):(t=uS(),Rt.lanes|=t,xs|=t,i)}function fx(t,i,s,c,h){var m=B.p;B.p=m!==0&&8>m?m:8;var b=z.T,N={};z.T=N,Np(t,!1,i,s);try{var X=h(),oe=z.S;if(oe!==null&&oe(N,X),X!==null&&typeof X=="object"&&typeof X.then=="function"){var ve=sT(X,c);Pc(t,i,ve,ca(t))}else Pc(t,i,c,ca(t))}catch(Me){Pc(t,i,{then:function(){},status:"rejected",reason:Me},ca())}finally{B.p=m,b!==null&&N.types!==null&&(b.types=N.types),z.T=b}}function hT(){}function Dp(t,i,s,c){if(t.tag!==5)throw Error(a(476));var h=hx(t).queue;fx(t,h,i,J,s===null?hT:function(){return dx(t),s(c)})}function hx(t){var i=t.memoizedState;if(i!==null)return i;i={memoizedState:J,baseState:J,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ur,lastRenderedState:J},next:null};var s={};return i.next={memoizedState:s,baseState:s,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:Ur,lastRenderedState:s},next:null},t.memoizedState=i,t=t.alternate,t!==null&&(t.memoizedState=i),i}function dx(t){var i=hx(t);i.next===null&&(i=t.alternate.memoizedState),Pc(t,i.next.queue,{},ca())}function Up(){return hi(Jc)}function px(){return Hn().memoizedState}function mx(){return Hn().memoizedState}function dT(t){for(var i=t.return;i!==null;){switch(i.tag){case 24:case 3:var s=ca();t=ds(s);var c=ps(i,t,s);c!==null&&(Wi(c,i,s),Dc(c,i,s)),i={cache:sp()},t.payload=i;return}i=i.return}}function pT(t,i,s){var c=ca();s={lane:c,revertLane:0,gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null},Rf(t)?gx(i,s):(s=Zd(t,i,s,c),s!==null&&(Wi(s,t,c),vx(s,i,c)))}function _x(t,i,s){var c=ca();Pc(t,i,s,c)}function Pc(t,i,s,c){var h={lane:c,revertLane:0,gesture:null,action:s,hasEagerState:!1,eagerState:null,next:null};if(Rf(t))gx(i,h);else{var m=t.alternate;if(t.lanes===0&&(m===null||m.lanes===0)&&(m=i.lastRenderedReducer,m!==null))try{var b=i.lastRenderedState,N=m(b,s);if(h.hasEagerState=!0,h.eagerState=N,ia(N,b))return of(t,i,h,0),vn===null&&sf(),!1}catch{}if(s=Zd(t,i,h,c),s!==null)return Wi(s,t,c),vx(s,i,c),!0}return!1}function Np(t,i,s,c){if(c={lane:2,revertLane:um(),gesture:null,action:c,hasEagerState:!1,eagerState:null,next:null},Rf(t)){if(i)throw Error(a(479))}else i=Zd(t,s,c,2),i!==null&&Wi(i,t,2)}function Rf(t){var i=t.alternate;return t===Rt||i!==null&&i===Rt}function gx(t,i){ul=Sf=!0;var s=t.pending;s===null?i.next=i:(i.next=s.next,s.next=i),t.pending=i}function vx(t,i,s){if((s&4194048)!==0){var c=i.lanes;c&=t.pendingLanes,s|=c,i.lanes=s,rt(t,s)}}var Fc={readContext:hi,use:bf,useCallback:Fn,useContext:Fn,useEffect:Fn,useImperativeHandle:Fn,useLayoutEffect:Fn,useInsertionEffect:Fn,useMemo:Fn,useReducer:Fn,useRef:Fn,useState:Fn,useDebugValue:Fn,useDeferredValue:Fn,useTransition:Fn,useSyncExternalStore:Fn,useId:Fn,useHostTransitionStatus:Fn,useFormState:Fn,useActionState:Fn,useOptimistic:Fn,useMemoCache:Fn,useCacheRefresh:Fn};Fc.useEffectEvent=Fn;var xx={readContext:hi,use:bf,useCallback:function(t,i){return Ui().memoizedState=[t,i===void 0?null:i],t},useContext:hi,useEffect:nx,useImperativeHandle:function(t,i,s){s=s!=null?s.concat([t]):null,Tf(4194308,4,sx.bind(null,i,t),s)},useLayoutEffect:function(t,i){return Tf(4194308,4,t,i)},useInsertionEffect:function(t,i){Tf(4,2,t,i)},useMemo:function(t,i){var s=Ui();i=i===void 0?null:i;var c=t();if(ho){Be(!0);try{t()}finally{Be(!1)}}return s.memoizedState=[c,i],c},useReducer:function(t,i,s){var c=Ui();if(s!==void 0){var h=s(i);if(ho){Be(!0);try{s(i)}finally{Be(!1)}}}else h=i;return c.memoizedState=c.baseState=h,t={pending:null,lanes:0,dispatch:null,lastRenderedReducer:t,lastRenderedState:h},c.queue=t,t=t.dispatch=pT.bind(null,Rt,t),[c.memoizedState,t]},useRef:function(t){var i=Ui();return t={current:t},i.memoizedState=t},useState:function(t){t=Tp(t);var i=t.queue,s=_x.bind(null,Rt,i);return i.dispatch=s,[t.memoizedState,s]},useDebugValue:Cp,useDeferredValue:function(t,i){var s=Ui();return wp(s,t,i)},useTransition:function(){var t=Tp(!1);return t=fx.bind(null,Rt,t.queue,!0,!1),Ui().memoizedState=t,[!1,t]},useSyncExternalStore:function(t,i,s){var c=Rt,h=Ui();if(kt){if(s===void 0)throw Error(a(407));s=s()}else{if(s=i(),vn===null)throw Error(a(349));(Gt&127)!==0||Hv(c,i,s)}h.memoizedState=s;var m={value:s,getSnapshot:i};return h.queue=m,nx(Vv.bind(null,c,m,t),[t]),c.flags|=2048,hl(9,{destroy:void 0},Gv.bind(null,c,m,s,i),null),s},useId:function(){var t=Ui(),i=vn.identifierPrefix;if(kt){var s=rr,c=ar;s=(c&~(1<<32-He(c)-1)).toString(32)+s,i="_"+i+"R_"+s,s=yf++,0<s&&(i+="H"+s.toString(32)),i+="_"}else s=oT++,i="_"+i+"r_"+s.toString(32)+"_";return t.memoizedState=i},useHostTransitionStatus:Up,useFormState:Qv,useActionState:Qv,useOptimistic:function(t){var i=Ui();i.memoizedState=i.baseState=t;var s={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};return i.queue=s,i=Np.bind(null,Rt,!0,s),s.dispatch=i,[t,i]},useMemoCache:Mp,useCacheRefresh:function(){return Ui().memoizedState=dT.bind(null,Rt)},useEffectEvent:function(t){var i=Ui(),s={impl:t};return i.memoizedState=s,function(){if(($t&2)!==0)throw Error(a(440));return s.impl.apply(void 0,arguments)}}},Lp={readContext:hi,use:bf,useCallback:lx,useContext:hi,useEffect:Rp,useImperativeHandle:ox,useInsertionEffect:ax,useLayoutEffect:rx,useMemo:cx,useReducer:Ef,useRef:tx,useState:function(){return Ef(Ur)},useDebugValue:Cp,useDeferredValue:function(t,i){var s=Hn();return ux(s,fn.memoizedState,t,i)},useTransition:function(){var t=Ef(Ur)[0],i=Hn().memoizedState;return[typeof t=="boolean"?t:Oc(t),i]},useSyncExternalStore:Bv,useId:px,useHostTransitionStatus:Up,useFormState:Jv,useActionState:Jv,useOptimistic:function(t,i){var s=Hn();return Wv(s,fn,t,i)},useMemoCache:Mp,useCacheRefresh:mx};Lp.useEffectEvent=ix;var Sx={readContext:hi,use:bf,useCallback:lx,useContext:hi,useEffect:Rp,useImperativeHandle:ox,useInsertionEffect:ax,useLayoutEffect:rx,useMemo:cx,useReducer:Ep,useRef:tx,useState:function(){return Ep(Ur)},useDebugValue:Cp,useDeferredValue:function(t,i){var s=Hn();return fn===null?wp(s,t,i):ux(s,fn.memoizedState,t,i)},useTransition:function(){var t=Ep(Ur)[0],i=Hn().memoizedState;return[typeof t=="boolean"?t:Oc(t),i]},useSyncExternalStore:Bv,useId:px,useHostTransitionStatus:Up,useFormState:ex,useActionState:ex,useOptimistic:function(t,i){var s=Hn();return fn!==null?Wv(s,fn,t,i):(s.baseState=t,[t,s.queue.dispatch])},useMemoCache:Mp,useCacheRefresh:mx};Sx.useEffectEvent=ix;function Op(t,i,s,c){i=t.memoizedState,s=s(c,i),s=s==null?i:v({},i,s),t.memoizedState=s,t.lanes===0&&(t.updateQueue.baseState=s)}var Pp={enqueueSetState:function(t,i,s){t=t._reactInternals;var c=ca(),h=ds(c);h.payload=i,s!=null&&(h.callback=s),i=ps(t,h,c),i!==null&&(Wi(i,t,c),Dc(i,t,c))},enqueueReplaceState:function(t,i,s){t=t._reactInternals;var c=ca(),h=ds(c);h.tag=1,h.payload=i,s!=null&&(h.callback=s),i=ps(t,h,c),i!==null&&(Wi(i,t,c),Dc(i,t,c))},enqueueForceUpdate:function(t,i){t=t._reactInternals;var s=ca(),c=ds(s);c.tag=2,i!=null&&(c.callback=i),i=ps(t,c,s),i!==null&&(Wi(i,t,s),Dc(i,t,s))}};function yx(t,i,s,c,h,m,b){return t=t.stateNode,typeof t.shouldComponentUpdate=="function"?t.shouldComponentUpdate(c,m,b):i.prototype&&i.prototype.isPureReactComponent?!Mc(s,c)||!Mc(h,m):!0}function Mx(t,i,s,c){t=i.state,typeof i.componentWillReceiveProps=="function"&&i.componentWillReceiveProps(s,c),typeof i.UNSAFE_componentWillReceiveProps=="function"&&i.UNSAFE_componentWillReceiveProps(s,c),i.state!==t&&Pp.enqueueReplaceState(i,i.state,null)}function po(t,i){var s=i;if("ref"in i){s={};for(var c in i)c!=="ref"&&(s[c]=i[c])}if(t=t.defaultProps){s===i&&(s=v({},s));for(var h in t)s[h]===void 0&&(s[h]=t[h])}return s}function bx(t){rf(t)}function Ex(t){console.error(t)}function Tx(t){rf(t)}function Cf(t,i){try{var s=t.onUncaughtError;s(i.value,{componentStack:i.stack})}catch(c){setTimeout(function(){throw c})}}function Ax(t,i,s){try{var c=t.onCaughtError;c(s.value,{componentStack:s.stack,errorBoundary:i.tag===1?i.stateNode:null})}catch(h){setTimeout(function(){throw h})}}function Fp(t,i,s){return s=ds(s),s.tag=3,s.payload={element:null},s.callback=function(){Cf(t,i)},s}function Rx(t){return t=ds(t),t.tag=3,t}function Cx(t,i,s,c){var h=s.type.getDerivedStateFromError;if(typeof h=="function"){var m=c.value;t.payload=function(){return h(m)},t.callback=function(){Ax(i,s,c)}}var b=s.stateNode;b!==null&&typeof b.componentDidCatch=="function"&&(t.callback=function(){Ax(i,s,c),typeof h!="function"&&(Ss===null?Ss=new Set([this]):Ss.add(this));var N=c.stack;this.componentDidCatch(c.value,{componentStack:N!==null?N:""})})}function mT(t,i,s,c,h){if(s.flags|=32768,c!==null&&typeof c=="object"&&typeof c.then=="function"){if(i=s.alternate,i!==null&&al(i,s,h,!0),s=ra.current,s!==null){switch(s.tag){case 31:case 13:return Da===null?Hf():s.alternate===null&&zn===0&&(zn=3),s.flags&=-257,s.flags|=65536,s.lanes=h,c===mf?s.flags|=16384:(i=s.updateQueue,i===null?s.updateQueue=new Set([c]):i.add(c),om(t,c,h)),!1;case 22:return s.flags|=65536,c===mf?s.flags|=16384:(i=s.updateQueue,i===null?(i={transitions:null,markerInstances:null,retryQueue:new Set([c])},s.updateQueue=i):(s=i.retryQueue,s===null?i.retryQueue=new Set([c]):s.add(c)),om(t,c,h)),!1}throw Error(a(435,s.tag))}return om(t,c,h),Hf(),!1}if(kt)return i=ra.current,i!==null?((i.flags&65536)===0&&(i.flags|=256),i.flags|=65536,i.lanes=h,c!==tp&&(t=Error(a(422),{cause:c}),Tc(Aa(t,s)))):(c!==tp&&(i=Error(a(423),{cause:c}),Tc(Aa(i,s))),t=t.current.alternate,t.flags|=65536,h&=-h,t.lanes|=h,c=Aa(c,s),h=Fp(t.stateNode,c,h),hp(t,h),zn!==4&&(zn=2)),!1;var m=Error(a(520),{cause:c});if(m=Aa(m,s),Xc===null?Xc=[m]:Xc.push(m),zn!==4&&(zn=2),i===null)return!0;c=Aa(c,s),s=i;do{switch(s.tag){case 3:return s.flags|=65536,t=h&-h,s.lanes|=t,t=Fp(s.stateNode,c,t),hp(s,t),!1;case 1:if(i=s.type,m=s.stateNode,(s.flags&128)===0&&(typeof i.getDerivedStateFromError=="function"||m!==null&&typeof m.componentDidCatch=="function"&&(Ss===null||!Ss.has(m))))return s.flags|=65536,h&=-h,s.lanes|=h,h=Rx(h),Cx(h,t,s,c),hp(s,h),!1}s=s.return}while(s!==null);return!1}var zp=Error(a(461)),jn=!1;function di(t,i,s,c){i.child=t===null?Nv(i,null,s,c):fo(i,t.child,s,c)}function wx(t,i,s,c,h){s=s.render;var m=i.ref;if("ref"in c){var b={};for(var N in c)N!=="ref"&&(b[N]=c[N])}else b=c;return oo(i),c=vp(t,i,s,b,m,h),N=xp(),t!==null&&!jn?(Sp(t,i,h),Nr(t,i,h)):(kt&&N&&$d(i),i.flags|=1,di(t,i,c,h),i.child)}function Dx(t,i,s,c,h){if(t===null){var m=s.type;return typeof m=="function"&&!Kd(m)&&m.defaultProps===void 0&&s.compare===null?(i.tag=15,i.type=m,Ux(t,i,m,c,h)):(t=cf(s.type,null,c,i,i.mode,h),t.ref=i.ref,t.return=i,i.child=t)}if(m=t.child,!Wp(t,h)){var b=m.memoizedProps;if(s=s.compare,s=s!==null?s:Mc,s(b,c)&&t.ref===i.ref)return Nr(t,i,h)}return i.flags|=1,t=Ar(m,c),t.ref=i.ref,t.return=i,i.child=t}function Ux(t,i,s,c,h){if(t!==null){var m=t.memoizedProps;if(Mc(m,c)&&t.ref===i.ref)if(jn=!1,i.pendingProps=c=m,Wp(t,h))(t.flags&131072)!==0&&(jn=!0);else return i.lanes=t.lanes,Nr(t,i,h)}return Ip(t,i,s,c,h)}function Nx(t,i,s,c){var h=c.children,m=t!==null?t.memoizedState:null;if(t===null&&i.stateNode===null&&(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),c.mode==="hidden"){if((i.flags&128)!==0){if(m=m!==null?m.baseLanes|s:s,t!==null){for(c=i.child=t.child,h=0;c!==null;)h=h|c.lanes|c.childLanes,c=c.sibling;c=h&~m}else c=0,i.child=null;return Lx(t,i,m,s,c)}if((s&536870912)!==0)i.memoizedState={baseLanes:0,cachePool:null},t!==null&&df(i,m!==null?m.cachePool:null),m!==null?Pv(i,m):pp(),Fv(i);else return c=i.lanes=536870912,Lx(t,i,m!==null?m.baseLanes|s:s,s,c)}else m!==null?(df(i,m.cachePool),Pv(i,m),_s(),i.memoizedState=null):(t!==null&&df(i,null),pp(),_s());return di(t,i,h,s),i.child}function zc(t,i){return t!==null&&t.tag===22||i.stateNode!==null||(i.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),i.sibling}function Lx(t,i,s,c,h){var m=lp();return m=m===null?null:{parent:qn._currentValue,pool:m},i.memoizedState={baseLanes:s,cachePool:m},t!==null&&df(i,null),pp(),Fv(i),t!==null&&al(t,i,c,!0),i.childLanes=h,null}function wf(t,i){return i=Uf({mode:i.mode,children:i.children},t.mode),i.ref=t.ref,t.child=i,i.return=t,i}function Ox(t,i,s){return fo(i,t.child,null,s),t=wf(i,i.pendingProps),t.flags|=2,sa(i),i.memoizedState=null,t}function _T(t,i,s){var c=i.pendingProps,h=(i.flags&128)!==0;if(i.flags&=-129,t===null){if(kt){if(c.mode==="hidden")return t=wf(i,c),i.lanes=536870912,zc(null,t);if(_p(i),(t=Tn)?(t=qS(t,wa),t=t!==null&&t.data==="&"?t:null,t!==null&&(i.memoizedState={dehydrated:t,treeContext:ls!==null?{id:ar,overflow:rr}:null,retryLane:536870912,hydrationErrors:null},s=gv(t),s.return=i,i.child=s,fi=i,Tn=null)):t=null,t===null)throw us(i);return i.lanes=536870912,null}return wf(i,c)}var m=t.memoizedState;if(m!==null){var b=m.dehydrated;if(_p(i),h)if(i.flags&256)i.flags&=-257,i=Ox(t,i,s);else if(i.memoizedState!==null)i.child=t.child,i.flags|=128,i=null;else throw Error(a(558));else if(jn||al(t,i,s,!1),h=(s&t.childLanes)!==0,jn||h){if(c=vn,c!==null&&(b=Qe(c,s),b!==0&&b!==m.retryLane))throw m.retryLane=b,io(t,b),Wi(c,t,b),zp;Hf(),i=Ox(t,i,s)}else t=m.treeContext,Tn=Ua(b.nextSibling),fi=i,kt=!0,cs=null,wa=!1,t!==null&&Sv(i,t),i=wf(i,c),i.flags|=4096;return i}return t=Ar(t.child,{mode:c.mode,children:c.children}),t.ref=i.ref,i.child=t,t.return=i,t}function Df(t,i){var s=i.ref;if(s===null)t!==null&&t.ref!==null&&(i.flags|=4194816);else{if(typeof s!="function"&&typeof s!="object")throw Error(a(284));(t===null||t.ref!==s)&&(i.flags|=4194816)}}function Ip(t,i,s,c,h){return oo(i),s=vp(t,i,s,c,void 0,h),c=xp(),t!==null&&!jn?(Sp(t,i,h),Nr(t,i,h)):(kt&&c&&$d(i),i.flags|=1,di(t,i,s,h),i.child)}function Px(t,i,s,c,h,m){return oo(i),i.updateQueue=null,s=Iv(i,c,s,h),zv(t),c=xp(),t!==null&&!jn?(Sp(t,i,m),Nr(t,i,m)):(kt&&c&&$d(i),i.flags|=1,di(t,i,s,m),i.child)}function Fx(t,i,s,c,h){if(oo(i),i.stateNode===null){var m=el,b=s.contextType;typeof b=="object"&&b!==null&&(m=hi(b)),m=new s(c,m),i.memoizedState=m.state!==null&&m.state!==void 0?m.state:null,m.updater=Pp,i.stateNode=m,m._reactInternals=i,m=i.stateNode,m.props=c,m.state=i.memoizedState,m.refs={},up(i),b=s.contextType,m.context=typeof b=="object"&&b!==null?hi(b):el,m.state=i.memoizedState,b=s.getDerivedStateFromProps,typeof b=="function"&&(Op(i,s,b,c),m.state=i.memoizedState),typeof s.getDerivedStateFromProps=="function"||typeof m.getSnapshotBeforeUpdate=="function"||typeof m.UNSAFE_componentWillMount!="function"&&typeof m.componentWillMount!="function"||(b=m.state,typeof m.componentWillMount=="function"&&m.componentWillMount(),typeof m.UNSAFE_componentWillMount=="function"&&m.UNSAFE_componentWillMount(),b!==m.state&&Pp.enqueueReplaceState(m,m.state,null),Nc(i,c,m,h),Uc(),m.state=i.memoizedState),typeof m.componentDidMount=="function"&&(i.flags|=4194308),c=!0}else if(t===null){m=i.stateNode;var N=i.memoizedProps,X=po(s,N);m.props=X;var oe=m.context,ve=s.contextType;b=el,typeof ve=="object"&&ve!==null&&(b=hi(ve));var Me=s.getDerivedStateFromProps;ve=typeof Me=="function"||typeof m.getSnapshotBeforeUpdate=="function",N=i.pendingProps!==N,ve||typeof m.UNSAFE_componentWillReceiveProps!="function"&&typeof m.componentWillReceiveProps!="function"||(N||oe!==b)&&Mx(i,m,c,b),hs=!1;var ce=i.memoizedState;m.state=ce,Nc(i,c,m,h),Uc(),oe=i.memoizedState,N||ce!==oe||hs?(typeof Me=="function"&&(Op(i,s,Me,c),oe=i.memoizedState),(X=hs||yx(i,s,X,c,ce,oe,b))?(ve||typeof m.UNSAFE_componentWillMount!="function"&&typeof m.componentWillMount!="function"||(typeof m.componentWillMount=="function"&&m.componentWillMount(),typeof m.UNSAFE_componentWillMount=="function"&&m.UNSAFE_componentWillMount()),typeof m.componentDidMount=="function"&&(i.flags|=4194308)):(typeof m.componentDidMount=="function"&&(i.flags|=4194308),i.memoizedProps=c,i.memoizedState=oe),m.props=c,m.state=oe,m.context=b,c=X):(typeof m.componentDidMount=="function"&&(i.flags|=4194308),c=!1)}else{m=i.stateNode,fp(t,i),b=i.memoizedProps,ve=po(s,b),m.props=ve,Me=i.pendingProps,ce=m.context,oe=s.contextType,X=el,typeof oe=="object"&&oe!==null&&(X=hi(oe)),N=s.getDerivedStateFromProps,(oe=typeof N=="function"||typeof m.getSnapshotBeforeUpdate=="function")||typeof m.UNSAFE_componentWillReceiveProps!="function"&&typeof m.componentWillReceiveProps!="function"||(b!==Me||ce!==X)&&Mx(i,m,c,X),hs=!1,ce=i.memoizedState,m.state=ce,Nc(i,c,m,h),Uc();var he=i.memoizedState;b!==Me||ce!==he||hs||t!==null&&t.dependencies!==null&&ff(t.dependencies)?(typeof N=="function"&&(Op(i,s,N,c),he=i.memoizedState),(ve=hs||yx(i,s,ve,c,ce,he,X)||t!==null&&t.dependencies!==null&&ff(t.dependencies))?(oe||typeof m.UNSAFE_componentWillUpdate!="function"&&typeof m.componentWillUpdate!="function"||(typeof m.componentWillUpdate=="function"&&m.componentWillUpdate(c,he,X),typeof m.UNSAFE_componentWillUpdate=="function"&&m.UNSAFE_componentWillUpdate(c,he,X)),typeof m.componentDidUpdate=="function"&&(i.flags|=4),typeof m.getSnapshotBeforeUpdate=="function"&&(i.flags|=1024)):(typeof m.componentDidUpdate!="function"||b===t.memoizedProps&&ce===t.memoizedState||(i.flags|=4),typeof m.getSnapshotBeforeUpdate!="function"||b===t.memoizedProps&&ce===t.memoizedState||(i.flags|=1024),i.memoizedProps=c,i.memoizedState=he),m.props=c,m.state=he,m.context=X,c=ve):(typeof m.componentDidUpdate!="function"||b===t.memoizedProps&&ce===t.memoizedState||(i.flags|=4),typeof m.getSnapshotBeforeUpdate!="function"||b===t.memoizedProps&&ce===t.memoizedState||(i.flags|=1024),c=!1)}return m=c,Df(t,i),c=(i.flags&128)!==0,m||c?(m=i.stateNode,s=c&&typeof s.getDerivedStateFromError!="function"?null:m.render(),i.flags|=1,t!==null&&c?(i.child=fo(i,t.child,null,h),i.child=fo(i,null,s,h)):di(t,i,s,h),i.memoizedState=m.state,t=i.child):t=Nr(t,i,h),t}function zx(t,i,s,c){return ro(),i.flags|=256,di(t,i,s,c),i.child}var Bp={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null};function Hp(t){return{baseLanes:t,cachePool:Av()}}function Gp(t,i,s){return t=t!==null?t.childLanes&~s:0,i&&(t|=la),t}function Ix(t,i,s){var c=i.pendingProps,h=!1,m=(i.flags&128)!==0,b;if((b=m)||(b=t!==null&&t.memoizedState===null?!1:(Bn.current&2)!==0),b&&(h=!0,i.flags&=-129),b=(i.flags&32)!==0,i.flags&=-33,t===null){if(kt){if(h?ms(i):_s(),(t=Tn)?(t=qS(t,wa),t=t!==null&&t.data!=="&"?t:null,t!==null&&(i.memoizedState={dehydrated:t,treeContext:ls!==null?{id:ar,overflow:rr}:null,retryLane:536870912,hydrationErrors:null},s=gv(t),s.return=i,i.child=s,fi=i,Tn=null)):t=null,t===null)throw us(i);return bm(t)?i.lanes=32:i.lanes=536870912,null}var N=c.children;return c=c.fallback,h?(_s(),h=i.mode,N=Uf({mode:"hidden",children:N},h),c=ao(c,h,s,null),N.return=i,c.return=i,N.sibling=c,i.child=N,c=i.child,c.memoizedState=Hp(s),c.childLanes=Gp(t,b,s),i.memoizedState=Bp,zc(null,c)):(ms(i),Vp(i,N))}var X=t.memoizedState;if(X!==null&&(N=X.dehydrated,N!==null)){if(m)i.flags&256?(ms(i),i.flags&=-257,i=kp(t,i,s)):i.memoizedState!==null?(_s(),i.child=t.child,i.flags|=128,i=null):(_s(),N=c.fallback,h=i.mode,c=Uf({mode:"visible",children:c.children},h),N=ao(N,h,s,null),N.flags|=2,c.return=i,N.return=i,c.sibling=N,i.child=c,fo(i,t.child,null,s),c=i.child,c.memoizedState=Hp(s),c.childLanes=Gp(t,b,s),i.memoizedState=Bp,i=zc(null,c));else if(ms(i),bm(N)){if(b=N.nextSibling&&N.nextSibling.dataset,b)var oe=b.dgst;b=oe,c=Error(a(419)),c.stack="",c.digest=b,Tc({value:c,source:null,stack:null}),i=kp(t,i,s)}else if(jn||al(t,i,s,!1),b=(s&t.childLanes)!==0,jn||b){if(b=vn,b!==null&&(c=Qe(b,s),c!==0&&c!==X.retryLane))throw X.retryLane=c,io(t,c),Wi(b,t,c),zp;Mm(N)||Hf(),i=kp(t,i,s)}else Mm(N)?(i.flags|=192,i.child=t.child,i=null):(t=X.treeContext,Tn=Ua(N.nextSibling),fi=i,kt=!0,cs=null,wa=!1,t!==null&&Sv(i,t),i=Vp(i,c.children),i.flags|=4096);return i}return h?(_s(),N=c.fallback,h=i.mode,X=t.child,oe=X.sibling,c=Ar(X,{mode:"hidden",children:c.children}),c.subtreeFlags=X.subtreeFlags&65011712,oe!==null?N=Ar(oe,N):(N=ao(N,h,s,null),N.flags|=2),N.return=i,c.return=i,c.sibling=N,i.child=c,zc(null,c),c=i.child,N=t.child.memoizedState,N===null?N=Hp(s):(h=N.cachePool,h!==null?(X=qn._currentValue,h=h.parent!==X?{parent:X,pool:X}:h):h=Av(),N={baseLanes:N.baseLanes|s,cachePool:h}),c.memoizedState=N,c.childLanes=Gp(t,b,s),i.memoizedState=Bp,zc(t.child,c)):(ms(i),s=t.child,t=s.sibling,s=Ar(s,{mode:"visible",children:c.children}),s.return=i,s.sibling=null,t!==null&&(b=i.deletions,b===null?(i.deletions=[t],i.flags|=16):b.push(t)),i.child=s,i.memoizedState=null,s)}function Vp(t,i){return i=Uf({mode:"visible",children:i},t.mode),i.return=t,t.child=i}function Uf(t,i){return t=aa(22,t,null,i),t.lanes=0,t}function kp(t,i,s){return fo(i,t.child,null,s),t=Vp(i,i.pendingProps.children),t.flags|=2,i.memoizedState=null,t}function Bx(t,i,s){t.lanes|=i;var c=t.alternate;c!==null&&(c.lanes|=i),ap(t.return,i,s)}function Xp(t,i,s,c,h,m){var b=t.memoizedState;b===null?t.memoizedState={isBackwards:i,rendering:null,renderingStartTime:0,last:c,tail:s,tailMode:h,treeForkCount:m}:(b.isBackwards=i,b.rendering=null,b.renderingStartTime=0,b.last=c,b.tail=s,b.tailMode=h,b.treeForkCount=m)}function Hx(t,i,s){var c=i.pendingProps,h=c.revealOrder,m=c.tail;c=c.children;var b=Bn.current,N=(b&2)!==0;if(N?(b=b&1|2,i.flags|=128):b&=1,Se(Bn,b),di(t,i,c,s),c=kt?Ec:0,!N&&t!==null&&(t.flags&128)!==0)e:for(t=i.child;t!==null;){if(t.tag===13)t.memoizedState!==null&&Bx(t,s,i);else if(t.tag===19)Bx(t,s,i);else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===i)break e;for(;t.sibling===null;){if(t.return===null||t.return===i)break e;t=t.return}t.sibling.return=t.return,t=t.sibling}switch(h){case"forwards":for(s=i.child,h=null;s!==null;)t=s.alternate,t!==null&&xf(t)===null&&(h=s),s=s.sibling;s=h,s===null?(h=i.child,i.child=null):(h=s.sibling,s.sibling=null),Xp(i,!1,h,s,m,c);break;case"backwards":case"unstable_legacy-backwards":for(s=null,h=i.child,i.child=null;h!==null;){if(t=h.alternate,t!==null&&xf(t)===null){i.child=h;break}t=h.sibling,h.sibling=s,s=h,h=t}Xp(i,!0,s,null,m,c);break;case"together":Xp(i,!1,null,null,void 0,c);break;default:i.memoizedState=null}return i.child}function Nr(t,i,s){if(t!==null&&(i.dependencies=t.dependencies),xs|=i.lanes,(s&i.childLanes)===0)if(t!==null){if(al(t,i,s,!1),(s&i.childLanes)===0)return null}else return null;if(t!==null&&i.child!==t.child)throw Error(a(153));if(i.child!==null){for(t=i.child,s=Ar(t,t.pendingProps),i.child=s,s.return=i;t.sibling!==null;)t=t.sibling,s=s.sibling=Ar(t,t.pendingProps),s.return=i;s.sibling=null}return i.child}function Wp(t,i){return(t.lanes&i)!==0?!0:(t=t.dependencies,!!(t!==null&&ff(t)))}function gT(t,i,s){switch(i.tag){case 3:Ee(i,i.stateNode.containerInfo),fs(i,qn,t.memoizedState.cache),ro();break;case 27:case 5:nt(i);break;case 4:Ee(i,i.stateNode.containerInfo);break;case 10:fs(i,i.type,i.memoizedProps.value);break;case 31:if(i.memoizedState!==null)return i.flags|=128,_p(i),null;break;case 13:var c=i.memoizedState;if(c!==null)return c.dehydrated!==null?(ms(i),i.flags|=128,null):(s&i.child.childLanes)!==0?Ix(t,i,s):(ms(i),t=Nr(t,i,s),t!==null?t.sibling:null);ms(i);break;case 19:var h=(t.flags&128)!==0;if(c=(s&i.childLanes)!==0,c||(al(t,i,s,!1),c=(s&i.childLanes)!==0),h){if(c)return Hx(t,i,s);i.flags|=128}if(h=i.memoizedState,h!==null&&(h.rendering=null,h.tail=null,h.lastEffect=null),Se(Bn,Bn.current),c)break;return null;case 22:return i.lanes=0,Nx(t,i,s,i.pendingProps);case 24:fs(i,qn,t.memoizedState.cache)}return Nr(t,i,s)}function Gx(t,i,s){if(t!==null)if(t.memoizedProps!==i.pendingProps)jn=!0;else{if(!Wp(t,s)&&(i.flags&128)===0)return jn=!1,gT(t,i,s);jn=(t.flags&131072)!==0}else jn=!1,kt&&(i.flags&1048576)!==0&&xv(i,Ec,i.index);switch(i.lanes=0,i.tag){case 16:e:{var c=i.pendingProps;if(t=co(i.elementType),i.type=t,typeof t=="function")Kd(t)?(c=po(t,c),i.tag=1,i=Fx(null,i,t,c,s)):(i.tag=0,i=Ip(null,i,t,c,s));else{if(t!=null){var h=t.$$typeof;if(h===C){i.tag=11,i=wx(null,i,t,c,s);break e}else if(h===D){i.tag=14,i=Dx(null,i,t,c,s);break e}}throw i=ie(t)||t,Error(a(306,i,""))}}return i;case 0:return Ip(t,i,i.type,i.pendingProps,s);case 1:return c=i.type,h=po(c,i.pendingProps),Fx(t,i,c,h,s);case 3:e:{if(Ee(i,i.stateNode.containerInfo),t===null)throw Error(a(387));c=i.pendingProps;var m=i.memoizedState;h=m.element,fp(t,i),Nc(i,c,null,s);var b=i.memoizedState;if(c=b.cache,fs(i,qn,c),c!==m.cache&&rp(i,[qn],s,!0),Uc(),c=b.element,m.isDehydrated)if(m={element:c,isDehydrated:!1,cache:b.cache},i.updateQueue.baseState=m,i.memoizedState=m,i.flags&256){i=zx(t,i,c,s);break e}else if(c!==h){h=Aa(Error(a(424)),i),Tc(h),i=zx(t,i,c,s);break e}else for(t=i.stateNode.containerInfo,t.nodeType===9?t=t.body:t=t.nodeName==="HTML"?t.ownerDocument.body:t,Tn=Ua(t.firstChild),fi=i,kt=!0,cs=null,wa=!0,s=Nv(i,null,c,s),i.child=s;s;)s.flags=s.flags&-3|4096,s=s.sibling;else{if(ro(),c===h){i=Nr(t,i,s);break e}di(t,i,c,s)}i=i.child}return i;case 26:return Df(t,i),t===null?(s=JS(i.type,null,i.pendingProps,null))?i.memoizedState=s:kt||(s=i.type,t=i.pendingProps,c=Yf(ne.current).createElement(s),c[St]=i,c[Tt]=t,pi(c,s,t),Ut(c),i.stateNode=c):i.memoizedState=JS(i.type,t.memoizedProps,i.pendingProps,t.memoizedState),null;case 27:return nt(i),t===null&&kt&&(c=i.stateNode=ZS(i.type,i.pendingProps,ne.current),fi=i,wa=!0,h=Tn,Es(i.type)?(Em=h,Tn=Ua(c.firstChild)):Tn=h),di(t,i,i.pendingProps.children,s),Df(t,i),t===null&&(i.flags|=4194304),i.child;case 5:return t===null&&kt&&((h=c=Tn)&&(c=YT(c,i.type,i.pendingProps,wa),c!==null?(i.stateNode=c,fi=i,Tn=Ua(c.firstChild),wa=!1,h=!0):h=!1),h||us(i)),nt(i),h=i.type,m=i.pendingProps,b=t!==null?t.memoizedProps:null,c=m.children,xm(h,m)?c=null:b!==null&&xm(h,b)&&(i.flags|=32),i.memoizedState!==null&&(h=vp(t,i,lT,null,null,s),Jc._currentValue=h),Df(t,i),di(t,i,c,s),i.child;case 6:return t===null&&kt&&((t=s=Tn)&&(s=jT(s,i.pendingProps,wa),s!==null?(i.stateNode=s,fi=i,Tn=null,t=!0):t=!1),t||us(i)),null;case 13:return Ix(t,i,s);case 4:return Ee(i,i.stateNode.containerInfo),c=i.pendingProps,t===null?i.child=fo(i,null,c,s):di(t,i,c,s),i.child;case 11:return wx(t,i,i.type,i.pendingProps,s);case 7:return di(t,i,i.pendingProps,s),i.child;case 8:return di(t,i,i.pendingProps.children,s),i.child;case 12:return di(t,i,i.pendingProps.children,s),i.child;case 10:return c=i.pendingProps,fs(i,i.type,c.value),di(t,i,c.children,s),i.child;case 9:return h=i.type._context,c=i.pendingProps.children,oo(i),h=hi(h),c=c(h),i.flags|=1,di(t,i,c,s),i.child;case 14:return Dx(t,i,i.type,i.pendingProps,s);case 15:return Ux(t,i,i.type,i.pendingProps,s);case 19:return Hx(t,i,s);case 31:return _T(t,i,s);case 22:return Nx(t,i,s,i.pendingProps);case 24:return oo(i),c=hi(qn),t===null?(h=lp(),h===null&&(h=vn,m=sp(),h.pooledCache=m,m.refCount++,m!==null&&(h.pooledCacheLanes|=s),h=m),i.memoizedState={parent:c,cache:h},up(i),fs(i,qn,h)):((t.lanes&s)!==0&&(fp(t,i),Nc(i,null,null,s),Uc()),h=t.memoizedState,m=i.memoizedState,h.parent!==c?(h={parent:c,cache:c},i.memoizedState=h,i.lanes===0&&(i.memoizedState=i.updateQueue.baseState=h),fs(i,qn,c)):(c=m.cache,fs(i,qn,c),c!==h.cache&&rp(i,[qn],s,!0))),di(t,i,i.pendingProps.children,s),i.child;case 29:throw i.pendingProps}throw Error(a(156,i.tag))}function Lr(t){t.flags|=4}function qp(t,i,s,c,h){if((i=(t.mode&32)!==0)&&(i=!1),i){if(t.flags|=16777216,(h&335544128)===h)if(t.stateNode.complete)t.flags|=8192;else if(pS())t.flags|=8192;else throw uo=mf,cp}else t.flags&=-16777217}function Vx(t,i){if(i.type!=="stylesheet"||(i.state.loading&4)!==0)t.flags&=-16777217;else if(t.flags|=16777216,!iy(i))if(pS())t.flags|=8192;else throw uo=mf,cp}function Nf(t,i){i!==null&&(t.flags|=4),t.flags&16384&&(i=t.tag!==22?Ae():536870912,t.lanes|=i,_l|=i)}function Ic(t,i){if(!kt)switch(t.tailMode){case"hidden":i=t.tail;for(var s=null;i!==null;)i.alternate!==null&&(s=i),i=i.sibling;s===null?t.tail=null:s.sibling=null;break;case"collapsed":s=t.tail;for(var c=null;s!==null;)s.alternate!==null&&(c=s),s=s.sibling;c===null?i||t.tail===null?t.tail=null:t.tail.sibling=null:c.sibling=null}}function An(t){var i=t.alternate!==null&&t.alternate.child===t.child,s=0,c=0;if(i)for(var h=t.child;h!==null;)s|=h.lanes|h.childLanes,c|=h.subtreeFlags&65011712,c|=h.flags&65011712,h.return=t,h=h.sibling;else for(h=t.child;h!==null;)s|=h.lanes|h.childLanes,c|=h.subtreeFlags,c|=h.flags,h.return=t,h=h.sibling;return t.subtreeFlags|=c,t.childLanes=s,i}function vT(t,i,s){var c=i.pendingProps;switch(ep(i),i.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return An(i),null;case 1:return An(i),null;case 3:return s=i.stateNode,c=null,t!==null&&(c=t.memoizedState.cache),i.memoizedState.cache!==c&&(i.flags|=2048),wr(qn),Ie(),s.pendingContext&&(s.context=s.pendingContext,s.pendingContext=null),(t===null||t.child===null)&&(il(i)?Lr(i):t===null||t.memoizedState.isDehydrated&&(i.flags&256)===0||(i.flags|=1024,np())),An(i),null;case 26:var h=i.type,m=i.memoizedState;return t===null?(Lr(i),m!==null?(An(i),Vx(i,m)):(An(i),qp(i,h,null,c,s))):m?m!==t.memoizedState?(Lr(i),An(i),Vx(i,m)):(An(i),i.flags&=-16777217):(t=t.memoizedProps,t!==c&&Lr(i),An(i),qp(i,h,t,c,s)),null;case 27:if(Ze(i),s=ne.current,h=i.type,t!==null&&i.stateNode!=null)t.memoizedProps!==c&&Lr(i);else{if(!c){if(i.stateNode===null)throw Error(a(166));return An(i),null}t=be.current,il(i)?yv(i):(t=ZS(h,c,s),i.stateNode=t,Lr(i))}return An(i),null;case 5:if(Ze(i),h=i.type,t!==null&&i.stateNode!=null)t.memoizedProps!==c&&Lr(i);else{if(!c){if(i.stateNode===null)throw Error(a(166));return An(i),null}if(m=be.current,il(i))yv(i);else{var b=Yf(ne.current);switch(m){case 1:m=b.createElementNS("http://www.w3.org/2000/svg",h);break;case 2:m=b.createElementNS("http://www.w3.org/1998/Math/MathML",h);break;default:switch(h){case"svg":m=b.createElementNS("http://www.w3.org/2000/svg",h);break;case"math":m=b.createElementNS("http://www.w3.org/1998/Math/MathML",h);break;case"script":m=b.createElement("div"),m.innerHTML="<script><\/script>",m=m.removeChild(m.firstChild);break;case"select":m=typeof c.is=="string"?b.createElement("select",{is:c.is}):b.createElement("select"),c.multiple?m.multiple=!0:c.size&&(m.size=c.size);break;default:m=typeof c.is=="string"?b.createElement(h,{is:c.is}):b.createElement(h)}}m[St]=i,m[Tt]=c;e:for(b=i.child;b!==null;){if(b.tag===5||b.tag===6)m.appendChild(b.stateNode);else if(b.tag!==4&&b.tag!==27&&b.child!==null){b.child.return=b,b=b.child;continue}if(b===i)break e;for(;b.sibling===null;){if(b.return===null||b.return===i)break e;b=b.return}b.sibling.return=b.return,b=b.sibling}i.stateNode=m;e:switch(pi(m,h,c),h){case"button":case"input":case"select":case"textarea":c=!!c.autoFocus;break e;case"img":c=!0;break e;default:c=!1}c&&Lr(i)}}return An(i),qp(i,i.type,t===null?null:t.memoizedProps,i.pendingProps,s),null;case 6:if(t&&i.stateNode!=null)t.memoizedProps!==c&&Lr(i);else{if(typeof c!="string"&&i.stateNode===null)throw Error(a(166));if(t=ne.current,il(i)){if(t=i.stateNode,s=i.memoizedProps,c=null,h=fi,h!==null)switch(h.tag){case 27:case 5:c=h.memoizedProps}t[St]=i,t=!!(t.nodeValue===s||c!==null&&c.suppressHydrationWarning===!0||IS(t.nodeValue,s)),t||us(i,!0)}else t=Yf(t).createTextNode(c),t[St]=i,i.stateNode=t}return An(i),null;case 31:if(s=i.memoizedState,t===null||t.memoizedState!==null){if(c=il(i),s!==null){if(t===null){if(!c)throw Error(a(318));if(t=i.memoizedState,t=t!==null?t.dehydrated:null,!t)throw Error(a(557));t[St]=i}else ro(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;An(i),t=!1}else s=np(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=s),t=!0;if(!t)return i.flags&256?(sa(i),i):(sa(i),null);if((i.flags&128)!==0)throw Error(a(558))}return An(i),null;case 13:if(c=i.memoizedState,t===null||t.memoizedState!==null&&t.memoizedState.dehydrated!==null){if(h=il(i),c!==null&&c.dehydrated!==null){if(t===null){if(!h)throw Error(a(318));if(h=i.memoizedState,h=h!==null?h.dehydrated:null,!h)throw Error(a(317));h[St]=i}else ro(),(i.flags&128)===0&&(i.memoizedState=null),i.flags|=4;An(i),h=!1}else h=np(),t!==null&&t.memoizedState!==null&&(t.memoizedState.hydrationErrors=h),h=!0;if(!h)return i.flags&256?(sa(i),i):(sa(i),null)}return sa(i),(i.flags&128)!==0?(i.lanes=s,i):(s=c!==null,t=t!==null&&t.memoizedState!==null,s&&(c=i.child,h=null,c.alternate!==null&&c.alternate.memoizedState!==null&&c.alternate.memoizedState.cachePool!==null&&(h=c.alternate.memoizedState.cachePool.pool),m=null,c.memoizedState!==null&&c.memoizedState.cachePool!==null&&(m=c.memoizedState.cachePool.pool),m!==h&&(c.flags|=2048)),s!==t&&s&&(i.child.flags|=8192),Nf(i,i.updateQueue),An(i),null);case 4:return Ie(),t===null&&pm(i.stateNode.containerInfo),An(i),null;case 10:return wr(i.type),An(i),null;case 19:if(K(Bn),c=i.memoizedState,c===null)return An(i),null;if(h=(i.flags&128)!==0,m=c.rendering,m===null)if(h)Ic(c,!1);else{if(zn!==0||t!==null&&(t.flags&128)!==0)for(t=i.child;t!==null;){if(m=xf(t),m!==null){for(i.flags|=128,Ic(c,!1),t=m.updateQueue,i.updateQueue=t,Nf(i,t),i.subtreeFlags=0,t=s,s=i.child;s!==null;)_v(s,t),s=s.sibling;return Se(Bn,Bn.current&1|2),kt&&Rr(i,c.treeForkCount),i.child}t=t.sibling}c.tail!==null&&Le()>zf&&(i.flags|=128,h=!0,Ic(c,!1),i.lanes=4194304)}else{if(!h)if(t=xf(m),t!==null){if(i.flags|=128,h=!0,t=t.updateQueue,i.updateQueue=t,Nf(i,t),Ic(c,!0),c.tail===null&&c.tailMode==="hidden"&&!m.alternate&&!kt)return An(i),null}else 2*Le()-c.renderingStartTime>zf&&s!==536870912&&(i.flags|=128,h=!0,Ic(c,!1),i.lanes=4194304);c.isBackwards?(m.sibling=i.child,i.child=m):(t=c.last,t!==null?t.sibling=m:i.child=m,c.last=m)}return c.tail!==null?(t=c.tail,c.rendering=t,c.tail=t.sibling,c.renderingStartTime=Le(),t.sibling=null,s=Bn.current,Se(Bn,h?s&1|2:s&1),kt&&Rr(i,c.treeForkCount),t):(An(i),null);case 22:case 23:return sa(i),mp(),c=i.memoizedState!==null,t!==null?t.memoizedState!==null!==c&&(i.flags|=8192):c&&(i.flags|=8192),c?(s&536870912)!==0&&(i.flags&128)===0&&(An(i),i.subtreeFlags&6&&(i.flags|=8192)):An(i),s=i.updateQueue,s!==null&&Nf(i,s.retryQueue),s=null,t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(s=t.memoizedState.cachePool.pool),c=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(c=i.memoizedState.cachePool.pool),c!==s&&(i.flags|=2048),t!==null&&K(lo),null;case 24:return s=null,t!==null&&(s=t.memoizedState.cache),i.memoizedState.cache!==s&&(i.flags|=2048),wr(qn),An(i),null;case 25:return null;case 30:return null}throw Error(a(156,i.tag))}function xT(t,i){switch(ep(i),i.tag){case 1:return t=i.flags,t&65536?(i.flags=t&-65537|128,i):null;case 3:return wr(qn),Ie(),t=i.flags,(t&65536)!==0&&(t&128)===0?(i.flags=t&-65537|128,i):null;case 26:case 27:case 5:return Ze(i),null;case 31:if(i.memoizedState!==null){if(sa(i),i.alternate===null)throw Error(a(340));ro()}return t=i.flags,t&65536?(i.flags=t&-65537|128,i):null;case 13:if(sa(i),t=i.memoizedState,t!==null&&t.dehydrated!==null){if(i.alternate===null)throw Error(a(340));ro()}return t=i.flags,t&65536?(i.flags=t&-65537|128,i):null;case 19:return K(Bn),null;case 4:return Ie(),null;case 10:return wr(i.type),null;case 22:case 23:return sa(i),mp(),t!==null&&K(lo),t=i.flags,t&65536?(i.flags=t&-65537|128,i):null;case 24:return wr(qn),null;case 25:return null;default:return null}}function kx(t,i){switch(ep(i),i.tag){case 3:wr(qn),Ie();break;case 26:case 27:case 5:Ze(i);break;case 4:Ie();break;case 31:i.memoizedState!==null&&sa(i);break;case 13:sa(i);break;case 19:K(Bn);break;case 10:wr(i.type);break;case 22:case 23:sa(i),mp(),t!==null&&K(lo);break;case 24:wr(qn)}}function Bc(t,i){try{var s=i.updateQueue,c=s!==null?s.lastEffect:null;if(c!==null){var h=c.next;s=h;do{if((s.tag&t)===t){c=void 0;var m=s.create,b=s.inst;c=m(),b.destroy=c}s=s.next}while(s!==h)}}catch(N){on(i,i.return,N)}}function gs(t,i,s){try{var c=i.updateQueue,h=c!==null?c.lastEffect:null;if(h!==null){var m=h.next;c=m;do{if((c.tag&t)===t){var b=c.inst,N=b.destroy;if(N!==void 0){b.destroy=void 0,h=i;var X=s,oe=N;try{oe()}catch(ve){on(h,X,ve)}}}c=c.next}while(c!==m)}}catch(ve){on(i,i.return,ve)}}function Xx(t){var i=t.updateQueue;if(i!==null){var s=t.stateNode;try{Ov(i,s)}catch(c){on(t,t.return,c)}}}function Wx(t,i,s){s.props=po(t.type,t.memoizedProps),s.state=t.memoizedState;try{s.componentWillUnmount()}catch(c){on(t,i,c)}}function Hc(t,i){try{var s=t.ref;if(s!==null){switch(t.tag){case 26:case 27:case 5:var c=t.stateNode;break;case 30:c=t.stateNode;break;default:c=t.stateNode}typeof s=="function"?t.refCleanup=s(c):s.current=c}}catch(h){on(t,i,h)}}function sr(t,i){var s=t.ref,c=t.refCleanup;if(s!==null)if(typeof c=="function")try{c()}catch(h){on(t,i,h)}finally{t.refCleanup=null,t=t.alternate,t!=null&&(t.refCleanup=null)}else if(typeof s=="function")try{s(null)}catch(h){on(t,i,h)}else s.current=null}function qx(t){var i=t.type,s=t.memoizedProps,c=t.stateNode;try{e:switch(i){case"button":case"input":case"select":case"textarea":s.autoFocus&&c.focus();break e;case"img":s.src?c.src=s.src:s.srcSet&&(c.srcset=s.srcSet)}}catch(h){on(t,t.return,h)}}function Yp(t,i,s){try{var c=t.stateNode;GT(c,t.type,s,i),c[Tt]=i}catch(h){on(t,t.return,h)}}function Yx(t){return t.tag===5||t.tag===3||t.tag===26||t.tag===27&&Es(t.type)||t.tag===4}function jp(t){e:for(;;){for(;t.sibling===null;){if(t.return===null||Yx(t.return))return null;t=t.return}for(t.sibling.return=t.return,t=t.sibling;t.tag!==5&&t.tag!==6&&t.tag!==18;){if(t.tag===27&&Es(t.type)||t.flags&2||t.child===null||t.tag===4)continue e;t.child.return=t,t=t.child}if(!(t.flags&2))return t.stateNode}}function Zp(t,i,s){var c=t.tag;if(c===5||c===6)t=t.stateNode,i?(s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s).insertBefore(t,i):(i=s.nodeType===9?s.body:s.nodeName==="HTML"?s.ownerDocument.body:s,i.appendChild(t),s=s._reactRootContainer,s!=null||i.onclick!==null||(i.onclick=Er));else if(c!==4&&(c===27&&Es(t.type)&&(s=t.stateNode,i=null),t=t.child,t!==null))for(Zp(t,i,s),t=t.sibling;t!==null;)Zp(t,i,s),t=t.sibling}function Lf(t,i,s){var c=t.tag;if(c===5||c===6)t=t.stateNode,i?s.insertBefore(t,i):s.appendChild(t);else if(c!==4&&(c===27&&Es(t.type)&&(s=t.stateNode),t=t.child,t!==null))for(Lf(t,i,s),t=t.sibling;t!==null;)Lf(t,i,s),t=t.sibling}function jx(t){var i=t.stateNode,s=t.memoizedProps;try{for(var c=t.type,h=i.attributes;h.length;)i.removeAttributeNode(h[0]);pi(i,c,s),i[St]=t,i[Tt]=s}catch(m){on(t,t.return,m)}}var Or=!1,Zn=!1,Kp=!1,Zx=typeof WeakSet=="function"?WeakSet:Set,si=null;function ST(t,i){if(t=t.containerInfo,gm=eh,t=ov(t),kd(t)){if("selectionStart"in t)var s={start:t.selectionStart,end:t.selectionEnd};else e:{s=(s=t.ownerDocument)&&s.defaultView||window;var c=s.getSelection&&s.getSelection();if(c&&c.rangeCount!==0){s=c.anchorNode;var h=c.anchorOffset,m=c.focusNode;c=c.focusOffset;try{s.nodeType,m.nodeType}catch{s=null;break e}var b=0,N=-1,X=-1,oe=0,ve=0,Me=t,ce=null;t:for(;;){for(var he;Me!==s||h!==0&&Me.nodeType!==3||(N=b+h),Me!==m||c!==0&&Me.nodeType!==3||(X=b+c),Me.nodeType===3&&(b+=Me.nodeValue.length),(he=Me.firstChild)!==null;)ce=Me,Me=he;for(;;){if(Me===t)break t;if(ce===s&&++oe===h&&(N=b),ce===m&&++ve===c&&(X=b),(he=Me.nextSibling)!==null)break;Me=ce,ce=Me.parentNode}Me=he}s=N===-1||X===-1?null:{start:N,end:X}}else s=null}s=s||{start:0,end:0}}else s=null;for(vm={focusedElem:t,selectionRange:s},eh=!1,si=i;si!==null;)if(i=si,t=i.child,(i.subtreeFlags&1028)!==0&&t!==null)t.return=i,si=t;else for(;si!==null;){switch(i=si,m=i.alternate,t=i.flags,i.tag){case 0:if((t&4)!==0&&(t=i.updateQueue,t=t!==null?t.events:null,t!==null))for(s=0;s<t.length;s++)h=t[s],h.ref.impl=h.nextImpl;break;case 11:case 15:break;case 1:if((t&1024)!==0&&m!==null){t=void 0,s=i,h=m.memoizedProps,m=m.memoizedState,c=s.stateNode;try{var $e=po(s.type,h);t=c.getSnapshotBeforeUpdate($e,m),c.__reactInternalSnapshotBeforeUpdate=t}catch(ht){on(s,s.return,ht)}}break;case 3:if((t&1024)!==0){if(t=i.stateNode.containerInfo,s=t.nodeType,s===9)ym(t);else if(s===1)switch(t.nodeName){case"HEAD":case"HTML":case"BODY":ym(t);break;default:t.textContent=""}}break;case 5:case 26:case 27:case 6:case 4:case 17:break;default:if((t&1024)!==0)throw Error(a(163))}if(t=i.sibling,t!==null){t.return=i.return,si=t;break}si=i.return}}function Kx(t,i,s){var c=s.flags;switch(s.tag){case 0:case 11:case 15:Fr(t,s),c&4&&Bc(5,s);break;case 1:if(Fr(t,s),c&4)if(t=s.stateNode,i===null)try{t.componentDidMount()}catch(b){on(s,s.return,b)}else{var h=po(s.type,i.memoizedProps);i=i.memoizedState;try{t.componentDidUpdate(h,i,t.__reactInternalSnapshotBeforeUpdate)}catch(b){on(s,s.return,b)}}c&64&&Xx(s),c&512&&Hc(s,s.return);break;case 3:if(Fr(t,s),c&64&&(t=s.updateQueue,t!==null)){if(i=null,s.child!==null)switch(s.child.tag){case 27:case 5:i=s.child.stateNode;break;case 1:i=s.child.stateNode}try{Ov(t,i)}catch(b){on(s,s.return,b)}}break;case 27:i===null&&c&4&&jx(s);case 26:case 5:Fr(t,s),i===null&&c&4&&qx(s),c&512&&Hc(s,s.return);break;case 12:Fr(t,s);break;case 31:Fr(t,s),c&4&&$x(t,s);break;case 13:Fr(t,s),c&4&&eS(t,s),c&64&&(t=s.memoizedState,t!==null&&(t=t.dehydrated,t!==null&&(s=wT.bind(null,s),ZT(t,s))));break;case 22:if(c=s.memoizedState!==null||Or,!c){i=i!==null&&i.memoizedState!==null||Zn,h=Or;var m=Zn;Or=c,(Zn=i)&&!m?zr(t,s,(s.subtreeFlags&8772)!==0):Fr(t,s),Or=h,Zn=m}break;case 30:break;default:Fr(t,s)}}function Qx(t){var i=t.alternate;i!==null&&(t.alternate=null,Qx(i)),t.child=null,t.deletions=null,t.sibling=null,t.tag===5&&(i=t.stateNode,i!==null&&Nn(i)),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null}var Dn=null,Gi=!1;function Pr(t,i,s){for(s=s.child;s!==null;)Jx(t,i,s),s=s.sibling}function Jx(t,i,s){if(pe&&typeof pe.onCommitFiberUnmount=="function")try{pe.onCommitFiberUnmount(de,s)}catch{}switch(s.tag){case 26:Zn||sr(s,i),Pr(t,i,s),s.memoizedState?s.memoizedState.count--:s.stateNode&&(s=s.stateNode,s.parentNode.removeChild(s));break;case 27:Zn||sr(s,i);var c=Dn,h=Gi;Es(s.type)&&(Dn=s.stateNode,Gi=!1),Pr(t,i,s),Zc(s.stateNode),Dn=c,Gi=h;break;case 5:Zn||sr(s,i);case 6:if(c=Dn,h=Gi,Dn=null,Pr(t,i,s),Dn=c,Gi=h,Dn!==null)if(Gi)try{(Dn.nodeType===9?Dn.body:Dn.nodeName==="HTML"?Dn.ownerDocument.body:Dn).removeChild(s.stateNode)}catch(m){on(s,i,m)}else try{Dn.removeChild(s.stateNode)}catch(m){on(s,i,m)}break;case 18:Dn!==null&&(Gi?(t=Dn,XS(t.nodeType===9?t.body:t.nodeName==="HTML"?t.ownerDocument.body:t,s.stateNode),El(t)):XS(Dn,s.stateNode));break;case 4:c=Dn,h=Gi,Dn=s.stateNode.containerInfo,Gi=!0,Pr(t,i,s),Dn=c,Gi=h;break;case 0:case 11:case 14:case 15:gs(2,s,i),Zn||gs(4,s,i),Pr(t,i,s);break;case 1:Zn||(sr(s,i),c=s.stateNode,typeof c.componentWillUnmount=="function"&&Wx(s,i,c)),Pr(t,i,s);break;case 21:Pr(t,i,s);break;case 22:Zn=(c=Zn)||s.memoizedState!==null,Pr(t,i,s),Zn=c;break;default:Pr(t,i,s)}}function $x(t,i){if(i.memoizedState===null&&(t=i.alternate,t!==null&&(t=t.memoizedState,t!==null))){t=t.dehydrated;try{El(t)}catch(s){on(i,i.return,s)}}}function eS(t,i){if(i.memoizedState===null&&(t=i.alternate,t!==null&&(t=t.memoizedState,t!==null&&(t=t.dehydrated,t!==null))))try{El(t)}catch(s){on(i,i.return,s)}}function yT(t){switch(t.tag){case 31:case 13:case 19:var i=t.stateNode;return i===null&&(i=t.stateNode=new Zx),i;case 22:return t=t.stateNode,i=t._retryCache,i===null&&(i=t._retryCache=new Zx),i;default:throw Error(a(435,t.tag))}}function Of(t,i){var s=yT(t);i.forEach(function(c){if(!s.has(c)){s.add(c);var h=DT.bind(null,t,c);c.then(h,h)}})}function Vi(t,i){var s=i.deletions;if(s!==null)for(var c=0;c<s.length;c++){var h=s[c],m=t,b=i,N=b;e:for(;N!==null;){switch(N.tag){case 27:if(Es(N.type)){Dn=N.stateNode,Gi=!1;break e}break;case 5:Dn=N.stateNode,Gi=!1;break e;case 3:case 4:Dn=N.stateNode.containerInfo,Gi=!0;break e}N=N.return}if(Dn===null)throw Error(a(160));Jx(m,b,h),Dn=null,Gi=!1,m=h.alternate,m!==null&&(m.return=null),h.return=null}if(i.subtreeFlags&13886)for(i=i.child;i!==null;)tS(i,t),i=i.sibling}var qa=null;function tS(t,i){var s=t.alternate,c=t.flags;switch(t.tag){case 0:case 11:case 14:case 15:Vi(i,t),ki(t),c&4&&(gs(3,t,t.return),Bc(3,t),gs(5,t,t.return));break;case 1:Vi(i,t),ki(t),c&512&&(Zn||s===null||sr(s,s.return)),c&64&&Or&&(t=t.updateQueue,t!==null&&(c=t.callbacks,c!==null&&(s=t.shared.hiddenCallbacks,t.shared.hiddenCallbacks=s===null?c:s.concat(c))));break;case 26:var h=qa;if(Vi(i,t),ki(t),c&512&&(Zn||s===null||sr(s,s.return)),c&4){var m=s!==null?s.memoizedState:null;if(c=t.memoizedState,s===null)if(c===null)if(t.stateNode===null){e:{c=t.type,s=t.memoizedProps,h=h.ownerDocument||h;t:switch(c){case"title":m=h.getElementsByTagName("title")[0],(!m||m[Mn]||m[St]||m.namespaceURI==="http://www.w3.org/2000/svg"||m.hasAttribute("itemprop"))&&(m=h.createElement(c),h.head.insertBefore(m,h.querySelector("head > title"))),pi(m,c,s),m[St]=t,Ut(m),c=m;break e;case"link":var b=ty("link","href",h).get(c+(s.href||""));if(b){for(var N=0;N<b.length;N++)if(m=b[N],m.getAttribute("href")===(s.href==null||s.href===""?null:s.href)&&m.getAttribute("rel")===(s.rel==null?null:s.rel)&&m.getAttribute("title")===(s.title==null?null:s.title)&&m.getAttribute("crossorigin")===(s.crossOrigin==null?null:s.crossOrigin)){b.splice(N,1);break t}}m=h.createElement(c),pi(m,c,s),h.head.appendChild(m);break;case"meta":if(b=ty("meta","content",h).get(c+(s.content||""))){for(N=0;N<b.length;N++)if(m=b[N],m.getAttribute("content")===(s.content==null?null:""+s.content)&&m.getAttribute("name")===(s.name==null?null:s.name)&&m.getAttribute("property")===(s.property==null?null:s.property)&&m.getAttribute("http-equiv")===(s.httpEquiv==null?null:s.httpEquiv)&&m.getAttribute("charset")===(s.charSet==null?null:s.charSet)){b.splice(N,1);break t}}m=h.createElement(c),pi(m,c,s),h.head.appendChild(m);break;default:throw Error(a(468,c))}m[St]=t,Ut(m),c=m}t.stateNode=c}else ny(h,t.type,t.stateNode);else t.stateNode=ey(h,c,t.memoizedProps);else m!==c?(m===null?s.stateNode!==null&&(s=s.stateNode,s.parentNode.removeChild(s)):m.count--,c===null?ny(h,t.type,t.stateNode):ey(h,c,t.memoizedProps)):c===null&&t.stateNode!==null&&Yp(t,t.memoizedProps,s.memoizedProps)}break;case 27:Vi(i,t),ki(t),c&512&&(Zn||s===null||sr(s,s.return)),s!==null&&c&4&&Yp(t,t.memoizedProps,s.memoizedProps);break;case 5:if(Vi(i,t),ki(t),c&512&&(Zn||s===null||sr(s,s.return)),t.flags&32){h=t.stateNode;try{na(h,"")}catch($e){on(t,t.return,$e)}}c&4&&t.stateNode!=null&&(h=t.memoizedProps,Yp(t,h,s!==null?s.memoizedProps:h)),c&1024&&(Kp=!0);break;case 6:if(Vi(i,t),ki(t),c&4){if(t.stateNode===null)throw Error(a(162));c=t.memoizedProps,s=t.stateNode;try{s.nodeValue=c}catch($e){on(t,t.return,$e)}}break;case 3:if(Kf=null,h=qa,qa=jf(i.containerInfo),Vi(i,t),qa=h,ki(t),c&4&&s!==null&&s.memoizedState.isDehydrated)try{El(i.containerInfo)}catch($e){on(t,t.return,$e)}Kp&&(Kp=!1,nS(t));break;case 4:c=qa,qa=jf(t.stateNode.containerInfo),Vi(i,t),ki(t),qa=c;break;case 12:Vi(i,t),ki(t);break;case 31:Vi(i,t),ki(t),c&4&&(c=t.updateQueue,c!==null&&(t.updateQueue=null,Of(t,c)));break;case 13:Vi(i,t),ki(t),t.child.flags&8192&&t.memoizedState!==null!=(s!==null&&s.memoizedState!==null)&&(Ff=Le()),c&4&&(c=t.updateQueue,c!==null&&(t.updateQueue=null,Of(t,c)));break;case 22:h=t.memoizedState!==null;var X=s!==null&&s.memoizedState!==null,oe=Or,ve=Zn;if(Or=oe||h,Zn=ve||X,Vi(i,t),Zn=ve,Or=oe,ki(t),c&8192)e:for(i=t.stateNode,i._visibility=h?i._visibility&-2:i._visibility|1,h&&(s===null||X||Or||Zn||mo(t)),s=null,i=t;;){if(i.tag===5||i.tag===26){if(s===null){X=s=i;try{if(m=X.stateNode,h)b=m.style,typeof b.setProperty=="function"?b.setProperty("display","none","important"):b.display="none";else{N=X.stateNode;var Me=X.memoizedProps.style,ce=Me!=null&&Me.hasOwnProperty("display")?Me.display:null;N.style.display=ce==null||typeof ce=="boolean"?"":(""+ce).trim()}}catch($e){on(X,X.return,$e)}}}else if(i.tag===6){if(s===null){X=i;try{X.stateNode.nodeValue=h?"":X.memoizedProps}catch($e){on(X,X.return,$e)}}}else if(i.tag===18){if(s===null){X=i;try{var he=X.stateNode;h?WS(he,!0):WS(X.stateNode,!1)}catch($e){on(X,X.return,$e)}}}else if((i.tag!==22&&i.tag!==23||i.memoizedState===null||i===t)&&i.child!==null){i.child.return=i,i=i.child;continue}if(i===t)break e;for(;i.sibling===null;){if(i.return===null||i.return===t)break e;s===i&&(s=null),i=i.return}s===i&&(s=null),i.sibling.return=i.return,i=i.sibling}c&4&&(c=t.updateQueue,c!==null&&(s=c.retryQueue,s!==null&&(c.retryQueue=null,Of(t,s))));break;case 19:Vi(i,t),ki(t),c&4&&(c=t.updateQueue,c!==null&&(t.updateQueue=null,Of(t,c)));break;case 30:break;case 21:break;default:Vi(i,t),ki(t)}}function ki(t){var i=t.flags;if(i&2){try{for(var s,c=t.return;c!==null;){if(Yx(c)){s=c;break}c=c.return}if(s==null)throw Error(a(160));switch(s.tag){case 27:var h=s.stateNode,m=jp(t);Lf(t,m,h);break;case 5:var b=s.stateNode;s.flags&32&&(na(b,""),s.flags&=-33);var N=jp(t);Lf(t,N,b);break;case 3:case 4:var X=s.stateNode.containerInfo,oe=jp(t);Zp(t,oe,X);break;default:throw Error(a(161))}}catch(ve){on(t,t.return,ve)}t.flags&=-3}i&4096&&(t.flags&=-4097)}function nS(t){if(t.subtreeFlags&1024)for(t=t.child;t!==null;){var i=t;nS(i),i.tag===5&&i.flags&1024&&i.stateNode.reset(),t=t.sibling}}function Fr(t,i){if(i.subtreeFlags&8772)for(i=i.child;i!==null;)Kx(t,i.alternate,i),i=i.sibling}function mo(t){for(t=t.child;t!==null;){var i=t;switch(i.tag){case 0:case 11:case 14:case 15:gs(4,i,i.return),mo(i);break;case 1:sr(i,i.return);var s=i.stateNode;typeof s.componentWillUnmount=="function"&&Wx(i,i.return,s),mo(i);break;case 27:Zc(i.stateNode);case 26:case 5:sr(i,i.return),mo(i);break;case 22:i.memoizedState===null&&mo(i);break;case 30:mo(i);break;default:mo(i)}t=t.sibling}}function zr(t,i,s){for(s=s&&(i.subtreeFlags&8772)!==0,i=i.child;i!==null;){var c=i.alternate,h=t,m=i,b=m.flags;switch(m.tag){case 0:case 11:case 15:zr(h,m,s),Bc(4,m);break;case 1:if(zr(h,m,s),c=m,h=c.stateNode,typeof h.componentDidMount=="function")try{h.componentDidMount()}catch(oe){on(c,c.return,oe)}if(c=m,h=c.updateQueue,h!==null){var N=c.stateNode;try{var X=h.shared.hiddenCallbacks;if(X!==null)for(h.shared.hiddenCallbacks=null,h=0;h<X.length;h++)Lv(X[h],N)}catch(oe){on(c,c.return,oe)}}s&&b&64&&Xx(m),Hc(m,m.return);break;case 27:jx(m);case 26:case 5:zr(h,m,s),s&&c===null&&b&4&&qx(m),Hc(m,m.return);break;case 12:zr(h,m,s);break;case 31:zr(h,m,s),s&&b&4&&$x(h,m);break;case 13:zr(h,m,s),s&&b&4&&eS(h,m);break;case 22:m.memoizedState===null&&zr(h,m,s),Hc(m,m.return);break;case 30:break;default:zr(h,m,s)}i=i.sibling}}function Qp(t,i){var s=null;t!==null&&t.memoizedState!==null&&t.memoizedState.cachePool!==null&&(s=t.memoizedState.cachePool.pool),t=null,i.memoizedState!==null&&i.memoizedState.cachePool!==null&&(t=i.memoizedState.cachePool.pool),t!==s&&(t!=null&&t.refCount++,s!=null&&Ac(s))}function Jp(t,i){t=null,i.alternate!==null&&(t=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==t&&(i.refCount++,t!=null&&Ac(t))}function Ya(t,i,s,c){if(i.subtreeFlags&10256)for(i=i.child;i!==null;)iS(t,i,s,c),i=i.sibling}function iS(t,i,s,c){var h=i.flags;switch(i.tag){case 0:case 11:case 15:Ya(t,i,s,c),h&2048&&Bc(9,i);break;case 1:Ya(t,i,s,c);break;case 3:Ya(t,i,s,c),h&2048&&(t=null,i.alternate!==null&&(t=i.alternate.memoizedState.cache),i=i.memoizedState.cache,i!==t&&(i.refCount++,t!=null&&Ac(t)));break;case 12:if(h&2048){Ya(t,i,s,c),t=i.stateNode;try{var m=i.memoizedProps,b=m.id,N=m.onPostCommit;typeof N=="function"&&N(b,i.alternate===null?"mount":"update",t.passiveEffectDuration,-0)}catch(X){on(i,i.return,X)}}else Ya(t,i,s,c);break;case 31:Ya(t,i,s,c);break;case 13:Ya(t,i,s,c);break;case 23:break;case 22:m=i.stateNode,b=i.alternate,i.memoizedState!==null?m._visibility&2?Ya(t,i,s,c):Gc(t,i):m._visibility&2?Ya(t,i,s,c):(m._visibility|=2,dl(t,i,s,c,(i.subtreeFlags&10256)!==0||!1)),h&2048&&Qp(b,i);break;case 24:Ya(t,i,s,c),h&2048&&Jp(i.alternate,i);break;default:Ya(t,i,s,c)}}function dl(t,i,s,c,h){for(h=h&&((i.subtreeFlags&10256)!==0||!1),i=i.child;i!==null;){var m=t,b=i,N=s,X=c,oe=b.flags;switch(b.tag){case 0:case 11:case 15:dl(m,b,N,X,h),Bc(8,b);break;case 23:break;case 22:var ve=b.stateNode;b.memoizedState!==null?ve._visibility&2?dl(m,b,N,X,h):Gc(m,b):(ve._visibility|=2,dl(m,b,N,X,h)),h&&oe&2048&&Qp(b.alternate,b);break;case 24:dl(m,b,N,X,h),h&&oe&2048&&Jp(b.alternate,b);break;default:dl(m,b,N,X,h)}i=i.sibling}}function Gc(t,i){if(i.subtreeFlags&10256)for(i=i.child;i!==null;){var s=t,c=i,h=c.flags;switch(c.tag){case 22:Gc(s,c),h&2048&&Qp(c.alternate,c);break;case 24:Gc(s,c),h&2048&&Jp(c.alternate,c);break;default:Gc(s,c)}i=i.sibling}}var Vc=8192;function pl(t,i,s){if(t.subtreeFlags&Vc)for(t=t.child;t!==null;)aS(t,i,s),t=t.sibling}function aS(t,i,s){switch(t.tag){case 26:pl(t,i,s),t.flags&Vc&&t.memoizedState!==null&&oA(s,qa,t.memoizedState,t.memoizedProps);break;case 5:pl(t,i,s);break;case 3:case 4:var c=qa;qa=jf(t.stateNode.containerInfo),pl(t,i,s),qa=c;break;case 22:t.memoizedState===null&&(c=t.alternate,c!==null&&c.memoizedState!==null?(c=Vc,Vc=16777216,pl(t,i,s),Vc=c):pl(t,i,s));break;default:pl(t,i,s)}}function rS(t){var i=t.alternate;if(i!==null&&(t=i.child,t!==null)){i.child=null;do i=t.sibling,t.sibling=null,t=i;while(t!==null)}}function kc(t){var i=t.deletions;if((t.flags&16)!==0){if(i!==null)for(var s=0;s<i.length;s++){var c=i[s];si=c,oS(c,t)}rS(t)}if(t.subtreeFlags&10256)for(t=t.child;t!==null;)sS(t),t=t.sibling}function sS(t){switch(t.tag){case 0:case 11:case 15:kc(t),t.flags&2048&&gs(9,t,t.return);break;case 3:kc(t);break;case 12:kc(t);break;case 22:var i=t.stateNode;t.memoizedState!==null&&i._visibility&2&&(t.return===null||t.return.tag!==13)?(i._visibility&=-3,Pf(t)):kc(t);break;default:kc(t)}}function Pf(t){var i=t.deletions;if((t.flags&16)!==0){if(i!==null)for(var s=0;s<i.length;s++){var c=i[s];si=c,oS(c,t)}rS(t)}for(t=t.child;t!==null;){switch(i=t,i.tag){case 0:case 11:case 15:gs(8,i,i.return),Pf(i);break;case 22:s=i.stateNode,s._visibility&2&&(s._visibility&=-3,Pf(i));break;default:Pf(i)}t=t.sibling}}function oS(t,i){for(;si!==null;){var s=si;switch(s.tag){case 0:case 11:case 15:gs(8,s,i);break;case 23:case 22:if(s.memoizedState!==null&&s.memoizedState.cachePool!==null){var c=s.memoizedState.cachePool.pool;c!=null&&c.refCount++}break;case 24:Ac(s.memoizedState.cache)}if(c=s.child,c!==null)c.return=s,si=c;else e:for(s=t;si!==null;){c=si;var h=c.sibling,m=c.return;if(Qx(c),c===s){si=null;break e}if(h!==null){h.return=m,si=h;break e}si=m}}}var MT={getCacheForType:function(t){var i=hi(qn),s=i.data.get(t);return s===void 0&&(s=t(),i.data.set(t,s)),s},cacheSignal:function(){return hi(qn).controller.signal}},bT=typeof WeakMap=="function"?WeakMap:Map,$t=0,vn=null,Bt=null,Gt=0,sn=0,oa=null,vs=!1,ml=!1,$p=!1,Ir=0,zn=0,xs=0,_o=0,em=0,la=0,_l=0,Xc=null,Xi=null,tm=!1,Ff=0,lS=0,zf=1/0,If=null,Ss=null,ei=0,ys=null,gl=null,Br=0,nm=0,im=null,cS=null,Wc=0,am=null;function ca(){return($t&2)!==0&&Gt!==0?Gt&-Gt:z.T!==null?um():Ct()}function uS(){if(la===0)if((Gt&536870912)===0||kt){var t=dt;dt<<=1,(dt&3932160)===0&&(dt=262144),la=t}else la=536870912;return t=ra.current,t!==null&&(t.flags|=32),la}function Wi(t,i,s){(t===vn&&(sn===2||sn===9)||t.cancelPendingCommit!==null)&&(vl(t,0),Ms(t,Gt,la,!1)),Ne(t,s),(($t&2)===0||t!==vn)&&(t===vn&&(($t&2)===0&&(_o|=s),zn===4&&Ms(t,Gt,la,!1)),or(t))}function fS(t,i,s){if(($t&6)!==0)throw Error(a(327));var c=!s&&(i&127)===0&&(i&t.expiredLanes)===0||Ve(t,i),h=c?AT(t,i):sm(t,i,!0),m=c;do{if(h===0){ml&&!c&&Ms(t,i,0,!1);break}else{if(s=t.current.alternate,m&&!ET(s)){h=sm(t,i,!1),m=!1;continue}if(h===2){if(m=i,t.errorRecoveryDisabledLanes&m)var b=0;else b=t.pendingLanes&-536870913,b=b!==0?b:b&536870912?536870912:0;if(b!==0){i=b;e:{var N=t;h=Xc;var X=N.current.memoizedState.isDehydrated;if(X&&(vl(N,b).flags|=256),b=sm(N,b,!1),b!==2){if($p&&!X){N.errorRecoveryDisabledLanes|=m,_o|=m,h=4;break e}m=Xi,Xi=h,m!==null&&(Xi===null?Xi=m:Xi.push.apply(Xi,m))}h=b}if(m=!1,h!==2)continue}}if(h===1){vl(t,0),Ms(t,i,0,!0);break}e:{switch(c=t,m=h,m){case 0:case 1:throw Error(a(345));case 4:if((i&4194048)!==i)break;case 6:Ms(c,i,la,!vs);break e;case 2:Xi=null;break;case 3:case 5:break;default:throw Error(a(329))}if((i&62914560)===i&&(h=Ff+300-Le(),10<h)){if(Ms(c,i,la,!vs),me(c,0,!0)!==0)break e;Br=i,c.timeoutHandle=VS(hS.bind(null,c,s,Xi,If,tm,i,la,_o,_l,vs,m,"Throttled",-0,0),h);break e}hS(c,s,Xi,If,tm,i,la,_o,_l,vs,m,null,-0,0)}}break}while(!0);or(t)}function hS(t,i,s,c,h,m,b,N,X,oe,ve,Me,ce,he){if(t.timeoutHandle=-1,Me=i.subtreeFlags,Me&8192||(Me&16785408)===16785408){Me={stylesheets:null,count:0,imgCount:0,imgBytes:0,suspenseyImages:[],waitingForImages:!0,waitingForViewTransition:!1,unsuspend:Er},aS(i,m,Me);var $e=(m&62914560)===m?Ff-Le():(m&4194048)===m?lS-Le():0;if($e=lA(Me,$e),$e!==null){Br=m,t.cancelPendingCommit=$e(SS.bind(null,t,i,m,s,c,h,b,N,X,ve,Me,null,ce,he)),Ms(t,m,b,!oe);return}}SS(t,i,m,s,c,h,b,N,X)}function ET(t){for(var i=t;;){var s=i.tag;if((s===0||s===11||s===15)&&i.flags&16384&&(s=i.updateQueue,s!==null&&(s=s.stores,s!==null)))for(var c=0;c<s.length;c++){var h=s[c],m=h.getSnapshot;h=h.value;try{if(!ia(m(),h))return!1}catch{return!1}}if(s=i.child,i.subtreeFlags&16384&&s!==null)s.return=i,i=s;else{if(i===t)break;for(;i.sibling===null;){if(i.return===null||i.return===t)return!0;i=i.return}i.sibling.return=i.return,i=i.sibling}}return!0}function Ms(t,i,s,c){i&=~em,i&=~_o,t.suspendedLanes|=i,t.pingedLanes&=~i,c&&(t.warmLanes|=i),c=t.expirationTimes;for(var h=i;0<h;){var m=31-He(h),b=1<<m;c[m]=-1,h&=~b}s!==0&&we(t,s,i)}function Bf(){return($t&6)===0?(qc(0),!1):!0}function rm(){if(Bt!==null){if(sn===0)var t=Bt.return;else t=Bt,Cr=so=null,yp(t),ll=null,Cc=0,t=Bt;for(;t!==null;)kx(t.alternate,t),t=t.return;Bt=null}}function vl(t,i){var s=t.timeoutHandle;s!==-1&&(t.timeoutHandle=-1,XT(s)),s=t.cancelPendingCommit,s!==null&&(t.cancelPendingCommit=null,s()),Br=0,rm(),vn=t,Bt=s=Ar(t.current,null),Gt=i,sn=0,oa=null,vs=!1,ml=Ve(t,i),$p=!1,_l=la=em=_o=xs=zn=0,Xi=Xc=null,tm=!1,(i&8)!==0&&(i|=i&32);var c=t.entangledLanes;if(c!==0)for(t=t.entanglements,c&=i;0<c;){var h=31-He(c),m=1<<h;i|=t[h],c&=~m}return Ir=i,sf(),s}function dS(t,i){Rt=null,z.H=Fc,i===ol||i===pf?(i=wv(),sn=3):i===cp?(i=wv(),sn=4):sn=i===zp?8:i!==null&&typeof i=="object"&&typeof i.then=="function"?6:1,oa=i,Bt===null&&(zn=1,Cf(t,Aa(i,t.current)))}function pS(){var t=ra.current;return t===null?!0:(Gt&4194048)===Gt?Da===null:(Gt&62914560)===Gt||(Gt&536870912)!==0?t===Da:!1}function mS(){var t=z.H;return z.H=Fc,t===null?Fc:t}function _S(){var t=z.A;return z.A=MT,t}function Hf(){zn=4,vs||(Gt&4194048)!==Gt&&ra.current!==null||(ml=!0),(xs&134217727)===0&&(_o&134217727)===0||vn===null||Ms(vn,Gt,la,!1)}function sm(t,i,s){var c=$t;$t|=2;var h=mS(),m=_S();(vn!==t||Gt!==i)&&(If=null,vl(t,i)),i=!1;var b=zn;e:do try{if(sn!==0&&Bt!==null){var N=Bt,X=oa;switch(sn){case 8:rm(),b=6;break e;case 3:case 2:case 9:case 6:ra.current===null&&(i=!0);var oe=sn;if(sn=0,oa=null,xl(t,N,X,oe),s&&ml){b=0;break e}break;default:oe=sn,sn=0,oa=null,xl(t,N,X,oe)}}TT(),b=zn;break}catch(ve){dS(t,ve)}while(!0);return i&&t.shellSuspendCounter++,Cr=so=null,$t=c,z.H=h,z.A=m,Bt===null&&(vn=null,Gt=0,sf()),b}function TT(){for(;Bt!==null;)gS(Bt)}function AT(t,i){var s=$t;$t|=2;var c=mS(),h=_S();vn!==t||Gt!==i?(If=null,zf=Le()+500,vl(t,i)):ml=Ve(t,i);e:do try{if(sn!==0&&Bt!==null){i=Bt;var m=oa;t:switch(sn){case 1:sn=0,oa=null,xl(t,i,m,1);break;case 2:case 9:if(Rv(m)){sn=0,oa=null,vS(i);break}i=function(){sn!==2&&sn!==9||vn!==t||(sn=7),or(t)},m.then(i,i);break e;case 3:sn=7;break e;case 4:sn=5;break e;case 7:Rv(m)?(sn=0,oa=null,vS(i)):(sn=0,oa=null,xl(t,i,m,7));break;case 5:var b=null;switch(Bt.tag){case 26:b=Bt.memoizedState;case 5:case 27:var N=Bt;if(b?iy(b):N.stateNode.complete){sn=0,oa=null;var X=N.sibling;if(X!==null)Bt=X;else{var oe=N.return;oe!==null?(Bt=oe,Gf(oe)):Bt=null}break t}}sn=0,oa=null,xl(t,i,m,5);break;case 6:sn=0,oa=null,xl(t,i,m,6);break;case 8:rm(),zn=6;break e;default:throw Error(a(462))}}RT();break}catch(ve){dS(t,ve)}while(!0);return Cr=so=null,z.H=c,z.A=h,$t=s,Bt!==null?0:(vn=null,Gt=0,sf(),zn)}function RT(){for(;Bt!==null&&!mt();)gS(Bt)}function gS(t){var i=Gx(t.alternate,t,Ir);t.memoizedProps=t.pendingProps,i===null?Gf(t):Bt=i}function vS(t){var i=t,s=i.alternate;switch(i.tag){case 15:case 0:i=Px(s,i,i.pendingProps,i.type,void 0,Gt);break;case 11:i=Px(s,i,i.pendingProps,i.type.render,i.ref,Gt);break;case 5:yp(i);default:kx(s,i),i=Bt=_v(i,Ir),i=Gx(s,i,Ir)}t.memoizedProps=t.pendingProps,i===null?Gf(t):Bt=i}function xl(t,i,s,c){Cr=so=null,yp(i),ll=null,Cc=0;var h=i.return;try{if(mT(t,h,i,s,Gt)){zn=1,Cf(t,Aa(s,t.current)),Bt=null;return}}catch(m){if(h!==null)throw Bt=h,m;zn=1,Cf(t,Aa(s,t.current)),Bt=null;return}i.flags&32768?(kt||c===1?t=!0:ml||(Gt&536870912)!==0?t=!1:(vs=t=!0,(c===2||c===9||c===3||c===6)&&(c=ra.current,c!==null&&c.tag===13&&(c.flags|=16384))),xS(i,t)):Gf(i)}function Gf(t){var i=t;do{if((i.flags&32768)!==0){xS(i,vs);return}t=i.return;var s=vT(i.alternate,i,Ir);if(s!==null){Bt=s;return}if(i=i.sibling,i!==null){Bt=i;return}Bt=i=t}while(i!==null);zn===0&&(zn=5)}function xS(t,i){do{var s=xT(t.alternate,t);if(s!==null){s.flags&=32767,Bt=s;return}if(s=t.return,s!==null&&(s.flags|=32768,s.subtreeFlags=0,s.deletions=null),!i&&(t=t.sibling,t!==null)){Bt=t;return}Bt=t=s}while(t!==null);zn=6,Bt=null}function SS(t,i,s,c,h,m,b,N,X){t.cancelPendingCommit=null;do Vf();while(ei!==0);if(($t&6)!==0)throw Error(a(327));if(i!==null){if(i===t.current)throw Error(a(177));if(m=i.lanes|i.childLanes,m|=jd,ot(t,s,m,b,N,X),t===vn&&(Bt=vn=null,Gt=0),gl=i,ys=t,Br=s,nm=m,im=h,cS=c,(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?(t.callbackNode=null,t.callbackPriority=0,UT(Q,function(){return TS(),null})):(t.callbackNode=null,t.callbackPriority=0),c=(i.flags&13878)!==0,(i.subtreeFlags&13878)!==0||c){c=z.T,z.T=null,h=B.p,B.p=2,b=$t,$t|=4;try{ST(t,i,s)}finally{$t=b,B.p=h,z.T=c}}ei=1,yS(),MS(),bS()}}function yS(){if(ei===1){ei=0;var t=ys,i=gl,s=(i.flags&13878)!==0;if((i.subtreeFlags&13878)!==0||s){s=z.T,z.T=null;var c=B.p;B.p=2;var h=$t;$t|=4;try{tS(i,t);var m=vm,b=ov(t.containerInfo),N=m.focusedElem,X=m.selectionRange;if(b!==N&&N&&N.ownerDocument&&sv(N.ownerDocument.documentElement,N)){if(X!==null&&kd(N)){var oe=X.start,ve=X.end;if(ve===void 0&&(ve=oe),"selectionStart"in N)N.selectionStart=oe,N.selectionEnd=Math.min(ve,N.value.length);else{var Me=N.ownerDocument||document,ce=Me&&Me.defaultView||window;if(ce.getSelection){var he=ce.getSelection(),$e=N.textContent.length,ht=Math.min(X.start,$e),dn=X.end===void 0?ht:Math.min(X.end,$e);!he.extend&&ht>dn&&(b=dn,dn=ht,ht=b);var $=rv(N,ht),Y=rv(N,dn);if($&&Y&&(he.rangeCount!==1||he.anchorNode!==$.node||he.anchorOffset!==$.offset||he.focusNode!==Y.node||he.focusOffset!==Y.offset)){var re=Me.createRange();re.setStart($.node,$.offset),he.removeAllRanges(),ht>dn?(he.addRange(re),he.extend(Y.node,Y.offset)):(re.setEnd(Y.node,Y.offset),he.addRange(re))}}}}for(Me=[],he=N;he=he.parentNode;)he.nodeType===1&&Me.push({element:he,left:he.scrollLeft,top:he.scrollTop});for(typeof N.focus=="function"&&N.focus(),N=0;N<Me.length;N++){var ye=Me[N];ye.element.scrollLeft=ye.left,ye.element.scrollTop=ye.top}}eh=!!gm,vm=gm=null}finally{$t=h,B.p=c,z.T=s}}t.current=i,ei=2}}function MS(){if(ei===2){ei=0;var t=ys,i=gl,s=(i.flags&8772)!==0;if((i.subtreeFlags&8772)!==0||s){s=z.T,z.T=null;var c=B.p;B.p=2;var h=$t;$t|=4;try{Kx(t,i.alternate,i)}finally{$t=h,B.p=c,z.T=s}}ei=3}}function bS(){if(ei===4||ei===3){ei=0,Ft();var t=ys,i=gl,s=Br,c=cS;(i.subtreeFlags&10256)!==0||(i.flags&10256)!==0?ei=5:(ei=0,gl=ys=null,ES(t,t.pendingLanes));var h=t.pendingLanes;if(h===0&&(Ss=null),Rn(s),i=i.stateNode,pe&&typeof pe.onCommitFiberRoot=="function")try{pe.onCommitFiberRoot(de,i,void 0,(i.current.flags&128)===128)}catch{}if(c!==null){i=z.T,h=B.p,B.p=2,z.T=null;try{for(var m=t.onRecoverableError,b=0;b<c.length;b++){var N=c[b];m(N.value,{componentStack:N.stack})}}finally{z.T=i,B.p=h}}(Br&3)!==0&&Vf(),or(t),h=t.pendingLanes,(s&261930)!==0&&(h&42)!==0?t===am?Wc++:(Wc=0,am=t):Wc=0,qc(0)}}function ES(t,i){(t.pooledCacheLanes&=i)===0&&(i=t.pooledCache,i!=null&&(t.pooledCache=null,Ac(i)))}function Vf(){return yS(),MS(),bS(),TS()}function TS(){if(ei!==5)return!1;var t=ys,i=nm;nm=0;var s=Rn(Br),c=z.T,h=B.p;try{B.p=32>s?32:s,z.T=null,s=im,im=null;var m=ys,b=Br;if(ei=0,gl=ys=null,Br=0,($t&6)!==0)throw Error(a(331));var N=$t;if($t|=4,sS(m.current),iS(m,m.current,b,s),$t=N,qc(0,!1),pe&&typeof pe.onPostCommitFiberRoot=="function")try{pe.onPostCommitFiberRoot(de,m)}catch{}return!0}finally{B.p=h,z.T=c,ES(t,i)}}function AS(t,i,s){i=Aa(s,i),i=Fp(t.stateNode,i,2),t=ps(t,i,2),t!==null&&(Ne(t,2),or(t))}function on(t,i,s){if(t.tag===3)AS(t,t,s);else for(;i!==null;){if(i.tag===3){AS(i,t,s);break}else if(i.tag===1){var c=i.stateNode;if(typeof i.type.getDerivedStateFromError=="function"||typeof c.componentDidCatch=="function"&&(Ss===null||!Ss.has(c))){t=Aa(s,t),s=Rx(2),c=ps(i,s,2),c!==null&&(Cx(s,c,i,t),Ne(c,2),or(c));break}}i=i.return}}function om(t,i,s){var c=t.pingCache;if(c===null){c=t.pingCache=new bT;var h=new Set;c.set(i,h)}else h=c.get(i),h===void 0&&(h=new Set,c.set(i,h));h.has(s)||($p=!0,h.add(s),t=CT.bind(null,t,i,s),i.then(t,t))}function CT(t,i,s){var c=t.pingCache;c!==null&&c.delete(i),t.pingedLanes|=t.suspendedLanes&s,t.warmLanes&=~s,vn===t&&(Gt&s)===s&&(zn===4||zn===3&&(Gt&62914560)===Gt&&300>Le()-Ff?($t&2)===0&&vl(t,0):em|=s,_l===Gt&&(_l=0)),or(t)}function RS(t,i){i===0&&(i=Ae()),t=io(t,i),t!==null&&(Ne(t,i),or(t))}function wT(t){var i=t.memoizedState,s=0;i!==null&&(s=i.retryLane),RS(t,s)}function DT(t,i){var s=0;switch(t.tag){case 31:case 13:var c=t.stateNode,h=t.memoizedState;h!==null&&(s=h.retryLane);break;case 19:c=t.stateNode;break;case 22:c=t.stateNode._retryCache;break;default:throw Error(a(314))}c!==null&&c.delete(i),RS(t,s)}function UT(t,i){return j(t,i)}var kf=null,Sl=null,lm=!1,Xf=!1,cm=!1,bs=0;function or(t){t!==Sl&&t.next===null&&(Sl===null?kf=Sl=t:Sl=Sl.next=t),Xf=!0,lm||(lm=!0,LT())}function qc(t,i){if(!cm&&Xf){cm=!0;do for(var s=!1,c=kf;c!==null;){if(t!==0){var h=c.pendingLanes;if(h===0)var m=0;else{var b=c.suspendedLanes,N=c.pingedLanes;m=(1<<31-He(42|t)+1)-1,m&=h&~(b&~N),m=m&201326741?m&201326741|1:m?m|2:0}m!==0&&(s=!0,US(c,m))}else m=Gt,m=me(c,c===vn?m:0,c.cancelPendingCommit!==null||c.timeoutHandle!==-1),(m&3)===0||Ve(c,m)||(s=!0,US(c,m));c=c.next}while(s);cm=!1}}function NT(){CS()}function CS(){Xf=lm=!1;var t=0;bs!==0&&kT()&&(t=bs);for(var i=Le(),s=null,c=kf;c!==null;){var h=c.next,m=wS(c,i);m===0?(c.next=null,s===null?kf=h:s.next=h,h===null&&(Sl=s)):(s=c,(t!==0||(m&3)!==0)&&(Xf=!0)),c=h}ei!==0&&ei!==5||qc(t),bs!==0&&(bs=0)}function wS(t,i){for(var s=t.suspendedLanes,c=t.pingedLanes,h=t.expirationTimes,m=t.pendingLanes&-62914561;0<m;){var b=31-He(m),N=1<<b,X=h[b];X===-1?((N&s)===0||(N&c)!==0)&&(h[b]=Pe(N,i)):X<=i&&(t.expiredLanes|=N),m&=~N}if(i=vn,s=Gt,s=me(t,t===i?s:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),c=t.callbackNode,s===0||t===i&&(sn===2||sn===9)||t.cancelPendingCommit!==null)return c!==null&&c!==null&&gt(c),t.callbackNode=null,t.callbackPriority=0;if((s&3)===0||Ve(t,s)){if(i=s&-s,i===t.callbackPriority)return i;switch(c!==null&&gt(c),Rn(s)){case 2:case 8:s=A;break;case 32:s=Q;break;case 268435456:s=Te;break;default:s=Q}return c=DS.bind(null,t),s=j(s,c),t.callbackPriority=i,t.callbackNode=s,i}return c!==null&&c!==null&&gt(c),t.callbackPriority=2,t.callbackNode=null,2}function DS(t,i){if(ei!==0&&ei!==5)return t.callbackNode=null,t.callbackPriority=0,null;var s=t.callbackNode;if(Vf()&&t.callbackNode!==s)return null;var c=Gt;return c=me(t,t===vn?c:0,t.cancelPendingCommit!==null||t.timeoutHandle!==-1),c===0?null:(fS(t,c,i),wS(t,Le()),t.callbackNode!=null&&t.callbackNode===s?DS.bind(null,t):null)}function US(t,i){if(Vf())return null;fS(t,i,!0)}function LT(){WT(function(){($t&6)!==0?j(P,NT):CS()})}function um(){if(bs===0){var t=rl;t===0&&(t=ut,ut<<=1,(ut&261888)===0&&(ut=256)),bs=t}return bs}function NS(t){return t==null||typeof t=="symbol"||typeof t=="boolean"?null:typeof t=="function"?t:$s(""+t)}function LS(t,i){var s=i.ownerDocument.createElement("input");return s.name=i.name,s.value=i.value,t.id&&s.setAttribute("form",t.id),i.parentNode.insertBefore(s,i),t=new FormData(t),s.parentNode.removeChild(s),t}function OT(t,i,s,c,h){if(i==="submit"&&s&&s.stateNode===h){var m=NS((h[Tt]||null).action),b=c.submitter;b&&(i=(i=b[Tt]||null)?NS(i.formAction):b.getAttribute("formAction"),i!==null&&(m=i,b=null));var N=new tf("action","action",null,c,h);t.push({event:N,listeners:[{instance:null,listener:function(){if(c.defaultPrevented){if(bs!==0){var X=b?LS(h,b):new FormData(h);Dp(s,{pending:!0,data:X,method:h.method,action:m},null,X)}}else typeof m=="function"&&(N.preventDefault(),X=b?LS(h,b):new FormData(h),Dp(s,{pending:!0,data:X,method:h.method,action:m},m,X))},currentTarget:h}]})}}for(var fm=0;fm<Yd.length;fm++){var hm=Yd[fm],PT=hm.toLowerCase(),FT=hm[0].toUpperCase()+hm.slice(1);Wa(PT,"on"+FT)}Wa(uv,"onAnimationEnd"),Wa(fv,"onAnimationIteration"),Wa(hv,"onAnimationStart"),Wa("dblclick","onDoubleClick"),Wa("focusin","onFocus"),Wa("focusout","onBlur"),Wa(JE,"onTransitionRun"),Wa($E,"onTransitionStart"),Wa(eT,"onTransitionCancel"),Wa(dv,"onTransitionEnd"),se("onMouseEnter",["mouseout","mouseover"]),se("onMouseLeave",["mouseout","mouseover"]),se("onPointerEnter",["pointerout","pointerover"]),se("onPointerLeave",["pointerout","pointerover"]),Z("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),Z("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),Z("onBeforeInput",["compositionend","keypress","textInput","paste"]),Z("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),Z("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),Z("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Yc="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),zT=new Set("beforetoggle cancel close invalid load scroll scrollend toggle".split(" ").concat(Yc));function OS(t,i){i=(i&4)!==0;for(var s=0;s<t.length;s++){var c=t[s],h=c.event;c=c.listeners;e:{var m=void 0;if(i)for(var b=c.length-1;0<=b;b--){var N=c[b],X=N.instance,oe=N.currentTarget;if(N=N.listener,X!==m&&h.isPropagationStopped())break e;m=N,h.currentTarget=oe;try{m(h)}catch(ve){rf(ve)}h.currentTarget=null,m=X}else for(b=0;b<c.length;b++){if(N=c[b],X=N.instance,oe=N.currentTarget,N=N.listener,X!==m&&h.isPropagationStopped())break e;m=N,h.currentTarget=oe;try{m(h)}catch(ve){rf(ve)}h.currentTarget=null,m=X}}}}function Ht(t,i){var s=i[Xn];s===void 0&&(s=i[Xn]=new Set);var c=t+"__bubble";s.has(c)||(PS(i,t,2,!1),s.add(c))}function dm(t,i,s){var c=0;i&&(c|=4),PS(s,t,c,i)}var Wf="_reactListening"+Math.random().toString(36).slice(2);function pm(t){if(!t[Wf]){t[Wf]=!0,Di.forEach(function(s){s!=="selectionchange"&&(zT.has(s)||dm(s,!1,t),dm(s,!0,t))});var i=t.nodeType===9?t:t.ownerDocument;i===null||i[Wf]||(i[Wf]=!0,dm("selectionchange",!1,i))}}function PS(t,i,s,c){switch(uy(i)){case 2:var h=fA;break;case 8:h=hA;break;default:h=wm}s=h.bind(null,i,s,t),h=void 0,!Od||i!=="touchstart"&&i!=="touchmove"&&i!=="wheel"||(h=!0),c?h!==void 0?t.addEventListener(i,s,{capture:!0,passive:h}):t.addEventListener(i,s,!0):h!==void 0?t.addEventListener(i,s,{passive:h}):t.addEventListener(i,s,!1)}function mm(t,i,s,c,h){var m=c;if((i&1)===0&&(i&2)===0&&c!==null)e:for(;;){if(c===null)return;var b=c.tag;if(b===3||b===4){var N=c.stateNode.containerInfo;if(N===h)break;if(b===4)for(b=c.return;b!==null;){var X=b.tag;if((X===3||X===4)&&b.stateNode.containerInfo===h)return;b=b.return}for(;N!==null;){if(b=bn(N),b===null)return;if(X=b.tag,X===5||X===6||X===26||X===27){c=m=b;continue e}N=N.parentNode}}c=c.return}Hg(function(){var oe=m,ve=Nd(s),Me=[];e:{var ce=pv.get(t);if(ce!==void 0){var he=tf,$e=t;switch(t){case"keypress":if($u(s)===0)break e;case"keydown":case"keyup":he=DE;break;case"focusin":$e="focus",he=Id;break;case"focusout":$e="blur",he=Id;break;case"beforeblur":case"afterblur":he=Id;break;case"click":if(s.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":he=kg;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":he=vE;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":he=LE;break;case uv:case fv:case hv:he=yE;break;case dv:he=PE;break;case"scroll":case"scrollend":he=_E;break;case"wheel":he=zE;break;case"copy":case"cut":case"paste":he=bE;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":he=Wg;break;case"toggle":case"beforetoggle":he=BE}var ht=(i&4)!==0,dn=!ht&&(t==="scroll"||t==="scrollend"),$=ht?ce!==null?ce+"Capture":null:ce;ht=[];for(var Y=oe,re;Y!==null;){var ye=Y;if(re=ye.stateNode,ye=ye.tag,ye!==5&&ye!==26&&ye!==27||re===null||$===null||(ye=mc(Y,$),ye!=null&&ht.push(jc(Y,ye,re))),dn)break;Y=Y.return}0<ht.length&&(ce=new he(ce,$e,null,s,ve),Me.push({event:ce,listeners:ht}))}}if((i&7)===0){e:{if(ce=t==="mouseover"||t==="pointerover",he=t==="mouseout"||t==="pointerout",ce&&s!==Ud&&($e=s.relatedTarget||s.fromElement)&&(bn($e)||$e[zt]))break e;if((he||ce)&&(ce=ve.window===ve?ve:(ce=ve.ownerDocument)?ce.defaultView||ce.parentWindow:window,he?($e=s.relatedTarget||s.toElement,he=oe,$e=$e?bn($e):null,$e!==null&&(dn=l($e),ht=$e.tag,$e!==dn||ht!==5&&ht!==27&&ht!==6)&&($e=null)):(he=null,$e=oe),he!==$e)){if(ht=kg,ye="onMouseLeave",$="onMouseEnter",Y="mouse",(t==="pointerout"||t==="pointerover")&&(ht=Wg,ye="onPointerLeave",$="onPointerEnter",Y="pointer"),dn=he==null?ce:Ea(he),re=$e==null?ce:Ea($e),ce=new ht(ye,Y+"leave",he,s,ve),ce.target=dn,ce.relatedTarget=re,ye=null,bn(ve)===oe&&(ht=new ht($,Y+"enter",$e,s,ve),ht.target=re,ht.relatedTarget=dn,ye=ht),dn=ye,he&&$e)t:{for(ht=IT,$=he,Y=$e,re=0,ye=$;ye;ye=ht(ye))re++;ye=0;for(var ct=Y;ct;ct=ht(ct))ye++;for(;0<re-ye;)$=ht($),re--;for(;0<ye-re;)Y=ht(Y),ye--;for(;re--;){if($===Y||Y!==null&&$===Y.alternate){ht=$;break t}$=ht($),Y=ht(Y)}ht=null}else ht=null;he!==null&&FS(Me,ce,he,ht,!1),$e!==null&&dn!==null&&FS(Me,dn,$e,ht,!0)}}e:{if(ce=oe?Ea(oe):window,he=ce.nodeName&&ce.nodeName.toLowerCase(),he==="select"||he==="input"&&ce.type==="file")var Kt=$g;else if(Qg(ce))if(ev)Kt=ZE;else{Kt=YE;var tt=qE}else he=ce.nodeName,!he||he.toLowerCase()!=="input"||ce.type!=="checkbox"&&ce.type!=="radio"?oe&&en(oe.elementType)&&(Kt=$g):Kt=jE;if(Kt&&(Kt=Kt(t,oe))){Jg(Me,Kt,s,ve);break e}tt&&tt(t,ce,oe),t==="focusout"&&oe&&ce.type==="number"&&oe.memoizedProps.value!=null&&It(ce,"number",ce.value)}switch(tt=oe?Ea(oe):window,t){case"focusin":(Qg(tt)||tt.contentEditable==="true")&&(Qo=tt,Xd=oe,bc=null);break;case"focusout":bc=Xd=Qo=null;break;case"mousedown":Wd=!0;break;case"contextmenu":case"mouseup":case"dragend":Wd=!1,lv(Me,s,ve);break;case"selectionchange":if(QE)break;case"keydown":case"keyup":lv(Me,s,ve)}var wt;if(Hd)e:{switch(t){case"compositionstart":var Vt="onCompositionStart";break e;case"compositionend":Vt="onCompositionEnd";break e;case"compositionupdate":Vt="onCompositionUpdate";break e}Vt=void 0}else Ko?Zg(t,s)&&(Vt="onCompositionEnd"):t==="keydown"&&s.keyCode===229&&(Vt="onCompositionStart");Vt&&(qg&&s.locale!=="ko"&&(Ko||Vt!=="onCompositionStart"?Vt==="onCompositionEnd"&&Ko&&(wt=Gg()):(os=ve,Pd="value"in os?os.value:os.textContent,Ko=!0)),tt=qf(oe,Vt),0<tt.length&&(Vt=new Xg(Vt,t,null,s,ve),Me.push({event:Vt,listeners:tt}),wt?Vt.data=wt:(wt=Kg(s),wt!==null&&(Vt.data=wt)))),(wt=GE?VE(t,s):kE(t,s))&&(Vt=qf(oe,"onBeforeInput"),0<Vt.length&&(tt=new Xg("onBeforeInput","beforeinput",null,s,ve),Me.push({event:tt,listeners:Vt}),tt.data=wt)),OT(Me,t,oe,s,ve)}OS(Me,i)})}function jc(t,i,s){return{instance:t,listener:i,currentTarget:s}}function qf(t,i){for(var s=i+"Capture",c=[];t!==null;){var h=t,m=h.stateNode;if(h=h.tag,h!==5&&h!==26&&h!==27||m===null||(h=mc(t,s),h!=null&&c.unshift(jc(t,h,m)),h=mc(t,i),h!=null&&c.push(jc(t,h,m))),t.tag===3)return c;t=t.return}return[]}function IT(t){if(t===null)return null;do t=t.return;while(t&&t.tag!==5&&t.tag!==27);return t||null}function FS(t,i,s,c,h){for(var m=i._reactName,b=[];s!==null&&s!==c;){var N=s,X=N.alternate,oe=N.stateNode;if(N=N.tag,X!==null&&X===c)break;N!==5&&N!==26&&N!==27||oe===null||(X=oe,h?(oe=mc(s,m),oe!=null&&b.unshift(jc(s,oe,X))):h||(oe=mc(s,m),oe!=null&&b.push(jc(s,oe,X)))),s=s.return}b.length!==0&&t.push({event:i,listeners:b})}var BT=/\r\n?/g,HT=/\u0000|\uFFFD/g;function zS(t){return(typeof t=="string"?t:""+t).replace(BT,`
`).replace(HT,"")}function IS(t,i){return i=zS(i),zS(t)===i}function hn(t,i,s,c,h,m){switch(s){case"children":typeof c=="string"?i==="body"||i==="textarea"&&c===""||na(t,c):(typeof c=="number"||typeof c=="bigint")&&i!=="body"&&na(t,""+c);break;case"className":Je(t,"class",c);break;case"tabIndex":Je(t,"tabindex",c);break;case"dir":case"role":case"viewBox":case"width":case"height":Je(t,s,c);break;case"style":Xa(t,c,m);break;case"data":if(i!=="object"){Je(t,"data",c);break}case"src":case"href":if(c===""&&(i!=="a"||s!=="href")){t.removeAttribute(s);break}if(c==null||typeof c=="function"||typeof c=="symbol"||typeof c=="boolean"){t.removeAttribute(s);break}c=$s(""+c),t.setAttribute(s,c);break;case"action":case"formAction":if(typeof c=="function"){t.setAttribute(s,"javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')");break}else typeof m=="function"&&(s==="formAction"?(i!=="input"&&hn(t,i,"name",h.name,h,null),hn(t,i,"formEncType",h.formEncType,h,null),hn(t,i,"formMethod",h.formMethod,h,null),hn(t,i,"formTarget",h.formTarget,h,null)):(hn(t,i,"encType",h.encType,h,null),hn(t,i,"method",h.method,h,null),hn(t,i,"target",h.target,h,null)));if(c==null||typeof c=="symbol"||typeof c=="boolean"){t.removeAttribute(s);break}c=$s(""+c),t.setAttribute(s,c);break;case"onClick":c!=null&&(t.onclick=Er);break;case"onScroll":c!=null&&Ht("scroll",t);break;case"onScrollEnd":c!=null&&Ht("scrollend",t);break;case"dangerouslySetInnerHTML":if(c!=null){if(typeof c!="object"||!("__html"in c))throw Error(a(61));if(s=c.__html,s!=null){if(h.children!=null)throw Error(a(60));t.innerHTML=s}}break;case"multiple":t.multiple=c&&typeof c!="function"&&typeof c!="symbol";break;case"muted":t.muted=c&&typeof c!="function"&&typeof c!="symbol";break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"defaultValue":case"defaultChecked":case"innerHTML":case"ref":break;case"autoFocus":break;case"xlinkHref":if(c==null||typeof c=="function"||typeof c=="boolean"||typeof c=="symbol"){t.removeAttribute("xlink:href");break}s=$s(""+c),t.setAttributeNS("http://www.w3.org/1999/xlink","xlink:href",s);break;case"contentEditable":case"spellCheck":case"draggable":case"value":case"autoReverse":case"externalResourcesRequired":case"focusable":case"preserveAlpha":c!=null&&typeof c!="function"&&typeof c!="symbol"?t.setAttribute(s,""+c):t.removeAttribute(s);break;case"inert":case"allowFullScreen":case"async":case"autoPlay":case"controls":case"default":case"defer":case"disabled":case"disablePictureInPicture":case"disableRemotePlayback":case"formNoValidate":case"hidden":case"loop":case"noModule":case"noValidate":case"open":case"playsInline":case"readOnly":case"required":case"reversed":case"scoped":case"seamless":case"itemScope":c&&typeof c!="function"&&typeof c!="symbol"?t.setAttribute(s,""):t.removeAttribute(s);break;case"capture":case"download":c===!0?t.setAttribute(s,""):c!==!1&&c!=null&&typeof c!="function"&&typeof c!="symbol"?t.setAttribute(s,c):t.removeAttribute(s);break;case"cols":case"rows":case"size":case"span":c!=null&&typeof c!="function"&&typeof c!="symbol"&&!isNaN(c)&&1<=c?t.setAttribute(s,c):t.removeAttribute(s);break;case"rowSpan":case"start":c==null||typeof c=="function"||typeof c=="symbol"||isNaN(c)?t.removeAttribute(s):t.setAttribute(s,c);break;case"popover":Ht("beforetoggle",t),Ht("toggle",t),Xe(t,"popover",c);break;case"xlinkActuate":Ke(t,"http://www.w3.org/1999/xlink","xlink:actuate",c);break;case"xlinkArcrole":Ke(t,"http://www.w3.org/1999/xlink","xlink:arcrole",c);break;case"xlinkRole":Ke(t,"http://www.w3.org/1999/xlink","xlink:role",c);break;case"xlinkShow":Ke(t,"http://www.w3.org/1999/xlink","xlink:show",c);break;case"xlinkTitle":Ke(t,"http://www.w3.org/1999/xlink","xlink:title",c);break;case"xlinkType":Ke(t,"http://www.w3.org/1999/xlink","xlink:type",c);break;case"xmlBase":Ke(t,"http://www.w3.org/XML/1998/namespace","xml:base",c);break;case"xmlLang":Ke(t,"http://www.w3.org/XML/1998/namespace","xml:lang",c);break;case"xmlSpace":Ke(t,"http://www.w3.org/XML/1998/namespace","xml:space",c);break;case"is":Xe(t,"is",c);break;case"innerText":case"textContent":break;default:(!(2<s.length)||s[0]!=="o"&&s[0]!=="O"||s[1]!=="n"&&s[1]!=="N")&&(s=ir.get(s)||s,Xe(t,s,c))}}function _m(t,i,s,c,h,m){switch(s){case"style":Xa(t,c,m);break;case"dangerouslySetInnerHTML":if(c!=null){if(typeof c!="object"||!("__html"in c))throw Error(a(61));if(s=c.__html,s!=null){if(h.children!=null)throw Error(a(60));t.innerHTML=s}}break;case"children":typeof c=="string"?na(t,c):(typeof c=="number"||typeof c=="bigint")&&na(t,""+c);break;case"onScroll":c!=null&&Ht("scroll",t);break;case"onScrollEnd":c!=null&&Ht("scrollend",t);break;case"onClick":c!=null&&(t.onclick=Er);break;case"suppressContentEditableWarning":case"suppressHydrationWarning":case"innerHTML":case"ref":break;case"innerText":case"textContent":break;default:if(!w.hasOwnProperty(s))e:{if(s[0]==="o"&&s[1]==="n"&&(h=s.endsWith("Capture"),i=s.slice(2,h?s.length-7:void 0),m=t[Tt]||null,m=m!=null?m[s]:null,typeof m=="function"&&t.removeEventListener(i,m,h),typeof c=="function")){typeof m!="function"&&m!==null&&(s in t?t[s]=null:t.hasAttribute(s)&&t.removeAttribute(s)),t.addEventListener(i,c,h);break e}s in t?t[s]=c:c===!0?t.setAttribute(s,""):Xe(t,s,c)}}}function pi(t,i,s){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"img":Ht("error",t),Ht("load",t);var c=!1,h=!1,m;for(m in s)if(s.hasOwnProperty(m)){var b=s[m];if(b!=null)switch(m){case"src":c=!0;break;case"srcSet":h=!0;break;case"children":case"dangerouslySetInnerHTML":throw Error(a(137,i));default:hn(t,i,m,b,s,null)}}h&&hn(t,i,"srcSet",s.srcSet,s,null),c&&hn(t,i,"src",s.src,s,null);return;case"input":Ht("invalid",t);var N=m=b=h=null,X=null,oe=null;for(c in s)if(s.hasOwnProperty(c)){var ve=s[c];if(ve!=null)switch(c){case"name":h=ve;break;case"type":b=ve;break;case"checked":X=ve;break;case"defaultChecked":oe=ve;break;case"value":m=ve;break;case"defaultValue":N=ve;break;case"children":case"dangerouslySetInnerHTML":if(ve!=null)throw Error(a(137,i));break;default:hn(t,i,c,ve,s,null)}}Si(t,m,N,X,oe,b,h,!1);return;case"select":Ht("invalid",t),c=b=m=null;for(h in s)if(s.hasOwnProperty(h)&&(N=s[h],N!=null))switch(h){case"value":m=N;break;case"defaultValue":b=N;break;case"multiple":c=N;default:hn(t,i,h,N,s,null)}i=m,s=b,t.multiple=!!c,i!=null?$n(t,!!c,i,!1):s!=null&&$n(t,!!c,s,!0);return;case"textarea":Ht("invalid",t),m=h=c=null;for(b in s)if(s.hasOwnProperty(b)&&(N=s[b],N!=null))switch(b){case"value":c=N;break;case"defaultValue":h=N;break;case"children":m=N;break;case"dangerouslySetInnerHTML":if(N!=null)throw Error(a(91));break;default:hn(t,i,b,N,s,null)}ka(t,c,h,m);return;case"option":for(X in s)s.hasOwnProperty(X)&&(c=s[X],c!=null)&&(X==="selected"?t.selected=c&&typeof c!="function"&&typeof c!="symbol":hn(t,i,X,c,s,null));return;case"dialog":Ht("beforetoggle",t),Ht("toggle",t),Ht("cancel",t),Ht("close",t);break;case"iframe":case"object":Ht("load",t);break;case"video":case"audio":for(c=0;c<Yc.length;c++)Ht(Yc[c],t);break;case"image":Ht("error",t),Ht("load",t);break;case"details":Ht("toggle",t);break;case"embed":case"source":case"link":Ht("error",t),Ht("load",t);case"area":case"base":case"br":case"col":case"hr":case"keygen":case"meta":case"param":case"track":case"wbr":case"menuitem":for(oe in s)if(s.hasOwnProperty(oe)&&(c=s[oe],c!=null))switch(oe){case"children":case"dangerouslySetInnerHTML":throw Error(a(137,i));default:hn(t,i,oe,c,s,null)}return;default:if(en(i)){for(ve in s)s.hasOwnProperty(ve)&&(c=s[ve],c!==void 0&&_m(t,i,ve,c,s,void 0));return}}for(N in s)s.hasOwnProperty(N)&&(c=s[N],c!=null&&hn(t,i,N,c,s,null))}function GT(t,i,s,c){switch(i){case"div":case"span":case"svg":case"path":case"a":case"g":case"p":case"li":break;case"input":var h=null,m=null,b=null,N=null,X=null,oe=null,ve=null;for(he in s){var Me=s[he];if(s.hasOwnProperty(he)&&Me!=null)switch(he){case"checked":break;case"value":break;case"defaultValue":X=Me;default:c.hasOwnProperty(he)||hn(t,i,he,null,c,Me)}}for(var ce in c){var he=c[ce];if(Me=s[ce],c.hasOwnProperty(ce)&&(he!=null||Me!=null))switch(ce){case"type":m=he;break;case"name":h=he;break;case"checked":oe=he;break;case"defaultChecked":ve=he;break;case"value":b=he;break;case"defaultValue":N=he;break;case"children":case"dangerouslySetInnerHTML":if(he!=null)throw Error(a(137,i));break;default:he!==Me&&hn(t,i,ce,he,c,Me)}}je(t,b,N,X,oe,ve,m,h);return;case"select":he=b=N=ce=null;for(m in s)if(X=s[m],s.hasOwnProperty(m)&&X!=null)switch(m){case"value":break;case"multiple":he=X;default:c.hasOwnProperty(m)||hn(t,i,m,null,c,X)}for(h in c)if(m=c[h],X=s[h],c.hasOwnProperty(h)&&(m!=null||X!=null))switch(h){case"value":ce=m;break;case"defaultValue":N=m;break;case"multiple":b=m;default:m!==X&&hn(t,i,h,m,c,X)}i=N,s=b,c=he,ce!=null?$n(t,!!s,ce,!1):!!c!=!!s&&(i!=null?$n(t,!!s,i,!0):$n(t,!!s,s?[]:"",!1));return;case"textarea":he=ce=null;for(N in s)if(h=s[N],s.hasOwnProperty(N)&&h!=null&&!c.hasOwnProperty(N))switch(N){case"value":break;case"children":break;default:hn(t,i,N,null,c,h)}for(b in c)if(h=c[b],m=s[b],c.hasOwnProperty(b)&&(h!=null||m!=null))switch(b){case"value":ce=h;break;case"defaultValue":he=h;break;case"children":break;case"dangerouslySetInnerHTML":if(h!=null)throw Error(a(91));break;default:h!==m&&hn(t,i,b,h,c,m)}ta(t,ce,he);return;case"option":for(var $e in s)ce=s[$e],s.hasOwnProperty($e)&&ce!=null&&!c.hasOwnProperty($e)&&($e==="selected"?t.selected=!1:hn(t,i,$e,null,c,ce));for(X in c)ce=c[X],he=s[X],c.hasOwnProperty(X)&&ce!==he&&(ce!=null||he!=null)&&(X==="selected"?t.selected=ce&&typeof ce!="function"&&typeof ce!="symbol":hn(t,i,X,ce,c,he));return;case"img":case"link":case"area":case"base":case"br":case"col":case"embed":case"hr":case"keygen":case"meta":case"param":case"source":case"track":case"wbr":case"menuitem":for(var ht in s)ce=s[ht],s.hasOwnProperty(ht)&&ce!=null&&!c.hasOwnProperty(ht)&&hn(t,i,ht,null,c,ce);for(oe in c)if(ce=c[oe],he=s[oe],c.hasOwnProperty(oe)&&ce!==he&&(ce!=null||he!=null))switch(oe){case"children":case"dangerouslySetInnerHTML":if(ce!=null)throw Error(a(137,i));break;default:hn(t,i,oe,ce,c,he)}return;default:if(en(i)){for(var dn in s)ce=s[dn],s.hasOwnProperty(dn)&&ce!==void 0&&!c.hasOwnProperty(dn)&&_m(t,i,dn,void 0,c,ce);for(ve in c)ce=c[ve],he=s[ve],!c.hasOwnProperty(ve)||ce===he||ce===void 0&&he===void 0||_m(t,i,ve,ce,c,he);return}}for(var $ in s)ce=s[$],s.hasOwnProperty($)&&ce!=null&&!c.hasOwnProperty($)&&hn(t,i,$,null,c,ce);for(Me in c)ce=c[Me],he=s[Me],!c.hasOwnProperty(Me)||ce===he||ce==null&&he==null||hn(t,i,Me,ce,c,he)}function BS(t){switch(t){case"css":case"script":case"font":case"img":case"image":case"input":case"link":return!0;default:return!1}}function VT(){if(typeof performance.getEntriesByType=="function"){for(var t=0,i=0,s=performance.getEntriesByType("resource"),c=0;c<s.length;c++){var h=s[c],m=h.transferSize,b=h.initiatorType,N=h.duration;if(m&&N&&BS(b)){for(b=0,N=h.responseEnd,c+=1;c<s.length;c++){var X=s[c],oe=X.startTime;if(oe>N)break;var ve=X.transferSize,Me=X.initiatorType;ve&&BS(Me)&&(X=X.responseEnd,b+=ve*(X<N?1:(N-oe)/(X-oe)))}if(--c,i+=8*(m+b)/(h.duration/1e3),t++,10<t)break}}if(0<t)return i/t/1e6}return navigator.connection&&(t=navigator.connection.downlink,typeof t=="number")?t:5}var gm=null,vm=null;function Yf(t){return t.nodeType===9?t:t.ownerDocument}function HS(t){switch(t){case"http://www.w3.org/2000/svg":return 1;case"http://www.w3.org/1998/Math/MathML":return 2;default:return 0}}function GS(t,i){if(t===0)switch(i){case"svg":return 1;case"math":return 2;default:return 0}return t===1&&i==="foreignObject"?0:t}function xm(t,i){return t==="textarea"||t==="noscript"||typeof i.children=="string"||typeof i.children=="number"||typeof i.children=="bigint"||typeof i.dangerouslySetInnerHTML=="object"&&i.dangerouslySetInnerHTML!==null&&i.dangerouslySetInnerHTML.__html!=null}var Sm=null;function kT(){var t=window.event;return t&&t.type==="popstate"?t===Sm?!1:(Sm=t,!0):(Sm=null,!1)}var VS=typeof setTimeout=="function"?setTimeout:void 0,XT=typeof clearTimeout=="function"?clearTimeout:void 0,kS=typeof Promise=="function"?Promise:void 0,WT=typeof queueMicrotask=="function"?queueMicrotask:typeof kS<"u"?function(t){return kS.resolve(null).then(t).catch(qT)}:VS;function qT(t){setTimeout(function(){throw t})}function Es(t){return t==="head"}function XS(t,i){var s=i,c=0;do{var h=s.nextSibling;if(t.removeChild(s),h&&h.nodeType===8)if(s=h.data,s==="/$"||s==="/&"){if(c===0){t.removeChild(h),El(i);return}c--}else if(s==="$"||s==="$?"||s==="$~"||s==="$!"||s==="&")c++;else if(s==="html")Zc(t.ownerDocument.documentElement);else if(s==="head"){s=t.ownerDocument.head,Zc(s);for(var m=s.firstChild;m;){var b=m.nextSibling,N=m.nodeName;m[Mn]||N==="SCRIPT"||N==="STYLE"||N==="LINK"&&m.rel.toLowerCase()==="stylesheet"||s.removeChild(m),m=b}}else s==="body"&&Zc(t.ownerDocument.body);s=h}while(s);El(i)}function WS(t,i){var s=t;t=0;do{var c=s.nextSibling;if(s.nodeType===1?i?(s._stashedDisplay=s.style.display,s.style.display="none"):(s.style.display=s._stashedDisplay||"",s.getAttribute("style")===""&&s.removeAttribute("style")):s.nodeType===3&&(i?(s._stashedText=s.nodeValue,s.nodeValue=""):s.nodeValue=s._stashedText||""),c&&c.nodeType===8)if(s=c.data,s==="/$"){if(t===0)break;t--}else s!=="$"&&s!=="$?"&&s!=="$~"&&s!=="$!"||t++;s=c}while(s)}function ym(t){var i=t.firstChild;for(i&&i.nodeType===10&&(i=i.nextSibling);i;){var s=i;switch(i=i.nextSibling,s.nodeName){case"HTML":case"HEAD":case"BODY":ym(s),Nn(s);continue;case"SCRIPT":case"STYLE":continue;case"LINK":if(s.rel.toLowerCase()==="stylesheet")continue}t.removeChild(s)}}function YT(t,i,s,c){for(;t.nodeType===1;){var h=s;if(t.nodeName.toLowerCase()!==i.toLowerCase()){if(!c&&(t.nodeName!=="INPUT"||t.type!=="hidden"))break}else if(c){if(!t[Mn])switch(i){case"meta":if(!t.hasAttribute("itemprop"))break;return t;case"link":if(m=t.getAttribute("rel"),m==="stylesheet"&&t.hasAttribute("data-precedence"))break;if(m!==h.rel||t.getAttribute("href")!==(h.href==null||h.href===""?null:h.href)||t.getAttribute("crossorigin")!==(h.crossOrigin==null?null:h.crossOrigin)||t.getAttribute("title")!==(h.title==null?null:h.title))break;return t;case"style":if(t.hasAttribute("data-precedence"))break;return t;case"script":if(m=t.getAttribute("src"),(m!==(h.src==null?null:h.src)||t.getAttribute("type")!==(h.type==null?null:h.type)||t.getAttribute("crossorigin")!==(h.crossOrigin==null?null:h.crossOrigin))&&m&&t.hasAttribute("async")&&!t.hasAttribute("itemprop"))break;return t;default:return t}}else if(i==="input"&&t.type==="hidden"){var m=h.name==null?null:""+h.name;if(h.type==="hidden"&&t.getAttribute("name")===m)return t}else return t;if(t=Ua(t.nextSibling),t===null)break}return null}function jT(t,i,s){if(i==="")return null;for(;t.nodeType!==3;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!s||(t=Ua(t.nextSibling),t===null))return null;return t}function qS(t,i){for(;t.nodeType!==8;)if((t.nodeType!==1||t.nodeName!=="INPUT"||t.type!=="hidden")&&!i||(t=Ua(t.nextSibling),t===null))return null;return t}function Mm(t){return t.data==="$?"||t.data==="$~"}function bm(t){return t.data==="$!"||t.data==="$?"&&t.ownerDocument.readyState!=="loading"}function ZT(t,i){var s=t.ownerDocument;if(t.data==="$~")t._reactRetry=i;else if(t.data!=="$?"||s.readyState!=="loading")i();else{var c=function(){i(),s.removeEventListener("DOMContentLoaded",c)};s.addEventListener("DOMContentLoaded",c),t._reactRetry=c}}function Ua(t){for(;t!=null;t=t.nextSibling){var i=t.nodeType;if(i===1||i===3)break;if(i===8){if(i=t.data,i==="$"||i==="$!"||i==="$?"||i==="$~"||i==="&"||i==="F!"||i==="F")break;if(i==="/$"||i==="/&")return null}}return t}var Em=null;function YS(t){t=t.nextSibling;for(var i=0;t;){if(t.nodeType===8){var s=t.data;if(s==="/$"||s==="/&"){if(i===0)return Ua(t.nextSibling);i--}else s!=="$"&&s!=="$!"&&s!=="$?"&&s!=="$~"&&s!=="&"||i++}t=t.nextSibling}return null}function jS(t){t=t.previousSibling;for(var i=0;t;){if(t.nodeType===8){var s=t.data;if(s==="$"||s==="$!"||s==="$?"||s==="$~"||s==="&"){if(i===0)return t;i--}else s!=="/$"&&s!=="/&"||i++}t=t.previousSibling}return null}function ZS(t,i,s){switch(i=Yf(s),t){case"html":if(t=i.documentElement,!t)throw Error(a(452));return t;case"head":if(t=i.head,!t)throw Error(a(453));return t;case"body":if(t=i.body,!t)throw Error(a(454));return t;default:throw Error(a(451))}}function Zc(t){for(var i=t.attributes;i.length;)t.removeAttributeNode(i[0]);Nn(t)}var Na=new Map,KS=new Set;function jf(t){return typeof t.getRootNode=="function"?t.getRootNode():t.nodeType===9?t:t.ownerDocument}var Hr=B.d;B.d={f:KT,r:QT,D:JT,C:$T,L:eA,m:tA,X:iA,S:nA,M:aA};function KT(){var t=Hr.f(),i=Bf();return t||i}function QT(t){var i=xi(t);i!==null&&i.tag===5&&i.type==="form"?dx(i):Hr.r(t)}var yl=typeof document>"u"?null:document;function QS(t,i,s){var c=yl;if(c&&typeof i=="string"&&i){var h=an(i);h='link[rel="'+t+'"][href="'+h+'"]',typeof s=="string"&&(h+='[crossorigin="'+s+'"]'),KS.has(h)||(KS.add(h),t={rel:t,crossOrigin:s,href:i},c.querySelector(h)===null&&(i=c.createElement("link"),pi(i,"link",t),Ut(i),c.head.appendChild(i)))}}function JT(t){Hr.D(t),QS("dns-prefetch",t,null)}function $T(t,i){Hr.C(t,i),QS("preconnect",t,i)}function eA(t,i,s){Hr.L(t,i,s);var c=yl;if(c&&t&&i){var h='link[rel="preload"][as="'+an(i)+'"]';i==="image"&&s&&s.imageSrcSet?(h+='[imagesrcset="'+an(s.imageSrcSet)+'"]',typeof s.imageSizes=="string"&&(h+='[imagesizes="'+an(s.imageSizes)+'"]')):h+='[href="'+an(t)+'"]';var m=h;switch(i){case"style":m=Ml(t);break;case"script":m=bl(t)}Na.has(m)||(t=v({rel:"preload",href:i==="image"&&s&&s.imageSrcSet?void 0:t,as:i},s),Na.set(m,t),c.querySelector(h)!==null||i==="style"&&c.querySelector(Kc(m))||i==="script"&&c.querySelector(Qc(m))||(i=c.createElement("link"),pi(i,"link",t),Ut(i),c.head.appendChild(i)))}}function tA(t,i){Hr.m(t,i);var s=yl;if(s&&t){var c=i&&typeof i.as=="string"?i.as:"script",h='link[rel="modulepreload"][as="'+an(c)+'"][href="'+an(t)+'"]',m=h;switch(c){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":m=bl(t)}if(!Na.has(m)&&(t=v({rel:"modulepreload",href:t},i),Na.set(m,t),s.querySelector(h)===null)){switch(c){case"audioworklet":case"paintworklet":case"serviceworker":case"sharedworker":case"worker":case"script":if(s.querySelector(Qc(m)))return}c=s.createElement("link"),pi(c,"link",t),Ut(c),s.head.appendChild(c)}}}function nA(t,i,s){Hr.S(t,i,s);var c=yl;if(c&&t){var h=En(c).hoistableStyles,m=Ml(t);i=i||"default";var b=h.get(m);if(!b){var N={loading:0,preload:null};if(b=c.querySelector(Kc(m)))N.loading=5;else{t=v({rel:"stylesheet",href:t,"data-precedence":i},s),(s=Na.get(m))&&Tm(t,s);var X=b=c.createElement("link");Ut(X),pi(X,"link",t),X._p=new Promise(function(oe,ve){X.onload=oe,X.onerror=ve}),X.addEventListener("load",function(){N.loading|=1}),X.addEventListener("error",function(){N.loading|=2}),N.loading|=4,Zf(b,i,c)}b={type:"stylesheet",instance:b,count:1,state:N},h.set(m,b)}}}function iA(t,i){Hr.X(t,i);var s=yl;if(s&&t){var c=En(s).hoistableScripts,h=bl(t),m=c.get(h);m||(m=s.querySelector(Qc(h)),m||(t=v({src:t,async:!0},i),(i=Na.get(h))&&Am(t,i),m=s.createElement("script"),Ut(m),pi(m,"link",t),s.head.appendChild(m)),m={type:"script",instance:m,count:1,state:null},c.set(h,m))}}function aA(t,i){Hr.M(t,i);var s=yl;if(s&&t){var c=En(s).hoistableScripts,h=bl(t),m=c.get(h);m||(m=s.querySelector(Qc(h)),m||(t=v({src:t,async:!0,type:"module"},i),(i=Na.get(h))&&Am(t,i),m=s.createElement("script"),Ut(m),pi(m,"link",t),s.head.appendChild(m)),m={type:"script",instance:m,count:1,state:null},c.set(h,m))}}function JS(t,i,s,c){var h=(h=ne.current)?jf(h):null;if(!h)throw Error(a(446));switch(t){case"meta":case"title":return null;case"style":return typeof s.precedence=="string"&&typeof s.href=="string"?(i=Ml(s.href),s=En(h).hoistableStyles,c=s.get(i),c||(c={type:"style",instance:null,count:0,state:null},s.set(i,c)),c):{type:"void",instance:null,count:0,state:null};case"link":if(s.rel==="stylesheet"&&typeof s.href=="string"&&typeof s.precedence=="string"){t=Ml(s.href);var m=En(h).hoistableStyles,b=m.get(t);if(b||(h=h.ownerDocument||h,b={type:"stylesheet",instance:null,count:0,state:{loading:0,preload:null}},m.set(t,b),(m=h.querySelector(Kc(t)))&&!m._p&&(b.instance=m,b.state.loading=5),Na.has(t)||(s={rel:"preload",as:"style",href:s.href,crossOrigin:s.crossOrigin,integrity:s.integrity,media:s.media,hrefLang:s.hrefLang,referrerPolicy:s.referrerPolicy},Na.set(t,s),m||rA(h,t,s,b.state))),i&&c===null)throw Error(a(528,""));return b}if(i&&c!==null)throw Error(a(529,""));return null;case"script":return i=s.async,s=s.src,typeof s=="string"&&i&&typeof i!="function"&&typeof i!="symbol"?(i=bl(s),s=En(h).hoistableScripts,c=s.get(i),c||(c={type:"script",instance:null,count:0,state:null},s.set(i,c)),c):{type:"void",instance:null,count:0,state:null};default:throw Error(a(444,t))}}function Ml(t){return'href="'+an(t)+'"'}function Kc(t){return'link[rel="stylesheet"]['+t+"]"}function $S(t){return v({},t,{"data-precedence":t.precedence,precedence:null})}function rA(t,i,s,c){t.querySelector('link[rel="preload"][as="style"]['+i+"]")?c.loading=1:(i=t.createElement("link"),c.preload=i,i.addEventListener("load",function(){return c.loading|=1}),i.addEventListener("error",function(){return c.loading|=2}),pi(i,"link",s),Ut(i),t.head.appendChild(i))}function bl(t){return'[src="'+an(t)+'"]'}function Qc(t){return"script[async]"+t}function ey(t,i,s){if(i.count++,i.instance===null)switch(i.type){case"style":var c=t.querySelector('style[data-href~="'+an(s.href)+'"]');if(c)return i.instance=c,Ut(c),c;var h=v({},s,{"data-href":s.href,"data-precedence":s.precedence,href:null,precedence:null});return c=(t.ownerDocument||t).createElement("style"),Ut(c),pi(c,"style",h),Zf(c,s.precedence,t),i.instance=c;case"stylesheet":h=Ml(s.href);var m=t.querySelector(Kc(h));if(m)return i.state.loading|=4,i.instance=m,Ut(m),m;c=$S(s),(h=Na.get(h))&&Tm(c,h),m=(t.ownerDocument||t).createElement("link"),Ut(m);var b=m;return b._p=new Promise(function(N,X){b.onload=N,b.onerror=X}),pi(m,"link",c),i.state.loading|=4,Zf(m,s.precedence,t),i.instance=m;case"script":return m=bl(s.src),(h=t.querySelector(Qc(m)))?(i.instance=h,Ut(h),h):(c=s,(h=Na.get(m))&&(c=v({},s),Am(c,h)),t=t.ownerDocument||t,h=t.createElement("script"),Ut(h),pi(h,"link",c),t.head.appendChild(h),i.instance=h);case"void":return null;default:throw Error(a(443,i.type))}else i.type==="stylesheet"&&(i.state.loading&4)===0&&(c=i.instance,i.state.loading|=4,Zf(c,s.precedence,t));return i.instance}function Zf(t,i,s){for(var c=s.querySelectorAll('link[rel="stylesheet"][data-precedence],style[data-precedence]'),h=c.length?c[c.length-1]:null,m=h,b=0;b<c.length;b++){var N=c[b];if(N.dataset.precedence===i)m=N;else if(m!==h)break}m?m.parentNode.insertBefore(t,m.nextSibling):(i=s.nodeType===9?s.head:s,i.insertBefore(t,i.firstChild))}function Tm(t,i){t.crossOrigin==null&&(t.crossOrigin=i.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=i.referrerPolicy),t.title==null&&(t.title=i.title)}function Am(t,i){t.crossOrigin==null&&(t.crossOrigin=i.crossOrigin),t.referrerPolicy==null&&(t.referrerPolicy=i.referrerPolicy),t.integrity==null&&(t.integrity=i.integrity)}var Kf=null;function ty(t,i,s){if(Kf===null){var c=new Map,h=Kf=new Map;h.set(s,c)}else h=Kf,c=h.get(s),c||(c=new Map,h.set(s,c));if(c.has(t))return c;for(c.set(t,null),s=s.getElementsByTagName(t),h=0;h<s.length;h++){var m=s[h];if(!(m[Mn]||m[St]||t==="link"&&m.getAttribute("rel")==="stylesheet")&&m.namespaceURI!=="http://www.w3.org/2000/svg"){var b=m.getAttribute(i)||"";b=t+b;var N=c.get(b);N?N.push(m):c.set(b,[m])}}return c}function ny(t,i,s){t=t.ownerDocument||t,t.head.insertBefore(s,i==="title"?t.querySelector("head > title"):null)}function sA(t,i,s){if(s===1||i.itemProp!=null)return!1;switch(t){case"meta":case"title":return!0;case"style":if(typeof i.precedence!="string"||typeof i.href!="string"||i.href==="")break;return!0;case"link":if(typeof i.rel!="string"||typeof i.href!="string"||i.href===""||i.onLoad||i.onError)break;return i.rel==="stylesheet"?(t=i.disabled,typeof i.precedence=="string"&&t==null):!0;case"script":if(i.async&&typeof i.async!="function"&&typeof i.async!="symbol"&&!i.onLoad&&!i.onError&&i.src&&typeof i.src=="string")return!0}return!1}function iy(t){return!(t.type==="stylesheet"&&(t.state.loading&3)===0)}function oA(t,i,s,c){if(s.type==="stylesheet"&&(typeof c.media!="string"||matchMedia(c.media).matches!==!1)&&(s.state.loading&4)===0){if(s.instance===null){var h=Ml(c.href),m=i.querySelector(Kc(h));if(m){i=m._p,i!==null&&typeof i=="object"&&typeof i.then=="function"&&(t.count++,t=Qf.bind(t),i.then(t,t)),s.state.loading|=4,s.instance=m,Ut(m);return}m=i.ownerDocument||i,c=$S(c),(h=Na.get(h))&&Tm(c,h),m=m.createElement("link"),Ut(m);var b=m;b._p=new Promise(function(N,X){b.onload=N,b.onerror=X}),pi(m,"link",c),s.instance=m}t.stylesheets===null&&(t.stylesheets=new Map),t.stylesheets.set(s,i),(i=s.state.preload)&&(s.state.loading&3)===0&&(t.count++,s=Qf.bind(t),i.addEventListener("load",s),i.addEventListener("error",s))}}var Rm=0;function lA(t,i){return t.stylesheets&&t.count===0&&$f(t,t.stylesheets),0<t.count||0<t.imgCount?function(s){var c=setTimeout(function(){if(t.stylesheets&&$f(t,t.stylesheets),t.unsuspend){var m=t.unsuspend;t.unsuspend=null,m()}},6e4+i);0<t.imgBytes&&Rm===0&&(Rm=62500*VT());var h=setTimeout(function(){if(t.waitingForImages=!1,t.count===0&&(t.stylesheets&&$f(t,t.stylesheets),t.unsuspend)){var m=t.unsuspend;t.unsuspend=null,m()}},(t.imgBytes>Rm?50:800)+i);return t.unsuspend=s,function(){t.unsuspend=null,clearTimeout(c),clearTimeout(h)}}:null}function Qf(){if(this.count--,this.count===0&&(this.imgCount===0||!this.waitingForImages)){if(this.stylesheets)$f(this,this.stylesheets);else if(this.unsuspend){var t=this.unsuspend;this.unsuspend=null,t()}}}var Jf=null;function $f(t,i){t.stylesheets=null,t.unsuspend!==null&&(t.count++,Jf=new Map,i.forEach(cA,t),Jf=null,Qf.call(t))}function cA(t,i){if(!(i.state.loading&4)){var s=Jf.get(t);if(s)var c=s.get(null);else{s=new Map,Jf.set(t,s);for(var h=t.querySelectorAll("link[data-precedence],style[data-precedence]"),m=0;m<h.length;m++){var b=h[m];(b.nodeName==="LINK"||b.getAttribute("media")!=="not all")&&(s.set(b.dataset.precedence,b),c=b)}c&&s.set(null,c)}h=i.instance,b=h.getAttribute("data-precedence"),m=s.get(b)||c,m===c&&s.set(null,h),s.set(b,h),this.count++,c=Qf.bind(this),h.addEventListener("load",c),h.addEventListener("error",c),m?m.parentNode.insertBefore(h,m.nextSibling):(t=t.nodeType===9?t.head:t,t.insertBefore(h,t.firstChild)),i.state.loading|=4}}var Jc={$$typeof:U,Provider:null,Consumer:null,_currentValue:J,_currentValue2:J,_threadCount:0};function uA(t,i,s,c,h,m,b,N,X){this.tag=1,this.containerInfo=t,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=Ce(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Ce(0),this.hiddenUpdates=Ce(null),this.identifierPrefix=c,this.onUncaughtError=h,this.onCaughtError=m,this.onRecoverableError=b,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=X,this.incompleteTransitions=new Map}function ay(t,i,s,c,h,m,b,N,X,oe,ve,Me){return t=new uA(t,i,s,b,X,oe,ve,Me,N),i=1,m===!0&&(i|=24),m=aa(3,null,null,i),t.current=m,m.stateNode=t,i=sp(),i.refCount++,t.pooledCache=i,i.refCount++,m.memoizedState={element:c,isDehydrated:s,cache:i},up(m),t}function ry(t){return t?(t=el,t):el}function sy(t,i,s,c,h,m){h=ry(h),c.context===null?c.context=h:c.pendingContext=h,c=ds(i),c.payload={element:s},m=m===void 0?null:m,m!==null&&(c.callback=m),s=ps(t,c,i),s!==null&&(Wi(s,t,i),Dc(s,t,i))}function oy(t,i){if(t=t.memoizedState,t!==null&&t.dehydrated!==null){var s=t.retryLane;t.retryLane=s!==0&&s<i?s:i}}function Cm(t,i){oy(t,i),(t=t.alternate)&&oy(t,i)}function ly(t){if(t.tag===13||t.tag===31){var i=io(t,67108864);i!==null&&Wi(i,t,67108864),Cm(t,67108864)}}function cy(t){if(t.tag===13||t.tag===31){var i=ca();i=ft(i);var s=io(t,i);s!==null&&Wi(s,t,i),Cm(t,i)}}var eh=!0;function fA(t,i,s,c){var h=z.T;z.T=null;var m=B.p;try{B.p=2,wm(t,i,s,c)}finally{B.p=m,z.T=h}}function hA(t,i,s,c){var h=z.T;z.T=null;var m=B.p;try{B.p=8,wm(t,i,s,c)}finally{B.p=m,z.T=h}}function wm(t,i,s,c){if(eh){var h=Dm(c);if(h===null)mm(t,i,c,th,s),fy(t,c);else if(pA(h,t,i,s,c))c.stopPropagation();else if(fy(t,c),i&4&&-1<dA.indexOf(t)){for(;h!==null;){var m=xi(h);if(m!==null)switch(m.tag){case 3:if(m=m.stateNode,m.current.memoizedState.isDehydrated){var b=Re(m.pendingLanes);if(b!==0){var N=m;for(N.pendingLanes|=2,N.entangledLanes|=2;b;){var X=1<<31-He(b);N.entanglements[1]|=X,b&=~X}or(m),($t&6)===0&&(zf=Le()+500,qc(0))}}break;case 31:case 13:N=io(m,2),N!==null&&Wi(N,m,2),Bf(),Cm(m,2)}if(m=Dm(c),m===null&&mm(t,i,c,th,s),m===h)break;h=m}h!==null&&c.stopPropagation()}else mm(t,i,c,null,s)}}function Dm(t){return t=Nd(t),Um(t)}var th=null;function Um(t){if(th=null,t=bn(t),t!==null){var i=l(t);if(i===null)t=null;else{var s=i.tag;if(s===13){if(t=u(i),t!==null)return t;t=null}else if(s===31){if(t=f(i),t!==null)return t;t=null}else if(s===3){if(i.stateNode.current.memoizedState.isDehydrated)return i.tag===3?i.stateNode.containerInfo:null;t=null}else i!==t&&(t=null)}}return th=t,null}function uy(t){switch(t){case"beforetoggle":case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"toggle":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 2;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 8;case"message":switch(bt()){case P:return 2;case A:return 8;case Q:case _e:return 32;case Te:return 268435456;default:return 32}default:return 32}}var Nm=!1,Ts=null,As=null,Rs=null,$c=new Map,eu=new Map,Cs=[],dA="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset".split(" ");function fy(t,i){switch(t){case"focusin":case"focusout":Ts=null;break;case"dragenter":case"dragleave":As=null;break;case"mouseover":case"mouseout":Rs=null;break;case"pointerover":case"pointerout":$c.delete(i.pointerId);break;case"gotpointercapture":case"lostpointercapture":eu.delete(i.pointerId)}}function tu(t,i,s,c,h,m){return t===null||t.nativeEvent!==m?(t={blockedOn:i,domEventName:s,eventSystemFlags:c,nativeEvent:m,targetContainers:[h]},i!==null&&(i=xi(i),i!==null&&ly(i)),t):(t.eventSystemFlags|=c,i=t.targetContainers,h!==null&&i.indexOf(h)===-1&&i.push(h),t)}function pA(t,i,s,c,h){switch(i){case"focusin":return Ts=tu(Ts,t,i,s,c,h),!0;case"dragenter":return As=tu(As,t,i,s,c,h),!0;case"mouseover":return Rs=tu(Rs,t,i,s,c,h),!0;case"pointerover":var m=h.pointerId;return $c.set(m,tu($c.get(m)||null,t,i,s,c,h)),!0;case"gotpointercapture":return m=h.pointerId,eu.set(m,tu(eu.get(m)||null,t,i,s,c,h)),!0}return!1}function hy(t){var i=bn(t.target);if(i!==null){var s=l(i);if(s!==null){if(i=s.tag,i===13){if(i=u(s),i!==null){t.blockedOn=i,_n(t.priority,function(){cy(s)});return}}else if(i===31){if(i=f(s),i!==null){t.blockedOn=i,_n(t.priority,function(){cy(s)});return}}else if(i===3&&s.stateNode.current.memoizedState.isDehydrated){t.blockedOn=s.tag===3?s.stateNode.containerInfo:null;return}}}t.blockedOn=null}function nh(t){if(t.blockedOn!==null)return!1;for(var i=t.targetContainers;0<i.length;){var s=Dm(t.nativeEvent);if(s===null){s=t.nativeEvent;var c=new s.constructor(s.type,s);Ud=c,s.target.dispatchEvent(c),Ud=null}else return i=xi(s),i!==null&&ly(i),t.blockedOn=s,!1;i.shift()}return!0}function dy(t,i,s){nh(t)&&s.delete(i)}function mA(){Nm=!1,Ts!==null&&nh(Ts)&&(Ts=null),As!==null&&nh(As)&&(As=null),Rs!==null&&nh(Rs)&&(Rs=null),$c.forEach(dy),eu.forEach(dy)}function ih(t,i){t.blockedOn===i&&(t.blockedOn=null,Nm||(Nm=!0,o.unstable_scheduleCallback(o.unstable_NormalPriority,mA)))}var ah=null;function py(t){ah!==t&&(ah=t,o.unstable_scheduleCallback(o.unstable_NormalPriority,function(){ah===t&&(ah=null);for(var i=0;i<t.length;i+=3){var s=t[i],c=t[i+1],h=t[i+2];if(typeof c!="function"){if(Um(c||s)===null)continue;break}var m=xi(s);m!==null&&(t.splice(i,3),i-=3,Dp(m,{pending:!0,data:h,method:s.method,action:c},c,h))}}))}function El(t){function i(X){return ih(X,t)}Ts!==null&&ih(Ts,t),As!==null&&ih(As,t),Rs!==null&&ih(Rs,t),$c.forEach(i),eu.forEach(i);for(var s=0;s<Cs.length;s++){var c=Cs[s];c.blockedOn===t&&(c.blockedOn=null)}for(;0<Cs.length&&(s=Cs[0],s.blockedOn===null);)hy(s),s.blockedOn===null&&Cs.shift();if(s=(t.ownerDocument||t).$$reactFormReplay,s!=null)for(c=0;c<s.length;c+=3){var h=s[c],m=s[c+1],b=h[Tt]||null;if(typeof m=="function")b||py(s);else if(b){var N=null;if(m&&m.hasAttribute("formAction")){if(h=m,b=m[Tt]||null)N=b.formAction;else if(Um(h)!==null)continue}else N=b.action;typeof N=="function"?s[c+1]=N:(s.splice(c,3),c-=3),py(s)}}}function my(){function t(m){m.canIntercept&&m.info==="react-transition"&&m.intercept({handler:function(){return new Promise(function(b){return h=b})},focusReset:"manual",scroll:"manual"})}function i(){h!==null&&(h(),h=null),c||setTimeout(s,20)}function s(){if(!c&&!navigation.transition){var m=navigation.currentEntry;m&&m.url!=null&&navigation.navigate(m.url,{state:m.getState(),info:"react-transition",history:"replace"})}}if(typeof navigation=="object"){var c=!1,h=null;return navigation.addEventListener("navigate",t),navigation.addEventListener("navigatesuccess",i),navigation.addEventListener("navigateerror",i),setTimeout(s,100),function(){c=!0,navigation.removeEventListener("navigate",t),navigation.removeEventListener("navigatesuccess",i),navigation.removeEventListener("navigateerror",i),h!==null&&(h(),h=null)}}}function Lm(t){this._internalRoot=t}rh.prototype.render=Lm.prototype.render=function(t){var i=this._internalRoot;if(i===null)throw Error(a(409));var s=i.current,c=ca();sy(s,c,t,i,null,null)},rh.prototype.unmount=Lm.prototype.unmount=function(){var t=this._internalRoot;if(t!==null){this._internalRoot=null;var i=t.containerInfo;sy(t.current,2,null,t,null,null),Bf(),i[zt]=null}};function rh(t){this._internalRoot=t}rh.prototype.unstable_scheduleHydration=function(t){if(t){var i=Ct();t={blockedOn:null,target:t,priority:i};for(var s=0;s<Cs.length&&i!==0&&i<Cs[s].priority;s++);Cs.splice(s,0,t),s===0&&hy(t)}};var _y=e.version;if(_y!=="19.2.3")throw Error(a(527,_y,"19.2.3"));B.findDOMNode=function(t){var i=t._reactInternals;if(i===void 0)throw typeof t.render=="function"?Error(a(188)):(t=Object.keys(t).join(","),Error(a(268,t)));return t=p(i),t=t!==null?_(t):null,t=t===null?null:t.stateNode,t};var _A={bundleType:0,version:"19.2.3",rendererPackageName:"react-dom",currentDispatcherRef:z,reconcilerVersion:"19.2.3"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var sh=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!sh.isDisabled&&sh.supportsFiber)try{de=sh.inject(_A),pe=sh}catch{}}return iu.createRoot=function(t,i){if(!r(t))throw Error(a(299));var s=!1,c="",h=bx,m=Ex,b=Tx;return i!=null&&(i.unstable_strictMode===!0&&(s=!0),i.identifierPrefix!==void 0&&(c=i.identifierPrefix),i.onUncaughtError!==void 0&&(h=i.onUncaughtError),i.onCaughtError!==void 0&&(m=i.onCaughtError),i.onRecoverableError!==void 0&&(b=i.onRecoverableError)),i=ay(t,1,!1,null,null,s,c,null,h,m,b,my),t[zt]=i.current,pm(t),new Lm(i)},iu.hydrateRoot=function(t,i,s){if(!r(t))throw Error(a(299));var c=!1,h="",m=bx,b=Ex,N=Tx,X=null;return s!=null&&(s.unstable_strictMode===!0&&(c=!0),s.identifierPrefix!==void 0&&(h=s.identifierPrefix),s.onUncaughtError!==void 0&&(m=s.onUncaughtError),s.onCaughtError!==void 0&&(b=s.onCaughtError),s.onRecoverableError!==void 0&&(N=s.onRecoverableError),s.formState!==void 0&&(X=s.formState)),i=ay(t,1,!0,i,s??null,c,h,X,m,b,N,my),i.context=ry(null),s=i.current,c=ca(),c=ft(c),h=ds(c),h.callback=null,ps(s,h,c),s=c,i.current.lanes=s,Ne(i,s),or(i),t[zt]=i.current,pm(t),new rh(i)},iu.version="19.2.3",iu}var Ay;function AA(){if(Ay)return Pm.exports;Ay=1;function o(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(o)}catch(e){console.error(e)}}return o(),Pm.exports=TA(),Pm.exports}var RA=AA(),pt=Z0();function qr(o){if(o===void 0)throw new ReferenceError("this hasn't been initialised - super() hasn't been called");return o}function f1(o,e){o.prototype=Object.create(e.prototype),o.prototype.constructor=o,o.__proto__=e}var Sa={autoSleep:120,force3D:"auto",nullTargetWarn:1,units:{lineHeight:""}},Fu={duration:.5,overwrite:!1,delay:0},K0,gi,Un,Ba=1e8,Sn=1/Ba,L_=Math.PI*2,CA=L_/4,wA=0,h1=Math.sqrt,DA=Math.cos,UA=Math.sin,ui=function(e){return typeof e=="string"},In=function(e){return typeof e=="function"},ns=function(e){return typeof e=="number"},Q0=function(e){return typeof e>"u"},yr=function(e){return typeof e=="object"},Zi=function(e){return e!==!1},J0=function(){return typeof window<"u"},oh=function(e){return In(e)||ui(e)},d1=typeof ArrayBuffer=="function"&&ArrayBuffer.isView||function(){},wi=Array.isArray,NA=/random\([^)]+\)/g,LA=/,\s*/g,Ry=/(?:-?\.?\d|\.)+/gi,p1=/[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g,Wl=/[-+=.]*\d+[.e-]*\d*[a-z%]*/g,Hm=/[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi,m1=/[+-]=-?[.\d]+/,OA=/[^,'"\[\]\s]+/gi,PA=/^[+\-=e\s\d]*\d+[.\d]*([a-z]*|%)\s*$/i,On,ur,O_,$0,Ma={},ad={},_1,g1=function(e){return(ad=ic(e,Ma))&&ea},eg=function(e,n){return console.warn("Invalid property",e,"set to",n,"Missing plugin? gsap.registerPlugin()")},zu=function(e,n){return!n&&console.warn(e)},v1=function(e,n){return e&&(Ma[e]=n)&&ad&&(ad[e]=n)||Ma},Iu=function(){return 0},FA={suppressEvents:!0,isStart:!0,kill:!1},kh={suppressEvents:!0,kill:!1},zA={suppressEvents:!0},tg={},Xs=[],P_={},x1,pa={},Gm={},Cy=30,Xh=[],ng="",ig=function(e){var n=e[0],a,r;if(yr(n)||In(n)||(e=[e]),!(a=(n._gsap||{}).harness)){for(r=Xh.length;r--&&!Xh[r].targetTest(n););a=Xh[r]}for(r=e.length;r--;)e[r]&&(e[r]._gsap||(e[r]._gsap=new G1(e[r],a)))||e.splice(r,1);return e},Lo=function(e){return e._gsap||ig(Ha(e))[0]._gsap},S1=function(e,n,a){return(a=e[n])&&In(a)?e[n]():Q0(a)&&e.getAttribute&&e.getAttribute(n)||a},Ki=function(e,n){return(e=e.split(",")).forEach(n)||e},Gn=function(e){return Math.round(e*1e5)/1e5||0},Ln=function(e){return Math.round(e*1e7)/1e7||0},jl=function(e,n){var a=n.charAt(0),r=parseFloat(n.substr(2));return e=parseFloat(e),a==="+"?e+r:a==="-"?e-r:a==="*"?e*r:e/r},IA=function(e,n){for(var a=n.length,r=0;e.indexOf(n[r])<0&&++r<a;);return r<a},rd=function(){var e=Xs.length,n=Xs.slice(0),a,r;for(P_={},Xs.length=0,a=0;a<e;a++)r=n[a],r&&r._lazy&&(r.render(r._lazy[0],r._lazy[1],!0)._lazy=0)},ag=function(e){return!!(e._initted||e._startAt||e.add)},y1=function(e,n,a,r){Xs.length&&!gi&&rd(),e.render(n,a,!!(gi&&n<0&&ag(e))),Xs.length&&!gi&&rd()},M1=function(e){var n=parseFloat(e);return(n||n===0)&&(e+"").match(OA).length<2?n:ui(e)?e.trim():e},b1=function(e){return e},ba=function(e,n){for(var a in n)a in e||(e[a]=n[a]);return e},BA=function(e){return function(n,a){for(var r in a)r in n||r==="duration"&&e||r==="ease"||(n[r]=a[r])}},ic=function(e,n){for(var a in n)e[a]=n[a];return e},wy=function o(e,n){for(var a in n)a!=="__proto__"&&a!=="constructor"&&a!=="prototype"&&(e[a]=yr(n[a])?o(e[a]||(e[a]={}),n[a]):n[a]);return e},sd=function(e,n){var a={},r;for(r in e)r in n||(a[r]=e[r]);return a},Eu=function(e){var n=e.parent||On,a=e.keyframes?BA(wi(e.keyframes)):ba;if(Zi(e.inherit))for(;n;)a(e,n.vars.defaults),n=n.parent||n._dp;return e},HA=function(e,n){for(var a=e.length,r=a===n.length;r&&a--&&e[a]===n[a];);return a<0},E1=function(e,n,a,r,l){var u=e[r],f;if(l)for(f=n[l];u&&u[l]>f;)u=u._prev;return u?(n._next=u._next,u._next=n):(n._next=e[a],e[a]=n),n._next?n._next._prev=n:e[r]=n,n._prev=u,n.parent=n._dp=e,n},Md=function(e,n,a,r){a===void 0&&(a="_first"),r===void 0&&(r="_last");var l=n._prev,u=n._next;l?l._next=u:e[a]===n&&(e[a]=u),u?u._prev=l:e[r]===n&&(e[r]=l),n._next=n._prev=n.parent=null},Ys=function(e,n){e.parent&&(!n||e.parent.autoRemoveChildren)&&e.parent.remove&&e.parent.remove(e),e._act=0},Oo=function(e,n){if(e&&(!n||n._end>e._dur||n._start<0))for(var a=e;a;)a._dirty=1,a=a.parent;return e},GA=function(e){for(var n=e.parent;n&&n.parent;)n._dirty=1,n.totalDuration(),n=n.parent;return e},F_=function(e,n,a,r){return e._startAt&&(gi?e._startAt.revert(kh):e.vars.immediateRender&&!e.vars.autoRevert||e._startAt.render(n,!0,r))},VA=function o(e){return!e||e._ts&&o(e.parent)},Dy=function(e){return e._repeat?ac(e._tTime,e=e.duration()+e._rDelay)*e:0},ac=function(e,n){var a=Math.floor(e=Ln(e/n));return e&&a===e?a-1:a},od=function(e,n){return(e-n._start)*n._ts+(n._ts>=0?0:n._dirty?n.totalDuration():n._tDur)},bd=function(e){return e._end=Ln(e._start+(e._tDur/Math.abs(e._ts||e._rts||Sn)||0))},Ed=function(e,n){var a=e._dp;return a&&a.smoothChildTiming&&e._ts&&(e._start=Ln(a._time-(e._ts>0?n/e._ts:((e._dirty?e.totalDuration():e._tDur)-n)/-e._ts)),bd(e),a._dirty||Oo(a,e)),e},T1=function(e,n){var a;if((n._time||!n._dur&&n._initted||n._start<e._time&&(n._dur||!n.add))&&(a=od(e.rawTime(),n),(!n._dur||ju(0,n.totalDuration(),a)-n._tTime>Sn)&&n.render(a,!0)),Oo(e,n)._dp&&e._initted&&e._time>=e._dur&&e._ts){if(e._dur<e.duration())for(a=e;a._dp;)a.rawTime()>=0&&a.totalTime(a._tTime),a=a._dp;e._zTime=-Sn}},dr=function(e,n,a,r){return n.parent&&Ys(n),n._start=Ln((ns(a)?a:a||e!==On?Oa(e,a,n):e._time)+n._delay),n._end=Ln(n._start+(n.totalDuration()/Math.abs(n.timeScale())||0)),E1(e,n,"_first","_last",e._sort?"_start":0),z_(n)||(e._recent=n),r||T1(e,n),e._ts<0&&Ed(e,e._tTime),e},A1=function(e,n){return(Ma.ScrollTrigger||eg("scrollTrigger",n))&&Ma.ScrollTrigger.create(n,e)},R1=function(e,n,a,r,l){if(sg(e,n,l),!e._initted)return 1;if(!a&&e._pt&&!gi&&(e._dur&&e.vars.lazy!==!1||!e._dur&&e.vars.lazy)&&x1!==_a.frame)return Xs.push(e),e._lazy=[l,r],1},kA=function o(e){var n=e.parent;return n&&n._ts&&n._initted&&!n._lock&&(n.rawTime()<0||o(n))},z_=function(e){var n=e.data;return n==="isFromStart"||n==="isStart"},XA=function(e,n,a,r){var l=e.ratio,u=n<0||!n&&(!e._start&&kA(e)&&!(!e._initted&&z_(e))||(e._ts<0||e._dp._ts<0)&&!z_(e))?0:1,f=e._rDelay,d=0,p,_,v;if(f&&e._repeat&&(d=ju(0,e._tDur,n),_=ac(d,f),e._yoyo&&_&1&&(u=1-u),_!==ac(e._tTime,f)&&(l=1-u,e.vars.repeatRefresh&&e._initted&&e.invalidate())),u!==l||gi||r||e._zTime===Sn||!n&&e._zTime){if(!e._initted&&R1(e,n,r,a,d))return;for(v=e._zTime,e._zTime=n||(a?Sn:0),a||(a=n&&!v),e.ratio=u,e._from&&(u=1-u),e._time=0,e._tTime=d,p=e._pt;p;)p.r(u,p.d),p=p._next;n<0&&F_(e,n,a,!0),e._onUpdate&&!a&&va(e,"onUpdate"),d&&e._repeat&&!a&&e.parent&&va(e,"onRepeat"),(n>=e._tDur||n<0)&&e.ratio===u&&(u&&Ys(e,1),!a&&!gi&&(va(e,u?"onComplete":"onReverseComplete",!0),e._prom&&e._prom()))}else e._zTime||(e._zTime=n)},WA=function(e,n,a){var r;if(a>n)for(r=e._first;r&&r._start<=a;){if(r.data==="isPause"&&r._start>n)return r;r=r._next}else for(r=e._last;r&&r._start>=a;){if(r.data==="isPause"&&r._start<n)return r;r=r._prev}},rc=function(e,n,a,r){var l=e._repeat,u=Ln(n)||0,f=e._tTime/e._tDur;return f&&!r&&(e._time*=u/e._dur),e._dur=u,e._tDur=l?l<0?1e10:Ln(u*(l+1)+e._rDelay*l):u,f>0&&!r&&Ed(e,e._tTime=e._tDur*f),e.parent&&bd(e),a||Oo(e.parent,e),e},Uy=function(e){return e instanceof ji?Oo(e):rc(e,e._dur)},qA={_start:0,endTime:Iu,totalDuration:Iu},Oa=function o(e,n,a){var r=e.labels,l=e._recent||qA,u=e.duration()>=Ba?l.endTime(!1):e._dur,f,d,p;return ui(n)&&(isNaN(n)||n in r)?(d=n.charAt(0),p=n.substr(-1)==="%",f=n.indexOf("="),d==="<"||d===">"?(f>=0&&(n=n.replace(/=/,"")),(d==="<"?l._start:l.endTime(l._repeat>=0))+(parseFloat(n.substr(1))||0)*(p?(f<0?l:a).totalDuration()/100:1)):f<0?(n in r||(r[n]=u),r[n]):(d=parseFloat(n.charAt(f-1)+n.substr(f+1)),p&&a&&(d=d/100*(wi(a)?a[0]:a).totalDuration()),f>1?o(e,n.substr(0,f-1),a)+d:u+d)):n==null?u:+n},Tu=function(e,n,a){var r=ns(n[1]),l=(r?2:1)+(e<2?0:1),u=n[l],f,d;if(r&&(u.duration=n[1]),u.parent=a,e){for(f=u,d=a;d&&!("immediateRender"in f);)f=d.vars.defaults||{},d=Zi(d.vars.inherit)&&d.parent;u.immediateRender=Zi(f.immediateRender),e<2?u.runBackwards=1:u.startAt=n[l-1]}return new Jn(n[0],u,n[l+1])},Js=function(e,n){return e||e===0?n(e):n},ju=function(e,n,a){return a<e?e:a>n?n:a},Ai=function(e,n){return!ui(e)||!(n=PA.exec(e))?"":n[1]},YA=function(e,n,a){return Js(a,function(r){return ju(e,n,r)})},I_=[].slice,C1=function(e,n){return e&&yr(e)&&"length"in e&&(!n&&!e.length||e.length-1 in e&&yr(e[0]))&&!e.nodeType&&e!==ur},jA=function(e,n,a){return a===void 0&&(a=[]),e.forEach(function(r){var l;return ui(r)&&!n||C1(r,1)?(l=a).push.apply(l,Ha(r)):a.push(r)})||a},Ha=function(e,n,a){return Un&&!n&&Un.selector?Un.selector(e):ui(e)&&!a&&(O_||!sc())?I_.call((n||$0).querySelectorAll(e),0):wi(e)?jA(e,a):C1(e)?I_.call(e,0):e?[e]:[]},B_=function(e){return e=Ha(e)[0]||zu("Invalid scope")||{},function(n){var a=e.current||e.nativeElement||e;return Ha(n,a.querySelectorAll?a:a===e?zu("Invalid scope")||$0.createElement("div"):e)}},w1=function(e){return e.sort(function(){return .5-Math.random()})},D1=function(e){if(In(e))return e;var n=yr(e)?e:{each:e},a=Po(n.ease),r=n.from||0,l=parseFloat(n.base)||0,u={},f=r>0&&r<1,d=isNaN(r)||f,p=n.axis,_=r,v=r;return ui(r)?_=v={center:.5,edges:.5,end:1}[r]||0:!f&&d&&(_=r[0],v=r[1]),function(g,x,M){var E=(M||n).length,S=u[E],y,R,U,C,F,O,D,T,L;if(!S){if(L=n.grid==="auto"?0:(n.grid||[1,Ba])[1],!L){for(D=-Ba;D<(D=M[L++].getBoundingClientRect().left)&&L<E;);L<E&&L--}for(S=u[E]=[],y=d?Math.min(L,E)*_-.5:r%L,R=L===Ba?0:d?E*v/L-.5:r/L|0,D=0,T=Ba,O=0;O<E;O++)U=O%L-y,C=R-(O/L|0),S[O]=F=p?Math.abs(p==="y"?C:U):h1(U*U+C*C),F>D&&(D=F),F<T&&(T=F);r==="random"&&w1(S),S.max=D-T,S.min=T,S.v=E=(parseFloat(n.amount)||parseFloat(n.each)*(L>E?E-1:p?p==="y"?E/L:L:Math.max(L,E/L))||0)*(r==="edges"?-1:1),S.b=E<0?l-E:l,S.u=Ai(n.amount||n.each)||0,a=a&&E<0?oR(a):a}return E=(S[g]-S.min)/S.max||0,Ln(S.b+(a?a(E):E)*S.v)+S.u}},H_=function(e){var n=Math.pow(10,((e+"").split(".")[1]||"").length);return function(a){var r=Ln(Math.round(parseFloat(a)/e)*e*n);return(r-r%1)/n+(ns(a)?0:Ai(a))}},U1=function(e,n){var a=wi(e),r,l;return!a&&yr(e)&&(r=a=e.radius||Ba,e.values?(e=Ha(e.values),(l=!ns(e[0]))&&(r*=r)):e=H_(e.increment)),Js(n,a?In(e)?function(u){return l=e(u),Math.abs(l-u)<=r?l:u}:function(u){for(var f=parseFloat(l?u.x:u),d=parseFloat(l?u.y:0),p=Ba,_=0,v=e.length,g,x;v--;)l?(g=e[v].x-f,x=e[v].y-d,g=g*g+x*x):g=Math.abs(e[v]-f),g<p&&(p=g,_=v);return _=!r||p<=r?e[_]:u,l||_===u||ns(u)?_:_+Ai(u)}:H_(e))},N1=function(e,n,a,r){return Js(wi(e)?!n:a===!0?!!(a=0):!r,function(){return wi(e)?e[~~(Math.random()*e.length)]:(a=a||1e-5)&&(r=a<1?Math.pow(10,(a+"").length-2):1)&&Math.floor(Math.round((e-a/2+Math.random()*(n-e+a*.99))/a)*a*r)/r})},ZA=function(){for(var e=arguments.length,n=new Array(e),a=0;a<e;a++)n[a]=arguments[a];return function(r){return n.reduce(function(l,u){return u(l)},r)}},KA=function(e,n){return function(a){return e(parseFloat(a))+(n||Ai(a))}},QA=function(e,n,a){return O1(e,n,0,1,a)},L1=function(e,n,a){return Js(a,function(r){return e[~~n(r)]})},JA=function o(e,n,a){var r=n-e;return wi(e)?L1(e,o(0,e.length),n):Js(a,function(l){return(r+(l-e)%r)%r+e})},$A=function o(e,n,a){var r=n-e,l=r*2;return wi(e)?L1(e,o(0,e.length-1),n):Js(a,function(u){return u=(l+(u-e)%l)%l||0,e+(u>r?l-u:u)})},Bu=function(e){return e.replace(NA,function(n){var a=n.indexOf("[")+1,r=n.substring(a||7,a?n.indexOf("]"):n.length-1).split(LA);return N1(a?r:+r[0],a?0:+r[1],+r[2]||1e-5)})},O1=function(e,n,a,r,l){var u=n-e,f=r-a;return Js(l,function(d){return a+((d-e)/u*f||0)})},eR=function o(e,n,a,r){var l=isNaN(e+n)?0:function(x){return(1-x)*e+x*n};if(!l){var u=ui(e),f={},d,p,_,v,g;if(a===!0&&(r=1)&&(a=null),u)e={p:e},n={p:n};else if(wi(e)&&!wi(n)){for(_=[],v=e.length,g=v-2,p=1;p<v;p++)_.push(o(e[p-1],e[p]));v--,l=function(M){M*=v;var E=Math.min(g,~~M);return _[E](M-E)},a=n}else r||(e=ic(wi(e)?[]:{},e));if(!_){for(d in n)rg.call(f,e,d,"get",n[d]);l=function(M){return cg(M,f)||(u?e.p:e)}}}return Js(a,l)},Ny=function(e,n,a){var r=e.labels,l=Ba,u,f,d;for(u in r)f=r[u]-n,f<0==!!a&&f&&l>(f=Math.abs(f))&&(d=u,l=f);return d},va=function(e,n,a){var r=e.vars,l=r[n],u=Un,f=e._ctx,d,p,_;if(l)return d=r[n+"Params"],p=r.callbackScope||e,a&&Xs.length&&rd(),f&&(Un=f),_=d?l.apply(p,d):l.call(p),Un=u,_},mu=function(e){return Ys(e),e.scrollTrigger&&e.scrollTrigger.kill(!!gi),e.progress()<1&&va(e,"onInterrupt"),e},ql,P1=[],F1=function(e){if(e)if(e=!e.name&&e.default||e,J0()||e.headless){var n=e.name,a=In(e),r=n&&!a&&e.init?function(){this._props=[]}:e,l={init:Iu,render:cg,add:rg,kill:gR,modifier:_R,rawVars:0},u={targetTest:0,get:0,getSetter:lg,aliases:{},register:0};if(sc(),e!==r){if(pa[n])return;ba(r,ba(sd(e,l),u)),ic(r.prototype,ic(l,sd(e,u))),pa[r.prop=n]=r,e.targetTest&&(Xh.push(r),tg[n]=1),n=(n==="css"?"CSS":n.charAt(0).toUpperCase()+n.substr(1))+"Plugin"}v1(n,r),e.register&&e.register(ea,r,Qi)}else P1.push(e)},xn=255,_u={aqua:[0,xn,xn],lime:[0,xn,0],silver:[192,192,192],black:[0,0,0],maroon:[128,0,0],teal:[0,128,128],blue:[0,0,xn],navy:[0,0,128],white:[xn,xn,xn],olive:[128,128,0],yellow:[xn,xn,0],orange:[xn,165,0],gray:[128,128,128],purple:[128,0,128],green:[0,128,0],red:[xn,0,0],pink:[xn,192,203],cyan:[0,xn,xn],transparent:[xn,xn,xn,0]},Vm=function(e,n,a){return e+=e<0?1:e>1?-1:0,(e*6<1?n+(a-n)*e*6:e<.5?a:e*3<2?n+(a-n)*(2/3-e)*6:n)*xn+.5|0},z1=function(e,n,a){var r=e?ns(e)?[e>>16,e>>8&xn,e&xn]:0:_u.black,l,u,f,d,p,_,v,g,x,M;if(!r){if(e.substr(-1)===","&&(e=e.substr(0,e.length-1)),_u[e])r=_u[e];else if(e.charAt(0)==="#"){if(e.length<6&&(l=e.charAt(1),u=e.charAt(2),f=e.charAt(3),e="#"+l+l+u+u+f+f+(e.length===5?e.charAt(4)+e.charAt(4):"")),e.length===9)return r=parseInt(e.substr(1,6),16),[r>>16,r>>8&xn,r&xn,parseInt(e.substr(7),16)/255];e=parseInt(e.substr(1),16),r=[e>>16,e>>8&xn,e&xn]}else if(e.substr(0,3)==="hsl"){if(r=M=e.match(Ry),!n)d=+r[0]%360/360,p=+r[1]/100,_=+r[2]/100,u=_<=.5?_*(p+1):_+p-_*p,l=_*2-u,r.length>3&&(r[3]*=1),r[0]=Vm(d+1/3,l,u),r[1]=Vm(d,l,u),r[2]=Vm(d-1/3,l,u);else if(~e.indexOf("="))return r=e.match(p1),a&&r.length<4&&(r[3]=1),r}else r=e.match(Ry)||_u.transparent;r=r.map(Number)}return n&&!M&&(l=r[0]/xn,u=r[1]/xn,f=r[2]/xn,v=Math.max(l,u,f),g=Math.min(l,u,f),_=(v+g)/2,v===g?d=p=0:(x=v-g,p=_>.5?x/(2-v-g):x/(v+g),d=v===l?(u-f)/x+(u<f?6:0):v===u?(f-l)/x+2:(l-u)/x+4,d*=60),r[0]=~~(d+.5),r[1]=~~(p*100+.5),r[2]=~~(_*100+.5)),a&&r.length<4&&(r[3]=1),r},I1=function(e){var n=[],a=[],r=-1;return e.split(Ws).forEach(function(l){var u=l.match(Wl)||[];n.push.apply(n,u),a.push(r+=u.length+1)}),n.c=a,n},Ly=function(e,n,a){var r="",l=(e+r).match(Ws),u=n?"hsla(":"rgba(",f=0,d,p,_,v;if(!l)return e;if(l=l.map(function(g){return(g=z1(g,n,1))&&u+(n?g[0]+","+g[1]+"%,"+g[2]+"%,"+g[3]:g.join(","))+")"}),a&&(_=I1(e),d=a.c,d.join(r)!==_.c.join(r)))for(p=e.replace(Ws,"1").split(Wl),v=p.length-1;f<v;f++)r+=p[f]+(~d.indexOf(f)?l.shift()||u+"0,0,0,0)":(_.length?_:l.length?l:a).shift());if(!p)for(p=e.split(Ws),v=p.length-1;f<v;f++)r+=p[f]+l[f];return r+p[v]},Ws=(function(){var o="(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b",e;for(e in _u)o+="|"+e+"\\b";return new RegExp(o+")","gi")})(),tR=/hsl[a]?\(/,B1=function(e){var n=e.join(" "),a;if(Ws.lastIndex=0,Ws.test(n))return a=tR.test(n),e[1]=Ly(e[1],a),e[0]=Ly(e[0],a,I1(e[1])),!0},Hu,_a=(function(){var o=Date.now,e=500,n=33,a=o(),r=a,l=1e3/240,u=l,f=[],d,p,_,v,g,x,M=function E(S){var y=o()-r,R=S===!0,U,C,F,O;if((y>e||y<0)&&(a+=y-n),r+=y,F=r-a,U=F-u,(U>0||R)&&(O=++v.frame,g=F-v.time*1e3,v.time=F=F/1e3,u+=U+(U>=l?4:l-U),C=1),R||(d=p(E)),C)for(x=0;x<f.length;x++)f[x](F,g,O,S)};return v={time:0,frame:0,tick:function(){M(!0)},deltaRatio:function(S){return g/(1e3/(S||60))},wake:function(){_1&&(!O_&&J0()&&(ur=O_=window,$0=ur.document||{},Ma.gsap=ea,(ur.gsapVersions||(ur.gsapVersions=[])).push(ea.version),g1(ad||ur.GreenSockGlobals||!ur.gsap&&ur||{}),P1.forEach(F1)),_=typeof requestAnimationFrame<"u"&&requestAnimationFrame,d&&v.sleep(),p=_||function(S){return setTimeout(S,u-v.time*1e3+1|0)},Hu=1,M(2))},sleep:function(){(_?cancelAnimationFrame:clearTimeout)(d),Hu=0,p=Iu},lagSmoothing:function(S,y){e=S||1/0,n=Math.min(y||33,e)},fps:function(S){l=1e3/(S||240),u=v.time*1e3+l},add:function(S,y,R){var U=y?function(C,F,O,D){S(C,F,O,D),v.remove(U)}:S;return v.remove(S),f[R?"unshift":"push"](U),sc(),U},remove:function(S,y){~(y=f.indexOf(S))&&f.splice(y,1)&&x>=y&&x--},_listeners:f},v})(),sc=function(){return!Hu&&_a.wake()},qt={},nR=/^[\d.\-M][\d.\-,\s]/,iR=/["']/g,aR=function(e){for(var n={},a=e.substr(1,e.length-3).split(":"),r=a[0],l=1,u=a.length,f,d,p;l<u;l++)d=a[l],f=l!==u-1?d.lastIndexOf(","):d.length,p=d.substr(0,f),n[r]=isNaN(p)?p.replace(iR,"").trim():+p,r=d.substr(f+1).trim();return n},rR=function(e){var n=e.indexOf("(")+1,a=e.indexOf(")"),r=e.indexOf("(",n);return e.substring(n,~r&&r<a?e.indexOf(")",a+1):a)},sR=function(e){var n=(e+"").split("("),a=qt[n[0]];return a&&n.length>1&&a.config?a.config.apply(null,~e.indexOf("{")?[aR(n[1])]:rR(e).split(",").map(M1)):qt._CE&&nR.test(e)?qt._CE("",e):a},oR=function(e){return function(n){return 1-e(1-n)}},Po=function(e,n){return e&&(In(e)?e:qt[e]||sR(e))||n},qo=function(e,n,a,r){a===void 0&&(a=function(d){return 1-n(1-d)}),r===void 0&&(r=function(d){return d<.5?n(d*2)/2:1-n((1-d)*2)/2});var l={easeIn:n,easeOut:a,easeInOut:r},u;return Ki(e,function(f){qt[f]=Ma[f]=l,qt[u=f.toLowerCase()]=a;for(var d in l)qt[u+(d==="easeIn"?".in":d==="easeOut"?".out":".inOut")]=qt[f+"."+d]=l[d]}),l},H1=function(e){return function(n){return n<.5?(1-e(1-n*2))/2:.5+e((n-.5)*2)/2}},km=function o(e,n,a){var r=n>=1?n:1,l=(a||(e?.3:.45))/(n<1?n:1),u=l/L_*(Math.asin(1/r)||0),f=function(_){return _===1?1:r*Math.pow(2,-10*_)*UA((_-u)*l)+1},d=e==="out"?f:e==="in"?function(p){return 1-f(1-p)}:H1(f);return l=L_/l,d.config=function(p,_){return o(e,p,_)},d},Xm=function o(e,n){n===void 0&&(n=1.70158);var a=function(u){return u?--u*u*((n+1)*u+n)+1:0},r=e==="out"?a:e==="in"?function(l){return 1-a(1-l)}:H1(a);return r.config=function(l){return o(e,l)},r};Ki("Linear,Quad,Cubic,Quart,Quint,Strong",function(o,e){var n=e<5?e+1:e;qo(o+",Power"+(n-1),e?function(a){return Math.pow(a,n)}:function(a){return a},function(a){return 1-Math.pow(1-a,n)},function(a){return a<.5?Math.pow(a*2,n)/2:1-Math.pow((1-a)*2,n)/2})});qt.Linear.easeNone=qt.none=qt.Linear.easeIn;qo("Elastic",km("in"),km("out"),km());(function(o,e){var n=1/e,a=2*n,r=2.5*n,l=function(f){return f<n?o*f*f:f<a?o*Math.pow(f-1.5/e,2)+.75:f<r?o*(f-=2.25/e)*f+.9375:o*Math.pow(f-2.625/e,2)+.984375};qo("Bounce",function(u){return 1-l(1-u)},l)})(7.5625,2.75);qo("Expo",function(o){return Math.pow(2,10*(o-1))*o+o*o*o*o*o*o*(1-o)});qo("Circ",function(o){return-(h1(1-o*o)-1)});qo("Sine",function(o){return o===1?1:-DA(o*CA)+1});qo("Back",Xm("in"),Xm("out"),Xm());qt.SteppedEase=qt.steps=Ma.SteppedEase={config:function(e,n){e===void 0&&(e=1);var a=1/e,r=e+(n?0:1),l=n?1:0,u=1-Sn;return function(f){return((r*ju(0,u,f)|0)+l)*a}}};Fu.ease=qt["quad.out"];Ki("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt",function(o){return ng+=o+","+o+"Params,"});var G1=function(e,n){this.id=wA++,e._gsap=this,this.target=e,this.harness=n,this.get=n?n.get:S1,this.set=n?n.getSetter:lg},Gu=(function(){function o(n){this.vars=n,this._delay=+n.delay||0,(this._repeat=n.repeat===1/0?-2:n.repeat||0)&&(this._rDelay=n.repeatDelay||0,this._yoyo=!!n.yoyo||!!n.yoyoEase),this._ts=1,rc(this,+n.duration,1,1),this.data=n.data,Un&&(this._ctx=Un,Un.data.push(this)),Hu||_a.wake()}var e=o.prototype;return e.delay=function(a){return a||a===0?(this.parent&&this.parent.smoothChildTiming&&this.startTime(this._start+a-this._delay),this._delay=a,this):this._delay},e.duration=function(a){return arguments.length?this.totalDuration(this._repeat>0?a+(a+this._rDelay)*this._repeat:a):this.totalDuration()&&this._dur},e.totalDuration=function(a){return arguments.length?(this._dirty=0,rc(this,this._repeat<0?a:(a-this._repeat*this._rDelay)/(this._repeat+1))):this._tDur},e.totalTime=function(a,r){if(sc(),!arguments.length)return this._tTime;var l=this._dp;if(l&&l.smoothChildTiming&&this._ts){for(Ed(this,a),!l._dp||l.parent||T1(l,this);l&&l.parent;)l.parent._time!==l._start+(l._ts>=0?l._tTime/l._ts:(l.totalDuration()-l._tTime)/-l._ts)&&l.totalTime(l._tTime,!0),l=l.parent;!this.parent&&this._dp.autoRemoveChildren&&(this._ts>0&&a<this._tDur||this._ts<0&&a>0||!this._tDur&&!a)&&dr(this._dp,this,this._start-this._delay)}return(this._tTime!==a||!this._dur&&!r||this._initted&&Math.abs(this._zTime)===Sn||!this._initted&&this._dur&&a||!a&&!this._initted&&(this.add||this._ptLookup))&&(this._ts||(this._pTime=a),y1(this,a,r)),this},e.time=function(a,r){return arguments.length?this.totalTime(Math.min(this.totalDuration(),a+Dy(this))%(this._dur+this._rDelay)||(a?this._dur:0),r):this._time},e.totalProgress=function(a,r){return arguments.length?this.totalTime(this.totalDuration()*a,r):this.totalDuration()?Math.min(1,this._tTime/this._tDur):this.rawTime()>=0&&this._initted?1:0},e.progress=function(a,r){return arguments.length?this.totalTime(this.duration()*(this._yoyo&&!(this.iteration()&1)?1-a:a)+Dy(this),r):this.duration()?Math.min(1,this._time/this._dur):this.rawTime()>0?1:0},e.iteration=function(a,r){var l=this.duration()+this._rDelay;return arguments.length?this.totalTime(this._time+(a-1)*l,r):this._repeat?ac(this._tTime,l)+1:1},e.timeScale=function(a,r){if(!arguments.length)return this._rts===-Sn?0:this._rts;if(this._rts===a)return this;var l=this.parent&&this._ts?od(this.parent._time,this):this._tTime;return this._rts=+a||0,this._ts=this._ps||a===-Sn?0:this._rts,this.totalTime(ju(-Math.abs(this._delay),this.totalDuration(),l),r!==!1),bd(this),GA(this)},e.paused=function(a){return arguments.length?(this._ps!==a&&(this._ps=a,a?(this._pTime=this._tTime||Math.max(-this._delay,this.rawTime()),this._ts=this._act=0):(sc(),this._ts=this._rts,this.totalTime(this.parent&&!this.parent.smoothChildTiming?this.rawTime():this._tTime||this._pTime,this.progress()===1&&Math.abs(this._zTime)!==Sn&&(this._tTime-=Sn)))),this):this._ps},e.startTime=function(a){if(arguments.length){this._start=Ln(a);var r=this.parent||this._dp;return r&&(r._sort||!this.parent)&&dr(r,this,this._start-this._delay),this}return this._start},e.endTime=function(a){return this._start+(Zi(a)?this.totalDuration():this.duration())/Math.abs(this._ts||1)},e.rawTime=function(a){var r=this.parent||this._dp;return r?a&&(!this._ts||this._repeat&&this._time&&this.totalProgress()<1)?this._tTime%(this._dur+this._rDelay):this._ts?od(r.rawTime(a),this):this._tTime:this._tTime},e.revert=function(a){a===void 0&&(a=zA);var r=gi;return gi=a,ag(this)&&(this.timeline&&this.timeline.revert(a),this.totalTime(-.01,a.suppressEvents)),this.data!=="nested"&&a.kill!==!1&&this.kill(),gi=r,this},e.globalTime=function(a){for(var r=this,l=arguments.length?a:r.rawTime();r;)l=r._start+l/(Math.abs(r._ts)||1),r=r._dp;return!this.parent&&this._sat?this._sat.globalTime(a):l},e.repeat=function(a){return arguments.length?(this._repeat=a===1/0?-2:a,Uy(this)):this._repeat===-2?1/0:this._repeat},e.repeatDelay=function(a){if(arguments.length){var r=this._time;return this._rDelay=a,Uy(this),r?this.time(r):this}return this._rDelay},e.yoyo=function(a){return arguments.length?(this._yoyo=a,this):this._yoyo},e.seek=function(a,r){return this.totalTime(Oa(this,a),Zi(r))},e.restart=function(a,r){return this.play().totalTime(a?-this._delay:0,Zi(r)),this._dur||(this._zTime=-Sn),this},e.play=function(a,r){return a!=null&&this.seek(a,r),this.reversed(!1).paused(!1)},e.reverse=function(a,r){return a!=null&&this.seek(a||this.totalDuration(),r),this.reversed(!0).paused(!1)},e.pause=function(a,r){return a!=null&&this.seek(a,r),this.paused(!0)},e.resume=function(){return this.paused(!1)},e.reversed=function(a){return arguments.length?(!!a!==this.reversed()&&this.timeScale(-this._rts||(a?-Sn:0)),this):this._rts<0},e.invalidate=function(){return this._initted=this._act=0,this._zTime=-Sn,this},e.isActive=function(){var a=this.parent||this._dp,r=this._start,l;return!!(!a||this._ts&&this._initted&&a.isActive()&&(l=a.rawTime(!0))>=r&&l<this.endTime(!0)-Sn)},e.eventCallback=function(a,r,l){var u=this.vars;return arguments.length>1?(r?(u[a]=r,l&&(u[a+"Params"]=l),a==="onUpdate"&&(this._onUpdate=r)):delete u[a],this):u[a]},e.then=function(a){var r=this,l=r._prom;return new Promise(function(u){var f=In(a)?a:b1,d=function(){var _=r.then;r.then=null,l&&l(),In(f)&&(f=f(r))&&(f.then||f===r)&&(r.then=_),u(f),r.then=_};r._initted&&r.totalProgress()===1&&r._ts>=0||!r._tTime&&r._ts<0?d():r._prom=d})},e.kill=function(){mu(this)},o})();ba(Gu.prototype,{_time:0,_start:0,_end:0,_tTime:0,_tDur:0,_dirty:0,_repeat:0,_yoyo:!1,parent:null,_initted:!1,_rDelay:0,_ts:1,_dp:0,ratio:0,_zTime:-Sn,_prom:0,_ps:!1,_rts:1});var ji=(function(o){f1(e,o);function e(a,r){var l;return a===void 0&&(a={}),l=o.call(this,a)||this,l.labels={},l.smoothChildTiming=!!a.smoothChildTiming,l.autoRemoveChildren=!!a.autoRemoveChildren,l._sort=Zi(a.sortChildren),On&&dr(a.parent||On,qr(l),r),a.reversed&&l.reverse(),a.paused&&l.paused(!0),a.scrollTrigger&&A1(qr(l),a.scrollTrigger),l}var n=e.prototype;return n.to=function(r,l,u){return Tu(0,arguments,this),this},n.from=function(r,l,u){return Tu(1,arguments,this),this},n.fromTo=function(r,l,u,f){return Tu(2,arguments,this),this},n.set=function(r,l,u){return l.duration=0,l.parent=this,Eu(l).repeatDelay||(l.repeat=0),l.immediateRender=!!l.immediateRender,new Jn(r,l,Oa(this,u),1),this},n.call=function(r,l,u){return dr(this,Jn.delayedCall(0,r,l),u)},n.staggerTo=function(r,l,u,f,d,p,_){return u.duration=l,u.stagger=u.stagger||f,u.onComplete=p,u.onCompleteParams=_,u.parent=this,new Jn(r,u,Oa(this,d)),this},n.staggerFrom=function(r,l,u,f,d,p,_){return u.runBackwards=1,Eu(u).immediateRender=Zi(u.immediateRender),this.staggerTo(r,l,u,f,d,p,_)},n.staggerFromTo=function(r,l,u,f,d,p,_,v){return f.startAt=u,Eu(f).immediateRender=Zi(f.immediateRender),this.staggerTo(r,l,f,d,p,_,v)},n.render=function(r,l,u){var f=this._time,d=this._dirty?this.totalDuration():this._tDur,p=this._dur,_=r<=0?0:Ln(r),v=this._zTime<0!=r<0&&(this._initted||!p),g,x,M,E,S,y,R,U,C,F,O,D;if(this!==On&&_>d&&r>=0&&(_=d),_!==this._tTime||u||v){if(f!==this._time&&p&&(_+=this._time-f,r+=this._time-f),g=_,C=this._start,U=this._ts,y=!U,v&&(p||(f=this._zTime),(r||!l)&&(this._zTime=r)),this._repeat){if(O=this._yoyo,S=p+this._rDelay,this._repeat<-1&&r<0)return this.totalTime(S*100+r,l,u);if(g=Ln(_%S),_===d?(E=this._repeat,g=p):(F=Ln(_/S),E=~~F,E&&E===F&&(g=p,E--),g>p&&(g=p)),F=ac(this._tTime,S),!f&&this._tTime&&F!==E&&this._tTime-F*S-this._dur<=0&&(F=E),O&&E&1&&(g=p-g,D=1),E!==F&&!this._lock){var T=O&&F&1,L=T===(O&&E&1);if(E<F&&(T=!T),f=T?0:_%p?p:_,this._lock=1,this.render(f||(D?0:Ln(E*S)),l,!p)._lock=0,this._tTime=_,!l&&this.parent&&va(this,"onRepeat"),this.vars.repeatRefresh&&!D&&(this.invalidate()._lock=1,F=E),f&&f!==this._time||y!==!this._ts||this.vars.onRepeat&&!this.parent&&!this._act)return this;if(p=this._dur,d=this._tDur,L&&(this._lock=2,f=T?p:-1e-4,this.render(f,!0),this.vars.repeatRefresh&&!D&&this.invalidate()),this._lock=0,!this._ts&&!y)return this}}if(this._hasPause&&!this._forcing&&this._lock<2&&(R=WA(this,Ln(f),Ln(g)),R&&(_-=g-(g=R._start))),this._tTime=_,this._time=g,this._act=!!U,this._initted||(this._onUpdate=this.vars.onUpdate,this._initted=1,this._zTime=r,f=0),!f&&_&&p&&!l&&!F&&(va(this,"onStart"),this._tTime!==_))return this;if(g>=f&&r>=0)for(x=this._first;x;){if(M=x._next,(x._act||g>=x._start)&&x._ts&&R!==x){if(x.parent!==this)return this.render(r,l,u);if(x.render(x._ts>0?(g-x._start)*x._ts:(x._dirty?x.totalDuration():x._tDur)+(g-x._start)*x._ts,l,u),g!==this._time||!this._ts&&!y){R=0,M&&(_+=this._zTime=-Sn);break}}x=M}else{x=this._last;for(var H=r<0?r:g;x;){if(M=x._prev,(x._act||H<=x._end)&&x._ts&&R!==x){if(x.parent!==this)return this.render(r,l,u);if(x.render(x._ts>0?(H-x._start)*x._ts:(x._dirty?x.totalDuration():x._tDur)+(H-x._start)*x._ts,l,u||gi&&ag(x)),g!==this._time||!this._ts&&!y){R=0,M&&(_+=this._zTime=H?-Sn:Sn);break}}x=M}}if(R&&!l&&(this.pause(),R.render(g>=f?0:-Sn)._zTime=g>=f?1:-1,this._ts))return this._start=C,bd(this),this.render(r,l,u);this._onUpdate&&!l&&va(this,"onUpdate",!0),(_===d&&this._tTime>=this.totalDuration()||!_&&f)&&(C===this._start||Math.abs(U)!==Math.abs(this._ts))&&(this._lock||((r||!p)&&(_===d&&this._ts>0||!_&&this._ts<0)&&Ys(this,1),!l&&!(r<0&&!f)&&(_||f||!d)&&(va(this,_===d&&r>=0?"onComplete":"onReverseComplete",!0),this._prom&&!(_<d&&this.timeScale()>0)&&this._prom())))}return this},n.add=function(r,l){var u=this;if(ns(l)||(l=Oa(this,l,r)),!(r instanceof Gu)){if(wi(r))return r.forEach(function(f){return u.add(f,l)}),this;if(ui(r))return this.addLabel(r,l);if(In(r))r=Jn.delayedCall(0,r);else return this}return this!==r?dr(this,r,l):this},n.getChildren=function(r,l,u,f){r===void 0&&(r=!0),l===void 0&&(l=!0),u===void 0&&(u=!0),f===void 0&&(f=-Ba);for(var d=[],p=this._first;p;)p._start>=f&&(p instanceof Jn?l&&d.push(p):(u&&d.push(p),r&&d.push.apply(d,p.getChildren(!0,l,u)))),p=p._next;return d},n.getById=function(r){for(var l=this.getChildren(1,1,1),u=l.length;u--;)if(l[u].vars.id===r)return l[u]},n.remove=function(r){return ui(r)?this.removeLabel(r):In(r)?this.killTweensOf(r):(r.parent===this&&Md(this,r),r===this._recent&&(this._recent=this._last),Oo(this))},n.totalTime=function(r,l){return arguments.length?(this._forcing=1,!this._dp&&this._ts&&(this._start=Ln(_a.time-(this._ts>0?r/this._ts:(this.totalDuration()-r)/-this._ts))),o.prototype.totalTime.call(this,r,l),this._forcing=0,this):this._tTime},n.addLabel=function(r,l){return this.labels[r]=Oa(this,l),this},n.removeLabel=function(r){return delete this.labels[r],this},n.addPause=function(r,l,u){var f=Jn.delayedCall(0,l||Iu,u);return f.data="isPause",this._hasPause=1,dr(this,f,Oa(this,r))},n.removePause=function(r){var l=this._first;for(r=Oa(this,r);l;)l._start===r&&l.data==="isPause"&&Ys(l),l=l._next},n.killTweensOf=function(r,l,u){for(var f=this.getTweensOf(r,u),d=f.length;d--;)Is!==f[d]&&f[d].kill(r,l);return this},n.getTweensOf=function(r,l){for(var u=[],f=Ha(r),d=this._first,p=ns(l),_;d;)d instanceof Jn?IA(d._targets,f)&&(p?(!Is||d._initted&&d._ts)&&d.globalTime(0)<=l&&d.globalTime(d.totalDuration())>l:!l||d.isActive())&&u.push(d):(_=d.getTweensOf(f,l)).length&&u.push.apply(u,_),d=d._next;return u},n.tweenTo=function(r,l){l=l||{};var u=this,f=Oa(u,r),d=l,p=d.startAt,_=d.onStart,v=d.onStartParams,g=d.immediateRender,x,M=Jn.to(u,ba({ease:l.ease||"none",lazy:!1,immediateRender:!1,time:f,overwrite:"auto",duration:l.duration||Math.abs((f-(p&&"time"in p?p.time:u._time))/u.timeScale())||Sn,onStart:function(){if(u.pause(),!x){var S=l.duration||Math.abs((f-(p&&"time"in p?p.time:u._time))/u.timeScale());M._dur!==S&&rc(M,S,0,1).render(M._time,!0,!0),x=1}_&&_.apply(M,v||[])}},l));return g?M.render(0):M},n.tweenFromTo=function(r,l,u){return this.tweenTo(l,ba({startAt:{time:Oa(this,r)}},u))},n.recent=function(){return this._recent},n.nextLabel=function(r){return r===void 0&&(r=this._time),Ny(this,Oa(this,r))},n.previousLabel=function(r){return r===void 0&&(r=this._time),Ny(this,Oa(this,r),1)},n.currentLabel=function(r){return arguments.length?this.seek(r,!0):this.previousLabel(this._time+Sn)},n.shiftChildren=function(r,l,u){u===void 0&&(u=0);var f=this._first,d=this.labels,p;for(r=Ln(r);f;)f._start>=u&&(f._start+=r,f._end+=r),f=f._next;if(l)for(p in d)d[p]>=u&&(d[p]+=r);return Oo(this)},n.invalidate=function(r){var l=this._first;for(this._lock=0;l;)l.invalidate(r),l=l._next;return o.prototype.invalidate.call(this,r)},n.clear=function(r){r===void 0&&(r=!0);for(var l=this._first,u;l;)u=l._next,this.remove(l),l=u;return this._dp&&(this._time=this._tTime=this._pTime=0),r&&(this.labels={}),Oo(this)},n.totalDuration=function(r){var l=0,u=this,f=u._last,d=Ba,p,_,v;if(arguments.length)return u.timeScale((u._repeat<0?u.duration():u.totalDuration())/(u.reversed()?-r:r));if(u._dirty){for(v=u.parent;f;)p=f._prev,f._dirty&&f.totalDuration(),_=f._start,_>d&&u._sort&&f._ts&&!u._lock?(u._lock=1,dr(u,f,_-f._delay,1)._lock=0):d=_,_<0&&f._ts&&(l-=_,(!v&&!u._dp||v&&v.smoothChildTiming)&&(u._start+=Ln(_/u._ts),u._time-=_,u._tTime-=_),u.shiftChildren(-_,!1,-1/0),d=0),f._end>l&&f._ts&&(l=f._end),f=p;rc(u,u===On&&u._time>l?u._time:l,1,1),u._dirty=0}return u._tDur},e.updateRoot=function(r){if(On._ts&&(y1(On,od(r,On)),x1=_a.frame),_a.frame>=Cy){Cy+=Sa.autoSleep||120;var l=On._first;if((!l||!l._ts)&&Sa.autoSleep&&_a._listeners.length<2){for(;l&&!l._ts;)l=l._next;l||_a.sleep()}}},e})(Gu);ba(ji.prototype,{_lock:0,_hasPause:0,_forcing:0});var lR=function(e,n,a,r,l,u,f){var d=new Qi(this._pt,e,n,0,1,Y1,null,l),p=0,_=0,v,g,x,M,E,S,y,R;for(d.b=a,d.e=r,a+="",r+="",(y=~r.indexOf("random("))&&(r=Bu(r)),u&&(R=[a,r],u(R,e,n),a=R[0],r=R[1]),g=a.match(Hm)||[];v=Hm.exec(r);)M=v[0],E=r.substring(p,v.index),x?x=(x+1)%5:E.substr(-5)==="rgba("&&(x=1),M!==g[_++]&&(S=parseFloat(g[_-1])||0,d._pt={_next:d._pt,p:E||_===1?E:",",s:S,c:M.charAt(1)==="="?jl(S,M)-S:parseFloat(M)-S,m:x&&x<4?Math.round:0},p=Hm.lastIndex);return d.c=p<r.length?r.substring(p,r.length):"",d.fp=f,(m1.test(r)||y)&&(d.e=0),this._pt=d,d},rg=function(e,n,a,r,l,u,f,d,p,_){In(r)&&(r=r(l||0,e,u));var v=e[n],g=a!=="get"?a:In(v)?p?e[n.indexOf("set")||!In(e["get"+n.substr(3)])?n:"get"+n.substr(3)](p):e[n]():v,x=In(v)?p?dR:W1:og,M;if(ui(r)&&(~r.indexOf("random(")&&(r=Bu(r)),r.charAt(1)==="="&&(M=jl(g,r)+(Ai(g)||0),(M||M===0)&&(r=M))),!_||g!==r||G_)return!isNaN(g*r)&&r!==""?(M=new Qi(this._pt,e,n,+g||0,r-(g||0),typeof v=="boolean"?mR:q1,0,x),p&&(M.fp=p),f&&M.modifier(f,this,e),this._pt=M):(!v&&!(n in e)&&eg(n,r),lR.call(this,e,n,g,r,x,d||Sa.stringFilter,p))},cR=function(e,n,a,r,l){if(In(e)&&(e=Au(e,l,n,a,r)),!yr(e)||e.style&&e.nodeType||wi(e)||d1(e))return ui(e)?Au(e,l,n,a,r):e;var u={},f;for(f in e)u[f]=Au(e[f],l,n,a,r);return u},V1=function(e,n,a,r,l,u){var f,d,p,_;if(pa[e]&&(f=new pa[e]).init(l,f.rawVars?n[e]:cR(n[e],r,l,u,a),a,r,u)!==!1&&(a._pt=d=new Qi(a._pt,l,e,0,1,f.render,f,0,f.priority),a!==ql))for(p=a._ptLookup[a._targets.indexOf(l)],_=f._props.length;_--;)p[f._props[_]]=d;return f},Is,G_,sg=function o(e,n,a){var r=e.vars,l=r.ease,u=r.startAt,f=r.immediateRender,d=r.lazy,p=r.onUpdate,_=r.runBackwards,v=r.yoyoEase,g=r.keyframes,x=r.autoRevert,M=e._dur,E=e._startAt,S=e._targets,y=e.parent,R=y&&y.data==="nested"?y.vars.targets:S,U=e._overwrite==="auto"&&!K0,C=e.timeline,F=r.easeReverse||v,O,D,T,L,H,V,k,te,ie,W,z,B,J;if(C&&(!g||!l)&&(l="none"),e._ease=Po(l,Fu.ease),e._rEase=F&&(Po(F)||e._ease),e._from=!C&&!!r.runBackwards,e._from&&(e.ratio=1),!C||g&&!r.stagger){if(te=S[0]?Lo(S[0]).harness:0,B=te&&r[te.prop],O=sd(r,tg),E&&(E._zTime<0&&E.progress(1),n<0&&_&&f&&!x?E.render(-1,!0):E.revert(_&&M?kh:FA),E._lazy=0),u){if(Ys(e._startAt=Jn.set(S,ba({data:"isStart",overwrite:!1,parent:y,immediateRender:!0,lazy:!E&&Zi(d),startAt:null,delay:0,onUpdate:p&&function(){return va(e,"onUpdate")},stagger:0},u))),e._startAt._dp=0,e._startAt._sat=e,n<0&&(gi||!f&&!x)&&e._startAt.revert(kh),f&&M&&n<=0&&a<=0){n&&(e._zTime=n);return}}else if(_&&M&&!E){if(n&&(f=!1),T=ba({overwrite:!1,data:"isFromStart",lazy:f&&!E&&Zi(d),immediateRender:f,stagger:0,parent:y},O),B&&(T[te.prop]=B),Ys(e._startAt=Jn.set(S,T)),e._startAt._dp=0,e._startAt._sat=e,n<0&&(gi?e._startAt.revert(kh):e._startAt.render(-1,!0)),e._zTime=n,!f)o(e._startAt,Sn,Sn);else if(!n)return}for(e._pt=e._ptCache=0,d=M&&Zi(d)||d&&!M,D=0;D<S.length;D++){if(H=S[D],k=H._gsap||ig(S)[D]._gsap,e._ptLookup[D]=W={},P_[k.id]&&Xs.length&&rd(),z=R===S?D:R.indexOf(H),te&&(ie=new te).init(H,B||O,e,z,R)!==!1&&(e._pt=L=new Qi(e._pt,H,ie.name,0,1,ie.render,ie,0,ie.priority),ie._props.forEach(function(fe){W[fe]=L}),ie.priority&&(V=1)),!te||B)for(T in O)pa[T]&&(ie=V1(T,O,e,z,H,R))?ie.priority&&(V=1):W[T]=L=rg.call(e,H,T,"get",O[T],z,R,0,r.stringFilter);e._op&&e._op[D]&&e.kill(H,e._op[D]),U&&e._pt&&(Is=e,On.killTweensOf(H,W,e.globalTime(n)),J=!e.parent,Is=0),e._pt&&d&&(P_[k.id]=1)}V&&j1(e),e._onInit&&e._onInit(e)}e._onUpdate=p,e._initted=(!e._op||e._pt)&&!J,g&&n<=0&&C.render(Ba,!0,!0)},uR=function(e,n,a,r,l,u,f,d){var p=(e._pt&&e._ptCache||(e._ptCache={}))[n],_,v,g,x;if(!p)for(p=e._ptCache[n]=[],g=e._ptLookup,x=e._targets.length;x--;){if(_=g[x][n],_&&_.d&&_.d._pt)for(_=_.d._pt;_&&_.p!==n&&_.fp!==n;)_=_._next;if(!_)return G_=1,e.vars[n]="+=0",sg(e,f),G_=0,d?zu(n+" not eligible for reset. Try splitting into individual properties"):1;p.push(_)}for(x=p.length;x--;)v=p[x],_=v._pt||v,_.s=(r||r===0)&&!l?r:_.s+(r||0)+u*_.c,_.c=a-_.s,v.e&&(v.e=Gn(a)+Ai(v.e)),v.b&&(v.b=_.s+Ai(v.b))},fR=function(e,n){var a=e[0]?Lo(e[0]).harness:0,r=a&&a.aliases,l,u,f,d;if(!r)return n;l=ic({},n);for(u in r)if(u in l)for(d=r[u].split(","),f=d.length;f--;)l[d[f]]=l[u];return l},hR=function(e,n,a,r){var l=n.ease||r||"power1.inOut",u,f;if(wi(n))f=a[e]||(a[e]=[]),n.forEach(function(d,p){return f.push({t:p/(n.length-1)*100,v:d,e:l})});else for(u in n)f=a[u]||(a[u]=[]),u==="ease"||f.push({t:parseFloat(e),v:n[u],e:l})},Au=function(e,n,a,r,l){return In(e)?e.call(n,a,r,l):ui(e)&&~e.indexOf("random(")?Bu(e):e},k1=ng+"repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase,easeReverse,autoRevert",X1={};Ki(k1+",id,stagger,delay,duration,paused,scrollTrigger",function(o){return X1[o]=1});var Jn=(function(o){f1(e,o);function e(a,r,l,u){var f;typeof r=="number"&&(l.duration=r,r=l,l=null),f=o.call(this,u?r:Eu(r))||this;var d=f.vars,p=d.duration,_=d.delay,v=d.immediateRender,g=d.stagger,x=d.overwrite,M=d.keyframes,E=d.defaults,S=d.scrollTrigger,y=r.parent||On,R=(wi(a)||d1(a)?ns(a[0]):"length"in r)?[a]:Ha(a),U,C,F,O,D,T,L,H;if(f._targets=R.length?ig(R):zu("GSAP target "+a+" not found. https://gsap.com",!Sa.nullTargetWarn)||[],f._ptLookup=[],f._overwrite=x,M||g||oh(p)||oh(_)){r=f.vars;var V=r.easeReverse||r.yoyoEase;if(U=f.timeline=new ji({data:"nested",defaults:E||{},targets:y&&y.data==="nested"?y.vars.targets:R}),U.kill(),U.parent=U._dp=qr(f),U._start=0,g||oh(p)||oh(_)){if(O=R.length,L=g&&D1(g),yr(g))for(D in g)~k1.indexOf(D)&&(H||(H={}),H[D]=g[D]);for(C=0;C<O;C++)F=sd(r,X1),F.stagger=0,V&&(F.easeReverse=V),H&&ic(F,H),T=R[C],F.duration=+Au(p,qr(f),C,T,R),F.delay=(+Au(_,qr(f),C,T,R)||0)-f._delay,!g&&O===1&&F.delay&&(f._delay=_=F.delay,f._start+=_,F.delay=0),U.to(T,F,L?L(C,T,R):0),U._ease=qt.none;U.duration()?p=_=0:f.timeline=0}else if(M){Eu(ba(U.vars.defaults,{ease:"none"})),U._ease=Po(M.ease||r.ease||"none");var k=0,te,ie,W;if(wi(M))M.forEach(function(z){return U.to(R,z,">")}),U.duration();else{F={};for(D in M)D==="ease"||D==="easeEach"||hR(D,M[D],F,M.easeEach);for(D in F)for(te=F[D].sort(function(z,B){return z.t-B.t}),k=0,C=0;C<te.length;C++)ie=te[C],W={ease:ie.e,duration:(ie.t-(C?te[C-1].t:0))/100*p},W[D]=ie.v,U.to(R,W,k),k+=W.duration;U.duration()<p&&U.to({},{duration:p-U.duration()})}}p||f.duration(p=U.duration())}else f.timeline=0;return x===!0&&!K0&&(Is=qr(f),On.killTweensOf(R),Is=0),dr(y,qr(f),l),r.reversed&&f.reverse(),r.paused&&f.paused(!0),(v||!p&&!M&&f._start===Ln(y._time)&&Zi(v)&&VA(qr(f))&&y.data!=="nested")&&(f._tTime=-Sn,f.render(Math.max(0,-_)||0)),S&&A1(qr(f),S),f}var n=e.prototype;return n.render=function(r,l,u){var f=this._time,d=this._tDur,p=this._dur,_=r<0,v=r>d-Sn&&!_?d:r<Sn?0:r,g,x,M,E,S,y,R,U;if(!p)XA(this,r,l,u);else if(v!==this._tTime||!r||u||!this._initted&&this._tTime||this._startAt&&this._zTime<0!==_||this._lazy){if(g=v,U=this.timeline,this._repeat){if(E=p+this._rDelay,this._repeat<-1&&_)return this.totalTime(E*100+r,l,u);if(g=Ln(v%E),v===d?(M=this._repeat,g=p):(S=Ln(v/E),M=~~S,M&&M===S?(g=p,M--):g>p&&(g=p)),y=this._yoyo&&M&1,y&&(g=p-g),S=ac(this._tTime,E),g===f&&!u&&this._initted&&M===S)return this._tTime=v,this;M!==S&&this.vars.repeatRefresh&&!y&&!this._lock&&g!==E&&this._initted&&(this._lock=u=1,this.render(Ln(E*M),!0).invalidate()._lock=0)}if(!this._initted){if(R1(this,_?r:g,u,l,v))return this._tTime=0,this;if(f!==this._time&&!(u&&this.vars.repeatRefresh&&M!==S))return this;if(p!==this._dur)return this.render(r,l,u)}if(this._rEase){var C=g<f;if(C!==this._inv){var F=C?f:p-f;this._inv=C,this._from&&(this.ratio=1-this.ratio),this._invRatio=this.ratio,this._invTime=f,this._invRecip=F?(C?-1:1)/F:0,this._invScale=C?-this.ratio:1-this.ratio,this._invEase=C?this._rEase:this._ease}this.ratio=R=this._invRatio+this._invScale*this._invEase((g-this._invTime)*this._invRecip)}else this.ratio=R=this._ease(g/p);if(this._from&&(this.ratio=R=1-R),this._tTime=v,this._time=g,!this._act&&this._ts&&(this._act=1,this._lazy=0),!f&&v&&!l&&!S&&(va(this,"onStart"),this._tTime!==v))return this;for(x=this._pt;x;)x.r(R,x.d),x=x._next;U&&U.render(r<0?r:U._dur*U._ease(g/this._dur),l,u)||this._startAt&&(this._zTime=r),this._onUpdate&&!l&&(_&&F_(this,r,l,u),va(this,"onUpdate")),this._repeat&&M!==S&&this.vars.onRepeat&&!l&&this.parent&&va(this,"onRepeat"),(v===this._tDur||!v)&&this._tTime===v&&(_&&!this._onUpdate&&F_(this,r,!0,!0),(r||!p)&&(v===this._tDur&&this._ts>0||!v&&this._ts<0)&&Ys(this,1),!l&&!(_&&!f)&&(v||f||y)&&(va(this,v===d?"onComplete":"onReverseComplete",!0),this._prom&&!(v<d&&this.timeScale()>0)&&this._prom()))}return this},n.targets=function(){return this._targets},n.invalidate=function(r){return(!r||!this.vars.runBackwards)&&(this._startAt=0),this._pt=this._op=this._onUpdate=this._lazy=this.ratio=0,this._ptLookup=[],this.timeline&&this.timeline.invalidate(r),o.prototype.invalidate.call(this,r)},n.resetTo=function(r,l,u,f,d){Hu||_a.wake(),this._ts||this.play();var p=Math.min(this._dur,(this._dp._time-this._start)*this._ts),_;return this._initted||sg(this,p),_=this._ease(p/this._dur),uR(this,r,l,u,f,_,p,d)?this.resetTo(r,l,u,f,1):(Ed(this,0),this.parent||E1(this._dp,this,"_first","_last",this._dp._sort?"_start":0),this.render(0))},n.kill=function(r,l){if(l===void 0&&(l="all"),!r&&(!l||l==="all"))return this._lazy=this._pt=0,this.parent?mu(this):this.scrollTrigger&&this.scrollTrigger.kill(!!gi),this;if(this.timeline){var u=this.timeline.totalDuration();return this.timeline.killTweensOf(r,l,Is&&Is.vars.overwrite!==!0)._first||mu(this),this.parent&&u!==this.timeline.totalDuration()&&rc(this,this._dur*this.timeline._tDur/u,0,1),this}var f=this._targets,d=r?Ha(r):f,p=this._ptLookup,_=this._pt,v,g,x,M,E,S,y;if((!l||l==="all")&&HA(f,d))return l==="all"&&(this._pt=0),mu(this);for(v=this._op=this._op||[],l!=="all"&&(ui(l)&&(E={},Ki(l,function(R){return E[R]=1}),l=E),l=fR(f,l)),y=f.length;y--;)if(~d.indexOf(f[y])){g=p[y],l==="all"?(v[y]=l,M=g,x={}):(x=v[y]=v[y]||{},M=l);for(E in M)S=g&&g[E],S&&((!("kill"in S.d)||S.d.kill(E)===!0)&&Md(this,S,"_pt"),delete g[E]),x!=="all"&&(x[E]=1)}return this._initted&&!this._pt&&_&&mu(this),this},e.to=function(r,l){return new e(r,l,arguments[2])},e.from=function(r,l){return Tu(1,arguments)},e.delayedCall=function(r,l,u,f){return new e(l,0,{immediateRender:!1,lazy:!1,overwrite:!1,delay:r,onComplete:l,onReverseComplete:l,onCompleteParams:u,onReverseCompleteParams:u,callbackScope:f})},e.fromTo=function(r,l,u){return Tu(2,arguments)},e.set=function(r,l){return l.duration=0,l.repeatDelay||(l.repeat=0),new e(r,l)},e.killTweensOf=function(r,l,u){return On.killTweensOf(r,l,u)},e})(Gu);ba(Jn.prototype,{_targets:[],_lazy:0,_startAt:0,_op:0,_onInit:0});Ki("staggerTo,staggerFrom,staggerFromTo",function(o){Jn[o]=function(){var e=new ji,n=I_.call(arguments,0);return n.splice(o==="staggerFromTo"?5:4,0,0),e[o].apply(e,n)}});var og=function(e,n,a){return e[n]=a},W1=function(e,n,a){return e[n](a)},dR=function(e,n,a,r){return e[n](r.fp,a)},pR=function(e,n,a){return e.setAttribute(n,a)},lg=function(e,n){return In(e[n])?W1:Q0(e[n])&&e.setAttribute?pR:og},q1=function(e,n){return n.set(n.t,n.p,Math.round((n.s+n.c*e)*1e6)/1e6,n)},mR=function(e,n){return n.set(n.t,n.p,!!(n.s+n.c*e),n)},Y1=function(e,n){var a=n._pt,r="";if(!e&&n.b)r=n.b;else if(e===1&&n.e)r=n.e;else{for(;a;)r=a.p+(a.m?a.m(a.s+a.c*e):Math.round((a.s+a.c*e)*1e4)/1e4)+r,a=a._next;r+=n.c}n.set(n.t,n.p,r,n)},cg=function(e,n){for(var a=n._pt;a;)a.r(e,a.d),a=a._next},_R=function(e,n,a,r){for(var l=this._pt,u;l;)u=l._next,l.p===r&&l.modifier(e,n,a),l=u},gR=function(e){for(var n=this._pt,a,r;n;)r=n._next,n.p===e&&!n.op||n.op===e?Md(this,n,"_pt"):n.dep||(a=1),n=r;return!a},vR=function(e,n,a,r){r.mSet(e,n,r.m.call(r.tween,a,r.mt),r)},j1=function(e){for(var n=e._pt,a,r,l,u;n;){for(a=n._next,r=l;r&&r.pr>n.pr;)r=r._next;(n._prev=r?r._prev:u)?n._prev._next=n:l=n,(n._next=r)?r._prev=n:u=n,n=a}e._pt=l},Qi=(function(){function o(n,a,r,l,u,f,d,p,_){this.t=a,this.s=l,this.c=u,this.p=r,this.r=f||q1,this.d=d||this,this.set=p||og,this.pr=_||0,this._next=n,n&&(n._prev=this)}var e=o.prototype;return e.modifier=function(a,r,l){this.mSet=this.mSet||this.set,this.set=vR,this.m=a,this.mt=l,this.tween=r},o})();Ki(ng+"parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger,easeReverse",function(o){return tg[o]=1});Ma.TweenMax=Ma.TweenLite=Jn;Ma.TimelineLite=Ma.TimelineMax=ji;On=new ji({sortChildren:!1,defaults:Fu,autoRemoveChildren:!0,id:"root",smoothChildTiming:!0});Sa.stringFilter=B1;var Fo=[],Wh={},xR=[],Oy=0,SR=0,Wm=function(e){return(Wh[e]||xR).map(function(n){return n()})},V_=function(){var e=Date.now(),n=[];e-Oy>2&&(Wm("matchMediaInit"),Fo.forEach(function(a){var r=a.queries,l=a.conditions,u,f,d,p;for(f in r)u=ur.matchMedia(r[f]).matches,u&&(d=1),u!==l[f]&&(l[f]=u,p=1);p&&(a.revert(),d&&n.push(a))}),Wm("matchMediaRevert"),n.forEach(function(a){return a.onMatch(a,function(r){return a.add(null,r)})}),Oy=e,Wm("matchMedia"))},Z1=(function(){function o(n,a){this.selector=a&&B_(a),this.data=[],this._r=[],this.isReverted=!1,this.id=SR++,n&&this.add(n)}var e=o.prototype;return e.add=function(a,r,l){In(a)&&(l=r,r=a,a=In);var u=this,f=function(){var p=Un,_=u.selector,v;return p&&p!==u&&p.data.push(u),l&&(u.selector=B_(l)),Un=u,v=r.apply(u,arguments),In(v)&&u._r.push(v),Un=p,u.selector=_,u.isReverted=!1,v};return u.last=f,a===In?f(u,function(d){return u.add(null,d)}):a?u[a]=f:f},e.ignore=function(a){var r=Un;Un=null,a(this),Un=r},e.getTweens=function(){var a=[];return this.data.forEach(function(r){return r instanceof o?a.push.apply(a,r.getTweens()):r instanceof Jn&&!(r.parent&&r.parent.data==="nested")&&a.push(r)}),a},e.clear=function(){this._r.length=this.data.length=0},e.kill=function(a,r){var l=this;if(a?(function(){for(var f=l.getTweens(),d=l.data.length,p;d--;)p=l.data[d],p.data==="isFlip"&&(p.revert(),p.getChildren(!0,!0,!1).forEach(function(_){return f.splice(f.indexOf(_),1)}));for(f.map(function(_){return{g:_._dur||_._delay||_._sat&&!_._sat.vars.immediateRender?_.globalTime(0):-1/0,t:_}}).sort(function(_,v){return v.g-_.g||-1/0}).forEach(function(_){return _.t.revert(a)}),d=l.data.length;d--;)p=l.data[d],p instanceof ji?p.data!=="nested"&&(p.scrollTrigger&&p.scrollTrigger.revert(),p.kill()):!(p instanceof Jn)&&p.revert&&p.revert(a);l._r.forEach(function(_){return _(a,l)}),l.isReverted=!0})():this.data.forEach(function(f){return f.kill&&f.kill()}),this.clear(),r)for(var u=Fo.length;u--;)Fo[u].id===this.id&&Fo.splice(u,1)},e.revert=function(a){this.kill(a||{})},o})(),yR=(function(){function o(n){this.contexts=[],this.scope=n,Un&&Un.data.push(this)}var e=o.prototype;return e.add=function(a,r,l){yr(a)||(a={matches:a});var u=new Z1(0,l||this.scope),f=u.conditions={},d,p,_;Un&&!u.selector&&(u.selector=Un.selector),this.contexts.push(u),r=u.add("onMatch",r),u.queries=a;for(p in a)p==="all"?_=1:(d=ur.matchMedia(a[p]),d&&(Fo.indexOf(u)<0&&Fo.push(u),(f[p]=d.matches)&&(_=1),d.addListener?d.addListener(V_):d.addEventListener("change",V_)));return _&&r(u,function(v){return u.add(null,v)}),this},e.revert=function(a){this.kill(a||{})},e.kill=function(a){this.contexts.forEach(function(r){return r.kill(a,!0)})},o})(),ld={registerPlugin:function(){for(var e=arguments.length,n=new Array(e),a=0;a<e;a++)n[a]=arguments[a];n.forEach(function(r){return F1(r)})},timeline:function(e){return new ji(e)},getTweensOf:function(e,n){return On.getTweensOf(e,n)},getProperty:function(e,n,a,r){ui(e)&&(e=Ha(e)[0]);var l=Lo(e||{}).get,u=a?b1:M1;return a==="native"&&(a=""),e&&(n?u((pa[n]&&pa[n].get||l)(e,n,a,r)):function(f,d,p){return u((pa[f]&&pa[f].get||l)(e,f,d,p))})},quickSetter:function(e,n,a){if(e=Ha(e),e.length>1){var r=e.map(function(_){return ea.quickSetter(_,n,a)}),l=r.length;return function(_){for(var v=l;v--;)r[v](_)}}e=e[0]||{};var u=pa[n],f=Lo(e),d=f.harness&&(f.harness.aliases||{})[n]||n,p=u?function(_){var v=new u;ql._pt=0,v.init(e,a?_+a:_,ql,0,[e]),v.render(1,v),ql._pt&&cg(1,ql)}:f.set(e,d);return u?p:function(_){return p(e,d,a?_+a:_,f,1)}},quickTo:function(e,n,a){var r,l=ea.to(e,ba((r={},r[n]="+=0.1",r.paused=!0,r.stagger=0,r),a||{})),u=function(d,p,_){return l.resetTo(n,d,p,_)};return u.tween=l,u},isTweening:function(e){return On.getTweensOf(e,!0).length>0},defaults:function(e){return e&&e.ease&&(e.ease=Po(e.ease,Fu.ease)),wy(Fu,e||{})},config:function(e){return wy(Sa,e||{})},registerEffect:function(e){var n=e.name,a=e.effect,r=e.plugins,l=e.defaults,u=e.extendTimeline;(r||"").split(",").forEach(function(f){return f&&!pa[f]&&!Ma[f]&&zu(n+" effect requires "+f+" plugin.")}),Gm[n]=function(f,d,p){return a(Ha(f),ba(d||{},l),p)},u&&(ji.prototype[n]=function(f,d,p){return this.add(Gm[n](f,yr(d)?d:(p=d)&&{},this),p)})},registerEase:function(e,n){qt[e]=Po(n)},parseEase:function(e,n){return arguments.length?Po(e,n):qt},getById:function(e){return On.getById(e)},exportRoot:function(e,n){e===void 0&&(e={});var a=new ji(e),r,l;for(a.smoothChildTiming=Zi(e.smoothChildTiming),On.remove(a),a._dp=0,a._time=a._tTime=On._time,r=On._first;r;)l=r._next,(n||!(!r._dur&&r instanceof Jn&&r.vars.onComplete===r._targets[0]))&&dr(a,r,r._start-r._delay),r=l;return dr(On,a,0),a},context:function(e,n){return e?new Z1(e,n):Un},matchMedia:function(e){return new yR(e)},matchMediaRefresh:function(){return Fo.forEach(function(e){var n=e.conditions,a,r;for(r in n)n[r]&&(n[r]=!1,a=1);a&&e.revert()})||V_()},addEventListener:function(e,n){var a=Wh[e]||(Wh[e]=[]);~a.indexOf(n)||a.push(n)},removeEventListener:function(e,n){var a=Wh[e],r=a&&a.indexOf(n);r>=0&&a.splice(r,1)},utils:{wrap:JA,wrapYoyo:$A,distribute:D1,random:N1,snap:U1,normalize:QA,getUnit:Ai,clamp:YA,splitColor:z1,toArray:Ha,selector:B_,mapRange:O1,pipe:ZA,unitize:KA,interpolate:eR,shuffle:w1},install:g1,effects:Gm,ticker:_a,updateRoot:ji.updateRoot,plugins:pa,globalTimeline:On,core:{PropTween:Qi,globals:v1,Tween:Jn,Timeline:ji,Animation:Gu,getCache:Lo,_removeLinkedListItem:Md,reverting:function(){return gi},context:function(e){return e&&Un&&(Un.data.push(e),e._ctx=Un),Un},suppressOverwrites:function(e){return K0=e}}};Ki("to,from,fromTo,delayedCall,set,killTweensOf",function(o){return ld[o]=Jn[o]});_a.add(ji.updateRoot);ql=ld.to({},{duration:0});var MR=function(e,n){for(var a=e._pt;a&&a.p!==n&&a.op!==n&&a.fp!==n;)a=a._next;return a},bR=function(e,n){var a=e._targets,r,l,u;for(r in n)for(l=a.length;l--;)u=e._ptLookup[l][r],u&&(u=u.d)&&(u._pt&&(u=MR(u,r)),u&&u.modifier&&u.modifier(n[r],e,a[l],r))},qm=function(e,n){return{name:e,headless:1,rawVars:1,init:function(r,l,u){u._onInit=function(f){var d,p;if(ui(l)&&(d={},Ki(l,function(_){return d[_]=1}),l=d),n){d={};for(p in l)d[p]=n(l[p]);l=d}bR(f,l)}}}},ea=ld.registerPlugin({name:"attr",init:function(e,n,a,r,l){var u,f,d;this.tween=a;for(u in n)d=e.getAttribute(u)||"",f=this.add(e,"setAttribute",(d||0)+"",n[u],r,l,0,0,u),f.op=u,f.b=d,this._props.push(u)},render:function(e,n){for(var a=n._pt;a;)gi?a.set(a.t,a.p,a.b,a):a.r(e,a.d),a=a._next}},{name:"endArray",headless:1,init:function(e,n){for(var a=n.length;a--;)this.add(e,a,e[a]||0,n[a],0,0,0,0,0,1)}},qm("roundProps",H_),qm("modifiers"),qm("snap",U1))||ld;Jn.version=ji.version=ea.version="3.15.0";_1=1;J0()&&sc();qt.Power0;qt.Power1;qt.Power2;qt.Power3;qt.Power4;qt.Linear;qt.Quad;qt.Cubic;qt.Quart;qt.Quint;qt.Strong;qt.Elastic;qt.Back;qt.SteppedEase;qt.Bounce;qt.Sine;qt.Expo;qt.Circ;var Py,Bs,Zl,ug,wo,Fy,fg,ER=function(){return typeof window<"u"},is={},bo=180/Math.PI,Kl=Math.PI/180,Tl=Math.atan2,zy=1e8,hg=/([A-Z])/g,TR=/(left|right|width|margin|padding|x)/i,AR=/[\s,\(]\S/,pr={autoAlpha:"opacity,visibility",scale:"scaleX,scaleY",alpha:"opacity"},k_=function(e,n){return n.set(n.t,n.p,Math.round((n.s+n.c*e)*1e4)/1e4+n.u,n)},RR=function(e,n){return n.set(n.t,n.p,e===1?n.e:Math.round((n.s+n.c*e)*1e4)/1e4+n.u,n)},CR=function(e,n){return n.set(n.t,n.p,e?Math.round((n.s+n.c*e)*1e4)/1e4+n.u:n.b,n)},wR=function(e,n){return n.set(n.t,n.p,e===1?n.e:e?Math.round((n.s+n.c*e)*1e4)/1e4+n.u:n.b,n)},DR=function(e,n){var a=n.s+n.c*e;n.set(n.t,n.p,~~(a+(a<0?-.5:.5))+n.u,n)},K1=function(e,n){return n.set(n.t,n.p,e?n.e:n.b,n)},Q1=function(e,n){return n.set(n.t,n.p,e!==1?n.b:n.e,n)},UR=function(e,n,a){return e.style[n]=a},NR=function(e,n,a){return e.style.setProperty(n,a)},LR=function(e,n,a){return e._gsap[n]=a},OR=function(e,n,a){return e._gsap.scaleX=e._gsap.scaleY=a},PR=function(e,n,a,r,l){var u=e._gsap;u.scaleX=u.scaleY=a,u.renderTransform(l,u)},FR=function(e,n,a,r,l){var u=e._gsap;u[n]=a,u.renderTransform(l,u)},Pn="transform",Ji=Pn+"Origin",zR=function o(e,n){var a=this,r=this.target,l=r.style,u=r._gsap;if(e in is&&l){if(this.tfm=this.tfm||{},e!=="transform")e=pr[e]||e,~e.indexOf(",")?e.split(",").forEach(function(f){return a.tfm[f]=Yr(r,f)}):this.tfm[e]=u.x?u[e]:Yr(r,e),e===Ji&&(this.tfm.zOrigin=u.zOrigin);else return pr.transform.split(",").forEach(function(f){return o.call(a,f,n)});if(this.props.indexOf(Pn)>=0)return;u.svg&&(this.svgo=r.getAttribute("data-svg-origin"),this.props.push(Ji,n,"")),e=Pn}(l||n)&&this.props.push(e,n,l[e])},J1=function(e){e.translate&&(e.removeProperty("translate"),e.removeProperty("scale"),e.removeProperty("rotate"))},IR=function(){var e=this.props,n=this.target,a=n.style,r=n._gsap,l,u;for(l=0;l<e.length;l+=3)e[l+1]?e[l+1]===2?n[e[l]](e[l+2]):n[e[l]]=e[l+2]:e[l+2]?a[e[l]]=e[l+2]:a.removeProperty(e[l].substr(0,2)==="--"?e[l]:e[l].replace(hg,"-$1").toLowerCase());if(this.tfm){for(u in this.tfm)r[u]=this.tfm[u];r.svg&&(r.renderTransform(),n.setAttribute("data-svg-origin",this.svgo||"")),l=fg(),(!l||!l.isStart)&&!a[Pn]&&(J1(a),r.zOrigin&&a[Ji]&&(a[Ji]+=" "+r.zOrigin+"px",r.zOrigin=0,r.renderTransform()),r.uncache=1)}},$1=function(e,n){var a={target:e,props:[],revert:IR,save:zR};return e._gsap||ea.core.getCache(e),n&&e.style&&e.nodeType&&n.split(",").forEach(function(r){return a.save(r)}),a},eb,X_=function(e,n){var a=Bs.createElementNS?Bs.createElementNS((n||"http://www.w3.org/1999/xhtml").replace(/^https/,"http"),e):Bs.createElement(e);return a&&a.style?a:Bs.createElement(e)},xa=function o(e,n,a){var r=getComputedStyle(e);return r[n]||r.getPropertyValue(n.replace(hg,"-$1").toLowerCase())||r.getPropertyValue(n)||!a&&o(e,oc(n)||n,1)||""},Iy="O,Moz,ms,Ms,Webkit".split(","),oc=function(e,n,a){var r=n||wo,l=r.style,u=5;if(e in l&&!a)return e;for(e=e.charAt(0).toUpperCase()+e.substr(1);u--&&!(Iy[u]+e in l););return u<0?null:(u===3?"ms":u>=0?Iy[u]:"")+e},W_=function(){ER()&&window.document&&(Py=window,Bs=Py.document,Zl=Bs.documentElement,wo=X_("div")||{style:{}},X_("div"),Pn=oc(Pn),Ji=Pn+"Origin",wo.style.cssText="border-width:0;line-height:0;position:absolute;padding:0",eb=!!oc("perspective"),fg=ea.core.reverting,ug=1)},By=function(e){var n=e.ownerSVGElement,a=X_("svg",n&&n.getAttribute("xmlns")||"http://www.w3.org/2000/svg"),r=e.cloneNode(!0),l;r.style.display="block",a.appendChild(r),Zl.appendChild(a);try{l=r.getBBox()}catch{}return a.removeChild(r),Zl.removeChild(a),l},Hy=function(e,n){for(var a=n.length;a--;)if(e.hasAttribute(n[a]))return e.getAttribute(n[a])},tb=function(e){var n,a;try{n=e.getBBox()}catch{n=By(e),a=1}return n&&(n.width||n.height)||a||(n=By(e)),n&&!n.width&&!n.x&&!n.y?{x:+Hy(e,["x","cx","x1"])||0,y:+Hy(e,["y","cy","y1"])||0,width:0,height:0}:n},nb=function(e){return!!(e.getCTM&&(!e.parentNode||e.ownerSVGElement)&&tb(e))},js=function(e,n){if(n){var a=e.style,r;n in is&&n!==Ji&&(n=Pn),a.removeProperty?(r=n.substr(0,2),(r==="ms"||n.substr(0,6)==="webkit")&&(n="-"+n),a.removeProperty(r==="--"?n:n.replace(hg,"-$1").toLowerCase())):a.removeAttribute(n)}},Hs=function(e,n,a,r,l,u){var f=new Qi(e._pt,n,a,0,1,u?Q1:K1);return e._pt=f,f.b=r,f.e=l,e._props.push(a),f},Gy={deg:1,rad:1,turn:1},BR={grid:1,flex:1},Zs=function o(e,n,a,r){var l=parseFloat(a)||0,u=(a+"").trim().substr((l+"").length)||"px",f=wo.style,d=TR.test(n),p=e.tagName.toLowerCase()==="svg",_=(p?"client":"offset")+(d?"Width":"Height"),v=100,g=r==="px",x=r==="%",M,E,S,y;if(r===u||!l||Gy[r]||Gy[u])return l;if(u!=="px"&&!g&&(l=o(e,n,a,"px")),y=e.getCTM&&nb(e),(x||u==="%")&&(is[n]||~n.indexOf("adius")))return M=y?e.getBBox()[d?"width":"height"]:e[_],Gn(x?l/M*v:l/100*M);if(f[d?"width":"height"]=v+(g?u:r),E=r!=="rem"&&~n.indexOf("adius")||r==="em"&&e.appendChild&&!p?e:e.parentNode,y&&(E=(e.ownerSVGElement||{}).parentNode),(!E||E===Bs||!E.appendChild)&&(E=Bs.body),S=E._gsap,S&&x&&S.width&&d&&S.time===_a.time&&!S.uncache)return Gn(l/S.width*v);if(x&&(n==="height"||n==="width")){var R=e.style[n];e.style[n]=v+r,M=e[_],R?e.style[n]=R:js(e,n)}else(x||u==="%")&&!BR[xa(E,"display")]&&(f.position=xa(e,"position")),E===e&&(f.position="static"),E.appendChild(wo),M=wo[_],E.removeChild(wo),f.position="absolute";return d&&x&&(S=Lo(E),S.time=_a.time,S.width=E[_]),Gn(g?M*l/v:M&&l?v/M*l:0)},Yr=function(e,n,a,r){var l;return ug||W_(),n in pr&&n!=="transform"&&(n=pr[n],~n.indexOf(",")&&(n=n.split(",")[0])),is[n]&&n!=="transform"?(l=ku(e,r),l=n!=="transformOrigin"?l[n]:l.svg?l.origin:ud(xa(e,Ji))+" "+l.zOrigin+"px"):(l=e.style[n],(!l||l==="auto"||r||~(l+"").indexOf("calc("))&&(l=cd[n]&&cd[n](e,n,a)||xa(e,n)||S1(e,n)||(n==="opacity"?1:0))),a&&!~(l+"").trim().indexOf(" ")?Zs(e,n,l,a)+a:l},HR=function(e,n,a,r){if(!a||a==="none"){var l=oc(n,e,1),u=l&&xa(e,l,1);u&&u!==a?(n=l,a=u):n==="borderColor"&&(a=xa(e,"borderTopColor"))}var f=new Qi(this._pt,e.style,n,0,1,Y1),d=0,p=0,_,v,g,x,M,E,S,y,R,U,C,F;if(f.b=a,f.e=r,a+="",r+="",r.substring(0,6)==="var(--"&&(r=xa(e,r.substring(4,r.indexOf(")")))),r==="auto"&&(E=e.style[n],e.style[n]=r,r=xa(e,n)||r,E?e.style[n]=E:js(e,n)),_=[a,r],B1(_),a=_[0],r=_[1],g=a.match(Wl)||[],F=r.match(Wl)||[],F.length){for(;v=Wl.exec(r);)S=v[0],R=r.substring(d,v.index),M?M=(M+1)%5:(R.substr(-5)==="rgba("||R.substr(-5)==="hsla(")&&(M=1),S!==(E=g[p++]||"")&&(x=parseFloat(E)||0,C=E.substr((x+"").length),S.charAt(1)==="="&&(S=jl(x,S)+C),y=parseFloat(S),U=S.substr((y+"").length),d=Wl.lastIndex-U.length,U||(U=U||Sa.units[n]||C,d===r.length&&(r+=U,f.e+=U)),C!==U&&(x=Zs(e,n,E,U)||0),f._pt={_next:f._pt,p:R||p===1?R:",",s:x,c:y-x,m:M&&M<4||n==="zIndex"?Math.round:0});f.c=d<r.length?r.substring(d,r.length):""}else f.r=n==="display"&&r==="none"?Q1:K1;return m1.test(r)&&(f.e=0),this._pt=f,f},Vy={top:"0%",bottom:"100%",left:"0%",right:"100%",center:"50%"},GR=function(e){var n=e.split(" "),a=n[0],r=n[1]||"50%";return(a==="top"||a==="bottom"||r==="left"||r==="right")&&(e=a,a=r,r=e),n[0]=Vy[a]||a,n[1]=Vy[r]||r,n.join(" ")},VR=function(e,n){if(n.tween&&n.tween._time===n.tween._dur){var a=n.t,r=a.style,l=n.u,u=a._gsap,f,d,p;if(l==="all"||l===!0)r.cssText="",d=1;else for(l=l.split(","),p=l.length;--p>-1;)f=l[p],is[f]&&(d=1,f=f==="transformOrigin"?Ji:Pn),js(a,f);d&&(js(a,Pn),u&&(u.svg&&a.removeAttribute("transform"),r.scale=r.rotate=r.translate="none",ku(a,1),u.uncache=1,J1(r)))}},cd={clearProps:function(e,n,a,r,l){if(l.data!=="isFromStart"){var u=e._pt=new Qi(e._pt,n,a,0,0,VR);return u.u=r,u.pr=-10,u.tween=l,e._props.push(a),1}}},Vu=[1,0,0,1,0,0],ib={},ab=function(e){return e==="matrix(1, 0, 0, 1, 0, 0)"||e==="none"||!e},ky=function(e){var n=xa(e,Pn);return ab(n)?Vu:n.substr(7).match(p1).map(Gn)},dg=function(e,n){var a=e._gsap||Lo(e),r=e.style,l=ky(e),u,f,d,p;return a.svg&&e.getAttribute("transform")?(d=e.transform.baseVal.consolidate().matrix,l=[d.a,d.b,d.c,d.d,d.e,d.f],l.join(",")==="1,0,0,1,0,0"?Vu:l):(l===Vu&&!e.offsetParent&&e!==Zl&&!a.svg&&(d=r.display,r.display="block",u=e.parentNode,(!u||!e.offsetParent&&!e.getBoundingClientRect().width)&&(p=1,f=e.nextElementSibling,Zl.appendChild(e)),l=ky(e),d?r.display=d:js(e,"display"),p&&(f?u.insertBefore(e,f):u?u.appendChild(e):Zl.removeChild(e))),n&&l.length>6?[l[0],l[1],l[4],l[5],l[12],l[13]]:l)},q_=function(e,n,a,r,l,u){var f=e._gsap,d=l||dg(e,!0),p=f.xOrigin||0,_=f.yOrigin||0,v=f.xOffset||0,g=f.yOffset||0,x=d[0],M=d[1],E=d[2],S=d[3],y=d[4],R=d[5],U=n.split(" "),C=parseFloat(U[0])||0,F=parseFloat(U[1])||0,O,D,T,L;a?d!==Vu&&(D=x*S-M*E)&&(T=C*(S/D)+F*(-E/D)+(E*R-S*y)/D,L=C*(-M/D)+F*(x/D)-(x*R-M*y)/D,C=T,F=L):(O=tb(e),C=O.x+(~U[0].indexOf("%")?C/100*O.width:C),F=O.y+(~(U[1]||U[0]).indexOf("%")?F/100*O.height:F)),r||r!==!1&&f.smooth?(y=C-p,R=F-_,f.xOffset=v+(y*x+R*E)-y,f.yOffset=g+(y*M+R*S)-R):f.xOffset=f.yOffset=0,f.xOrigin=C,f.yOrigin=F,f.smooth=!!r,f.origin=n,f.originIsAbsolute=!!a,e.style[Ji]="0px 0px",u&&(Hs(u,f,"xOrigin",p,C),Hs(u,f,"yOrigin",_,F),Hs(u,f,"xOffset",v,f.xOffset),Hs(u,f,"yOffset",g,f.yOffset)),e.setAttribute("data-svg-origin",C+" "+F)},ku=function(e,n){var a=e._gsap||new G1(e);if("x"in a&&!n&&!a.uncache)return a;var r=e.style,l=a.scaleX<0,u="px",f="deg",d=getComputedStyle(e),p=xa(e,Ji)||"0",_,v,g,x,M,E,S,y,R,U,C,F,O,D,T,L,H,V,k,te,ie,W,z,B,J,fe,G,I,K,Se,be,Ue;return _=v=g=E=S=y=R=U=C=0,x=M=1,a.svg=!!(e.getCTM&&nb(e)),d.translate&&((d.translate!=="none"||d.scale!=="none"||d.rotate!=="none")&&(r[Pn]=(d.translate!=="none"?"translate3d("+(d.translate+" 0 0").split(" ").slice(0,3).join(", ")+") ":"")+(d.rotate!=="none"?"rotate("+d.rotate+") ":"")+(d.scale!=="none"?"scale("+d.scale.split(" ").join(",")+") ":"")+(d[Pn]!=="none"?d[Pn]:"")),r.scale=r.rotate=r.translate="none"),D=dg(e,a.svg),a.svg&&(a.uncache?(J=e.getBBox(),p=a.xOrigin-J.x+"px "+(a.yOrigin-J.y)+"px",B=""):B=!n&&e.getAttribute("data-svg-origin"),q_(e,B||p,!!B||a.originIsAbsolute,a.smooth!==!1,D)),F=a.xOrigin||0,O=a.yOrigin||0,D!==Vu&&(V=D[0],k=D[1],te=D[2],ie=D[3],_=W=D[4],v=z=D[5],D.length===6?(x=Math.sqrt(V*V+k*k),M=Math.sqrt(ie*ie+te*te),E=V||k?Tl(k,V)*bo:0,R=te||ie?Tl(te,ie)*bo+E:0,R&&(M*=Math.abs(Math.cos(R*Kl))),a.svg&&(_-=F-(F*V+O*te),v-=O-(F*k+O*ie))):(Ue=D[6],Se=D[7],G=D[8],I=D[9],K=D[10],be=D[11],_=D[12],v=D[13],g=D[14],T=Tl(Ue,K),S=T*bo,T&&(L=Math.cos(-T),H=Math.sin(-T),B=W*L+G*H,J=z*L+I*H,fe=Ue*L+K*H,G=W*-H+G*L,I=z*-H+I*L,K=Ue*-H+K*L,be=Se*-H+be*L,W=B,z=J,Ue=fe),T=Tl(-te,K),y=T*bo,T&&(L=Math.cos(-T),H=Math.sin(-T),B=V*L-G*H,J=k*L-I*H,fe=te*L-K*H,be=ie*H+be*L,V=B,k=J,te=fe),T=Tl(k,V),E=T*bo,T&&(L=Math.cos(T),H=Math.sin(T),B=V*L+k*H,J=W*L+z*H,k=k*L-V*H,z=z*L-W*H,V=B,W=J),S&&Math.abs(S)+Math.abs(E)>359.9&&(S=E=0,y=180-y),x=Gn(Math.sqrt(V*V+k*k+te*te)),M=Gn(Math.sqrt(z*z+Ue*Ue)),T=Tl(W,z),R=Math.abs(T)>2e-4?T*bo:0,C=be?1/(be<0?-be:be):0),a.svg&&(B=e.getAttribute("transform"),a.forceCSS=e.setAttribute("transform","")||!ab(xa(e,Pn)),B&&e.setAttribute("transform",B))),Math.abs(R)>90&&Math.abs(R)<270&&(l?(x*=-1,R+=E<=0?180:-180,E+=E<=0?180:-180):(M*=-1,R+=R<=0?180:-180)),n=n||a.uncache,a.x=_-((a.xPercent=_&&(!n&&a.xPercent||(Math.round(e.offsetWidth/2)===Math.round(-_)?-50:0)))?e.offsetWidth*a.xPercent/100:0)+u,a.y=v-((a.yPercent=v&&(!n&&a.yPercent||(Math.round(e.offsetHeight/2)===Math.round(-v)?-50:0)))?e.offsetHeight*a.yPercent/100:0)+u,a.z=g+u,a.scaleX=Gn(x),a.scaleY=Gn(M),a.rotation=Gn(E)+f,a.rotationX=Gn(S)+f,a.rotationY=Gn(y)+f,a.skewX=R+f,a.skewY=U+f,a.transformPerspective=C+u,(a.zOrigin=parseFloat(p.split(" ")[2])||!n&&a.zOrigin||0)&&(r[Ji]=ud(p)),a.xOffset=a.yOffset=0,a.force3D=Sa.force3D,a.renderTransform=a.svg?XR:eb?rb:kR,a.uncache=0,a},ud=function(e){return(e=e.split(" "))[0]+" "+e[1]},Ym=function(e,n,a){var r=Ai(n);return Gn(parseFloat(n)+parseFloat(Zs(e,"x",a+"px",r)))+r},kR=function(e,n){n.z="0px",n.rotationY=n.rotationX="0deg",n.force3D=0,rb(e,n)},go="0deg",au="0px",vo=") ",rb=function(e,n){var a=n||this,r=a.xPercent,l=a.yPercent,u=a.x,f=a.y,d=a.z,p=a.rotation,_=a.rotationY,v=a.rotationX,g=a.skewX,x=a.skewY,M=a.scaleX,E=a.scaleY,S=a.transformPerspective,y=a.force3D,R=a.target,U=a.zOrigin,C="",F=y==="auto"&&e&&e!==1||y===!0;if(U&&(v!==go||_!==go)){var O=parseFloat(_)*Kl,D=Math.sin(O),T=Math.cos(O),L;O=parseFloat(v)*Kl,L=Math.cos(O),u=Ym(R,u,D*L*-U),f=Ym(R,f,-Math.sin(O)*-U),d=Ym(R,d,T*L*-U+U)}S!==au&&(C+="perspective("+S+vo),(r||l)&&(C+="translate("+r+"%, "+l+"%) "),(F||u!==au||f!==au||d!==au)&&(C+=d!==au||F?"translate3d("+u+", "+f+", "+d+") ":"translate("+u+", "+f+vo),p!==go&&(C+="rotate("+p+vo),_!==go&&(C+="rotateY("+_+vo),v!==go&&(C+="rotateX("+v+vo),(g!==go||x!==go)&&(C+="skew("+g+", "+x+vo),(M!==1||E!==1)&&(C+="scale("+M+", "+E+vo),R.style[Pn]=C||"translate(0, 0)"},XR=function(e,n){var a=n||this,r=a.xPercent,l=a.yPercent,u=a.x,f=a.y,d=a.rotation,p=a.skewX,_=a.skewY,v=a.scaleX,g=a.scaleY,x=a.target,M=a.xOrigin,E=a.yOrigin,S=a.xOffset,y=a.yOffset,R=a.forceCSS,U=parseFloat(u),C=parseFloat(f),F,O,D,T,L;d=parseFloat(d),p=parseFloat(p),_=parseFloat(_),_&&(_=parseFloat(_),p+=_,d+=_),d||p?(d*=Kl,p*=Kl,F=Math.cos(d)*v,O=Math.sin(d)*v,D=Math.sin(d-p)*-g,T=Math.cos(d-p)*g,p&&(_*=Kl,L=Math.tan(p-_),L=Math.sqrt(1+L*L),D*=L,T*=L,_&&(L=Math.tan(_),L=Math.sqrt(1+L*L),F*=L,O*=L)),F=Gn(F),O=Gn(O),D=Gn(D),T=Gn(T)):(F=v,T=g,O=D=0),(U&&!~(u+"").indexOf("px")||C&&!~(f+"").indexOf("px"))&&(U=Zs(x,"x",u,"px"),C=Zs(x,"y",f,"px")),(M||E||S||y)&&(U=Gn(U+M-(M*F+E*D)+S),C=Gn(C+E-(M*O+E*T)+y)),(r||l)&&(L=x.getBBox(),U=Gn(U+r/100*L.width),C=Gn(C+l/100*L.height)),L="matrix("+F+","+O+","+D+","+T+","+U+","+C+")",x.setAttribute("transform",L),R&&(x.style[Pn]=L)},WR=function(e,n,a,r,l){var u=360,f=ui(l),d=parseFloat(l)*(f&&~l.indexOf("rad")?bo:1),p=d-r,_=r+p+"deg",v,g;return f&&(v=l.split("_")[1],v==="short"&&(p%=u,p!==p%(u/2)&&(p+=p<0?u:-u)),v==="cw"&&p<0?p=(p+u*zy)%u-~~(p/u)*u:v==="ccw"&&p>0&&(p=(p-u*zy)%u-~~(p/u)*u)),e._pt=g=new Qi(e._pt,n,a,r,p,RR),g.e=_,g.u="deg",e._props.push(a),g},Xy=function(e,n){for(var a in n)e[a]=n[a];return e},qR=function(e,n,a){var r=Xy({},a._gsap),l="perspective,force3D,transformOrigin,svgOrigin",u=a.style,f,d,p,_,v,g,x,M;r.svg?(p=a.getAttribute("transform"),a.setAttribute("transform",""),u[Pn]=n,f=ku(a,1),js(a,Pn),a.setAttribute("transform",p)):(p=getComputedStyle(a)[Pn],u[Pn]=n,f=ku(a,1),u[Pn]=p);for(d in is)p=r[d],_=f[d],p!==_&&l.indexOf(d)<0&&(x=Ai(p),M=Ai(_),v=x!==M?Zs(a,d,p,M):parseFloat(p),g=parseFloat(_),e._pt=new Qi(e._pt,f,d,v,g-v,k_),e._pt.u=M||0,e._props.push(d));Xy(f,r)};Ki("padding,margin,Width,Radius",function(o,e){var n="Top",a="Right",r="Bottom",l="Left",u=(e<3?[n,a,r,l]:[n+l,n+a,r+a,r+l]).map(function(f){return e<2?o+f:"border"+f+o});cd[e>1?"border"+o:o]=function(f,d,p,_,v){var g,x;if(arguments.length<4)return g=u.map(function(M){return Yr(f,M,p)}),x=g.join(" "),x.split(g[0]).length===5?g[0]:x;g=(_+"").split(" "),x={},u.forEach(function(M,E){return x[M]=g[E]=g[E]||g[(E-1)/2|0]}),f.init(d,x,v)}});var sb={name:"css",register:W_,targetTest:function(e){return e.style&&e.nodeType},init:function(e,n,a,r,l){var u=this._props,f=e.style,d=a.vars.startAt,p,_,v,g,x,M,E,S,y,R,U,C,F,O,D,T,L;ug||W_(),this.styles=this.styles||$1(e),T=this.styles.props,this.tween=a;for(E in n)if(E!=="autoRound"&&(_=n[E],!(pa[E]&&V1(E,n,a,r,e,l)))){if(x=typeof _,M=cd[E],x==="function"&&(_=_.call(a,r,e,l),x=typeof _),x==="string"&&~_.indexOf("random(")&&(_=Bu(_)),M)M(this,e,E,_,a)&&(D=1);else if(E.substr(0,2)==="--")p=(getComputedStyle(e).getPropertyValue(E)+"").trim(),_+="",Ws.lastIndex=0,Ws.test(p)||(S=Ai(p),y=Ai(_),y?S!==y&&(p=Zs(e,E,p,y)+y):S&&(_+=S)),this.add(f,"setProperty",p,_,r,l,0,0,E),u.push(E),T.push(E,0,f[E]);else if(x!=="undefined"){if(d&&E in d?(p=typeof d[E]=="function"?d[E].call(a,r,e,l):d[E],ui(p)&&~p.indexOf("random(")&&(p=Bu(p)),Ai(p+"")||p==="auto"||(p+=Sa.units[E]||Ai(Yr(e,E))||""),(p+"").charAt(1)==="="&&(p=Yr(e,E))):p=Yr(e,E),g=parseFloat(p),R=x==="string"&&_.charAt(1)==="="&&_.substr(0,2),R&&(_=_.substr(2)),v=parseFloat(_),E in pr&&(E==="autoAlpha"&&(g===1&&Yr(e,"visibility")==="hidden"&&v&&(g=0),T.push("visibility",0,f.visibility),Hs(this,f,"visibility",g?"inherit":"hidden",v?"inherit":"hidden",!v)),E!=="scale"&&E!=="transform"&&(E=pr[E],~E.indexOf(",")&&(E=E.split(",")[0]))),U=E in is,U){if(this.styles.save(E),L=_,x==="string"&&_.substring(0,6)==="var(--"){if(_=xa(e,_.substring(4,_.indexOf(")"))),_.substring(0,5)==="calc("){var H=e.style.perspective;e.style.perspective=_,_=xa(e,"perspective"),H?e.style.perspective=H:js(e,"perspective")}v=parseFloat(_)}if(C||(F=e._gsap,F.renderTransform&&!n.parseTransform||ku(e,n.parseTransform),O=n.smoothOrigin!==!1&&F.smooth,C=this._pt=new Qi(this._pt,f,Pn,0,1,F.renderTransform,F,0,-1),C.dep=1),E==="scale")this._pt=new Qi(this._pt,F,"scaleY",F.scaleY,(R?jl(F.scaleY,R+v):v)-F.scaleY||0,k_),this._pt.u=0,u.push("scaleY",E),E+="X";else if(E==="transformOrigin"){T.push(Ji,0,f[Ji]),_=GR(_),F.svg?q_(e,_,0,O,0,this):(y=parseFloat(_.split(" ")[2])||0,y!==F.zOrigin&&Hs(this,F,"zOrigin",F.zOrigin,y),Hs(this,f,E,ud(p),ud(_)));continue}else if(E==="svgOrigin"){q_(e,_,1,O,0,this);continue}else if(E in ib){WR(this,F,E,g,R?jl(g,R+_):_);continue}else if(E==="smoothOrigin"){Hs(this,F,"smooth",F.smooth,_);continue}else if(E==="force3D"){F[E]=_;continue}else if(E==="transform"){qR(this,_,e);continue}}else E in f||(E=oc(E)||E);if(U||(v||v===0)&&(g||g===0)&&!AR.test(_)&&E in f)S=(p+"").substr((g+"").length),v||(v=0),y=Ai(_)||(E in Sa.units?Sa.units[E]:S),S!==y&&(g=Zs(e,E,p,y)),this._pt=new Qi(this._pt,U?F:f,E,g,(R?jl(g,R+v):v)-g,!U&&(y==="px"||E==="zIndex")&&n.autoRound!==!1?DR:k_),this._pt.u=y||0,U&&L!==_?(this._pt.b=p,this._pt.e=L,this._pt.r=wR):S!==y&&y!=="%"&&(this._pt.b=p,this._pt.r=CR);else if(E in f)HR.call(this,e,E,p,R?R+_:_);else if(E in e)this.add(e,E,p||e[E],R?R+_:_,r,l);else if(E!=="parseTransform"){eg(E,_);continue}U||(E in f?T.push(E,0,f[E]):typeof e[E]=="function"?T.push(E,2,e[E]()):T.push(E,1,p||e[E])),u.push(E)}}D&&j1(this)},render:function(e,n){if(n.tween._time||!fg())for(var a=n._pt;a;)a.r(e,a.d),a=a._next;else n.styles.revert()},get:Yr,aliases:pr,getSetter:function(e,n,a){var r=pr[n];return r&&r.indexOf(",")<0&&(n=r),n in is&&n!==Ji&&(e._gsap.x||Yr(e,"x"))?a&&Fy===a?n==="scale"?OR:LR:(Fy=a||{})&&(n==="scale"?PR:FR):e.style&&!Q0(e.style[n])?UR:~n.indexOf("-")?NR:lg(e,n)},core:{_removeProperty:js,_getMatrix:dg}};ea.utils.checkPrefix=oc;ea.core.getStyleSaver=$1;(function(o,e,n,a){var r=Ki(o+","+e+","+n,function(l){is[l]=1});Ki(e,function(l){Sa.units[l]="deg",ib[l]=1}),pr[r[13]]=o+","+e,Ki(a,function(l){var u=l.split(":");pr[u[1]]=r[u[0]]})})("x,y,z,scale,scaleX,scaleY,xPercent,yPercent","rotation,rotationX,rotationY,skewX,skewY","transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective","0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY");Ki("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective",function(o){Sa.units[o]="px"});ea.registerPlugin(sb);var yn=ea.registerPlugin(sb)||ea;yn.core.Tween;function YR(){const o=pt.useRef(null),[e,n]=pt.useState(!1),[a,r]=pt.useState(!1);pt.useEffect(()=>{if(!o.current)return;yn.fromTo(o.current,{opacity:0,y:-20},{opacity:1,y:0,duration:.8,delay:.2,ease:"power2.out"});const f=()=>{n(window.scrollY>window.innerHeight*.8)};return window.addEventListener("scroll",f,{passive:!0}),()=>window.removeEventListener("scroll",f)},[]);const l=f=>{r(!1);const d=document.getElementById(f);d&&d.scrollIntoView({behavior:"smooth",block:"start"})},u=[{label:"Cestas",target:"cestas"},{label:"Sobre",target:"sobre"},{label:"Depoimentos",target:"depoimentos"},{label:"Galeria",target:"galeria"},{label:"Contato",target:"contato"}];return ge.jsxs(ge.Fragment,{children:[ge.jsx("nav",{"code-path":"src/components/Navigation.tsx:42:7",ref:o,className:"fixed top-0 left-0 right-0 z-50 transition-all duration-300",style:{height:80,backgroundColor:e?"rgba(255,248,240,0.92)":"transparent",backdropFilter:e?"blur(12px)":"none"},children:ge.jsxs("div",{"code-path":"src/components/Navigation.tsx:51:9",className:"flex items-center justify-between h-full px-6 lg:px-12 max-w-[1400px] mx-auto",children:[ge.jsx("button",{"code-path":"src/components/Navigation.tsx:53:11",onClick:()=>window.scrollTo({top:0,behavior:"smooth"}),className:"font-display text-chocolate text-2xl cursor-pointer",children:"Petit Pauly"}),ge.jsx("div",{"code-path":"src/components/Navigation.tsx:61:11",className:"hidden md:flex items-center gap-8",children:u.map(f=>ge.jsx("button",{"code-path":"src/components/Navigation.tsx:63:15",onClick:()=>l(f.target),className:"font-menu text-chocolate hover:text-caramel transition-colors duration-300 cursor-pointer",children:f.label},f.target))}),ge.jsx("button",{"code-path":"src/components/Navigation.tsx:74:11",onClick:()=>l("contato"),className:"hidden md:block font-menu text-milk bg-chocolate hover:bg-caramel px-6 py-3 rounded-full transition-colors duration-300 cursor-pointer",children:"Encomendar"}),ge.jsxs("button",{"code-path":"src/components/Navigation.tsx:82:11",onClick:()=>r(!a),className:"md:hidden flex flex-col gap-1.5 p-2 cursor-pointer","aria-label":"Menu",children:[ge.jsx("span",{"code-path":"src/components/Navigation.tsx:87:13",className:"block w-6 h-0.5 bg-chocolate transition-transform duration-300",style:{transform:a?"rotate(45deg) translateY(4px)":"none"}}),ge.jsx("span",{"code-path":"src/components/Navigation.tsx:93:13",className:"block w-6 h-0.5 bg-chocolate transition-opacity duration-300",style:{opacity:a?0:1}}),ge.jsx("span",{"code-path":"src/components/Navigation.tsx:97:13",className:"block w-6 h-0.5 bg-chocolate transition-transform duration-300",style:{transform:a?"rotate(-45deg) translateY(-4px)":"none"}})]})]})}),a&&ge.jsxs("div",{"code-path":"src/components/Navigation.tsx:109:9",className:"fixed inset-0 z-40 bg-milk flex flex-col items-center justify-center gap-8 md:hidden",children:[u.map(f=>ge.jsx("button",{"code-path":"src/components/Navigation.tsx:111:13",onClick:()=>l(f.target),className:"font-display text-chocolate text-3xl hover:text-caramel transition-colors duration-300 cursor-pointer",children:f.label},f.target)),ge.jsx("button",{"code-path":"src/components/Navigation.tsx:119:11",onClick:()=>l("contato"),className:"font-menu text-milk bg-chocolate hover:bg-caramel px-8 py-4 rounded-full transition-colors duration-300 cursor-pointer mt-4",children:"Encomendar"})]})]})}function jR(o,e){for(var n=0;n<e.length;n++){var a=e[n];a.enumerable=a.enumerable||!1,a.configurable=!0,"value"in a&&(a.writable=!0),Object.defineProperty(o,a.key,a)}}function ZR(o,e,n){return e&&jR(o.prototype,e),o}var mi,qh,ga,Gs,Vs,Ql,ob,Eo,Jl,lb,Kr,Qa,cb,ub=function(){return mi||typeof window<"u"&&(mi=window.gsap)&&mi.registerPlugin&&mi},fb=1,Yl=[],Pt=[],vr=[],Ru=Date.now,Y_=function(e,n){return n},KR=function(){var e=Jl.core,n=e.bridge||{},a=e._scrollers,r=e._proxies;a.push.apply(a,Pt),r.push.apply(r,vr),Pt=a,vr=r,Y_=function(u,f){return n[u](f)}},qs=function(e,n){return~vr.indexOf(e)&&vr[vr.indexOf(e)+1][n]},Cu=function(e){return!!~lb.indexOf(e)},Li=function(e,n,a,r,l){return e.addEventListener(n,a,{passive:r!==!1,capture:!!l})},Ni=function(e,n,a,r){return e.removeEventListener(n,a,!!r)},lh="scrollLeft",ch="scrollTop",j_=function(){return Kr&&Kr.isPressed||Pt.cache++},fd=function(e,n){var a=function r(l){if(l||l===0){fb&&(ga.history.scrollRestoration="manual");var u=Kr&&Kr.isPressed;l=r.v=Math.round(l)||(Kr&&Kr.iOS?1:0),e(l),r.cacheID=Pt.cache,u&&Y_("ss",l)}else(n||Pt.cache!==r.cacheID||Y_("ref"))&&(r.cacheID=Pt.cache,r.v=e());return r.v+r.offset};return a.offset=0,e&&a},Ii={s:lh,p:"left",p2:"Left",os:"right",os2:"Right",d:"width",d2:"Width",a:"x",sc:fd(function(o){return arguments.length?ga.scrollTo(o,ni.sc()):ga.pageXOffset||Gs[lh]||Vs[lh]||Ql[lh]||0})},ni={s:ch,p:"top",p2:"Top",os:"bottom",os2:"Bottom",d:"height",d2:"Height",a:"y",op:Ii,sc:fd(function(o){return arguments.length?ga.scrollTo(Ii.sc(),o):ga.pageYOffset||Gs[ch]||Vs[ch]||Ql[ch]||0})},Yi=function(e,n){return(n&&n._ctx&&n._ctx.selector||mi.utils.toArray)(e)[0]||(typeof e=="string"&&mi.config().nullTargetWarn!==!1?console.warn("Element not found:",e):null)},QR=function(e,n){for(var a=n.length;a--;)if(n[a]===e||n[a].contains(e))return!0;return!1},Ks=function(e,n){var a=n.s,r=n.sc;Cu(e)&&(e=Gs.scrollingElement||Vs);var l=Pt.indexOf(e),u=r===ni.sc?1:2;!~l&&(l=Pt.push(e)-1),Pt[l+u]||Li(e,"scroll",j_);var f=Pt[l+u],d=f||(Pt[l+u]=fd(qs(e,a),!0)||(Cu(e)?r:fd(function(p){return arguments.length?e[a]=p:e[a]})));return d.target=e,f||(d.smooth=mi.getProperty(e,"scrollBehavior")==="smooth"),d},Z_=function(e,n,a){var r=e,l=e,u=Ru(),f=u,d=n||50,p=Math.max(500,d*3),_=function(M,E){var S=Ru();E||S-u>d?(l=r,r=M,f=u,u=S):a?r+=M:r=l+(M-l)/(S-f)*(u-f)},v=function(){l=r=a?0:r,f=u=0},g=function(M){var E=f,S=l,y=Ru();return(M||M===0)&&M!==r&&_(M),u===f||y-f>p?0:(r+(a?S:-S))/((a?y:u)-E)*1e3};return{update:_,reset:v,getVelocity:g}},ru=function(e,n){return n&&!e._gsapAllow&&e.cancelable!==!1&&e.preventDefault(),e.changedTouches?e.changedTouches[0]:e},Wy=function(e){var n=Math.max.apply(Math,e),a=Math.min.apply(Math,e);return Math.abs(n)>=Math.abs(a)?n:a},hb=function(){Jl=mi.core.globals().ScrollTrigger,Jl&&Jl.core&&KR()},db=function(e){return mi=e||ub(),!qh&&mi&&typeof document<"u"&&document.body&&(ga=window,Gs=document,Vs=Gs.documentElement,Ql=Gs.body,lb=[ga,Gs,Vs,Ql],mi.utils.clamp,cb=mi.core.context||function(){},Eo="onpointerenter"in Ql?"pointer":"mouse",ob=kn.isTouch=ga.matchMedia&&ga.matchMedia("(hover: none), (pointer: coarse)").matches?1:"ontouchstart"in ga||navigator.maxTouchPoints>0||navigator.msMaxTouchPoints>0?2:0,Qa=kn.eventTypes=("ontouchstart"in Vs?"touchstart,touchmove,touchcancel,touchend":"onpointerdown"in Vs?"pointerdown,pointermove,pointercancel,pointerup":"mousedown,mousemove,mouseup,mouseup").split(","),setTimeout(function(){return fb=0},500),qh=1),Jl||hb(),qh};Ii.op=ni;Pt.cache=0;var kn=(function(){function o(n){this.init(n)}var e=o.prototype;return e.init=function(a){qh||db(mi)||console.warn("Please gsap.registerPlugin(Observer)"),Jl||hb();var r=a.tolerance,l=a.dragMinimum,u=a.type,f=a.target,d=a.lineHeight,p=a.debounce,_=a.preventDefault,v=a.onStop,g=a.onStopDelay,x=a.ignore,M=a.wheelSpeed,E=a.event,S=a.onDragStart,y=a.onDragEnd,R=a.onDrag,U=a.onPress,C=a.onRelease,F=a.onRight,O=a.onLeft,D=a.onUp,T=a.onDown,L=a.onChangeX,H=a.onChangeY,V=a.onChange,k=a.onToggleX,te=a.onToggleY,ie=a.onHover,W=a.onHoverEnd,z=a.onMove,B=a.ignoreCheck,J=a.isNormalizer,fe=a.onGestureStart,G=a.onGestureEnd,I=a.onWheel,K=a.onEnable,Se=a.onDisable,be=a.onClick,Ue=a.scrollSpeed,ne=a.capture,xe=a.allowClicks,Ee=a.lockAxis,Ie=a.onLockAxis;this.target=f=Yi(f)||Vs,this.vars=a,x&&(x=mi.utils.toArray(x)),r=r||1e-9,l=l||0,M=M||1,Ue=Ue||1,u=u||"wheel,touch,pointer",p=p!==!1,d||(d=parseFloat(ga.getComputedStyle(Ql).lineHeight)||22);var nt,Ze,Mt,Ye,it,xt,st,le=this,Dt=0,mn=0,j=a.passive||!_&&a.passive!==!1,gt=Ks(f,Ii),mt=Ks(f,ni),Ft=gt(),Le=mt(),bt=~u.indexOf("touch")&&!~u.indexOf("pointer")&&Qa[0]==="pointerdown",P=Cu(f),A=f.ownerDocument||Gs,Q=[0,0,0],_e=[0,0,0],Te=0,Fe=function(){return Te=Ru()},De=function(Ne,ot){return(le.event=Ne)&&x&&QR(Ne.target,x)||ot&&bt&&Ne.pointerType!=="touch"||B&&B(Ne,ot)},de=function(){le._vx.reset(),le._vy.reset(),Ze.pause(),v&&v(le)},pe=function(){var Ne=le.deltaX=Wy(Q),ot=le.deltaY=Wy(_e),we=Math.abs(Ne)>=r,rt=Math.abs(ot)>=r;V&&(we||rt)&&V(le,Ne,ot,Q,_e),we&&(F&&le.deltaX>0&&F(le),O&&le.deltaX<0&&O(le),L&&L(le),k&&le.deltaX<0!=Dt<0&&k(le),Dt=le.deltaX,Q[0]=Q[1]=Q[2]=0),rt&&(T&&le.deltaY>0&&T(le),D&&le.deltaY<0&&D(le),H&&H(le),te&&le.deltaY<0!=mn<0&&te(le),mn=le.deltaY,_e[0]=_e[1]=_e[2]=0),(Ye||Mt)&&(z&&z(le),Mt&&(S&&Mt===1&&S(le),R&&R(le),Mt=0),Ye=!1),xt&&!(xt=!1)&&Ie&&Ie(le),it&&(I(le),it=!1),nt=0},Be=function(Ne,ot,we){Q[we]+=Ne,_e[we]+=ot,le._vx.update(Ne),le._vy.update(ot),p?nt||(nt=requestAnimationFrame(pe)):pe()},He=function(Ne,ot){Ee&&!st&&(le.axis=st=Math.abs(Ne)>Math.abs(ot)?"x":"y",xt=!0),st!=="y"&&(Q[2]+=Ne,le._vx.update(Ne,!0)),st!=="x"&&(_e[2]+=ot,le._vy.update(ot,!0)),p?nt||(nt=requestAnimationFrame(pe)):pe()},ze=function(Ne){if(!De(Ne,1)){Ne=ru(Ne,_);var ot=Ne.clientX,we=Ne.clientY,rt=ot-le.x,Qe=we-le.y,ft=le.isDragging;le.x=ot,le.y=we,(ft||(rt||Qe)&&(Math.abs(le.startX-ot)>=l||Math.abs(le.startY-we)>=l))&&(Mt||(Mt=ft?2:1),ft||(le.isDragging=!0),He(rt,Qe))}},Oe=le.onPress=function(Ce){De(Ce,1)||Ce&&Ce.button||(le.axis=st=null,Ze.pause(),le.isPressed=!0,Ce=ru(Ce),Dt=mn=0,le.startX=le.x=Ce.clientX,le.startY=le.y=Ce.clientY,le._vx.reset(),le._vy.reset(),Li(J?f:A,Qa[1],ze,j,!0),le.deltaX=le.deltaY=0,U&&U(le))},Ge=le.onRelease=function(Ce){if(!De(Ce,1)){Ni(J?f:A,Qa[1],ze,!0);var Ne=!isNaN(le.y-le.startY),ot=le.isDragging,we=ot&&(Math.abs(le.x-le.startX)>3||Math.abs(le.y-le.startY)>3),rt=ru(Ce);!we&&Ne&&(le._vx.reset(),le._vy.reset(),_&&xe&&mi.delayedCall(.08,function(){if(Ru()-Te>300&&!Ce.defaultPrevented){if(Ce.target.click)Ce.target.click();else if(A.createEvent){var Qe=A.createEvent("MouseEvents");Qe.initMouseEvent("click",!0,!0,ga,1,rt.screenX,rt.screenY,rt.clientX,rt.clientY,!1,!1,!1,!1,0,null),Ce.target.dispatchEvent(Qe)}}})),le.isDragging=le.isGesturing=le.isPressed=!1,v&&ot&&!J&&Ze.restart(!0),Mt&&pe(),y&&ot&&y(le),C&&C(le,we)}},ut=function(Ne){return Ne.touches&&Ne.touches.length>1&&(le.isGesturing=!0)&&fe(Ne,le.isDragging)},dt=function(){return(le.isGesturing=!1)||G(le)},q=function(Ne){if(!De(Ne)){var ot=gt(),we=mt();Be((ot-Ft)*Ue,(we-Le)*Ue,1),Ft=ot,Le=we,v&&Ze.restart(!0)}},Re=function(Ne){if(!De(Ne)){Ne=ru(Ne,_),I&&(it=!0);var ot=(Ne.deltaMode===1?d:Ne.deltaMode===2?ga.innerHeight:1)*M;Be(Ne.deltaX*ot,Ne.deltaY*ot,0),v&&!J&&Ze.restart(!0)}},me=function(Ne){if(!De(Ne)){var ot=Ne.clientX,we=Ne.clientY,rt=ot-le.x,Qe=we-le.y;le.x=ot,le.y=we,Ye=!0,v&&Ze.restart(!0),(rt||Qe)&&He(rt,Qe)}},Ve=function(Ne){le.event=Ne,ie(le)},Pe=function(Ne){le.event=Ne,W(le)},Ae=function(Ne){return De(Ne)||ru(Ne,_)&&be(le)};Ze=le._dc=mi.delayedCall(g||.25,de).pause(),le.deltaX=le.deltaY=0,le._vx=Z_(0,50,!0),le._vy=Z_(0,50,!0),le.scrollX=gt,le.scrollY=mt,le.isDragging=le.isGesturing=le.isPressed=!1,cb(this),le.enable=function(Ce){return le.isEnabled||(Li(P?A:f,"scroll",j_),u.indexOf("scroll")>=0&&Li(P?A:f,"scroll",q,j,ne),u.indexOf("wheel")>=0&&Li(f,"wheel",Re,j,ne),(u.indexOf("touch")>=0&&ob||u.indexOf("pointer")>=0)&&(Li(f,Qa[0],Oe,j,ne),Li(A,Qa[2],Ge),Li(A,Qa[3],Ge),xe&&Li(f,"click",Fe,!0,!0),be&&Li(f,"click",Ae),fe&&Li(A,"gesturestart",ut),G&&Li(A,"gestureend",dt),ie&&Li(f,Eo+"enter",Ve),W&&Li(f,Eo+"leave",Pe),z&&Li(f,Eo+"move",me)),le.isEnabled=!0,le.isDragging=le.isGesturing=le.isPressed=Ye=Mt=!1,le._vx.reset(),le._vy.reset(),Ft=gt(),Le=mt(),Ce&&Ce.type&&Oe(Ce),K&&K(le)),le},le.disable=function(){le.isEnabled&&(Yl.filter(function(Ce){return Ce!==le&&Cu(Ce.target)}).length||Ni(P?A:f,"scroll",j_),le.isPressed&&(le._vx.reset(),le._vy.reset(),Ni(J?f:A,Qa[1],ze,!0)),Ni(P?A:f,"scroll",q,ne),Ni(f,"wheel",Re,ne),Ni(f,Qa[0],Oe,ne),Ni(A,Qa[2],Ge),Ni(A,Qa[3],Ge),Ni(f,"click",Fe,!0),Ni(f,"click",Ae),Ni(A,"gesturestart",ut),Ni(A,"gestureend",dt),Ni(f,Eo+"enter",Ve),Ni(f,Eo+"leave",Pe),Ni(f,Eo+"move",me),le.isEnabled=le.isPressed=le.isDragging=!1,Se&&Se(le))},le.kill=le.revert=function(){le.disable();var Ce=Yl.indexOf(le);Ce>=0&&Yl.splice(Ce,1),Kr===le&&(Kr=0)},Yl.push(le),J&&Cu(f)&&(Kr=le),le.enable(E)},ZR(o,[{key:"velocityX",get:function(){return this._vx.getVelocity()}},{key:"velocityY",get:function(){return this._vy.getVelocity()}}]),o})();kn.version="3.15.0";kn.create=function(o){return new kn(o)};kn.register=db;kn.getAll=function(){return Yl.slice()};kn.getById=function(o){return Yl.filter(function(e){return e.vars.id===o})[0]};ub()&&mi.registerPlugin(kn);var et,kl,Ot,ln,ma,tn,pg,hd,Xu,wu,gu,uh,Ei,Td,K_,Fi,qy,Yy,Xl,pb,jm,mb,Pi,Q_,_b,gb,Fs,J_,mg,$l,_g,Du,$_,Zm,fh=1,Ti=Date.now,Km=Ti(),Ga=0,vu=0,jy=function(e,n,a){var r=da(e)&&(e.substr(0,6)==="clamp("||e.indexOf("max")>-1);return a["_"+n+"Clamp"]=r,r?e.substr(6,e.length-7):e},Zy=function(e,n){return n&&(!da(e)||e.substr(0,6)!=="clamp(")?"clamp("+e+")":e},JR=function o(){return vu&&requestAnimationFrame(o)},Ky=function(){return Td=1},Qy=function(){return Td=0},fr=function(e){return e},xu=function(e){return Math.round(e*1e5)/1e5||0},vb=function(){return typeof window<"u"},xb=function(){return et||vb()&&(et=window.gsap)&&et.registerPlugin&&et},Ho=function(e){return!!~pg.indexOf(e)},Sb=function(e){return(e==="Height"?_g:Ot["inner"+e])||ma["client"+e]||tn["client"+e]},yb=function(e){return qs(e,"getBoundingClientRect")||(Ho(e)?function(){return Qh.width=Ot.innerWidth,Qh.height=_g,Qh}:function(){return jr(e)})},$R=function(e,n,a){var r=a.d,l=a.d2,u=a.a;return(u=qs(e,"getBoundingClientRect"))?function(){return u()[r]}:function(){return(n?Sb(l):e["client"+l])||0}},eC=function(e,n){return!n||~vr.indexOf(e)?yb(e):function(){return Qh}},mr=function(e,n){var a=n.s,r=n.d2,l=n.d,u=n.a;return Math.max(0,(a="scroll"+r)&&(u=qs(e,a))?u()-yb(e)()[l]:Ho(e)?(ma[a]||tn[a])-Sb(r):e[a]-e["offset"+r])},hh=function(e,n){for(var a=0;a<Xl.length;a+=3)(!n||~n.indexOf(Xl[a+1]))&&e(Xl[a],Xl[a+1],Xl[a+2])},da=function(e){return typeof e=="string"},Ri=function(e){return typeof e=="function"},Su=function(e){return typeof e=="number"},To=function(e){return typeof e=="object"},su=function(e,n,a){return e&&e.progress(n?0:1)&&a&&e.pause()},Al=function(e,n,a){if(e.enabled){var r=e._ctx?e._ctx.add(function(){return n(e,a)}):n(e,a);r&&r.totalTime&&(e.callbackAnimation=r)}},Rl=Math.abs,Mb="left",bb="top",gg="right",vg="bottom",zo="width",Io="height",Uu="Right",Nu="Left",Lu="Top",Ou="Bottom",Qn="padding",Fa="margin",lc="Width",xg="Height",ti="px",za=function(e){return Ot.getComputedStyle(e.nodeType===Node.DOCUMENT_NODE?e.scrollingElement:e)},tC=function(e){var n=za(e).position;e.style.position=n==="absolute"||n==="fixed"?n:"relative"},Jy=function(e,n){for(var a in n)a in e||(e[a]=n[a]);return e},jr=function(e,n){var a=n&&za(e)[K_]!=="matrix(1, 0, 0, 1, 0, 0)"&&et.to(e,{x:0,y:0,xPercent:0,yPercent:0,rotation:0,rotationX:0,rotationY:0,scale:1,skewX:0,skewY:0}).progress(1),r=e.getBoundingClientRect?e.getBoundingClientRect():e.scrollingElement.getBoundingClientRect();return a&&a.progress(0).kill(),r},dd=function(e,n){var a=n.d2;return e["offset"+a]||e["client"+a]||0},Eb=function(e){var n=[],a=e.labels,r=e.duration(),l;for(l in a)n.push(a[l]/r);return n},nC=function(e){return function(n){return et.utils.snap(Eb(e),n)}},Sg=function(e){var n=et.utils.snap(e),a=Array.isArray(e)&&e.slice(0).sort(function(r,l){return r-l});return a?function(r,l,u){u===void 0&&(u=.001);var f;if(!l)return n(r);if(l>0){for(r-=u,f=0;f<a.length;f++)if(a[f]>=r)return a[f];return a[f-1]}else for(f=a.length,r+=u;f--;)if(a[f]<=r)return a[f];return a[0]}:function(r,l,u){u===void 0&&(u=.001);var f=n(r);return!l||Math.abs(f-r)<u||f-r<0==l<0?f:n(l<0?r-e:r+e)}},iC=function(e){return function(n,a){return Sg(Eb(e))(n,a.direction)}},dh=function(e,n,a,r){return a.split(",").forEach(function(l){return e(n,l,r)})},ci=function(e,n,a,r,l){return e.addEventListener(n,a,{passive:!r,capture:!!l})},li=function(e,n,a,r){return e.removeEventListener(n,a,!!r)},ph=function(e,n,a){a=a&&a.wheelHandler,a&&(e(n,"wheel",a),e(n,"touchmove",a))},$y={startColor:"green",endColor:"red",indent:0,fontSize:"16px",fontWeight:"normal"},mh={toggleActions:"play",anticipatePin:0},pd={top:0,left:0,center:.5,bottom:1,right:1},Yh=function(e,n){if(da(e)){var a=e.indexOf("="),r=~a?+(e.charAt(a-1)+1)*parseFloat(e.substr(a+1)):0;~a&&(e.indexOf("%")>a&&(r*=n/100),e=e.substr(0,a-1)),e=r+(e in pd?pd[e]*n:~e.indexOf("%")?parseFloat(e)*n/100:parseFloat(e)||0)}return e},_h=function(e,n,a,r,l,u,f,d){var p=l.startColor,_=l.endColor,v=l.fontSize,g=l.indent,x=l.fontWeight,M=ln.createElement("div"),E=Ho(a)||qs(a,"pinType")==="fixed",S=e.indexOf("scroller")!==-1,y=E?tn:a.tagName==="IFRAME"?a.contentDocument.body:a,R=e.indexOf("start")!==-1,U=R?p:_,C="border-color:"+U+";font-size:"+v+";color:"+U+";font-weight:"+x+";pointer-events:none;white-space:nowrap;font-family:sans-serif,Arial;z-index:1000;padding:4px 8px;border-width:0;border-style:solid;";return C+="position:"+((S||d)&&E?"fixed;":"absolute;"),(S||d||!E)&&(C+=(r===ni?gg:vg)+":"+(u+parseFloat(g))+"px;"),f&&(C+="box-sizing:border-box;text-align:left;width:"+f.offsetWidth+"px;"),M._isStart=R,M.setAttribute("class","gsap-marker-"+e+(n?" marker-"+n:"")),M.style.cssText=C,M.innerText=n||n===0?e+"-"+n:e,y.children[0]?y.insertBefore(M,y.children[0]):y.appendChild(M),M._offset=M["offset"+r.op.d2],jh(M,0,r,R),M},jh=function(e,n,a,r){var l={display:"block"},u=a[r?"os2":"p2"],f=a[r?"p2":"os2"];e._isFlipped=r,l[a.a+"Percent"]=r?-100:0,l[a.a]=r?"1px":0,l["border"+u+lc]=1,l["border"+f+lc]=0,l[a.p]=n+"px",et.set(e,l)},Lt=[],e0={},Wu,eM=function(){return Ti()-Ga>34&&(Wu||(Wu=requestAnimationFrame(Jr)))},Cl=function(){(!Pi||!Pi.isPressed||Pi.startX>tn.clientWidth)&&(Pt.cache++,Pi?Wu||(Wu=requestAnimationFrame(Jr)):Jr(),Ga||Vo("scrollStart"),Ga=Ti())},Qm=function(){gb=Ot.innerWidth,_b=Ot.innerHeight},yu=function(e){Pt.cache++,(e===!0||!Ei&&!mb&&!ln.fullscreenElement&&!ln.webkitFullscreenElement&&(!Q_||gb!==Ot.innerWidth||Math.abs(Ot.innerHeight-_b)>Ot.innerHeight*.25))&&hd.restart(!0)},Go={},aC=[],Tb=function o(){return li(vt,"scrollEnd",o)||Do(!0)},Vo=function(e){return Go[e]&&Go[e].map(function(n){return n()})||aC},ha=[],Ab=function(e){for(var n=0;n<ha.length;n+=5)(!e||ha[n+4]&&ha[n+4].query===e)&&(ha[n].style.cssText=ha[n+1],ha[n].getBBox&&ha[n].setAttribute("transform",ha[n+2]||""),ha[n+3].uncache=1)},Rb=function(){return Pt.forEach(function(e){return Ri(e)&&++e.cacheID&&(e.rec=e())})},yg=function(e,n){var a;for(Fi=0;Fi<Lt.length;Fi++)a=Lt[Fi],a&&(!n||a._ctx===n)&&(e?a.kill(1):a.revert(!0,!0));Du=!0,n&&Ab(n),n||Vo("revert")},Cb=function(e,n){Pt.cache++,(n||!zi)&&Pt.forEach(function(a){return Ri(a)&&a.cacheID++&&(a.rec=0)}),da(e)&&(Ot.history.scrollRestoration=mg=e)},zi,Bo=0,tM,rC=function(){if(tM!==Bo){var e=tM=Bo;requestAnimationFrame(function(){return e===Bo&&Do(!0)})}},wb=function(){tn.appendChild($l),_g=!Pi&&$l.offsetHeight||Ot.innerHeight,tn.removeChild($l)},nM=function(e){return Xu(".gsap-marker-start, .gsap-marker-end, .gsap-marker-scroller-start, .gsap-marker-scroller-end").forEach(function(n){return n.style.display=e?"none":"block"})},Do=function(e,n){if(ma=ln.documentElement,tn=ln.body,pg=[Ot,ln,ma,tn],Ga&&!e&&!Du){ci(vt,"scrollEnd",Tb);return}wb(),zi=vt.isRefreshing=!0,Du||Rb();var a=Vo("refreshInit");pb&&vt.sort(),n||yg(),Pt.forEach(function(r){Ri(r)&&(r.smooth&&(r.target.style.scrollBehavior="auto"),r(0))}),Lt.slice(0).forEach(function(r){return r.refresh()}),Du=!1,Lt.forEach(function(r){if(r._subPinOffset&&r.pin){var l=r.vars.horizontal?"offsetWidth":"offsetHeight",u=r.pin[l];r.revert(!0,1),r.adjustPinSpacing(r.pin[l]-u),r.refresh()}}),$_=1,nM(!0),Lt.forEach(function(r){var l=mr(r.scroller,r._dir),u=r.vars.end==="max"||r._endClamp&&r.end>l,f=r._startClamp&&r.start>=l;(u||f)&&r.setPositions(f?l-1:r.start,u?Math.max(f?l:r.start+1,l):r.end,!0)}),nM(!1),$_=0,a.forEach(function(r){return r&&r.render&&r.render(-1)}),Pt.forEach(function(r){Ri(r)&&(r.smooth&&requestAnimationFrame(function(){return r.target.style.scrollBehavior="smooth"}),r.rec&&r(r.rec))}),Cb(mg,1),hd.pause(),Bo++,zi=2,Jr(2),Lt.forEach(function(r){return Ri(r.vars.onRefresh)&&r.vars.onRefresh(r)}),zi=vt.isRefreshing=!1,Vo("refresh")},t0=0,Zh=1,Pu,Jr=function(e){if(e===2||!zi&&!Du){vt.isUpdating=!0,Pu&&Pu.update(0);var n=Lt.length,a=Ti(),r=a-Km>=50,l=n&&Lt[0].scroll();if(Zh=t0>l?-1:1,zi||(t0=l),r&&(Ga&&!Td&&a-Ga>200&&(Ga=0,Vo("scrollEnd")),gu=Km,Km=a),Zh<0){for(Fi=n;Fi-- >0;)Lt[Fi]&&Lt[Fi].update(0,r);Zh=1}else for(Fi=0;Fi<n;Fi++)Lt[Fi]&&Lt[Fi].update(0,r);vt.isUpdating=!1}Wu=0},n0=[Mb,bb,vg,gg,Fa+Ou,Fa+Uu,Fa+Lu,Fa+Nu,"display","flexShrink","float","zIndex","gridColumnStart","gridColumnEnd","gridRowStart","gridRowEnd","gridArea","justifySelf","alignSelf","placeSelf","order"],Kh=n0.concat([zo,Io,"boxSizing","max"+lc,"max"+xg,"position",Fa,Qn,Qn+Lu,Qn+Uu,Qn+Ou,Qn+Nu]),sC=function(e,n,a){ec(a);var r=e._gsap;if(r.spacerIsNative)ec(r.spacerState);else if(e._gsap.swappedIn){var l=n.parentNode;l&&(l.insertBefore(e,n),l.removeChild(n))}e._gsap.swappedIn=!1},Jm=function(e,n,a,r){if(!e._gsap.swappedIn){for(var l=n0.length,u=n.style,f=e.style,d;l--;)d=n0[l],u[d]=a[d];u.position=a.position==="absolute"?"absolute":"relative",a.display==="inline"&&(u.display="inline-block"),f[vg]=f[gg]="auto",u.flexBasis=a.flexBasis||"auto",u.overflow="visible",u.boxSizing="border-box",u[zo]=dd(e,Ii)+ti,u[Io]=dd(e,ni)+ti,u[Qn]=f[Fa]=f[bb]=f[Mb]="0",ec(r),f[zo]=f["max"+lc]=a[zo],f[Io]=f["max"+xg]=a[Io],f[Qn]=a[Qn],e.parentNode!==n&&(e.parentNode.insertBefore(n,e),n.appendChild(e)),e._gsap.swappedIn=!0}},oC=/([A-Z])/g,ec=function(e){if(e){var n=e.t.style,a=e.length,r=0,l,u;for((e.t._gsap||et.core.getCache(e.t)).uncache=1;r<a;r+=2)u=e[r+1],l=e[r],u?n[l]=u:n[l]&&n.removeProperty(l.replace(oC,"-$1").toLowerCase())}},gh=function(e){for(var n=Kh.length,a=e.style,r=[],l=0;l<n;l++)r.push(Kh[l],a[Kh[l]]);return r.t=e,r},lC=function(e,n,a){for(var r=[],l=e.length,u=a?8:0,f;u<l;u+=2)f=e[u],r.push(f,f in n?n[f]:e[u+1]);return r.t=e.t,r},Qh={left:0,top:0},iM=function(e,n,a,r,l,u,f,d,p,_,v,g,x,M){Ri(e)&&(e=e(d)),da(e)&&e.substr(0,3)==="max"&&(e=g+(e.charAt(4)==="="?Yh("0"+e.substr(3),a):0));var E=x?x.time():0,S,y,R;if(x&&x.seek(0),isNaN(e)||(e=+e),Su(e))x&&(e=et.utils.mapRange(x.scrollTrigger.start,x.scrollTrigger.end,0,g,e)),f&&jh(f,a,r,!0);else{Ri(n)&&(n=n(d));var U=(e||"0").split(" "),C,F,O,D;R=Yi(n,d)||tn,C=jr(R)||{},(!C||!C.left&&!C.top)&&za(R).display==="none"&&(D=R.style.display,R.style.display="block",C=jr(R),D?R.style.display=D:R.style.removeProperty("display")),F=Yh(U[0],C[r.d]),O=Yh(U[1]||"0",a),e=C[r.p]-p[r.p]-_+F+l-O,f&&jh(f,O,r,a-O<20||f._isStart&&O>20),a-=a-O}if(M&&(d[M]=e||-.001,e<0&&(e=0)),u){var T=e+a,L=u._isStart;S="scroll"+r.d2,jh(u,T,r,L&&T>20||!L&&(v?Math.max(tn[S],ma[S]):u.parentNode[S])<=T+1),v&&(p=jr(f),v&&(u.style[r.op.p]=p[r.op.p]-r.op.m-u._offset+ti))}return x&&R&&(S=jr(R),x.seek(g),y=jr(R),x._caScrollDist=S[r.p]-y[r.p],e=e/x._caScrollDist*g),x&&x.seek(E),x?e:Math.round(e)},cC=/(webkit|moz|length|cssText|inset)/i,aM=function(e,n,a,r){if(e.parentNode!==n){var l=e.style,u,f;if(n===tn){e._stOrig=l.cssText,f=za(e);for(u in f)!+u&&!cC.test(u)&&f[u]&&typeof l[u]=="string"&&u!=="0"&&(l[u]=f[u]);l.top=a,l.left=r}else l.cssText=e._stOrig;et.core.getCache(e).uncache=1,n.appendChild(e)}},Db=function(e,n,a){var r=n,l=r;return function(u){var f=Math.round(e());return f!==r&&f!==l&&Math.abs(f-r)>3&&Math.abs(f-l)>3&&(u=f,a&&a()),l=r,r=Math.round(u),r}},vh=function(e,n,a){var r={};r[n.p]="+="+a,et.set(e,r)},rM=function(e,n){var a=Ks(e,n),r="_scroll"+n.p2,l=function u(f,d,p,_,v){var g=u.tween,x=d.onComplete,M={};p=p||a();var E=Db(a,p,function(){g.kill(),u.tween=0});return v=_&&v||0,_=_||f-p,g&&g.kill(),d[r]=f,d.inherit=!1,d.modifiers=M,M[r]=function(){return E(p+_*g.ratio+v*g.ratio*g.ratio)},d.onUpdate=function(){Pt.cache++,u.tween&&Jr()},d.onComplete=function(){u.tween=0,x&&x.call(g)},g=u.tween=et.to(e,d),g};return e[r]=a,a.wheelHandler=function(){return l.tween&&l.tween.kill()&&(l.tween=0)},ci(e,"wheel",a.wheelHandler),vt.isTouch&&ci(e,"touchmove",a.wheelHandler),l},vt=(function(){function o(n,a){kl||o.register(et)||console.warn("Please gsap.registerPlugin(ScrollTrigger)"),J_(this),this.init(n,a)}var e=o.prototype;return e.init=function(a,r){if(this.progress=this.start=0,this.vars&&this.kill(!0,!0),!vu){this.update=this.refresh=this.kill=fr;return}a=Jy(da(a)||Su(a)||a.nodeType?{trigger:a}:a,mh);var l=a,u=l.onUpdate,f=l.toggleClass,d=l.id,p=l.onToggle,_=l.onRefresh,v=l.scrub,g=l.trigger,x=l.pin,M=l.pinSpacing,E=l.invalidateOnRefresh,S=l.anticipatePin,y=l.onScrubComplete,R=l.onSnapComplete,U=l.once,C=l.snap,F=l.pinReparent,O=l.pinSpacer,D=l.containerAnimation,T=l.fastScrollEnd,L=l.preventOverlaps,H=a.horizontal||a.containerAnimation&&a.horizontal!==!1?Ii:ni,V=!v&&v!==0,k=Yi(a.scroller||Ot),te=et.core.getCache(k),ie=Ho(k),W=("pinType"in a?a.pinType:qs(k,"pinType")||ie&&"fixed")==="fixed",z=[a.onEnter,a.onLeave,a.onEnterBack,a.onLeaveBack],B=V&&a.toggleActions.split(" "),J="markers"in a?a.markers:mh.markers,fe=ie?0:parseFloat(za(k)["border"+H.p2+lc])||0,G=this,I=a.onRefreshInit&&function(){return a.onRefreshInit(G)},K=$R(k,ie,H),Se=eC(k,ie),be=0,Ue=0,ne=0,xe=Ks(k,H),Ee,Ie,nt,Ze,Mt,Ye,it,xt,st,le,Dt,mn,j,gt,mt,Ft,Le,bt,P,A,Q,_e,Te,Fe,De,de,pe,Be,He,ze,Oe,Ge,ut,dt,q,Re,me,Ve,Pe;if(G._startClamp=G._endClamp=!1,G._dir=H,S*=45,G.scroller=k,G.scroll=D?D.time.bind(D):xe,Ze=xe(),G.vars=a,r=r||a.animation,"refreshPriority"in a&&(pb=1,a.refreshPriority===-9999&&(Pu=G)),te.tweenScroll=te.tweenScroll||{top:rM(k,ni),left:rM(k,Ii)},G.tweenTo=Ee=te.tweenScroll[H.p],G.scrubDuration=function(we){ut=Su(we)&&we,ut?Ge?Ge.duration(we):Ge=et.to(r,{ease:"expo",totalProgress:"+=0",inherit:!1,duration:ut,paused:!0,onComplete:function(){return y&&y(G)}}):(Ge&&Ge.progress(1).kill(),Ge=0)},r&&(r.vars.lazy=!1,r._initted&&!G.isReverted||r.vars.immediateRender!==!1&&a.immediateRender!==!1&&r.duration()&&r.render(0,!0,!0),G.animation=r.pause(),r.scrollTrigger=G,G.scrubDuration(v),ze=0,d||(d=r.vars.id)),C&&((!To(C)||C.push)&&(C={snapTo:C}),"scrollBehavior"in tn.style&&et.set(ie?[tn,ma]:k,{scrollBehavior:"auto"}),Pt.forEach(function(we){return Ri(we)&&we.target===(ie?ln.scrollingElement||ma:k)&&(we.smooth=!1)}),nt=Ri(C.snapTo)?C.snapTo:C.snapTo==="labels"?nC(r):C.snapTo==="labelsDirectional"?iC(r):C.directional!==!1?function(we,rt){return Sg(C.snapTo)(we,Ti()-Ue<500?0:rt.direction)}:et.utils.snap(C.snapTo),dt=C.duration||{min:.1,max:2},dt=To(dt)?wu(dt.min,dt.max):wu(dt,dt),q=et.delayedCall(C.delay||ut/2||.1,function(){var we=xe(),rt=Ti()-Ue<500,Qe=Ee.tween;if((rt||Math.abs(G.getVelocity())<10)&&!Qe&&!Td&&be!==we){var ft=(we-Ye)/gt,Rn=r&&!V?r.totalProgress():ft,Ct=rt?0:(Rn-Oe)/(Ti()-gu)*1e3||0,_n=et.utils.clamp(-ft,1-ft,Rl(Ct/2)*Ct/.185),Yt=ft+(C.inertia===!1?0:_n),St,Tt,zt=C,Xn=zt.onStart,un=zt.onInterrupt,Wn=zt.onComplete;if(St=nt(Yt,G),Su(St)||(St=Yt),Tt=Math.max(0,Math.round(Ye+St*gt)),we<=it&&we>=Ye&&Tt!==we){if(Qe&&!Qe._initted&&Qe.data<=Rl(Tt-we))return;C.inertia===!1&&(_n=St-ft),Ee(Tt,{duration:dt(Rl(Math.max(Rl(Yt-Rn),Rl(St-Rn))*.185/Ct/.05||0)),ease:C.ease||"power3",data:Rl(Tt-we),onInterrupt:function(){return q.restart(!0)&&un&&Al(G,un)},onComplete:function(){G.update(),be=xe(),r&&!V&&(Ge?Ge.resetTo("totalProgress",St,r._tTime/r._tDur):r.progress(St)),ze=Oe=r&&!V?r.totalProgress():G.progress,R&&R(G),Wn&&Al(G,Wn)}},we,_n*gt,Tt-we-_n*gt),Xn&&Al(G,Xn,Ee.tween)}}else G.isActive&&be!==we&&q.restart(!0)}).pause()),d&&(e0[d]=G),g=G.trigger=Yi(g||x!==!0&&x),Pe=g&&g._gsap&&g._gsap.stRevert,Pe&&(Pe=Pe(G)),x=x===!0?g:Yi(x),da(f)&&(f={targets:g,className:f}),x&&(M===!1||M===Fa||(M=!M&&x.parentNode&&x.parentNode.style&&za(x.parentNode).display==="flex"?!1:Qn),G.pin=x,Ie=et.core.getCache(x),Ie.spacer?mt=Ie.pinState:(O&&(O=Yi(O),O&&!O.nodeType&&(O=O.current||O.nativeElement),Ie.spacerIsNative=!!O,O&&(Ie.spacerState=gh(O))),Ie.spacer=bt=O||ln.createElement("div"),bt.classList.add("pin-spacer"),d&&bt.classList.add("pin-spacer-"+d),Ie.pinState=mt=gh(x)),a.force3D!==!1&&et.set(x,{force3D:!0}),G.spacer=bt=Ie.spacer,He=za(x),Fe=He[M+H.os2],A=et.getProperty(x),Q=et.quickSetter(x,H.a,ti),Jm(x,bt,He),Le=gh(x)),J){mn=To(J)?Jy(J,$y):$y,le=_h("scroller-start",d,k,H,mn,0),Dt=_h("scroller-end",d,k,H,mn,0,le),P=le["offset"+H.op.d2];var Ae=Yi(qs(k,"content")||k);xt=this.markerStart=_h("start",d,Ae,H,mn,P,0,D),st=this.markerEnd=_h("end",d,Ae,H,mn,P,0,D),D&&(Ve=et.quickSetter([xt,st],H.a,ti)),!W&&!(vr.length&&qs(k,"fixedMarkers")===!0)&&(tC(ie?tn:k),et.set([le,Dt],{force3D:!0}),de=et.quickSetter(le,H.a,ti),Be=et.quickSetter(Dt,H.a,ti))}if(D){var Ce=D.vars.onUpdate,Ne=D.vars.onUpdateParams;D.eventCallback("onUpdate",function(){G.update(0,0,1),Ce&&Ce.apply(D,Ne||[])})}if(G.previous=function(){return Lt[Lt.indexOf(G)-1]},G.next=function(){return Lt[Lt.indexOf(G)+1]},G.revert=function(we,rt){if(!rt)return G.kill(!0);var Qe=we!==!1||!G.enabled,ft=Ei;Qe!==G.isReverted&&(Qe&&(Re=Math.max(xe(),G.scroll.rec||0),ne=G.progress,me=r&&r.progress()),xt&&[xt,st,le,Dt].forEach(function(Rn){return Rn.style.display=Qe?"none":"block"}),Qe&&(Ei=G,G.update(Qe)),x&&(!F||!G.isActive)&&(Qe?sC(x,bt,mt):Jm(x,bt,za(x),De)),Qe||G.update(Qe),Ei=ft,G.isReverted=Qe)},G.refresh=function(we,rt,Qe,ft){if(!((Ei||!G.enabled)&&!rt)){if(x&&we&&Ga){ci(o,"scrollEnd",Tb);return}!zi&&I&&I(G),Ei=G,Ee.tween&&!Qe&&(Ee.tween.kill(),Ee.tween=0),Ge&&Ge.pause(),E&&r&&(r.revert({kill:!1}).invalidate(),r.getChildren?r.getChildren(!0,!0,!1).forEach(function(We){return We.vars.immediateRender&&We.render(0,!0,!0)}):r.vars.immediateRender&&r.render(0,!0,!0)),G.isReverted||G.revert(!0,!0),G._subPinOffset=!1;var Rn=K(),Ct=Se(),_n=D?D.duration():mr(k,H),Yt=gt<=.01||!gt,St=0,Tt=ft||0,zt=To(Qe)?Qe.end:a.end,Xn=a.endTrigger||g,un=To(Qe)?Qe.start:a.start||(a.start===0||!g?0:x?"0 0":"0 100%"),Wn=G.pinnedContainer=a.pinnedContainer&&Yi(a.pinnedContainer,G),vi=g&&Math.max(0,Lt.indexOf(G))||0,Mn=vi,Nn,bn,xi,Ea,En,Ut,Di,w,Z,se,ee,ae,ke;for(J&&To(Qe)&&(ae=et.getProperty(le,H.p),ke=et.getProperty(Dt,H.p));Mn-- >0;)Ut=Lt[Mn],Ut.end||Ut.refresh(0,1)||(Ei=G),Di=Ut.pin,Di&&(Di===g||Di===x||Di===Wn)&&!Ut.isReverted&&(se||(se=[]),se.unshift(Ut),Ut.revert(!0,!0)),Ut!==Lt[Mn]&&(vi--,Mn--);for(Ri(un)&&(un=un(G)),un=jy(un,"start",G),Ye=iM(un,g,Rn,H,xe(),xt,le,G,Ct,fe,W,_n,D,G._startClamp&&"_startClamp")||(x?-.001:0),Ri(zt)&&(zt=zt(G)),da(zt)&&!zt.indexOf("+=")&&(~zt.indexOf(" ")?zt=(da(un)?un.split(" ")[0]:"")+zt:(St=Yh(zt.substr(2),Rn),zt=da(un)?un:(D?et.utils.mapRange(0,D.duration(),D.scrollTrigger.start,D.scrollTrigger.end,Ye):Ye)+St,Xn=g)),zt=jy(zt,"end",G),it=Math.max(Ye,iM(zt||(Xn?"100% 0":_n),Xn,Rn,H,xe()+St,st,Dt,G,Ct,fe,W,_n,D,G._endClamp&&"_endClamp"))||-.001,St=0,Mn=vi;Mn--;)Ut=Lt[Mn]||{},Di=Ut.pin,Di&&Ut.start-Ut._pinPush<=Ye&&!D&&Ut.end>0&&(Nn=Ut.end-(G._startClamp?Math.max(0,Ut.start):Ut.start),(Di===g&&Ut.start-Ut._pinPush<Ye||Di===Wn)&&isNaN(un)&&(St+=Nn*(1-Ut.progress)),Di===x&&(Tt+=Nn));if(Ye+=St,it+=St,G._startClamp&&(G._startClamp+=St),G._endClamp&&!zi&&(G._endClamp=it||-.001,it=Math.min(it,mr(k,H))),gt=it-Ye||(Ye-=.01)&&.001,Yt&&(ne=et.utils.clamp(0,1,et.utils.normalize(Ye,it,Re))),G._pinPush=Tt,xt&&St&&(Nn={},Nn[H.a]="+="+St,Wn&&(Nn[H.p]="-="+xe()),et.set([xt,st],Nn)),x&&!($_&&G.end>=mr(k,H)))Nn=za(x),Ea=H===ni,xi=xe(),_e=parseFloat(A(H.a))+Tt,!_n&&it>1&&(ee=(ie?ln.scrollingElement||ma:k).style,ee={style:ee,value:ee["overflow"+H.a.toUpperCase()]},ie&&za(tn)["overflow"+H.a.toUpperCase()]!=="scroll"&&(ee.style["overflow"+H.a.toUpperCase()]="scroll")),Jm(x,bt,Nn),Le=gh(x),bn=jr(x,!0),w=W&&Ks(k,Ea?Ii:ni)(),M?(De=[M+H.os2,gt+Tt+ti],De.t=bt,Mn=M===Qn?dd(x,H)+gt+Tt:0,Mn&&(De.push(H.d,Mn+ti),bt.style.flexBasis!=="auto"&&(bt.style.flexBasis=Mn+ti)),ec(De),Wn&&Lt.forEach(function(We){We.pin===Wn&&We.vars.pinSpacing!==!1&&(We._subPinOffset=!0)}),W&&xe(Re)):(Mn=dd(x,H),Mn&&bt.style.flexBasis!=="auto"&&(bt.style.flexBasis=Mn+ti)),W&&(En={top:bn.top+(Ea?xi-Ye:w)+ti,left:bn.left+(Ea?w:xi-Ye)+ti,boxSizing:"border-box",position:"fixed"},En[zo]=En["max"+lc]=Math.ceil(bn.width)+ti,En[Io]=En["max"+xg]=Math.ceil(bn.height)+ti,En[Fa]=En[Fa+Lu]=En[Fa+Uu]=En[Fa+Ou]=En[Fa+Nu]="0",En[Qn]=Nn[Qn],En[Qn+Lu]=Nn[Qn+Lu],En[Qn+Uu]=Nn[Qn+Uu],En[Qn+Ou]=Nn[Qn+Ou],En[Qn+Nu]=Nn[Qn+Nu],Ft=lC(mt,En,F),zi&&xe(0)),r?(Z=r._initted,jm(1),r.render(r.duration(),!0,!0),Te=A(H.a)-_e+gt+Tt,pe=Math.abs(gt-Te)>1,W&&pe&&Ft.splice(Ft.length-2,2),r.render(0,!0,!0),Z||r.invalidate(!0),r.parent||r.totalTime(r.totalTime()),jm(0)):Te=gt,ee&&(ee.value?ee.style["overflow"+H.a.toUpperCase()]=ee.value:ee.style.removeProperty("overflow-"+H.a));else if(g&&xe()&&!D)for(bn=g.parentNode;bn&&bn!==tn;)bn._pinOffset&&(Ye-=bn._pinOffset,it-=bn._pinOffset),bn=bn.parentNode;se&&se.forEach(function(We){return We.revert(!1,!0)}),G.start=Ye,G.end=it,Ze=Mt=zi?Re:xe(),!D&&!zi&&(Ze<Re&&xe(Re),G.scroll.rec=0),G.revert(!1,!0),Ue=Ti(),q&&(be=-1,q.restart(!0)),Ei=0,r&&V&&(r._initted||me)&&r.progress()!==me&&r.progress(me||0,!0).render(r.time(),!0,!0),(Yt||ne!==G.progress||D||E||r&&!r._initted)&&(r&&!V&&(r._initted||ne||r.vars.immediateRender!==!1)&&r.totalProgress(D&&Ye<-.001&&!ne?et.utils.normalize(Ye,it,0):ne,!0),G.progress=Yt||(Ze-Ye)/gt===ne?0:ne),x&&M&&(bt._pinOffset=Math.round(G.progress*Te)),Ge&&Ge.invalidate(),isNaN(ae)||(ae-=et.getProperty(le,H.p),ke-=et.getProperty(Dt,H.p),vh(le,H,ae),vh(xt,H,ae-(ft||0)),vh(Dt,H,ke),vh(st,H,ke-(ft||0))),Yt&&!zi&&G.update(),_&&!zi&&!j&&(j=!0,_(G),j=!1)}},G.getVelocity=function(){return(xe()-Mt)/(Ti()-gu)*1e3||0},G.endAnimation=function(){su(G.callbackAnimation),r&&(Ge?Ge.progress(1):r.paused()?V||su(r,G.direction<0,1):su(r,r.reversed()))},G.labelToScroll=function(we){return r&&r.labels&&(Ye||G.refresh()||Ye)+r.labels[we]/r.duration()*gt||0},G.getTrailing=function(we){var rt=Lt.indexOf(G),Qe=G.direction>0?Lt.slice(0,rt).reverse():Lt.slice(rt+1);return(da(we)?Qe.filter(function(ft){return ft.vars.preventOverlaps===we}):Qe).filter(function(ft){return G.direction>0?ft.end<=Ye:ft.start>=it})},G.update=function(we,rt,Qe){if(!(D&&!Qe&&!we)){var ft=zi===!0?Re:G.scroll(),Rn=we?0:(ft-Ye)/gt,Ct=Rn<0?0:Rn>1?1:Rn||0,_n=G.progress,Yt,St,Tt,zt,Xn,un,Wn,vi;if(rt&&(Mt=Ze,Ze=D?xe():ft,C&&(Oe=ze,ze=r&&!V?r.totalProgress():Ct)),S&&x&&!Ei&&!fh&&Ga&&(!Ct&&Ye<ft+(ft-Mt)/(Ti()-gu)*S?Ct=1e-4:Ct===1&&it>ft+(ft-Mt)/(Ti()-gu)*S&&(Ct=.9999)),Ct!==_n&&G.enabled){if(Yt=G.isActive=!!Ct&&Ct<1,St=!!_n&&_n<1,un=Yt!==St,Xn=un||!!Ct!=!!_n,G.direction=Ct>_n?1:-1,G.progress=Ct,Xn&&!Ei&&(Tt=Ct&&!_n?0:Ct===1?1:_n===1?2:3,V&&(zt=!un&&B[Tt+1]!=="none"&&B[Tt+1]||B[Tt],vi=r&&(zt==="complete"||zt==="reset"||zt in r))),L&&(un||vi)&&(vi||v||!r)&&(Ri(L)?L(G):G.getTrailing(L).forEach(function(xi){return xi.endAnimation()})),V||(Ge&&!Ei&&!fh?(Ge._dp._time-Ge._start!==Ge._time&&Ge.render(Ge._dp._time-Ge._start),Ge.resetTo?Ge.resetTo("totalProgress",Ct,r._tTime/r._tDur):(Ge.vars.totalProgress=Ct,Ge.invalidate().restart())):r&&r.totalProgress(Ct,!!(Ei&&(Ue||we)))),x){if(we&&M&&(bt.style[M+H.os2]=Fe),!W)Q(xu(_e+Te*Ct));else if(Xn){if(Wn=!we&&Ct>_n&&it+1>ft&&ft+1>=mr(k,H),F)if(!we&&(Yt||Wn)){var Mn=jr(x,!0),Nn=ft-Ye;aM(x,tn,Mn.top+(H===ni?Nn:0)+ti,Mn.left+(H===ni?0:Nn)+ti)}else aM(x,bt);ec(Yt||Wn?Ft:Le),pe&&Ct<1&&Yt||Q(_e+(Ct===1&&!Wn?Te:0))}}C&&!Ee.tween&&!Ei&&!fh&&q.restart(!0),f&&(un||U&&Ct&&(Ct<1||!Zm))&&Xu(f.targets).forEach(function(xi){return xi.classList[Yt||U?"add":"remove"](f.className)}),u&&!V&&!we&&u(G),Xn&&!Ei?(V&&(vi&&(zt==="complete"?r.pause().totalProgress(1):zt==="reset"?r.restart(!0).pause():zt==="restart"?r.restart(!0):r[zt]()),u&&u(G)),(un||!Zm)&&(p&&un&&Al(G,p),z[Tt]&&Al(G,z[Tt]),U&&(Ct===1?G.kill(!1,1):z[Tt]=0),un||(Tt=Ct===1?1:3,z[Tt]&&Al(G,z[Tt]))),T&&!Yt&&Math.abs(G.getVelocity())>(Su(T)?T:2500)&&(su(G.callbackAnimation),Ge?Ge.progress(1):su(r,zt==="reverse"?1:!Ct,1))):V&&u&&!Ei&&u(G)}if(Be){var bn=D?ft/D.duration()*(D._caScrollDist||0):ft;de(bn+(le._isFlipped?1:0)),Be(bn)}Ve&&Ve(-ft/D.duration()*(D._caScrollDist||0))}},G.enable=function(we,rt){G.enabled||(G.enabled=!0,ci(k,"resize",yu),ie||ci(k,"scroll",Cl),I&&ci(o,"refreshInit",I),we!==!1&&(G.progress=ne=0,Ze=Mt=be=xe()),rt!==!1&&G.refresh())},G.getTween=function(we){return we&&Ee?Ee.tween:Ge},G.setPositions=function(we,rt,Qe,ft){if(D){var Rn=D.scrollTrigger,Ct=D.duration(),_n=Rn.end-Rn.start;we=Rn.start+_n*we/Ct,rt=Rn.start+_n*rt/Ct}G.refresh(!1,!1,{start:Zy(we,Qe&&!!G._startClamp),end:Zy(rt,Qe&&!!G._endClamp)},ft),G.update()},G.adjustPinSpacing=function(we){if(De&&we){var rt=De.indexOf(H.d)+1;De[rt]=parseFloat(De[rt])+we+ti,De[1]=parseFloat(De[1])+we+ti,ec(De)}},G.disable=function(we,rt){if(we!==!1&&G.revert(!0,!0),G.enabled&&(G.enabled=G.isActive=!1,rt||Ge&&Ge.pause(),Re=0,Ie&&(Ie.uncache=1),I&&li(o,"refreshInit",I),q&&(q.pause(),Ee.tween&&Ee.tween.kill()&&(Ee.tween=0)),!ie)){for(var Qe=Lt.length;Qe--;)if(Lt[Qe].scroller===k&&Lt[Qe]!==G)return;li(k,"resize",yu),ie||li(k,"scroll",Cl)}},G.kill=function(we,rt){G.disable(we,rt),Ge&&!rt&&Ge.kill(),d&&delete e0[d];var Qe=Lt.indexOf(G);Qe>=0&&Lt.splice(Qe,1),Qe===Fi&&Zh>0&&Fi--,Qe=0,Lt.forEach(function(ft){return ft.scroller===G.scroller&&(Qe=1)}),Qe||zi||(G.scroll.rec=0),r&&(r.scrollTrigger=null,we&&r.revert({kill:!1}),rt||r.kill()),xt&&[xt,st,le,Dt].forEach(function(ft){return ft.parentNode&&ft.parentNode.removeChild(ft)}),Pu===G&&(Pu=0),x&&(Ie&&(Ie.uncache=1),Qe=0,Lt.forEach(function(ft){return ft.pin===x&&Qe++}),Qe||(Ie.spacer=0)),a.onKill&&a.onKill(G)},Lt.push(G),G.enable(!1,!1),Pe&&Pe(G),r&&r.add&&!gt){var ot=G.update;G.update=function(){G.update=ot,Pt.cache++,Ye||it||G.refresh()},et.delayedCall(.01,G.update),gt=.01,Ye=it=0}else G.refresh();x&&rC()},o.register=function(a){return kl||(et=a||xb(),vb()&&window.document&&o.enable(),kl=vu),kl},o.defaults=function(a){if(a)for(var r in a)mh[r]=a[r];return mh},o.disable=function(a,r){vu=0,Lt.forEach(function(u){return u[r?"kill":"disable"](a)}),li(Ot,"wheel",Cl),li(ln,"scroll",Cl),clearInterval(uh),li(ln,"touchcancel",fr),li(tn,"touchstart",fr),dh(li,ln,"pointerdown,touchstart,mousedown",Ky),dh(li,ln,"pointerup,touchend,mouseup",Qy),hd.kill(),hh(li);for(var l=0;l<Pt.length;l+=3)ph(li,Pt[l],Pt[l+1]),ph(li,Pt[l],Pt[l+2])},o.enable=function(){if(Ot=window,ln=document,ma=ln.documentElement,tn=ln.body,et){if(Xu=et.utils.toArray,wu=et.utils.clamp,J_=et.core.context||fr,jm=et.core.suppressOverwrites||fr,mg=Ot.history.scrollRestoration||"auto",t0=Ot.pageYOffset||0,et.core.globals("ScrollTrigger",o),tn){vu=1,$l=document.createElement("div"),$l.style.height="100vh",$l.style.position="absolute",wb(),JR(),kn.register(et),o.isTouch=kn.isTouch,Fs=kn.isTouch&&/(iPad|iPhone|iPod|Mac)/g.test(navigator.userAgent),Q_=kn.isTouch===1,ci(Ot,"wheel",Cl),pg=[Ot,ln,ma,tn],et.matchMedia?(o.matchMedia=function(_){var v=et.matchMedia(),g;for(g in _)v.add(g,_[g]);return v},et.addEventListener("matchMediaInit",function(){Rb(),yg()}),et.addEventListener("matchMediaRevert",function(){return Ab()}),et.addEventListener("matchMedia",function(){Do(0,1),Vo("matchMedia")}),et.matchMedia().add("(orientation: portrait)",function(){return Qm(),Qm})):console.warn("Requires GSAP 3.11.0 or later"),Qm(),ci(ln,"scroll",Cl);var a=tn.hasAttribute("style"),r=tn.style,l=r.borderTopStyle,u=et.core.Animation.prototype,f,d;for(u.revert||Object.defineProperty(u,"revert",{value:function(){return this.time(-.01,!0)}}),r.borderTopStyle="solid",f=jr(tn),ni.m=Math.round(f.top+ni.sc())||0,Ii.m=Math.round(f.left+Ii.sc())||0,l?r.borderTopStyle=l:r.removeProperty("border-top-style"),a||(tn.setAttribute("style",""),tn.removeAttribute("style")),uh=setInterval(eM,250),et.delayedCall(.5,function(){return fh=0}),ci(ln,"touchcancel",fr),ci(tn,"touchstart",fr),dh(ci,ln,"pointerdown,touchstart,mousedown",Ky),dh(ci,ln,"pointerup,touchend,mouseup",Qy),K_=et.utils.checkPrefix("transform"),Kh.push(K_),kl=Ti(),hd=et.delayedCall(.2,Do).pause(),Xl=[ln,"visibilitychange",function(){var _=Ot.innerWidth,v=Ot.innerHeight;ln.hidden?(qy=_,Yy=v):(qy!==_||Yy!==v)&&yu()},ln,"DOMContentLoaded",Do,Ot,"load",Do,Ot,"resize",yu],hh(ci),Lt.forEach(function(_){return _.enable(0,1)}),d=0;d<Pt.length;d+=3)ph(li,Pt[d],Pt[d+1]),ph(li,Pt[d],Pt[d+2])}else if(ln){var p=function _(){o.enable(),ln.removeEventListener("DOMContentLoaded",_)};ln.addEventListener("DOMContentLoaded",p)}}},o.config=function(a){"limitCallbacks"in a&&(Zm=!!a.limitCallbacks);var r=a.syncInterval;r&&clearInterval(uh)||(uh=r)&&setInterval(eM,r),"ignoreMobileResize"in a&&(Q_=o.isTouch===1&&a.ignoreMobileResize),"autoRefreshEvents"in a&&(hh(li)||hh(ci,a.autoRefreshEvents||"none"),mb=(a.autoRefreshEvents+"").indexOf("resize")===-1)},o.scrollerProxy=function(a,r){var l=Yi(a),u=Pt.indexOf(l),f=Ho(l);~u&&Pt.splice(u,f?6:2),r&&(f?vr.unshift(Ot,r,tn,r,ma,r):vr.unshift(l,r))},o.clearMatchMedia=function(a){Lt.forEach(function(r){return r._ctx&&r._ctx.query===a&&r._ctx.kill(!0,!0)})},o.isInViewport=function(a,r,l){var u=(da(a)?Yi(a):a).getBoundingClientRect(),f=u[l?zo:Io]*r||0;return l?u.right-f>0&&u.left+f<Ot.innerWidth:u.bottom-f>0&&u.top+f<Ot.innerHeight},o.positionInViewport=function(a,r,l){da(a)&&(a=Yi(a));var u=a.getBoundingClientRect(),f=u[l?zo:Io],d=r==null?f/2:r in pd?pd[r]*f:~r.indexOf("%")?parseFloat(r)*f/100:parseFloat(r)||0;return l?(u.left+d)/Ot.innerWidth:(u.top+d)/Ot.innerHeight},o.killAll=function(a){if(Lt.slice(0).forEach(function(l){return l.vars.id!=="ScrollSmoother"&&l.kill()}),a!==!0){var r=Go.killAll||[];Go={},r.forEach(function(l){return l()})}},o})();vt.version="3.15.0";vt.saveStyles=function(o){return o?Xu(o).forEach(function(e){if(e&&e.style){var n=ha.indexOf(e);n>=0&&ha.splice(n,5),ha.push(e,e.style.cssText,e.getBBox&&e.getAttribute("transform"),et.core.getCache(e),J_())}}):ha};vt.revert=function(o,e){return yg(!o,e)};vt.create=function(o,e){return new vt(o,e)};vt.refresh=function(o){return o?yu(!0):(kl||vt.register())&&Do(!0)};vt.update=function(o){return++Pt.cache&&Jr(o===!0?2:0)};vt.clearScrollMemory=Cb;vt.maxScroll=function(o,e){return mr(o,e?Ii:ni)};vt.getScrollFunc=function(o,e){return Ks(Yi(o),e?Ii:ni)};vt.getById=function(o){return e0[o]};vt.getAll=function(){return Lt.filter(function(o){return o.vars.id!=="ScrollSmoother"})};vt.isScrolling=function(){return!!Ga};vt.snapDirectional=Sg;vt.addEventListener=function(o,e){var n=Go[o]||(Go[o]=[]);~n.indexOf(e)||n.push(e)};vt.removeEventListener=function(o,e){var n=Go[o],a=n&&n.indexOf(e);a>=0&&n.splice(a,1)};vt.batch=function(o,e){var n=[],a={},r=e.interval||.016,l=e.batchMax||1e9,u=function(p,_){var v=[],g=[],x=et.delayedCall(r,function(){_(v,g),v=[],g=[]}).pause();return function(M){v.length||x.restart(!0),v.push(M.trigger),g.push(M),l<=v.length&&x.progress(1)}},f;for(f in e)a[f]=f.substr(0,2)==="on"&&Ri(e[f])&&f!=="onRefreshInit"?u(f,e[f]):e[f];return Ri(l)&&(l=l(),ci(vt,"refresh",function(){return l=e.batchMax()})),Xu(o).forEach(function(d){var p={};for(f in a)p[f]=a[f];p.trigger=d,n.push(vt.create(p))}),n};var sM=function(e,n,a,r){return n>r?e(r):n<0&&e(0),a>r?(r-n)/(a-n):a<0?n/(n-a):1},$m=function o(e,n){n===!0?e.style.removeProperty("touch-action"):e.style.touchAction=n===!0?"auto":n?"pan-"+n+(kn.isTouch?" pinch-zoom":""):"none",e===ma&&o(tn,n)},xh={auto:1,scroll:1},uC=function(e){var n=e.event,a=e.target,r=e.axis,l=(n.changedTouches?n.changedTouches[0]:n).target,u=l._gsap||et.core.getCache(l),f=Ti(),d;if(!u._isScrollT||f-u._isScrollT>2e3){for(;l&&l!==tn&&(l.scrollHeight<=l.clientHeight&&l.scrollWidth<=l.clientWidth||!(xh[(d=za(l)).overflowY]||xh[d.overflowX]));)l=l.parentNode;u._isScroll=l&&l!==a&&!Ho(l)&&(xh[(d=za(l)).overflowY]||xh[d.overflowX]),u._isScrollT=f}(u._isScroll||r==="x")&&(n.stopPropagation(),n._gsapAllow=!0)},Ub=function(e,n,a,r){return kn.create({target:e,capture:!0,debounce:!1,lockAxis:!0,type:n,onWheel:r=r&&uC,onPress:r,onDrag:r,onScroll:r,onEnable:function(){return a&&ci(ln,kn.eventTypes[0],lM,!1,!0)},onDisable:function(){return li(ln,kn.eventTypes[0],lM,!0)}})},fC=/(input|label|select|textarea)/i,oM,lM=function(e){var n=fC.test(e.target.tagName);(n||oM)&&(e._gsapAllow=!0,oM=n)},hC=function(e){To(e)||(e={}),e.preventDefault=e.isNormalizer=e.allowClicks=!0,e.type||(e.type="wheel,touch"),e.debounce=!!e.debounce,e.id=e.id||"normalizer";var n=e,a=n.normalizeScrollX,r=n.momentum,l=n.allowNestedScroll,u=n.onRelease,f,d,p=Yi(e.target)||ma,_=et.core.globals().ScrollSmoother,v=_&&_.get(),g=Fs&&(e.content&&Yi(e.content)||v&&e.content!==!1&&!v.smooth()&&v.content()),x=Ks(p,ni),M=Ks(p,Ii),E=1,S=(kn.isTouch&&Ot.visualViewport?Ot.visualViewport.scale*Ot.visualViewport.width:Ot.outerWidth)/Ot.innerWidth,y=0,R=Ri(r)?function(){return r(f)}:function(){return r||2.8},U,C,F=Ub(p,e.type,!0,l),O=function(){return C=!1},D=fr,T=fr,L=function(){d=mr(p,ni),T=wu(Fs?1:0,d),a&&(D=wu(0,mr(p,Ii))),U=Bo},H=function(){g._gsap.y=xu(parseFloat(g._gsap.y)+x.offset)+"px",g.style.transform="matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, "+parseFloat(g._gsap.y)+", 0, 1)",x.offset=x.cacheID=0},V=function(){if(C){requestAnimationFrame(O);var J=xu(f.deltaY/2),fe=T(x.v-J);if(g&&fe!==x.v+x.offset){x.offset=fe-x.v;var G=xu((parseFloat(g&&g._gsap.y)||0)-x.offset);g.style.transform="matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, "+G+", 0, 1)",g._gsap.y=G+"px",x.cacheID=Pt.cache,Jr()}return!0}x.offset&&H(),C=!0},k,te,ie,W,z=function(){L(),k.isActive()&&k.vars.scrollY>d&&(x()>d?k.progress(1)&&x(d):k.resetTo("scrollY",d))};return g&&et.set(g,{y:"+=0"}),e.ignoreCheck=function(B){return Fs&&B.type==="touchmove"&&V()||E>1.05&&B.type!=="touchstart"||f.isGesturing||B.touches&&B.touches.length>1},e.onPress=function(){C=!1;var B=E;E=xu((Ot.visualViewport&&Ot.visualViewport.scale||1)/S),k.pause(),B!==E&&$m(p,E>1.01?!0:a?!1:"x"),te=M(),ie=x(),L(),U=Bo},e.onRelease=e.onGestureStart=function(B,J){if(x.offset&&H(),!J)W.restart(!0);else{Pt.cache++;var fe=R(),G,I;a&&(G=M(),I=G+fe*.05*-B.velocityX/.227,fe*=sM(M,G,I,mr(p,Ii)),k.vars.scrollX=D(I)),G=x(),I=G+fe*.05*-B.velocityY/.227,fe*=sM(x,G,I,mr(p,ni)),k.vars.scrollY=T(I),k.invalidate().duration(fe).play(.01),(Fs&&k.vars.scrollY>=d||G>=d-1)&&et.to({},{onUpdate:z,duration:fe})}u&&u(B)},e.onWheel=function(){k._ts&&k.pause(),Ti()-y>1e3&&(U=0,y=Ti())},e.onChange=function(B,J,fe,G,I){if(Bo!==U&&L(),J&&a&&M(D(G[2]===J?te+(B.startX-B.x):M()+J-G[1])),fe){x.offset&&H();var K=I[2]===fe,Se=K?ie+B.startY-B.y:x()+fe-I[1],be=T(Se);K&&Se!==be&&(ie+=be-Se),x(be)}(fe||J)&&Jr()},e.onEnable=function(){$m(p,a?!1:"x"),vt.addEventListener("refresh",z),ci(Ot,"resize",z),x.smooth&&(x.target.style.scrollBehavior="auto",x.smooth=M.smooth=!1),F.enable()},e.onDisable=function(){$m(p,!0),li(Ot,"resize",z),vt.removeEventListener("refresh",z),F.kill()},e.lockAxis=e.lockAxis!==!1,f=new kn(e),f.iOS=Fs,Fs&&!x()&&x(1),Fs&&et.ticker.add(fr),W=f._dc,k=et.to(f,{ease:"power4",paused:!0,inherit:!1,scrollX:a?"+=0.1":"+=0",scrollY:"+=0.1",modifiers:{scrollY:Db(x,x(),function(){return k.pause()})},onUpdate:Jr,onComplete:W.vars.onComplete}),f};vt.sort=function(o){if(Ri(o))return Lt.sort(o);var e=Ot.pageYOffset||0;return vt.getAll().forEach(function(n){return n._sortY=n.trigger?e+n.trigger.getBoundingClientRect().top:n.start+Ot.innerHeight}),Lt.sort(o||function(n,a){return(n.vars.refreshPriority||0)*-1e6+(n.vars.containerAnimation?1e6:n._sortY)-((a.vars.containerAnimation?1e6:a._sortY)+(a.vars.refreshPriority||0)*-1e6)})};vt.observe=function(o){return new kn(o)};vt.normalizeScroll=function(o){if(typeof o>"u")return Pi;if(o===!0&&Pi)return Pi.enable();if(o===!1){Pi&&Pi.kill(),Pi=o;return}var e=o instanceof kn?o:hC(o);return Pi&&Pi.target===e.target&&Pi.kill(),Ho(e.target)&&(Pi=e),e};vt.core={_getVelocityProp:Z_,_inputObserver:Ub,_scrollers:Pt,_proxies:vr,bridge:{ss:function(){Ga||Vo("scrollStart"),Ga=Ti()},ref:function(){return Ei}}};xb()&&et.registerPlugin(vt);yn.registerPlugin(vt);function dC(){const o=pt.useRef(null);pt.useEffect(()=>{if(!o.current)return;const n=o.current.querySelectorAll(".footer-animate");yn.fromTo(n,{opacity:0,y:40},{opacity:1,y:0,stagger:.05,duration:.8,ease:"power3.out",scrollTrigger:{trigger:o.current,start:"top 85%",toggleActions:"play none none none"}})},[]);const e=[{title:"Cestas",links:["Café da Manhã","Aniversário","Chocolate","Personalizada"]},{title:"Sobre",links:["Nossa História","A Chef","Ingredientes"]},{title:"Informações",links:["Como Encomendar","Prazos de Entrega","São Paulo/SP"]},{title:"Redes",links:["Instagram","WhatsApp"]}];return ge.jsx("footer",{"code-path":"src/components/Footer.tsx:51:5",ref:o,className:"bg-espresso text-milk",children:ge.jsxs("div",{"code-path":"src/components/Footer.tsx:52:7",className:"px-6 lg:px-12 pt-20 pb-8 max-w-[1200px] mx-auto",children:[ge.jsxs("div",{"code-path":"src/components/Footer.tsx:54:9",className:"footer-animate mb-12",children:[ge.jsx("h3",{"code-path":"src/components/Footer.tsx:55:11",className:"font-display text-[32px] text-milk mb-2",children:"Petit Pauly"}),ge.jsx("p",{"code-path":"src/components/Footer.tsx:56:11",className:"font-body text-base text-milk/50",children:"Cestas artesanais com amor"})]}),ge.jsx("div",{"code-path":"src/components/Footer.tsx:60:9",className:"grid grid-cols-2 md:grid-cols-4 gap-8 mb-16",children:e.map(n=>ge.jsxs("div",{"code-path":"src/components/Footer.tsx:62:13",className:"footer-animate",children:[ge.jsx("h4",{"code-path":"src/components/Footer.tsx:63:15",className:"font-label text-milk/70 mb-4",children:n.title}),ge.jsx("ul",{"code-path":"src/components/Footer.tsx:64:15",className:"space-y-2",children:n.links.map(a=>ge.jsx("li",{"code-path":"src/components/Footer.tsx:66:19",children:ge.jsx("span",{"code-path":"src/components/Footer.tsx:67:21",className:"font-body text-sm text-milk/50 hover:text-caramel transition-colors duration-300 cursor-pointer",children:a})},a))})]},n.title))}),ge.jsxs("div",{"code-path":"src/components/Footer.tsx:78:9",className:"footer-animate flex flex-col md:flex-row items-center justify-between gap-4 pt-8 border-t border-milk/10",children:[ge.jsx("p",{"code-path":"src/components/Footer.tsx:79:11",className:"font-body text-sm text-milk/40",children:"© 2025 Petit Pauly. Todos os direitos reservados."}),ge.jsx("p",{"code-path":"src/components/Footer.tsx:82:11",className:"font-accent text-xl text-caramel",children:"Feito com amor"})]})]})})}const Mg="184",pC=0,cM=1,mC=2,Jh=1,_C=2,Mu=3,Qs=0,$i=1,Zr=2,$r=0,tc=1,i0=2,uM=3,fM=4,gC=5,Ro=100,vC=101,xC=102,SC=103,yC=104,MC=200,bC=201,EC=202,TC=203,a0=204,r0=205,AC=206,RC=207,CC=208,wC=209,DC=210,UC=211,NC=212,LC=213,OC=214,s0=0,o0=1,l0=2,cc=3,c0=4,u0=5,f0=6,h0=7,Nb=0,PC=1,FC=2,xr=0,Lb=1,Ob=2,Pb=3,Fb=4,zb=5,Ib=6,Bb=7,Hb=300,ko=301,uc=302,e_=303,t_=304,Ad=306,d0=1e3,Qr=1001,p0=1002,_i=1003,zC=1004,Sh=1005,Ci=1006,n_=1007,Uo=1008,Ia=1009,Gb=1010,Vb=1011,qu=1012,bg=1013,Mr=1014,_r=1015,as=1016,Eg=1017,Tg=1018,Yu=1020,kb=35902,Xb=35899,Wb=1021,qb=1022,er=1023,rs=1026,No=1027,Yb=1028,Ag=1029,Xo=1030,Rg=1031,Cg=1033,$h=33776,ed=33777,td=33778,nd=33779,m0=35840,_0=35841,g0=35842,v0=35843,x0=36196,S0=37492,y0=37496,M0=37488,b0=37489,md=37490,E0=37491,T0=37808,A0=37809,R0=37810,C0=37811,w0=37812,D0=37813,U0=37814,N0=37815,L0=37816,O0=37817,P0=37818,F0=37819,z0=37820,I0=37821,B0=36492,H0=36494,G0=36495,V0=36283,k0=36284,_d=36285,X0=36286,IC=3200,hM=0,BC=1,zs="",Pa="srgb",gd="srgb-linear",vd="linear",cn="srgb",wl=7680,dM=519,HC=512,GC=513,VC=514,wg=515,kC=516,XC=517,Dg=518,WC=519,pM=35044,mM="300 es",gr=2e3,xd=2001;function qC(o){for(let e=o.length-1;e>=0;--e)if(o[e]>=65535)return!0;return!1}function Sd(o){return document.createElementNS("http://www.w3.org/1999/xhtml",o)}function YC(){const o=Sd("canvas");return o.style.display="block",o}const _M={};function gM(...o){const e="THREE."+o.shift();console.log(e,...o)}function jb(o){const e=o[0];if(typeof e=="string"&&e.startsWith("TSL:")){const n=o[1];n&&n.isStackTrace?o[0]+=" "+n.getLocation():o[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'}return o}function _t(...o){o=jb(o);const e="THREE."+o.shift();{const n=o[0];n&&n.isStackTrace?console.warn(n.getError(e)):console.warn(e,...o)}}function jt(...o){o=jb(o);const e="THREE."+o.shift();{const n=o[0];n&&n.isStackTrace?console.error(n.getError(e)):console.error(e,...o)}}function W0(...o){const e=o.join(" ");e in _M||(_M[e]=!0,_t(...o))}function jC(o,e,n){return new Promise(function(a,r){function l(){switch(o.clientWaitSync(e,o.SYNC_FLUSH_COMMANDS_BIT,0)){case o.WAIT_FAILED:r();break;case o.TIMEOUT_EXPIRED:setTimeout(l,n);break;default:a()}}setTimeout(l,n)})}const ZC={[s0]:o0,[l0]:f0,[c0]:h0,[cc]:u0,[o0]:s0,[f0]:l0,[h0]:c0,[u0]:cc};class Yo{addEventListener(e,n){this._listeners===void 0&&(this._listeners={});const a=this._listeners;a[e]===void 0&&(a[e]=[]),a[e].indexOf(n)===-1&&a[e].push(n)}hasEventListener(e,n){const a=this._listeners;return a===void 0?!1:a[e]!==void 0&&a[e].indexOf(n)!==-1}removeEventListener(e,n){const a=this._listeners;if(a===void 0)return;const r=a[e];if(r!==void 0){const l=r.indexOf(n);l!==-1&&r.splice(l,1)}}dispatchEvent(e){const n=this._listeners;if(n===void 0)return;const a=n[e.type];if(a!==void 0){e.target=this;const r=a.slice(0);for(let l=0,u=r.length;l<u;l++)r[l].call(this,e);e.target=null}}}const Mi=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],i_=Math.PI/180,q0=180/Math.PI;function Zu(){const o=Math.random()*4294967295|0,e=Math.random()*4294967295|0,n=Math.random()*4294967295|0,a=Math.random()*4294967295|0;return(Mi[o&255]+Mi[o>>8&255]+Mi[o>>16&255]+Mi[o>>24&255]+"-"+Mi[e&255]+Mi[e>>8&255]+"-"+Mi[e>>16&15|64]+Mi[e>>24&255]+"-"+Mi[n&63|128]+Mi[n>>8&255]+"-"+Mi[n>>16&255]+Mi[n>>24&255]+Mi[a&255]+Mi[a>>8&255]+Mi[a>>16&255]+Mi[a>>24&255]).toLowerCase()}function Wt(o,e,n){return Math.max(e,Math.min(n,o))}function KC(o,e){return(o%e+e)%e}function a_(o,e,n){return(1-n)*o+n*e}function ou(o,e){switch(e.constructor){case Float32Array:return o;case Uint32Array:return o/4294967295;case Uint16Array:return o/65535;case Uint8Array:return o/255;case Int32Array:return Math.max(o/2147483647,-1);case Int16Array:return Math.max(o/32767,-1);case Int8Array:return Math.max(o/127,-1);default:throw new Error("Invalid component type.")}}function qi(o,e){switch(e.constructor){case Float32Array:return o;case Uint32Array:return Math.round(o*4294967295);case Uint16Array:return Math.round(o*65535);case Uint8Array:return Math.round(o*255);case Int32Array:return Math.round(o*2147483647);case Int16Array:return Math.round(o*32767);case Int8Array:return Math.round(o*127);default:throw new Error("Invalid component type.")}}const Og=class Og{constructor(e=0,n=0){this.x=e,this.y=n}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,n){return this.x=e,this.y=n,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const n=this.x,a=this.y,r=e.elements;return this.x=r[0]*n+r[3]*a+r[6],this.y=r[1]*n+r[4]*a+r[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,n){return this.x=Wt(this.x,e.x,n.x),this.y=Wt(this.y,e.y,n.y),this}clampScalar(e,n){return this.x=Wt(this.x,e,n),this.y=Wt(this.y,e,n),this}clampLength(e,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(Wt(a,e,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const n=Math.sqrt(this.lengthSq()*e.lengthSq());if(n===0)return Math.PI/2;const a=this.dot(e)/n;return Math.acos(Wt(a,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const n=this.x-e.x,a=this.y-e.y;return n*n+a*a}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this}lerpVectors(e,n,a){return this.x=e.x+(n.x-e.x)*a,this.y=e.y+(n.y-e.y)*a,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this}rotateAround(e,n){const a=Math.cos(n),r=Math.sin(n),l=this.x-e.x,u=this.y-e.y;return this.x=l*a-u*r+e.x,this.y=l*r+u*a+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}};Og.prototype.isVector2=!0;let Jt=Og;class dc{constructor(e=0,n=0,a=0,r=1){this.isQuaternion=!0,this._x=e,this._y=n,this._z=a,this._w=r}static slerpFlat(e,n,a,r,l,u,f){let d=a[r+0],p=a[r+1],_=a[r+2],v=a[r+3],g=l[u+0],x=l[u+1],M=l[u+2],E=l[u+3];if(v!==E||d!==g||p!==x||_!==M){let S=d*g+p*x+_*M+v*E;S<0&&(g=-g,x=-x,M=-M,E=-E,S=-S);let y=1-f;if(S<.9995){const R=Math.acos(S),U=Math.sin(R);y=Math.sin(y*R)/U,f=Math.sin(f*R)/U,d=d*y+g*f,p=p*y+x*f,_=_*y+M*f,v=v*y+E*f}else{d=d*y+g*f,p=p*y+x*f,_=_*y+M*f,v=v*y+E*f;const R=1/Math.sqrt(d*d+p*p+_*_+v*v);d*=R,p*=R,_*=R,v*=R}}e[n]=d,e[n+1]=p,e[n+2]=_,e[n+3]=v}static multiplyQuaternionsFlat(e,n,a,r,l,u){const f=a[r],d=a[r+1],p=a[r+2],_=a[r+3],v=l[u],g=l[u+1],x=l[u+2],M=l[u+3];return e[n]=f*M+_*v+d*x-p*g,e[n+1]=d*M+_*g+p*v-f*x,e[n+2]=p*M+_*x+f*g-d*v,e[n+3]=_*M-f*v-d*g-p*x,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,n,a,r){return this._x=e,this._y=n,this._z=a,this._w=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,n=!0){const a=e._x,r=e._y,l=e._z,u=e._order,f=Math.cos,d=Math.sin,p=f(a/2),_=f(r/2),v=f(l/2),g=d(a/2),x=d(r/2),M=d(l/2);switch(u){case"XYZ":this._x=g*_*v+p*x*M,this._y=p*x*v-g*_*M,this._z=p*_*M+g*x*v,this._w=p*_*v-g*x*M;break;case"YXZ":this._x=g*_*v+p*x*M,this._y=p*x*v-g*_*M,this._z=p*_*M-g*x*v,this._w=p*_*v+g*x*M;break;case"ZXY":this._x=g*_*v-p*x*M,this._y=p*x*v+g*_*M,this._z=p*_*M+g*x*v,this._w=p*_*v-g*x*M;break;case"ZYX":this._x=g*_*v-p*x*M,this._y=p*x*v+g*_*M,this._z=p*_*M-g*x*v,this._w=p*_*v+g*x*M;break;case"YZX":this._x=g*_*v+p*x*M,this._y=p*x*v+g*_*M,this._z=p*_*M-g*x*v,this._w=p*_*v-g*x*M;break;case"XZY":this._x=g*_*v-p*x*M,this._y=p*x*v-g*_*M,this._z=p*_*M+g*x*v,this._w=p*_*v+g*x*M;break;default:_t("Quaternion: .setFromEuler() encountered an unknown order: "+u)}return n===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,n){const a=n/2,r=Math.sin(a);return this._x=e.x*r,this._y=e.y*r,this._z=e.z*r,this._w=Math.cos(a),this._onChangeCallback(),this}setFromRotationMatrix(e){const n=e.elements,a=n[0],r=n[4],l=n[8],u=n[1],f=n[5],d=n[9],p=n[2],_=n[6],v=n[10],g=a+f+v;if(g>0){const x=.5/Math.sqrt(g+1);this._w=.25/x,this._x=(_-d)*x,this._y=(l-p)*x,this._z=(u-r)*x}else if(a>f&&a>v){const x=2*Math.sqrt(1+a-f-v);this._w=(_-d)/x,this._x=.25*x,this._y=(r+u)/x,this._z=(l+p)/x}else if(f>v){const x=2*Math.sqrt(1+f-a-v);this._w=(l-p)/x,this._x=(r+u)/x,this._y=.25*x,this._z=(d+_)/x}else{const x=2*Math.sqrt(1+v-a-f);this._w=(u-r)/x,this._x=(l+p)/x,this._y=(d+_)/x,this._z=.25*x}return this._onChangeCallback(),this}setFromUnitVectors(e,n){let a=e.dot(n)+1;return a<1e-8?(a=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=a):(this._x=0,this._y=-e.z,this._z=e.y,this._w=a)):(this._x=e.y*n.z-e.z*n.y,this._y=e.z*n.x-e.x*n.z,this._z=e.x*n.y-e.y*n.x,this._w=a),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(Wt(this.dot(e),-1,1)))}rotateTowards(e,n){const a=this.angleTo(e);if(a===0)return this;const r=Math.min(1,n/a);return this.slerp(e,r),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,n){const a=e._x,r=e._y,l=e._z,u=e._w,f=n._x,d=n._y,p=n._z,_=n._w;return this._x=a*_+u*f+r*p-l*d,this._y=r*_+u*d+l*f-a*p,this._z=l*_+u*p+a*d-r*f,this._w=u*_-a*f-r*d-l*p,this._onChangeCallback(),this}slerp(e,n){let a=e._x,r=e._y,l=e._z,u=e._w,f=this.dot(e);f<0&&(a=-a,r=-r,l=-l,u=-u,f=-f);let d=1-n;if(f<.9995){const p=Math.acos(f),_=Math.sin(p);d=Math.sin(d*p)/_,n=Math.sin(n*p)/_,this._x=this._x*d+a*n,this._y=this._y*d+r*n,this._z=this._z*d+l*n,this._w=this._w*d+u*n,this._onChangeCallback()}else this._x=this._x*d+a*n,this._y=this._y*d+r*n,this._z=this._z*d+l*n,this._w=this._w*d+u*n,this.normalize();return this}slerpQuaternions(e,n,a){return this.copy(e).slerp(n,a)}random(){const e=2*Math.PI*Math.random(),n=2*Math.PI*Math.random(),a=Math.random(),r=Math.sqrt(1-a),l=Math.sqrt(a);return this.set(r*Math.sin(e),r*Math.cos(e),l*Math.sin(n),l*Math.cos(n))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,n=0){return this._x=e[n],this._y=e[n+1],this._z=e[n+2],this._w=e[n+3],this._onChangeCallback(),this}toArray(e=[],n=0){return e[n]=this._x,e[n+1]=this._y,e[n+2]=this._z,e[n+3]=this._w,e}fromBufferAttribute(e,n){return this._x=e.getX(n),this._y=e.getY(n),this._z=e.getZ(n),this._w=e.getW(n),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}const Pg=class Pg{constructor(e=0,n=0,a=0){this.x=e,this.y=n,this.z=a}set(e,n,a){return a===void 0&&(a=this.z),this.x=e,this.y=n,this.z=a,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this.z=e.z+n.z,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this.z+=e.z*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this.z=e.z-n.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,n){return this.x=e.x*n.x,this.y=e.y*n.y,this.z=e.z*n.z,this}applyEuler(e){return this.applyQuaternion(vM.setFromEuler(e))}applyAxisAngle(e,n){return this.applyQuaternion(vM.setFromAxisAngle(e,n))}applyMatrix3(e){const n=this.x,a=this.y,r=this.z,l=e.elements;return this.x=l[0]*n+l[3]*a+l[6]*r,this.y=l[1]*n+l[4]*a+l[7]*r,this.z=l[2]*n+l[5]*a+l[8]*r,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const n=this.x,a=this.y,r=this.z,l=e.elements,u=1/(l[3]*n+l[7]*a+l[11]*r+l[15]);return this.x=(l[0]*n+l[4]*a+l[8]*r+l[12])*u,this.y=(l[1]*n+l[5]*a+l[9]*r+l[13])*u,this.z=(l[2]*n+l[6]*a+l[10]*r+l[14])*u,this}applyQuaternion(e){const n=this.x,a=this.y,r=this.z,l=e.x,u=e.y,f=e.z,d=e.w,p=2*(u*r-f*a),_=2*(f*n-l*r),v=2*(l*a-u*n);return this.x=n+d*p+u*v-f*_,this.y=a+d*_+f*p-l*v,this.z=r+d*v+l*_-u*p,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const n=this.x,a=this.y,r=this.z,l=e.elements;return this.x=l[0]*n+l[4]*a+l[8]*r,this.y=l[1]*n+l[5]*a+l[9]*r,this.z=l[2]*n+l[6]*a+l[10]*r,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,n){return this.x=Wt(this.x,e.x,n.x),this.y=Wt(this.y,e.y,n.y),this.z=Wt(this.z,e.z,n.z),this}clampScalar(e,n){return this.x=Wt(this.x,e,n),this.y=Wt(this.y,e,n),this.z=Wt(this.z,e,n),this}clampLength(e,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(Wt(a,e,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this.z+=(e.z-this.z)*n,this}lerpVectors(e,n,a){return this.x=e.x+(n.x-e.x)*a,this.y=e.y+(n.y-e.y)*a,this.z=e.z+(n.z-e.z)*a,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,n){const a=e.x,r=e.y,l=e.z,u=n.x,f=n.y,d=n.z;return this.x=r*d-l*f,this.y=l*u-a*d,this.z=a*f-r*u,this}projectOnVector(e){const n=e.lengthSq();if(n===0)return this.set(0,0,0);const a=e.dot(this)/n;return this.copy(e).multiplyScalar(a)}projectOnPlane(e){return r_.copy(this).projectOnVector(e),this.sub(r_)}reflect(e){return this.sub(r_.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const n=Math.sqrt(this.lengthSq()*e.lengthSq());if(n===0)return Math.PI/2;const a=this.dot(e)/n;return Math.acos(Wt(a,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const n=this.x-e.x,a=this.y-e.y,r=this.z-e.z;return n*n+a*a+r*r}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,n,a){const r=Math.sin(n)*e;return this.x=r*Math.sin(a),this.y=Math.cos(n)*e,this.z=r*Math.cos(a),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,n,a){return this.x=e*Math.sin(n),this.y=a,this.z=e*Math.cos(n),this}setFromMatrixPosition(e){const n=e.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this}setFromMatrixScale(e){const n=this.setFromMatrixColumn(e,0).length(),a=this.setFromMatrixColumn(e,1).length(),r=this.setFromMatrixColumn(e,2).length();return this.x=n,this.y=a,this.z=r,this}setFromMatrixColumn(e,n){return this.fromArray(e.elements,n*4)}setFromMatrix3Column(e,n){return this.fromArray(e.elements,n*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this.z=e[n+2],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e[n+2]=this.z,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this.z=e.getZ(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,n=Math.random()*2-1,a=Math.sqrt(1-n*n);return this.x=a*Math.cos(e),this.y=n,this.z=a*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}};Pg.prototype.isVector3=!0;let ue=Pg;const r_=new ue,vM=new dc,Fg=class Fg{constructor(e,n,a,r,l,u,f,d,p){this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,n,a,r,l,u,f,d,p)}set(e,n,a,r,l,u,f,d,p){const _=this.elements;return _[0]=e,_[1]=r,_[2]=f,_[3]=n,_[4]=l,_[5]=d,_[6]=a,_[7]=u,_[8]=p,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const n=this.elements,a=e.elements;return n[0]=a[0],n[1]=a[1],n[2]=a[2],n[3]=a[3],n[4]=a[4],n[5]=a[5],n[6]=a[6],n[7]=a[7],n[8]=a[8],this}extractBasis(e,n,a){return e.setFromMatrix3Column(this,0),n.setFromMatrix3Column(this,1),a.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const n=e.elements;return this.set(n[0],n[4],n[8],n[1],n[5],n[9],n[2],n[6],n[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,n){const a=e.elements,r=n.elements,l=this.elements,u=a[0],f=a[3],d=a[6],p=a[1],_=a[4],v=a[7],g=a[2],x=a[5],M=a[8],E=r[0],S=r[3],y=r[6],R=r[1],U=r[4],C=r[7],F=r[2],O=r[5],D=r[8];return l[0]=u*E+f*R+d*F,l[3]=u*S+f*U+d*O,l[6]=u*y+f*C+d*D,l[1]=p*E+_*R+v*F,l[4]=p*S+_*U+v*O,l[7]=p*y+_*C+v*D,l[2]=g*E+x*R+M*F,l[5]=g*S+x*U+M*O,l[8]=g*y+x*C+M*D,this}multiplyScalar(e){const n=this.elements;return n[0]*=e,n[3]*=e,n[6]*=e,n[1]*=e,n[4]*=e,n[7]*=e,n[2]*=e,n[5]*=e,n[8]*=e,this}determinant(){const e=this.elements,n=e[0],a=e[1],r=e[2],l=e[3],u=e[4],f=e[5],d=e[6],p=e[7],_=e[8];return n*u*_-n*f*p-a*l*_+a*f*d+r*l*p-r*u*d}invert(){const e=this.elements,n=e[0],a=e[1],r=e[2],l=e[3],u=e[4],f=e[5],d=e[6],p=e[7],_=e[8],v=_*u-f*p,g=f*d-_*l,x=p*l-u*d,M=n*v+a*g+r*x;if(M===0)return this.set(0,0,0,0,0,0,0,0,0);const E=1/M;return e[0]=v*E,e[1]=(r*p-_*a)*E,e[2]=(f*a-r*u)*E,e[3]=g*E,e[4]=(_*n-r*d)*E,e[5]=(r*l-f*n)*E,e[6]=x*E,e[7]=(a*d-p*n)*E,e[8]=(u*n-a*l)*E,this}transpose(){let e;const n=this.elements;return e=n[1],n[1]=n[3],n[3]=e,e=n[2],n[2]=n[6],n[6]=e,e=n[5],n[5]=n[7],n[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const n=this.elements;return e[0]=n[0],e[1]=n[3],e[2]=n[6],e[3]=n[1],e[4]=n[4],e[5]=n[7],e[6]=n[2],e[7]=n[5],e[8]=n[8],this}setUvTransform(e,n,a,r,l,u,f){const d=Math.cos(l),p=Math.sin(l);return this.set(a*d,a*p,-a*(d*u+p*f)+u+e,-r*p,r*d,-r*(-p*u+d*f)+f+n,0,0,1),this}scale(e,n){return this.premultiply(s_.makeScale(e,n)),this}rotate(e){return this.premultiply(s_.makeRotation(-e)),this}translate(e,n){return this.premultiply(s_.makeTranslation(e,n)),this}makeTranslation(e,n){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,n,0,0,1),this}makeRotation(e){const n=Math.cos(e),a=Math.sin(e);return this.set(n,-a,0,a,n,0,0,0,1),this}makeScale(e,n){return this.set(e,0,0,0,n,0,0,0,1),this}equals(e){const n=this.elements,a=e.elements;for(let r=0;r<9;r++)if(n[r]!==a[r])return!1;return!0}fromArray(e,n=0){for(let a=0;a<9;a++)this.elements[a]=e[a+n];return this}toArray(e=[],n=0){const a=this.elements;return e[n]=a[0],e[n+1]=a[1],e[n+2]=a[2],e[n+3]=a[3],e[n+4]=a[4],e[n+5]=a[5],e[n+6]=a[6],e[n+7]=a[7],e[n+8]=a[8],e}clone(){return new this.constructor().fromArray(this.elements)}};Fg.prototype.isMatrix3=!0;let Et=Fg;const s_=new Et,xM=new Et().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),SM=new Et().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function QC(){const o={enabled:!0,workingColorSpace:gd,spaces:{},convert:function(r,l,u){return this.enabled===!1||l===u||!l||!u||(this.spaces[l].transfer===cn&&(r.r=es(r.r),r.g=es(r.g),r.b=es(r.b)),this.spaces[l].primaries!==this.spaces[u].primaries&&(r.applyMatrix3(this.spaces[l].toXYZ),r.applyMatrix3(this.spaces[u].fromXYZ)),this.spaces[u].transfer===cn&&(r.r=nc(r.r),r.g=nc(r.g),r.b=nc(r.b))),r},workingToColorSpace:function(r,l){return this.convert(r,this.workingColorSpace,l)},colorSpaceToWorking:function(r,l){return this.convert(r,l,this.workingColorSpace)},getPrimaries:function(r){return this.spaces[r].primaries},getTransfer:function(r){return r===zs?vd:this.spaces[r].transfer},getToneMappingMode:function(r){return this.spaces[r].outputColorSpaceConfig.toneMappingMode||"standard"},getLuminanceCoefficients:function(r,l=this.workingColorSpace){return r.fromArray(this.spaces[l].luminanceCoefficients)},define:function(r){Object.assign(this.spaces,r)},_getMatrix:function(r,l,u){return r.copy(this.spaces[l].toXYZ).multiply(this.spaces[u].fromXYZ)},_getDrawingBufferColorSpace:function(r){return this.spaces[r].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(r=this.workingColorSpace){return this.spaces[r].workingColorSpaceConfig.unpackColorSpace},fromWorkingColorSpace:function(r,l){return W0("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),o.workingToColorSpace(r,l)},toWorkingColorSpace:function(r,l){return W0("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),o.colorSpaceToWorking(r,l)}},e=[.64,.33,.3,.6,.15,.06],n=[.2126,.7152,.0722],a=[.3127,.329];return o.define({[gd]:{primaries:e,whitePoint:a,transfer:vd,toXYZ:xM,fromXYZ:SM,luminanceCoefficients:n,workingColorSpaceConfig:{unpackColorSpace:Pa},outputColorSpaceConfig:{drawingBufferColorSpace:Pa}},[Pa]:{primaries:e,whitePoint:a,transfer:cn,toXYZ:xM,fromXYZ:SM,luminanceCoefficients:n,outputColorSpaceConfig:{drawingBufferColorSpace:Pa}}}),o}const Xt=QC();function es(o){return o<.04045?o*.0773993808:Math.pow(o*.9478672986+.0521327014,2.4)}function nc(o){return o<.0031308?o*12.92:1.055*Math.pow(o,.41666)-.055}let Dl;class JC{static getDataURL(e,n="image/png"){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let a;if(e instanceof HTMLCanvasElement)a=e;else{Dl===void 0&&(Dl=Sd("canvas")),Dl.width=e.width,Dl.height=e.height;const r=Dl.getContext("2d");e instanceof ImageData?r.putImageData(e,0,0):r.drawImage(e,0,0,e.width,e.height),a=Dl}return a.toDataURL(n)}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const n=Sd("canvas");n.width=e.width,n.height=e.height;const a=n.getContext("2d");a.drawImage(e,0,0,e.width,e.height);const r=a.getImageData(0,0,e.width,e.height),l=r.data;for(let u=0;u<l.length;u++)l[u]=es(l[u]/255)*255;return a.putImageData(r,0,0),n}else if(e.data){const n=e.data.slice(0);for(let a=0;a<n.length;a++)n instanceof Uint8Array||n instanceof Uint8ClampedArray?n[a]=Math.floor(es(n[a]/255)*255):n[a]=es(n[a]);return{data:n,width:e.width,height:e.height}}else return _t("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let $C=0;class Ug{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:$C++}),this.uuid=Zu(),this.data=e,this.dataReady=!0,this.version=0}getSize(e){const n=this.data;return typeof HTMLVideoElement<"u"&&n instanceof HTMLVideoElement?e.set(n.videoWidth,n.videoHeight,0):typeof VideoFrame<"u"&&n instanceof VideoFrame?e.set(n.displayWidth,n.displayHeight,0):n!==null?e.set(n.width,n.height,n.depth||0):e.set(0,0,0),e}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const n=e===void 0||typeof e=="string";if(!n&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const a={uuid:this.uuid,url:""},r=this.data;if(r!==null){let l;if(Array.isArray(r)){l=[];for(let u=0,f=r.length;u<f;u++)r[u].isDataTexture?l.push(o_(r[u].image)):l.push(o_(r[u]))}else l=o_(r);a.url=l}return n||(e.images[this.uuid]=a),a}}function o_(o){return typeof HTMLImageElement<"u"&&o instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&o instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&o instanceof ImageBitmap?JC.getDataURL(o):o.data?{data:Array.from(o.data),width:o.width,height:o.height,type:o.data.constructor.name}:(_t("Texture: Unable to serialize Texture."),{})}let e2=0;const l_=new ue;class Bi extends Yo{constructor(e=Bi.DEFAULT_IMAGE,n=Bi.DEFAULT_MAPPING,a=Qr,r=Qr,l=Ci,u=Uo,f=er,d=Ia,p=Bi.DEFAULT_ANISOTROPY,_=zs){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:e2++}),this.uuid=Zu(),this.name="",this.source=new Ug(e),this.mipmaps=[],this.mapping=n,this.channel=0,this.wrapS=a,this.wrapT=r,this.magFilter=l,this.minFilter=u,this.anisotropy=p,this.format=f,this.internalFormat=null,this.type=d,this.offset=new Jt(0,0),this.repeat=new Jt(1,1),this.center=new Jt(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new Et,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=_,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!(e&&e.depth&&e.depth>1),this.pmremVersion=0,this.normalized=!1}get width(){return this.source.getSize(l_).x}get height(){return this.source.getSize(l_).y}get depth(){return this.source.getSize(l_).z}get image(){return this.source.data}set image(e){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}addUpdateRange(e,n){this.updateRanges.push({start:e,count:n})}clearUpdateRanges(){this.updateRanges.length=0}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.normalized=e.normalized,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.isArrayTexture=e.isArrayTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}setValues(e){for(const n in e){const a=e[n];if(a===void 0){_t(`Texture.setValues(): parameter '${n}' has value of undefined.`);continue}const r=this[n];if(r===void 0){_t(`Texture.setValues(): property '${n}' does not exist.`);continue}r&&a&&r.isVector2&&a.isVector2||r&&a&&r.isVector3&&a.isVector3||r&&a&&r.isMatrix3&&a.isMatrix3?r.copy(a):this[n]=a}}toJSON(e){const n=e===void 0||typeof e=="string";if(!n&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const a={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(a.userData=this.userData),n||(e.textures[this.uuid]=a),a}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Hb)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case d0:e.x=e.x-Math.floor(e.x);break;case Qr:e.x=e.x<0?0:1;break;case p0:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case d0:e.y=e.y-Math.floor(e.y);break;case Qr:e.y=e.y<0?0:1;break;case p0:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Bi.DEFAULT_IMAGE=null;Bi.DEFAULT_MAPPING=Hb;Bi.DEFAULT_ANISOTROPY=1;const zg=class zg{constructor(e=0,n=0,a=0,r=1){this.x=e,this.y=n,this.z=a,this.w=r}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,n,a,r){return this.x=e,this.y=n,this.z=a,this.w=r,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,n){switch(e){case 0:this.x=n;break;case 1:this.y=n;break;case 2:this.z=n;break;case 3:this.w=n;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,n){return this.x=e.x+n.x,this.y=e.y+n.y,this.z=e.z+n.z,this.w=e.w+n.w,this}addScaledVector(e,n){return this.x+=e.x*n,this.y+=e.y*n,this.z+=e.z*n,this.w+=e.w*n,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,n){return this.x=e.x-n.x,this.y=e.y-n.y,this.z=e.z-n.z,this.w=e.w-n.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const n=this.x,a=this.y,r=this.z,l=this.w,u=e.elements;return this.x=u[0]*n+u[4]*a+u[8]*r+u[12]*l,this.y=u[1]*n+u[5]*a+u[9]*r+u[13]*l,this.z=u[2]*n+u[6]*a+u[10]*r+u[14]*l,this.w=u[3]*n+u[7]*a+u[11]*r+u[15]*l,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const n=Math.sqrt(1-e.w*e.w);return n<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/n,this.y=e.y/n,this.z=e.z/n),this}setAxisAngleFromRotationMatrix(e){let n,a,r,l;const d=e.elements,p=d[0],_=d[4],v=d[8],g=d[1],x=d[5],M=d[9],E=d[2],S=d[6],y=d[10];if(Math.abs(_-g)<.01&&Math.abs(v-E)<.01&&Math.abs(M-S)<.01){if(Math.abs(_+g)<.1&&Math.abs(v+E)<.1&&Math.abs(M+S)<.1&&Math.abs(p+x+y-3)<.1)return this.set(1,0,0,0),this;n=Math.PI;const U=(p+1)/2,C=(x+1)/2,F=(y+1)/2,O=(_+g)/4,D=(v+E)/4,T=(M+S)/4;return U>C&&U>F?U<.01?(a=0,r=.707106781,l=.707106781):(a=Math.sqrt(U),r=O/a,l=D/a):C>F?C<.01?(a=.707106781,r=0,l=.707106781):(r=Math.sqrt(C),a=O/r,l=T/r):F<.01?(a=.707106781,r=.707106781,l=0):(l=Math.sqrt(F),a=D/l,r=T/l),this.set(a,r,l,n),this}let R=Math.sqrt((S-M)*(S-M)+(v-E)*(v-E)+(g-_)*(g-_));return Math.abs(R)<.001&&(R=1),this.x=(S-M)/R,this.y=(v-E)/R,this.z=(g-_)/R,this.w=Math.acos((p+x+y-1)/2),this}setFromMatrixPosition(e){const n=e.elements;return this.x=n[12],this.y=n[13],this.z=n[14],this.w=n[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,n){return this.x=Wt(this.x,e.x,n.x),this.y=Wt(this.y,e.y,n.y),this.z=Wt(this.z,e.z,n.z),this.w=Wt(this.w,e.w,n.w),this}clampScalar(e,n){return this.x=Wt(this.x,e,n),this.y=Wt(this.y,e,n),this.z=Wt(this.z,e,n),this.w=Wt(this.w,e,n),this}clampLength(e,n){const a=this.length();return this.divideScalar(a||1).multiplyScalar(Wt(a,e,n))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,n){return this.x+=(e.x-this.x)*n,this.y+=(e.y-this.y)*n,this.z+=(e.z-this.z)*n,this.w+=(e.w-this.w)*n,this}lerpVectors(e,n,a){return this.x=e.x+(n.x-e.x)*a,this.y=e.y+(n.y-e.y)*a,this.z=e.z+(n.z-e.z)*a,this.w=e.w+(n.w-e.w)*a,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,n=0){return this.x=e[n],this.y=e[n+1],this.z=e[n+2],this.w=e[n+3],this}toArray(e=[],n=0){return e[n]=this.x,e[n+1]=this.y,e[n+2]=this.z,e[n+3]=this.w,e}fromBufferAttribute(e,n){return this.x=e.getX(n),this.y=e.getY(n),this.z=e.getZ(n),this.w=e.getW(n),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}};zg.prototype.isVector4=!0;let Vn=zg;class t2 extends Yo{constructor(e=1,n=1,a={}){super(),a=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Ci,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},a),this.isRenderTarget=!0,this.width=e,this.height=n,this.depth=a.depth,this.scissor=new Vn(0,0,e,n),this.scissorTest=!1,this.viewport=new Vn(0,0,e,n),this.textures=[];const r={width:e,height:n,depth:a.depth},l=new Bi(r),u=a.count;for(let f=0;f<u;f++)this.textures[f]=l.clone(),this.textures[f].isRenderTargetTexture=!0,this.textures[f].renderTarget=this;this._setTextureOptions(a),this.depthBuffer=a.depthBuffer,this.stencilBuffer=a.stencilBuffer,this.resolveDepthBuffer=a.resolveDepthBuffer,this.resolveStencilBuffer=a.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=a.depthTexture,this.samples=a.samples,this.multiview=a.multiview}_setTextureOptions(e={}){const n={minFilter:Ci,generateMipmaps:!1,flipY:!1,internalFormat:null};e.mapping!==void 0&&(n.mapping=e.mapping),e.wrapS!==void 0&&(n.wrapS=e.wrapS),e.wrapT!==void 0&&(n.wrapT=e.wrapT),e.wrapR!==void 0&&(n.wrapR=e.wrapR),e.magFilter!==void 0&&(n.magFilter=e.magFilter),e.minFilter!==void 0&&(n.minFilter=e.minFilter),e.format!==void 0&&(n.format=e.format),e.type!==void 0&&(n.type=e.type),e.anisotropy!==void 0&&(n.anisotropy=e.anisotropy),e.colorSpace!==void 0&&(n.colorSpace=e.colorSpace),e.flipY!==void 0&&(n.flipY=e.flipY),e.generateMipmaps!==void 0&&(n.generateMipmaps=e.generateMipmaps),e.internalFormat!==void 0&&(n.internalFormat=e.internalFormat);for(let a=0;a<this.textures.length;a++)this.textures[a].setValues(n)}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,n,a=1){if(this.width!==e||this.height!==n||this.depth!==a){this.width=e,this.height=n,this.depth=a;for(let r=0,l=this.textures.length;r<l;r++)this.textures[r].image.width=e,this.textures[r].image.height=n,this.textures[r].image.depth=a,this.textures[r].isData3DTexture!==!0&&(this.textures[r].isArrayTexture=this.textures[r].image.depth>1);this.dispose()}this.viewport.set(0,0,e,n),this.scissor.set(0,0,e,n)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let n=0,a=e.textures.length;n<a;n++){this.textures[n]=e.textures[n].clone(),this.textures[n].isRenderTargetTexture=!0,this.textures[n].renderTarget=this;const r=Object.assign({},e.textures[n].image);this.textures[n].source=new Ug(r)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this.multiview=e.multiview,this}dispose(){this.dispatchEvent({type:"dispose"})}}class Sr extends t2{constructor(e=1,n=1,a={}){super(e,n,a),this.isWebGLRenderTarget=!0}}class Zb extends Bi{constructor(e=null,n=1,a=1,r=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:n,height:a,depth:r},this.magFilter=_i,this.minFilter=_i,this.wrapR=Qr,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class n2 extends Bi{constructor(e=null,n=1,a=1,r=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:n,height:a,depth:r},this.magFilter=_i,this.minFilter=_i,this.wrapR=Qr,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const yd=class yd{constructor(e,n,a,r,l,u,f,d,p,_,v,g,x,M,E,S){this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,n,a,r,l,u,f,d,p,_,v,g,x,M,E,S)}set(e,n,a,r,l,u,f,d,p,_,v,g,x,M,E,S){const y=this.elements;return y[0]=e,y[4]=n,y[8]=a,y[12]=r,y[1]=l,y[5]=u,y[9]=f,y[13]=d,y[2]=p,y[6]=_,y[10]=v,y[14]=g,y[3]=x,y[7]=M,y[11]=E,y[15]=S,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new yd().fromArray(this.elements)}copy(e){const n=this.elements,a=e.elements;return n[0]=a[0],n[1]=a[1],n[2]=a[2],n[3]=a[3],n[4]=a[4],n[5]=a[5],n[6]=a[6],n[7]=a[7],n[8]=a[8],n[9]=a[9],n[10]=a[10],n[11]=a[11],n[12]=a[12],n[13]=a[13],n[14]=a[14],n[15]=a[15],this}copyPosition(e){const n=this.elements,a=e.elements;return n[12]=a[12],n[13]=a[13],n[14]=a[14],this}setFromMatrix3(e){const n=e.elements;return this.set(n[0],n[3],n[6],0,n[1],n[4],n[7],0,n[2],n[5],n[8],0,0,0,0,1),this}extractBasis(e,n,a){return this.determinant()===0?(e.set(1,0,0),n.set(0,1,0),a.set(0,0,1),this):(e.setFromMatrixColumn(this,0),n.setFromMatrixColumn(this,1),a.setFromMatrixColumn(this,2),this)}makeBasis(e,n,a){return this.set(e.x,n.x,a.x,0,e.y,n.y,a.y,0,e.z,n.z,a.z,0,0,0,0,1),this}extractRotation(e){if(e.determinant()===0)return this.identity();const n=this.elements,a=e.elements,r=1/Ul.setFromMatrixColumn(e,0).length(),l=1/Ul.setFromMatrixColumn(e,1).length(),u=1/Ul.setFromMatrixColumn(e,2).length();return n[0]=a[0]*r,n[1]=a[1]*r,n[2]=a[2]*r,n[3]=0,n[4]=a[4]*l,n[5]=a[5]*l,n[6]=a[6]*l,n[7]=0,n[8]=a[8]*u,n[9]=a[9]*u,n[10]=a[10]*u,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromEuler(e){const n=this.elements,a=e.x,r=e.y,l=e.z,u=Math.cos(a),f=Math.sin(a),d=Math.cos(r),p=Math.sin(r),_=Math.cos(l),v=Math.sin(l);if(e.order==="XYZ"){const g=u*_,x=u*v,M=f*_,E=f*v;n[0]=d*_,n[4]=-d*v,n[8]=p,n[1]=x+M*p,n[5]=g-E*p,n[9]=-f*d,n[2]=E-g*p,n[6]=M+x*p,n[10]=u*d}else if(e.order==="YXZ"){const g=d*_,x=d*v,M=p*_,E=p*v;n[0]=g+E*f,n[4]=M*f-x,n[8]=u*p,n[1]=u*v,n[5]=u*_,n[9]=-f,n[2]=x*f-M,n[6]=E+g*f,n[10]=u*d}else if(e.order==="ZXY"){const g=d*_,x=d*v,M=p*_,E=p*v;n[0]=g-E*f,n[4]=-u*v,n[8]=M+x*f,n[1]=x+M*f,n[5]=u*_,n[9]=E-g*f,n[2]=-u*p,n[6]=f,n[10]=u*d}else if(e.order==="ZYX"){const g=u*_,x=u*v,M=f*_,E=f*v;n[0]=d*_,n[4]=M*p-x,n[8]=g*p+E,n[1]=d*v,n[5]=E*p+g,n[9]=x*p-M,n[2]=-p,n[6]=f*d,n[10]=u*d}else if(e.order==="YZX"){const g=u*d,x=u*p,M=f*d,E=f*p;n[0]=d*_,n[4]=E-g*v,n[8]=M*v+x,n[1]=v,n[5]=u*_,n[9]=-f*_,n[2]=-p*_,n[6]=x*v+M,n[10]=g-E*v}else if(e.order==="XZY"){const g=u*d,x=u*p,M=f*d,E=f*p;n[0]=d*_,n[4]=-v,n[8]=p*_,n[1]=g*v+E,n[5]=u*_,n[9]=x*v-M,n[2]=M*v-x,n[6]=f*_,n[10]=E*v+g}return n[3]=0,n[7]=0,n[11]=0,n[12]=0,n[13]=0,n[14]=0,n[15]=1,this}makeRotationFromQuaternion(e){return this.compose(i2,e,a2)}lookAt(e,n,a){const r=this.elements;return ua.subVectors(e,n),ua.lengthSq()===0&&(ua.z=1),ua.normalize(),Ds.crossVectors(a,ua),Ds.lengthSq()===0&&(Math.abs(a.z)===1?ua.x+=1e-4:ua.z+=1e-4,ua.normalize(),Ds.crossVectors(a,ua)),Ds.normalize(),yh.crossVectors(ua,Ds),r[0]=Ds.x,r[4]=yh.x,r[8]=ua.x,r[1]=Ds.y,r[5]=yh.y,r[9]=ua.y,r[2]=Ds.z,r[6]=yh.z,r[10]=ua.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,n){const a=e.elements,r=n.elements,l=this.elements,u=a[0],f=a[4],d=a[8],p=a[12],_=a[1],v=a[5],g=a[9],x=a[13],M=a[2],E=a[6],S=a[10],y=a[14],R=a[3],U=a[7],C=a[11],F=a[15],O=r[0],D=r[4],T=r[8],L=r[12],H=r[1],V=r[5],k=r[9],te=r[13],ie=r[2],W=r[6],z=r[10],B=r[14],J=r[3],fe=r[7],G=r[11],I=r[15];return l[0]=u*O+f*H+d*ie+p*J,l[4]=u*D+f*V+d*W+p*fe,l[8]=u*T+f*k+d*z+p*G,l[12]=u*L+f*te+d*B+p*I,l[1]=_*O+v*H+g*ie+x*J,l[5]=_*D+v*V+g*W+x*fe,l[9]=_*T+v*k+g*z+x*G,l[13]=_*L+v*te+g*B+x*I,l[2]=M*O+E*H+S*ie+y*J,l[6]=M*D+E*V+S*W+y*fe,l[10]=M*T+E*k+S*z+y*G,l[14]=M*L+E*te+S*B+y*I,l[3]=R*O+U*H+C*ie+F*J,l[7]=R*D+U*V+C*W+F*fe,l[11]=R*T+U*k+C*z+F*G,l[15]=R*L+U*te+C*B+F*I,this}multiplyScalar(e){const n=this.elements;return n[0]*=e,n[4]*=e,n[8]*=e,n[12]*=e,n[1]*=e,n[5]*=e,n[9]*=e,n[13]*=e,n[2]*=e,n[6]*=e,n[10]*=e,n[14]*=e,n[3]*=e,n[7]*=e,n[11]*=e,n[15]*=e,this}determinant(){const e=this.elements,n=e[0],a=e[4],r=e[8],l=e[12],u=e[1],f=e[5],d=e[9],p=e[13],_=e[2],v=e[6],g=e[10],x=e[14],M=e[3],E=e[7],S=e[11],y=e[15],R=d*x-p*g,U=f*x-p*v,C=f*g-d*v,F=u*x-p*_,O=u*g-d*_,D=u*v-f*_;return n*(E*R-S*U+y*C)-a*(M*R-S*F+y*O)+r*(M*U-E*F+y*D)-l*(M*C-E*O+S*D)}transpose(){const e=this.elements;let n;return n=e[1],e[1]=e[4],e[4]=n,n=e[2],e[2]=e[8],e[8]=n,n=e[6],e[6]=e[9],e[9]=n,n=e[3],e[3]=e[12],e[12]=n,n=e[7],e[7]=e[13],e[13]=n,n=e[11],e[11]=e[14],e[14]=n,this}setPosition(e,n,a){const r=this.elements;return e.isVector3?(r[12]=e.x,r[13]=e.y,r[14]=e.z):(r[12]=e,r[13]=n,r[14]=a),this}invert(){const e=this.elements,n=e[0],a=e[1],r=e[2],l=e[3],u=e[4],f=e[5],d=e[6],p=e[7],_=e[8],v=e[9],g=e[10],x=e[11],M=e[12],E=e[13],S=e[14],y=e[15],R=n*f-a*u,U=n*d-r*u,C=n*p-l*u,F=a*d-r*f,O=a*p-l*f,D=r*p-l*d,T=_*E-v*M,L=_*S-g*M,H=_*y-x*M,V=v*S-g*E,k=v*y-x*E,te=g*y-x*S,ie=R*te-U*k+C*V+F*H-O*L+D*T;if(ie===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const W=1/ie;return e[0]=(f*te-d*k+p*V)*W,e[1]=(r*k-a*te-l*V)*W,e[2]=(E*D-S*O+y*F)*W,e[3]=(g*O-v*D-x*F)*W,e[4]=(d*H-u*te-p*L)*W,e[5]=(n*te-r*H+l*L)*W,e[6]=(S*C-M*D-y*U)*W,e[7]=(_*D-g*C+x*U)*W,e[8]=(u*k-f*H+p*T)*W,e[9]=(a*H-n*k-l*T)*W,e[10]=(M*O-E*C+y*R)*W,e[11]=(v*C-_*O-x*R)*W,e[12]=(f*L-u*V-d*T)*W,e[13]=(n*V-a*L+r*T)*W,e[14]=(E*U-M*F-S*R)*W,e[15]=(_*F-v*U+g*R)*W,this}scale(e){const n=this.elements,a=e.x,r=e.y,l=e.z;return n[0]*=a,n[4]*=r,n[8]*=l,n[1]*=a,n[5]*=r,n[9]*=l,n[2]*=a,n[6]*=r,n[10]*=l,n[3]*=a,n[7]*=r,n[11]*=l,this}getMaxScaleOnAxis(){const e=this.elements,n=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],a=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],r=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(n,a,r))}makeTranslation(e,n,a){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,n,0,0,1,a,0,0,0,1),this}makeRotationX(e){const n=Math.cos(e),a=Math.sin(e);return this.set(1,0,0,0,0,n,-a,0,0,a,n,0,0,0,0,1),this}makeRotationY(e){const n=Math.cos(e),a=Math.sin(e);return this.set(n,0,a,0,0,1,0,0,-a,0,n,0,0,0,0,1),this}makeRotationZ(e){const n=Math.cos(e),a=Math.sin(e);return this.set(n,-a,0,0,a,n,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,n){const a=Math.cos(n),r=Math.sin(n),l=1-a,u=e.x,f=e.y,d=e.z,p=l*u,_=l*f;return this.set(p*u+a,p*f-r*d,p*d+r*f,0,p*f+r*d,_*f+a,_*d-r*u,0,p*d-r*f,_*d+r*u,l*d*d+a,0,0,0,0,1),this}makeScale(e,n,a){return this.set(e,0,0,0,0,n,0,0,0,0,a,0,0,0,0,1),this}makeShear(e,n,a,r,l,u){return this.set(1,a,l,0,e,1,u,0,n,r,1,0,0,0,0,1),this}compose(e,n,a){const r=this.elements,l=n._x,u=n._y,f=n._z,d=n._w,p=l+l,_=u+u,v=f+f,g=l*p,x=l*_,M=l*v,E=u*_,S=u*v,y=f*v,R=d*p,U=d*_,C=d*v,F=a.x,O=a.y,D=a.z;return r[0]=(1-(E+y))*F,r[1]=(x+C)*F,r[2]=(M-U)*F,r[3]=0,r[4]=(x-C)*O,r[5]=(1-(g+y))*O,r[6]=(S+R)*O,r[7]=0,r[8]=(M+U)*D,r[9]=(S-R)*D,r[10]=(1-(g+E))*D,r[11]=0,r[12]=e.x,r[13]=e.y,r[14]=e.z,r[15]=1,this}decompose(e,n,a){const r=this.elements;e.x=r[12],e.y=r[13],e.z=r[14];const l=this.determinant();if(l===0)return a.set(1,1,1),n.identity(),this;let u=Ul.set(r[0],r[1],r[2]).length();const f=Ul.set(r[4],r[5],r[6]).length(),d=Ul.set(r[8],r[9],r[10]).length();l<0&&(u=-u),ja.copy(this);const p=1/u,_=1/f,v=1/d;return ja.elements[0]*=p,ja.elements[1]*=p,ja.elements[2]*=p,ja.elements[4]*=_,ja.elements[5]*=_,ja.elements[6]*=_,ja.elements[8]*=v,ja.elements[9]*=v,ja.elements[10]*=v,n.setFromRotationMatrix(ja),a.x=u,a.y=f,a.z=d,this}makePerspective(e,n,a,r,l,u,f=gr,d=!1){const p=this.elements,_=2*l/(n-e),v=2*l/(a-r),g=(n+e)/(n-e),x=(a+r)/(a-r);let M,E;if(d)M=l/(u-l),E=u*l/(u-l);else if(f===gr)M=-(u+l)/(u-l),E=-2*u*l/(u-l);else if(f===xd)M=-u/(u-l),E=-u*l/(u-l);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+f);return p[0]=_,p[4]=0,p[8]=g,p[12]=0,p[1]=0,p[5]=v,p[9]=x,p[13]=0,p[2]=0,p[6]=0,p[10]=M,p[14]=E,p[3]=0,p[7]=0,p[11]=-1,p[15]=0,this}makeOrthographic(e,n,a,r,l,u,f=gr,d=!1){const p=this.elements,_=2/(n-e),v=2/(a-r),g=-(n+e)/(n-e),x=-(a+r)/(a-r);let M,E;if(d)M=1/(u-l),E=u/(u-l);else if(f===gr)M=-2/(u-l),E=-(u+l)/(u-l);else if(f===xd)M=-1/(u-l),E=-l/(u-l);else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+f);return p[0]=_,p[4]=0,p[8]=0,p[12]=g,p[1]=0,p[5]=v,p[9]=0,p[13]=x,p[2]=0,p[6]=0,p[10]=M,p[14]=E,p[3]=0,p[7]=0,p[11]=0,p[15]=1,this}equals(e){const n=this.elements,a=e.elements;for(let r=0;r<16;r++)if(n[r]!==a[r])return!1;return!0}fromArray(e,n=0){for(let a=0;a<16;a++)this.elements[a]=e[a+n];return this}toArray(e=[],n=0){const a=this.elements;return e[n]=a[0],e[n+1]=a[1],e[n+2]=a[2],e[n+3]=a[3],e[n+4]=a[4],e[n+5]=a[5],e[n+6]=a[6],e[n+7]=a[7],e[n+8]=a[8],e[n+9]=a[9],e[n+10]=a[10],e[n+11]=a[11],e[n+12]=a[12],e[n+13]=a[13],e[n+14]=a[14],e[n+15]=a[15],e}};yd.prototype.isMatrix4=!0;let ii=yd;const Ul=new ue,ja=new ii,i2=new ue(0,0,0),a2=new ue(1,1,1),Ds=new ue,yh=new ue,ua=new ue,yM=new ii,MM=new dc;class Wo{constructor(e=0,n=0,a=0,r=Wo.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=n,this._z=a,this._order=r}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,n,a,r=this._order){return this._x=e,this._y=n,this._z=a,this._order=r,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,n=this._order,a=!0){const r=e.elements,l=r[0],u=r[4],f=r[8],d=r[1],p=r[5],_=r[9],v=r[2],g=r[6],x=r[10];switch(n){case"XYZ":this._y=Math.asin(Wt(f,-1,1)),Math.abs(f)<.9999999?(this._x=Math.atan2(-_,x),this._z=Math.atan2(-u,l)):(this._x=Math.atan2(g,p),this._z=0);break;case"YXZ":this._x=Math.asin(-Wt(_,-1,1)),Math.abs(_)<.9999999?(this._y=Math.atan2(f,x),this._z=Math.atan2(d,p)):(this._y=Math.atan2(-v,l),this._z=0);break;case"ZXY":this._x=Math.asin(Wt(g,-1,1)),Math.abs(g)<.9999999?(this._y=Math.atan2(-v,x),this._z=Math.atan2(-u,p)):(this._y=0,this._z=Math.atan2(d,l));break;case"ZYX":this._y=Math.asin(-Wt(v,-1,1)),Math.abs(v)<.9999999?(this._x=Math.atan2(g,x),this._z=Math.atan2(d,l)):(this._x=0,this._z=Math.atan2(-u,p));break;case"YZX":this._z=Math.asin(Wt(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(-_,p),this._y=Math.atan2(-v,l)):(this._x=0,this._y=Math.atan2(f,x));break;case"XZY":this._z=Math.asin(-Wt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(g,p),this._y=Math.atan2(f,l)):(this._x=Math.atan2(-_,x),this._y=0);break;default:_t("Euler: .setFromRotationMatrix() encountered an unknown order: "+n)}return this._order=n,a===!0&&this._onChangeCallback(),this}setFromQuaternion(e,n,a){return yM.makeRotationFromQuaternion(e),this.setFromRotationMatrix(yM,n,a)}setFromVector3(e,n=this._order){return this.set(e.x,e.y,e.z,n)}reorder(e){return MM.setFromEuler(this),this.setFromQuaternion(MM,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],n=0){return e[n]=this._x,e[n+1]=this._y,e[n+2]=this._z,e[n+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Wo.DEFAULT_ORDER="XYZ";class Kb{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let r2=0;const bM=new ue,Nl=new dc,Gr=new ii,Mh=new ue,lu=new ue,s2=new ue,o2=new dc,EM=new ue(1,0,0),TM=new ue(0,1,0),AM=new ue(0,0,1),RM={type:"added"},l2={type:"removed"},Ll={type:"childadded",child:null},c_={type:"childremoved",child:null};class ya extends Yo{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:r2++}),this.uuid=Zu(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=ya.DEFAULT_UP.clone();const e=new ue,n=new Wo,a=new dc,r=new ue(1,1,1);function l(){a.setFromEuler(n,!1)}function u(){n.setFromQuaternion(a,void 0,!1)}n._onChange(l),a._onChange(u),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:n},quaternion:{configurable:!0,enumerable:!0,value:a},scale:{configurable:!0,enumerable:!0,value:r},modelViewMatrix:{value:new ii},normalMatrix:{value:new Et}}),this.matrix=new ii,this.matrixWorld=new ii,this.matrixAutoUpdate=ya.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=ya.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Kb,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,n){this.quaternion.setFromAxisAngle(e,n)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,n){return Nl.setFromAxisAngle(e,n),this.quaternion.multiply(Nl),this}rotateOnWorldAxis(e,n){return Nl.setFromAxisAngle(e,n),this.quaternion.premultiply(Nl),this}rotateX(e){return this.rotateOnAxis(EM,e)}rotateY(e){return this.rotateOnAxis(TM,e)}rotateZ(e){return this.rotateOnAxis(AM,e)}translateOnAxis(e,n){return bM.copy(e).applyQuaternion(this.quaternion),this.position.add(bM.multiplyScalar(n)),this}translateX(e){return this.translateOnAxis(EM,e)}translateY(e){return this.translateOnAxis(TM,e)}translateZ(e){return this.translateOnAxis(AM,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Gr.copy(this.matrixWorld).invert())}lookAt(e,n,a){e.isVector3?Mh.copy(e):Mh.set(e,n,a);const r=this.parent;this.updateWorldMatrix(!0,!1),lu.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Gr.lookAt(lu,Mh,this.up):Gr.lookAt(Mh,lu,this.up),this.quaternion.setFromRotationMatrix(Gr),r&&(Gr.extractRotation(r.matrixWorld),Nl.setFromRotationMatrix(Gr),this.quaternion.premultiply(Nl.invert()))}add(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.add(arguments[n]);return this}return e===this?(jt("Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(RM),Ll.child=e,this.dispatchEvent(Ll),Ll.child=null):jt("Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let a=0;a<arguments.length;a++)this.remove(arguments[a]);return this}const n=this.children.indexOf(e);return n!==-1&&(e.parent=null,this.children.splice(n,1),e.dispatchEvent(l2),c_.child=e,this.dispatchEvent(c_),c_.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Gr.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Gr.multiply(e.parent.matrixWorld)),e.applyMatrix4(Gr),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(RM),Ll.child=e,this.dispatchEvent(Ll),Ll.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,n){if(this[e]===n)return this;for(let a=0,r=this.children.length;a<r;a++){const u=this.children[a].getObjectByProperty(e,n);if(u!==void 0)return u}}getObjectsByProperty(e,n,a=[]){this[e]===n&&a.push(this);const r=this.children;for(let l=0,u=r.length;l<u;l++)r[l].getObjectsByProperty(e,n,a);return a}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(lu,e,s2),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(lu,o2,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const n=this.matrixWorld.elements;return e.set(n[8],n[9],n[10]).normalize()}raycast(){}traverse(e){e(this);const n=this.children;for(let a=0,r=n.length;a<r;a++)n[a].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const n=this.children;for(let a=0,r=n.length;a<r;a++)n[a].traverseVisible(e)}traverseAncestors(e){const n=this.parent;n!==null&&(e(n),n.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale);const e=this.pivot;if(e!==null){const n=e.x,a=e.y,r=e.z,l=this.matrix.elements;l[12]+=n-l[0]*n-l[4]*a-l[8]*r,l[13]+=a-l[1]*n-l[5]*a-l[9]*r,l[14]+=r-l[2]*n-l[6]*a-l[10]*r}this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const n=this.children;for(let a=0,r=n.length;a<r;a++)n[a].updateMatrixWorld(e)}updateWorldMatrix(e,n){const a=this.parent;if(e===!0&&a!==null&&a.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),n===!0){const r=this.children;for(let l=0,u=r.length;l<u;l++)r[l].updateWorldMatrix(!1,!0)}}toJSON(e){const n=e===void 0||typeof e=="string",a={};n&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},a.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});const r={};r.uuid=this.uuid,r.type=this.type,this.name!==""&&(r.name=this.name),this.castShadow===!0&&(r.castShadow=!0),this.receiveShadow===!0&&(r.receiveShadow=!0),this.visible===!1&&(r.visible=!1),this.frustumCulled===!1&&(r.frustumCulled=!1),this.renderOrder!==0&&(r.renderOrder=this.renderOrder),this.static!==!1&&(r.static=this.static),Object.keys(this.userData).length>0&&(r.userData=this.userData),r.layers=this.layers.mask,r.matrix=this.matrix.toArray(),r.up=this.up.toArray(),this.pivot!==null&&(r.pivot=this.pivot.toArray()),this.matrixAutoUpdate===!1&&(r.matrixAutoUpdate=!1),this.morphTargetDictionary!==void 0&&(r.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),this.morphTargetInfluences!==void 0&&(r.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(r.type="InstancedMesh",r.count=this.count,r.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(r.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(r.type="BatchedMesh",r.perObjectFrustumCulled=this.perObjectFrustumCulled,r.sortObjects=this.sortObjects,r.drawRanges=this._drawRanges,r.reservedRanges=this._reservedRanges,r.geometryInfo=this._geometryInfo.map(f=>({...f,boundingBox:f.boundingBox?f.boundingBox.toJSON():void 0,boundingSphere:f.boundingSphere?f.boundingSphere.toJSON():void 0})),r.instanceInfo=this._instanceInfo.map(f=>({...f})),r.availableInstanceIds=this._availableInstanceIds.slice(),r.availableGeometryIds=this._availableGeometryIds.slice(),r.nextIndexStart=this._nextIndexStart,r.nextVertexStart=this._nextVertexStart,r.geometryCount=this._geometryCount,r.maxInstanceCount=this._maxInstanceCount,r.maxVertexCount=this._maxVertexCount,r.maxIndexCount=this._maxIndexCount,r.geometryInitialized=this._geometryInitialized,r.matricesTexture=this._matricesTexture.toJSON(e),r.indirectTexture=this._indirectTexture.toJSON(e),this._colorsTexture!==null&&(r.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(r.boundingSphere=this.boundingSphere.toJSON()),this.boundingBox!==null&&(r.boundingBox=this.boundingBox.toJSON()));function l(f,d){return f[d.uuid]===void 0&&(f[d.uuid]=d.toJSON(e)),d.uuid}if(this.isScene)this.background&&(this.background.isColor?r.background=this.background.toJSON():this.background.isTexture&&(r.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(r.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){r.geometry=l(e.geometries,this.geometry);const f=this.geometry.parameters;if(f!==void 0&&f.shapes!==void 0){const d=f.shapes;if(Array.isArray(d))for(let p=0,_=d.length;p<_;p++){const v=d[p];l(e.shapes,v)}else l(e.shapes,d)}}if(this.isSkinnedMesh&&(r.bindMode=this.bindMode,r.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(l(e.skeletons,this.skeleton),r.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const f=[];for(let d=0,p=this.material.length;d<p;d++)f.push(l(e.materials,this.material[d]));r.material=f}else r.material=l(e.materials,this.material);if(this.children.length>0){r.children=[];for(let f=0;f<this.children.length;f++)r.children.push(this.children[f].toJSON(e).object)}if(this.animations.length>0){r.animations=[];for(let f=0;f<this.animations.length;f++){const d=this.animations[f];r.animations.push(l(e.animations,d))}}if(n){const f=u(e.geometries),d=u(e.materials),p=u(e.textures),_=u(e.images),v=u(e.shapes),g=u(e.skeletons),x=u(e.animations),M=u(e.nodes);f.length>0&&(a.geometries=f),d.length>0&&(a.materials=d),p.length>0&&(a.textures=p),_.length>0&&(a.images=_),v.length>0&&(a.shapes=v),g.length>0&&(a.skeletons=g),x.length>0&&(a.animations=x),M.length>0&&(a.nodes=M)}return a.object=r,a;function u(f){const d=[];for(const p in f){const _=f[p];delete _.metadata,d.push(_)}return d}}clone(e){return new this.constructor().copy(this,e)}copy(e,n=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.pivot=e.pivot!==null?e.pivot.clone():null,this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.static=e.static,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),n===!0)for(let a=0;a<e.children.length;a++){const r=e.children[a];this.add(r.clone())}return this}}ya.DEFAULT_UP=new ue(0,1,0);ya.DEFAULT_MATRIX_AUTO_UPDATE=!0;ya.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;class bh extends ya{constructor(){super(),this.isGroup=!0,this.type="Group"}}const c2={type:"move"};class u_{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new bh,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new bh,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new ue,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new ue),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new bh,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new ue,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new ue,this._grip.eventsEnabled=!1),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const n=this._hand;if(n)for(const a of e.hand.values())this._getHandJoint(n,a)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,n,a){let r=null,l=null,u=null;const f=this._targetRay,d=this._grip,p=this._hand;if(e&&n.session.visibilityState!=="visible-blurred"){if(p&&e.hand){u=!0;for(const E of e.hand.values()){const S=n.getJointPose(E,a),y=this._getHandJoint(p,E);S!==null&&(y.matrix.fromArray(S.transform.matrix),y.matrix.decompose(y.position,y.rotation,y.scale),y.matrixWorldNeedsUpdate=!0,y.jointRadius=S.radius),y.visible=S!==null}const _=p.joints["index-finger-tip"],v=p.joints["thumb-tip"],g=_.position.distanceTo(v.position),x=.02,M=.005;p.inputState.pinching&&g>x+M?(p.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!p.inputState.pinching&&g<=x-M&&(p.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else d!==null&&e.gripSpace&&(l=n.getPose(e.gripSpace,a),l!==null&&(d.matrix.fromArray(l.transform.matrix),d.matrix.decompose(d.position,d.rotation,d.scale),d.matrixWorldNeedsUpdate=!0,l.linearVelocity?(d.hasLinearVelocity=!0,d.linearVelocity.copy(l.linearVelocity)):d.hasLinearVelocity=!1,l.angularVelocity?(d.hasAngularVelocity=!0,d.angularVelocity.copy(l.angularVelocity)):d.hasAngularVelocity=!1,d.eventsEnabled&&d.dispatchEvent({type:"gripUpdated",data:e,target:this})));f!==null&&(r=n.getPose(e.targetRaySpace,a),r===null&&l!==null&&(r=l),r!==null&&(f.matrix.fromArray(r.transform.matrix),f.matrix.decompose(f.position,f.rotation,f.scale),f.matrixWorldNeedsUpdate=!0,r.linearVelocity?(f.hasLinearVelocity=!0,f.linearVelocity.copy(r.linearVelocity)):f.hasLinearVelocity=!1,r.angularVelocity?(f.hasAngularVelocity=!0,f.angularVelocity.copy(r.angularVelocity)):f.hasAngularVelocity=!1,this.dispatchEvent(c2)))}return f!==null&&(f.visible=r!==null),d!==null&&(d.visible=l!==null),p!==null&&(p.visible=u!==null),this}_getHandJoint(e,n){if(e.joints[n.jointName]===void 0){const a=new bh;a.matrixAutoUpdate=!1,a.visible=!1,e.joints[n.jointName]=a,e.add(a)}return e.joints[n.jointName]}}const Qb={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Us={h:0,s:0,l:0},Eh={h:0,s:0,l:0};function f_(o,e,n){return n<0&&(n+=1),n>1&&(n-=1),n<1/6?o+(e-o)*6*n:n<1/2?e:n<2/3?o+(e-o)*6*(2/3-n):o}class pn{constructor(e,n,a){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,n,a)}set(e,n,a){if(n===void 0&&a===void 0){const r=e;r&&r.isColor?this.copy(r):typeof r=="number"?this.setHex(r):typeof r=="string"&&this.setStyle(r)}else this.setRGB(e,n,a);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,n=Pa){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,Xt.colorSpaceToWorking(this,n),this}setRGB(e,n,a,r=Xt.workingColorSpace){return this.r=e,this.g=n,this.b=a,Xt.colorSpaceToWorking(this,r),this}setHSL(e,n,a,r=Xt.workingColorSpace){if(e=KC(e,1),n=Wt(n,0,1),a=Wt(a,0,1),n===0)this.r=this.g=this.b=a;else{const l=a<=.5?a*(1+n):a+n-a*n,u=2*a-l;this.r=f_(u,l,e+1/3),this.g=f_(u,l,e),this.b=f_(u,l,e-1/3)}return Xt.colorSpaceToWorking(this,r),this}setStyle(e,n=Pa){function a(l){l!==void 0&&parseFloat(l)<1&&_t("Color: Alpha component of "+e+" will be ignored.")}let r;if(r=/^(\w+)\(([^\)]*)\)/.exec(e)){let l;const u=r[1],f=r[2];switch(u){case"rgb":case"rgba":if(l=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(f))return a(l[4]),this.setRGB(Math.min(255,parseInt(l[1],10))/255,Math.min(255,parseInt(l[2],10))/255,Math.min(255,parseInt(l[3],10))/255,n);if(l=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(f))return a(l[4]),this.setRGB(Math.min(100,parseInt(l[1],10))/100,Math.min(100,parseInt(l[2],10))/100,Math.min(100,parseInt(l[3],10))/100,n);break;case"hsl":case"hsla":if(l=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(f))return a(l[4]),this.setHSL(parseFloat(l[1])/360,parseFloat(l[2])/100,parseFloat(l[3])/100,n);break;default:_t("Color: Unknown color model "+e)}}else if(r=/^\#([A-Fa-f\d]+)$/.exec(e)){const l=r[1],u=l.length;if(u===3)return this.setRGB(parseInt(l.charAt(0),16)/15,parseInt(l.charAt(1),16)/15,parseInt(l.charAt(2),16)/15,n);if(u===6)return this.setHex(parseInt(l,16),n);_t("Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,n);return this}setColorName(e,n=Pa){const a=Qb[e.toLowerCase()];return a!==void 0?this.setHex(a,n):_t("Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=es(e.r),this.g=es(e.g),this.b=es(e.b),this}copyLinearToSRGB(e){return this.r=nc(e.r),this.g=nc(e.g),this.b=nc(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=Pa){return Xt.workingToColorSpace(bi.copy(this),e),Math.round(Wt(bi.r*255,0,255))*65536+Math.round(Wt(bi.g*255,0,255))*256+Math.round(Wt(bi.b*255,0,255))}getHexString(e=Pa){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,n=Xt.workingColorSpace){Xt.workingToColorSpace(bi.copy(this),n);const a=bi.r,r=bi.g,l=bi.b,u=Math.max(a,r,l),f=Math.min(a,r,l);let d,p;const _=(f+u)/2;if(f===u)d=0,p=0;else{const v=u-f;switch(p=_<=.5?v/(u+f):v/(2-u-f),u){case a:d=(r-l)/v+(r<l?6:0);break;case r:d=(l-a)/v+2;break;case l:d=(a-r)/v+4;break}d/=6}return e.h=d,e.s=p,e.l=_,e}getRGB(e,n=Xt.workingColorSpace){return Xt.workingToColorSpace(bi.copy(this),n),e.r=bi.r,e.g=bi.g,e.b=bi.b,e}getStyle(e=Pa){Xt.workingToColorSpace(bi.copy(this),e);const n=bi.r,a=bi.g,r=bi.b;return e!==Pa?`color(${e} ${n.toFixed(3)} ${a.toFixed(3)} ${r.toFixed(3)})`:`rgb(${Math.round(n*255)},${Math.round(a*255)},${Math.round(r*255)})`}offsetHSL(e,n,a){return this.getHSL(Us),this.setHSL(Us.h+e,Us.s+n,Us.l+a)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,n){return this.r=e.r+n.r,this.g=e.g+n.g,this.b=e.b+n.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,n){return this.r+=(e.r-this.r)*n,this.g+=(e.g-this.g)*n,this.b+=(e.b-this.b)*n,this}lerpColors(e,n,a){return this.r=e.r+(n.r-e.r)*a,this.g=e.g+(n.g-e.g)*a,this.b=e.b+(n.b-e.b)*a,this}lerpHSL(e,n){this.getHSL(Us),e.getHSL(Eh);const a=a_(Us.h,Eh.h,n),r=a_(Us.s,Eh.s,n),l=a_(Us.l,Eh.l,n);return this.setHSL(a,r,l),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const n=this.r,a=this.g,r=this.b,l=e.elements;return this.r=l[0]*n+l[3]*a+l[6]*r,this.g=l[1]*n+l[4]*a+l[7]*r,this.b=l[2]*n+l[5]*a+l[8]*r,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,n=0){return this.r=e[n],this.g=e[n+1],this.b=e[n+2],this}toArray(e=[],n=0){return e[n]=this.r,e[n+1]=this.g,e[n+2]=this.b,e}fromBufferAttribute(e,n){return this.r=e.getX(n),this.g=e.getY(n),this.b=e.getZ(n),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const bi=new pn;pn.NAMES=Qb;class CM extends ya{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Wo,this.environmentIntensity=1,this.environmentRotation=new Wo,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,n){return super.copy(e,n),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const n=super.toJSON(e);return this.fog!==null&&(n.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(n.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(n.object.backgroundIntensity=this.backgroundIntensity),n.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(n.object.environmentIntensity=this.environmentIntensity),n.object.environmentRotation=this.environmentRotation.toArray(),n}}const Za=new ue,Vr=new ue,h_=new ue,kr=new ue,Ol=new ue,Pl=new ue,wM=new ue,d_=new ue,p_=new ue,m_=new ue,__=new Vn,g_=new Vn,v_=new Vn;class $a{constructor(e=new ue,n=new ue,a=new ue){this.a=e,this.b=n,this.c=a}static getNormal(e,n,a,r){r.subVectors(a,n),Za.subVectors(e,n),r.cross(Za);const l=r.lengthSq();return l>0?r.multiplyScalar(1/Math.sqrt(l)):r.set(0,0,0)}static getBarycoord(e,n,a,r,l){Za.subVectors(r,n),Vr.subVectors(a,n),h_.subVectors(e,n);const u=Za.dot(Za),f=Za.dot(Vr),d=Za.dot(h_),p=Vr.dot(Vr),_=Vr.dot(h_),v=u*p-f*f;if(v===0)return l.set(0,0,0),null;const g=1/v,x=(p*d-f*_)*g,M=(u*_-f*d)*g;return l.set(1-x-M,M,x)}static containsPoint(e,n,a,r){return this.getBarycoord(e,n,a,r,kr)===null?!1:kr.x>=0&&kr.y>=0&&kr.x+kr.y<=1}static getInterpolation(e,n,a,r,l,u,f,d){return this.getBarycoord(e,n,a,r,kr)===null?(d.x=0,d.y=0,"z"in d&&(d.z=0),"w"in d&&(d.w=0),null):(d.setScalar(0),d.addScaledVector(l,kr.x),d.addScaledVector(u,kr.y),d.addScaledVector(f,kr.z),d)}static getInterpolatedAttribute(e,n,a,r,l,u){return __.setScalar(0),g_.setScalar(0),v_.setScalar(0),__.fromBufferAttribute(e,n),g_.fromBufferAttribute(e,a),v_.fromBufferAttribute(e,r),u.setScalar(0),u.addScaledVector(__,l.x),u.addScaledVector(g_,l.y),u.addScaledVector(v_,l.z),u}static isFrontFacing(e,n,a,r){return Za.subVectors(a,n),Vr.subVectors(e,n),Za.cross(Vr).dot(r)<0}set(e,n,a){return this.a.copy(e),this.b.copy(n),this.c.copy(a),this}setFromPointsAndIndices(e,n,a,r){return this.a.copy(e[n]),this.b.copy(e[a]),this.c.copy(e[r]),this}setFromAttributeAndIndices(e,n,a,r){return this.a.fromBufferAttribute(e,n),this.b.fromBufferAttribute(e,a),this.c.fromBufferAttribute(e,r),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Za.subVectors(this.c,this.b),Vr.subVectors(this.a,this.b),Za.cross(Vr).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return $a.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,n){return $a.getBarycoord(e,this.a,this.b,this.c,n)}getInterpolation(e,n,a,r,l){return $a.getInterpolation(e,this.a,this.b,this.c,n,a,r,l)}containsPoint(e){return $a.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return $a.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,n){const a=this.a,r=this.b,l=this.c;let u,f;Ol.subVectors(r,a),Pl.subVectors(l,a),d_.subVectors(e,a);const d=Ol.dot(d_),p=Pl.dot(d_);if(d<=0&&p<=0)return n.copy(a);p_.subVectors(e,r);const _=Ol.dot(p_),v=Pl.dot(p_);if(_>=0&&v<=_)return n.copy(r);const g=d*v-_*p;if(g<=0&&d>=0&&_<=0)return u=d/(d-_),n.copy(a).addScaledVector(Ol,u);m_.subVectors(e,l);const x=Ol.dot(m_),M=Pl.dot(m_);if(M>=0&&x<=M)return n.copy(l);const E=x*p-d*M;if(E<=0&&p>=0&&M<=0)return f=p/(p-M),n.copy(a).addScaledVector(Pl,f);const S=_*M-x*v;if(S<=0&&v-_>=0&&x-M>=0)return wM.subVectors(l,r),f=(v-_)/(v-_+(x-M)),n.copy(r).addScaledVector(wM,f);const y=1/(S+E+g);return u=E*y,f=g*y,n.copy(a).addScaledVector(Ol,u).addScaledVector(Pl,f)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}class Ku{constructor(e=new ue(1/0,1/0,1/0),n=new ue(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=n}set(e,n){return this.min.copy(e),this.max.copy(n),this}setFromArray(e){this.makeEmpty();for(let n=0,a=e.length;n<a;n+=3)this.expandByPoint(Ka.fromArray(e,n));return this}setFromBufferAttribute(e){this.makeEmpty();for(let n=0,a=e.count;n<a;n++)this.expandByPoint(Ka.fromBufferAttribute(e,n));return this}setFromPoints(e){this.makeEmpty();for(let n=0,a=e.length;n<a;n++)this.expandByPoint(e[n]);return this}setFromCenterAndSize(e,n){const a=Ka.copy(n).multiplyScalar(.5);return this.min.copy(e).sub(a),this.max.copy(e).add(a),this}setFromObject(e,n=!1){return this.makeEmpty(),this.expandByObject(e,n)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,n=!1){e.updateWorldMatrix(!1,!1);const a=e.geometry;if(a!==void 0){const l=a.getAttribute("position");if(n===!0&&l!==void 0&&e.isInstancedMesh!==!0)for(let u=0,f=l.count;u<f;u++)e.isMesh===!0?e.getVertexPosition(u,Ka):Ka.fromBufferAttribute(l,u),Ka.applyMatrix4(e.matrixWorld),this.expandByPoint(Ka);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Th.copy(e.boundingBox)):(a.boundingBox===null&&a.computeBoundingBox(),Th.copy(a.boundingBox)),Th.applyMatrix4(e.matrixWorld),this.union(Th)}const r=e.children;for(let l=0,u=r.length;l<u;l++)this.expandByObject(r[l],n);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,n){return n.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Ka),Ka.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let n,a;return e.normal.x>0?(n=e.normal.x*this.min.x,a=e.normal.x*this.max.x):(n=e.normal.x*this.max.x,a=e.normal.x*this.min.x),e.normal.y>0?(n+=e.normal.y*this.min.y,a+=e.normal.y*this.max.y):(n+=e.normal.y*this.max.y,a+=e.normal.y*this.min.y),e.normal.z>0?(n+=e.normal.z*this.min.z,a+=e.normal.z*this.max.z):(n+=e.normal.z*this.max.z,a+=e.normal.z*this.min.z),n<=-e.constant&&a>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(cu),Ah.subVectors(this.max,cu),Fl.subVectors(e.a,cu),zl.subVectors(e.b,cu),Il.subVectors(e.c,cu),Ns.subVectors(zl,Fl),Ls.subVectors(Il,zl),xo.subVectors(Fl,Il);let n=[0,-Ns.z,Ns.y,0,-Ls.z,Ls.y,0,-xo.z,xo.y,Ns.z,0,-Ns.x,Ls.z,0,-Ls.x,xo.z,0,-xo.x,-Ns.y,Ns.x,0,-Ls.y,Ls.x,0,-xo.y,xo.x,0];return!x_(n,Fl,zl,Il,Ah)||(n=[1,0,0,0,1,0,0,0,1],!x_(n,Fl,zl,Il,Ah))?!1:(Rh.crossVectors(Ns,Ls),n=[Rh.x,Rh.y,Rh.z],x_(n,Fl,zl,Il,Ah))}clampPoint(e,n){return n.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Ka).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Ka).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Xr[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Xr[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Xr[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Xr[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Xr[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Xr[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Xr[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Xr[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Xr),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}toJSON(){return{min:this.min.toArray(),max:this.max.toArray()}}fromJSON(e){return this.min.fromArray(e.min),this.max.fromArray(e.max),this}}const Xr=[new ue,new ue,new ue,new ue,new ue,new ue,new ue,new ue],Ka=new ue,Th=new Ku,Fl=new ue,zl=new ue,Il=new ue,Ns=new ue,Ls=new ue,xo=new ue,cu=new ue,Ah=new ue,Rh=new ue,So=new ue;function x_(o,e,n,a,r){for(let l=0,u=o.length-3;l<=u;l+=3){So.fromArray(o,l);const f=r.x*Math.abs(So.x)+r.y*Math.abs(So.y)+r.z*Math.abs(So.z),d=e.dot(So),p=n.dot(So),_=a.dot(So);if(Math.max(-Math.max(d,p,_),Math.min(d,p,_))>f)return!1}return!0}const Kn=new ue,Ch=new Jt;let u2=0;class tr extends Yo{constructor(e,n,a=!1){if(super(),Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:u2++}),this.name="",this.array=e,this.itemSize=n,this.count=e!==void 0?e.length/n:0,this.normalized=a,this.usage=pM,this.updateRanges=[],this.gpuType=_r,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,n){this.updateRanges.push({start:e,count:n})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,n,a){e*=this.itemSize,a*=n.itemSize;for(let r=0,l=this.itemSize;r<l;r++)this.array[e+r]=n.array[a+r];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let n=0,a=this.count;n<a;n++)Ch.fromBufferAttribute(this,n),Ch.applyMatrix3(e),this.setXY(n,Ch.x,Ch.y);else if(this.itemSize===3)for(let n=0,a=this.count;n<a;n++)Kn.fromBufferAttribute(this,n),Kn.applyMatrix3(e),this.setXYZ(n,Kn.x,Kn.y,Kn.z);return this}applyMatrix4(e){for(let n=0,a=this.count;n<a;n++)Kn.fromBufferAttribute(this,n),Kn.applyMatrix4(e),this.setXYZ(n,Kn.x,Kn.y,Kn.z);return this}applyNormalMatrix(e){for(let n=0,a=this.count;n<a;n++)Kn.fromBufferAttribute(this,n),Kn.applyNormalMatrix(e),this.setXYZ(n,Kn.x,Kn.y,Kn.z);return this}transformDirection(e){for(let n=0,a=this.count;n<a;n++)Kn.fromBufferAttribute(this,n),Kn.transformDirection(e),this.setXYZ(n,Kn.x,Kn.y,Kn.z);return this}set(e,n=0){return this.array.set(e,n),this}getComponent(e,n){let a=this.array[e*this.itemSize+n];return this.normalized&&(a=ou(a,this.array)),a}setComponent(e,n,a){return this.normalized&&(a=qi(a,this.array)),this.array[e*this.itemSize+n]=a,this}getX(e){let n=this.array[e*this.itemSize];return this.normalized&&(n=ou(n,this.array)),n}setX(e,n){return this.normalized&&(n=qi(n,this.array)),this.array[e*this.itemSize]=n,this}getY(e){let n=this.array[e*this.itemSize+1];return this.normalized&&(n=ou(n,this.array)),n}setY(e,n){return this.normalized&&(n=qi(n,this.array)),this.array[e*this.itemSize+1]=n,this}getZ(e){let n=this.array[e*this.itemSize+2];return this.normalized&&(n=ou(n,this.array)),n}setZ(e,n){return this.normalized&&(n=qi(n,this.array)),this.array[e*this.itemSize+2]=n,this}getW(e){let n=this.array[e*this.itemSize+3];return this.normalized&&(n=ou(n,this.array)),n}setW(e,n){return this.normalized&&(n=qi(n,this.array)),this.array[e*this.itemSize+3]=n,this}setXY(e,n,a){return e*=this.itemSize,this.normalized&&(n=qi(n,this.array),a=qi(a,this.array)),this.array[e+0]=n,this.array[e+1]=a,this}setXYZ(e,n,a,r){return e*=this.itemSize,this.normalized&&(n=qi(n,this.array),a=qi(a,this.array),r=qi(r,this.array)),this.array[e+0]=n,this.array[e+1]=a,this.array[e+2]=r,this}setXYZW(e,n,a,r,l){return e*=this.itemSize,this.normalized&&(n=qi(n,this.array),a=qi(a,this.array),r=qi(r,this.array),l=qi(l,this.array)),this.array[e+0]=n,this.array[e+1]=a,this.array[e+2]=r,this.array[e+3]=l,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==pM&&(e.usage=this.usage),e}dispose(){this.dispatchEvent({type:"dispose"})}}class Jb extends tr{constructor(e,n,a){super(new Uint16Array(e),n,a)}}class $b extends tr{constructor(e,n,a){super(new Uint32Array(e),n,a)}}class ts extends tr{constructor(e,n,a){super(new Float32Array(e),n,a)}}const f2=new Ku,uu=new ue,S_=new ue;class Ng{constructor(e=new ue,n=-1){this.isSphere=!0,this.center=e,this.radius=n}set(e,n){return this.center.copy(e),this.radius=n,this}setFromPoints(e,n){const a=this.center;n!==void 0?a.copy(n):f2.setFromPoints(e).getCenter(a);let r=0;for(let l=0,u=e.length;l<u;l++)r=Math.max(r,a.distanceToSquared(e[l]));return this.radius=Math.sqrt(r),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const n=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=n*n}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,n){const a=this.center.distanceToSquared(e);return n.copy(e),a>this.radius*this.radius&&(n.sub(this.center).normalize(),n.multiplyScalar(this.radius).add(this.center)),n}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;uu.subVectors(e,this.center);const n=uu.lengthSq();if(n>this.radius*this.radius){const a=Math.sqrt(n),r=(a-this.radius)*.5;this.center.addScaledVector(uu,r/a),this.radius+=r}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(S_.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(uu.copy(e.center).add(S_)),this.expandByPoint(uu.copy(e.center).sub(S_))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}toJSON(){return{radius:this.radius,center:this.center.toArray()}}fromJSON(e){return this.radius=e.radius,this.center.fromArray(e.center),this}}let h2=0;const La=new ii,y_=new ya,Bl=new ue,fa=new Ku,fu=new Ku,oi=new ue;class br extends Yo{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:h2++}),this.uuid=Zu(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(qC(e)?$b:Jb)(e,1):this.index=e,this}setIndirect(e,n=0){return this.indirect=e,this.indirectOffset=n,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,n){return this.attributes[e]=n,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,n,a=0){this.groups.push({start:e,count:n,materialIndex:a})}clearGroups(){this.groups=[]}setDrawRange(e,n){this.drawRange.start=e,this.drawRange.count=n}applyMatrix4(e){const n=this.attributes.position;n!==void 0&&(n.applyMatrix4(e),n.needsUpdate=!0);const a=this.attributes.normal;if(a!==void 0){const l=new Et().getNormalMatrix(e);a.applyNormalMatrix(l),a.needsUpdate=!0}const r=this.attributes.tangent;return r!==void 0&&(r.transformDirection(e),r.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return La.makeRotationFromQuaternion(e),this.applyMatrix4(La),this}rotateX(e){return La.makeRotationX(e),this.applyMatrix4(La),this}rotateY(e){return La.makeRotationY(e),this.applyMatrix4(La),this}rotateZ(e){return La.makeRotationZ(e),this.applyMatrix4(La),this}translate(e,n,a){return La.makeTranslation(e,n,a),this.applyMatrix4(La),this}scale(e,n,a){return La.makeScale(e,n,a),this.applyMatrix4(La),this}lookAt(e){return y_.lookAt(e),y_.updateMatrix(),this.applyMatrix4(y_.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Bl).negate(),this.translate(Bl.x,Bl.y,Bl.z),this}setFromPoints(e){const n=this.getAttribute("position");if(n===void 0){const a=[];for(let r=0,l=e.length;r<l;r++){const u=e[r];a.push(u.x,u.y,u.z||0)}this.setAttribute("position",new ts(a,3))}else{const a=Math.min(e.length,n.count);for(let r=0;r<a;r++){const l=e[r];n.setXYZ(r,l.x,l.y,l.z||0)}e.length>n.count&&_t("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),n.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Ku);const e=this.attributes.position,n=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){jt("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new ue(-1/0,-1/0,-1/0),new ue(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),n)for(let a=0,r=n.length;a<r;a++){const l=n[a];fa.setFromBufferAttribute(l),this.morphTargetsRelative?(oi.addVectors(this.boundingBox.min,fa.min),this.boundingBox.expandByPoint(oi),oi.addVectors(this.boundingBox.max,fa.max),this.boundingBox.expandByPoint(oi)):(this.boundingBox.expandByPoint(fa.min),this.boundingBox.expandByPoint(fa.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&jt('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new Ng);const e=this.attributes.position,n=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){jt("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new ue,1/0);return}if(e){const a=this.boundingSphere.center;if(fa.setFromBufferAttribute(e),n)for(let l=0,u=n.length;l<u;l++){const f=n[l];fu.setFromBufferAttribute(f),this.morphTargetsRelative?(oi.addVectors(fa.min,fu.min),fa.expandByPoint(oi),oi.addVectors(fa.max,fu.max),fa.expandByPoint(oi)):(fa.expandByPoint(fu.min),fa.expandByPoint(fu.max))}fa.getCenter(a);let r=0;for(let l=0,u=e.count;l<u;l++)oi.fromBufferAttribute(e,l),r=Math.max(r,a.distanceToSquared(oi));if(n)for(let l=0,u=n.length;l<u;l++){const f=n[l],d=this.morphTargetsRelative;for(let p=0,_=f.count;p<_;p++)oi.fromBufferAttribute(f,p),d&&(Bl.fromBufferAttribute(e,p),oi.add(Bl)),r=Math.max(r,a.distanceToSquared(oi))}this.boundingSphere.radius=Math.sqrt(r),isNaN(this.boundingSphere.radius)&&jt('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,n=this.attributes;if(e===null||n.position===void 0||n.normal===void 0||n.uv===void 0){jt("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const a=n.position,r=n.normal,l=n.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new tr(new Float32Array(4*a.count),4));const u=this.getAttribute("tangent"),f=[],d=[];for(let T=0;T<a.count;T++)f[T]=new ue,d[T]=new ue;const p=new ue,_=new ue,v=new ue,g=new Jt,x=new Jt,M=new Jt,E=new ue,S=new ue;function y(T,L,H){p.fromBufferAttribute(a,T),_.fromBufferAttribute(a,L),v.fromBufferAttribute(a,H),g.fromBufferAttribute(l,T),x.fromBufferAttribute(l,L),M.fromBufferAttribute(l,H),_.sub(p),v.sub(p),x.sub(g),M.sub(g);const V=1/(x.x*M.y-M.x*x.y);isFinite(V)&&(E.copy(_).multiplyScalar(M.y).addScaledVector(v,-x.y).multiplyScalar(V),S.copy(v).multiplyScalar(x.x).addScaledVector(_,-M.x).multiplyScalar(V),f[T].add(E),f[L].add(E),f[H].add(E),d[T].add(S),d[L].add(S),d[H].add(S))}let R=this.groups;R.length===0&&(R=[{start:0,count:e.count}]);for(let T=0,L=R.length;T<L;++T){const H=R[T],V=H.start,k=H.count;for(let te=V,ie=V+k;te<ie;te+=3)y(e.getX(te+0),e.getX(te+1),e.getX(te+2))}const U=new ue,C=new ue,F=new ue,O=new ue;function D(T){F.fromBufferAttribute(r,T),O.copy(F);const L=f[T];U.copy(L),U.sub(F.multiplyScalar(F.dot(L))).normalize(),C.crossVectors(O,L);const V=C.dot(d[T])<0?-1:1;u.setXYZW(T,U.x,U.y,U.z,V)}for(let T=0,L=R.length;T<L;++T){const H=R[T],V=H.start,k=H.count;for(let te=V,ie=V+k;te<ie;te+=3)D(e.getX(te+0)),D(e.getX(te+1)),D(e.getX(te+2))}}computeVertexNormals(){const e=this.index,n=this.getAttribute("position");if(n!==void 0){let a=this.getAttribute("normal");if(a===void 0)a=new tr(new Float32Array(n.count*3),3),this.setAttribute("normal",a);else for(let g=0,x=a.count;g<x;g++)a.setXYZ(g,0,0,0);const r=new ue,l=new ue,u=new ue,f=new ue,d=new ue,p=new ue,_=new ue,v=new ue;if(e)for(let g=0,x=e.count;g<x;g+=3){const M=e.getX(g+0),E=e.getX(g+1),S=e.getX(g+2);r.fromBufferAttribute(n,M),l.fromBufferAttribute(n,E),u.fromBufferAttribute(n,S),_.subVectors(u,l),v.subVectors(r,l),_.cross(v),f.fromBufferAttribute(a,M),d.fromBufferAttribute(a,E),p.fromBufferAttribute(a,S),f.add(_),d.add(_),p.add(_),a.setXYZ(M,f.x,f.y,f.z),a.setXYZ(E,d.x,d.y,d.z),a.setXYZ(S,p.x,p.y,p.z)}else for(let g=0,x=n.count;g<x;g+=3)r.fromBufferAttribute(n,g+0),l.fromBufferAttribute(n,g+1),u.fromBufferAttribute(n,g+2),_.subVectors(u,l),v.subVectors(r,l),_.cross(v),a.setXYZ(g+0,_.x,_.y,_.z),a.setXYZ(g+1,_.x,_.y,_.z),a.setXYZ(g+2,_.x,_.y,_.z);this.normalizeNormals(),a.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let n=0,a=e.count;n<a;n++)oi.fromBufferAttribute(e,n),oi.normalize(),e.setXYZ(n,oi.x,oi.y,oi.z)}toNonIndexed(){function e(f,d){const p=f.array,_=f.itemSize,v=f.normalized,g=new p.constructor(d.length*_);let x=0,M=0;for(let E=0,S=d.length;E<S;E++){f.isInterleavedBufferAttribute?x=d[E]*f.data.stride+f.offset:x=d[E]*_;for(let y=0;y<_;y++)g[M++]=p[x++]}return new tr(g,_,v)}if(this.index===null)return _t("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const n=new br,a=this.index.array,r=this.attributes;for(const f in r){const d=r[f],p=e(d,a);n.setAttribute(f,p)}const l=this.morphAttributes;for(const f in l){const d=[],p=l[f];for(let _=0,v=p.length;_<v;_++){const g=p[_],x=e(g,a);d.push(x)}n.morphAttributes[f]=d}n.morphTargetsRelative=this.morphTargetsRelative;const u=this.groups;for(let f=0,d=u.length;f<d;f++){const p=u[f];n.addGroup(p.start,p.count,p.materialIndex)}return n}toJSON(){const e={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const d=this.parameters;for(const p in d)d[p]!==void 0&&(e[p]=d[p]);return e}e.data={attributes:{}};const n=this.index;n!==null&&(e.data.index={type:n.array.constructor.name,array:Array.prototype.slice.call(n.array)});const a=this.attributes;for(const d in a){const p=a[d];e.data.attributes[d]=p.toJSON(e.data)}const r={};let l=!1;for(const d in this.morphAttributes){const p=this.morphAttributes[d],_=[];for(let v=0,g=p.length;v<g;v++){const x=p[v];_.push(x.toJSON(e.data))}_.length>0&&(r[d]=_,l=!0)}l&&(e.data.morphAttributes=r,e.data.morphTargetsRelative=this.morphTargetsRelative);const u=this.groups;u.length>0&&(e.data.groups=JSON.parse(JSON.stringify(u)));const f=this.boundingSphere;return f!==null&&(e.data.boundingSphere=f.toJSON()),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const n={};this.name=e.name;const a=e.index;a!==null&&this.setIndex(a.clone());const r=e.attributes;for(const p in r){const _=r[p];this.setAttribute(p,_.clone(n))}const l=e.morphAttributes;for(const p in l){const _=[],v=l[p];for(let g=0,x=v.length;g<x;g++)_.push(v[g].clone(n));this.morphAttributes[p]=_}this.morphTargetsRelative=e.morphTargetsRelative;const u=e.groups;for(let p=0,_=u.length;p<_;p++){const v=u[p];this.addGroup(v.start,v.count,v.materialIndex)}const f=e.boundingBox;f!==null&&(this.boundingBox=f.clone());const d=e.boundingSphere;return d!==null&&(this.boundingSphere=d.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}let d2=0;class Rd extends Yo{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:d2++}),this.uuid=Zu(),this.name="",this.type="Material",this.blending=tc,this.side=Qs,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=a0,this.blendDst=r0,this.blendEquation=Ro,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new pn(0,0,0),this.blendAlpha=0,this.depthFunc=cc,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=dM,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=wl,this.stencilZFail=wl,this.stencilZPass=wl,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const n in e){const a=e[n];if(a===void 0){_t(`Material: parameter '${n}' has value of undefined.`);continue}const r=this[n];if(r===void 0){_t(`Material: '${n}' is not a property of THREE.${this.type}.`);continue}r&&r.isColor?r.set(a):r&&r.isVector3&&a&&a.isVector3?r.copy(a):this[n]=a}}toJSON(e){const n=e===void 0||typeof e=="string";n&&(e={textures:{},images:{}});const a={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};a.uuid=this.uuid,a.type=this.type,this.name!==""&&(a.name=this.name),this.color&&this.color.isColor&&(a.color=this.color.getHex()),this.roughness!==void 0&&(a.roughness=this.roughness),this.metalness!==void 0&&(a.metalness=this.metalness),this.sheen!==void 0&&(a.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(a.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(a.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(a.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(a.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(a.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(a.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(a.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(a.shininess=this.shininess),this.clearcoat!==void 0&&(a.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(a.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(a.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(a.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(a.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,a.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(a.sheenColorMap=this.sheenColorMap.toJSON(e).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(a.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(e).uuid),this.dispersion!==void 0&&(a.dispersion=this.dispersion),this.iridescence!==void 0&&(a.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(a.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(a.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(a.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(a.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(a.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(a.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(a.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(a.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(a.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(a.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(a.lightMap=this.lightMap.toJSON(e).uuid,a.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(a.aoMap=this.aoMap.toJSON(e).uuid,a.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(a.bumpMap=this.bumpMap.toJSON(e).uuid,a.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(a.normalMap=this.normalMap.toJSON(e).uuid,a.normalMapType=this.normalMapType,a.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(a.displacementMap=this.displacementMap.toJSON(e).uuid,a.displacementScale=this.displacementScale,a.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(a.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(a.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(a.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(a.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(a.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(a.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(a.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(a.combine=this.combine)),this.envMapRotation!==void 0&&(a.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(a.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(a.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(a.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(a.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(a.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(a.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(a.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(a.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(a.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(a.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(a.size=this.size),this.shadowSide!==null&&(a.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(a.sizeAttenuation=this.sizeAttenuation),this.blending!==tc&&(a.blending=this.blending),this.side!==Qs&&(a.side=this.side),this.vertexColors===!0&&(a.vertexColors=!0),this.opacity<1&&(a.opacity=this.opacity),this.transparent===!0&&(a.transparent=!0),this.blendSrc!==a0&&(a.blendSrc=this.blendSrc),this.blendDst!==r0&&(a.blendDst=this.blendDst),this.blendEquation!==Ro&&(a.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(a.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(a.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(a.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(a.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(a.blendAlpha=this.blendAlpha),this.depthFunc!==cc&&(a.depthFunc=this.depthFunc),this.depthTest===!1&&(a.depthTest=this.depthTest),this.depthWrite===!1&&(a.depthWrite=this.depthWrite),this.colorWrite===!1&&(a.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(a.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==dM&&(a.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(a.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(a.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==wl&&(a.stencilFail=this.stencilFail),this.stencilZFail!==wl&&(a.stencilZFail=this.stencilZFail),this.stencilZPass!==wl&&(a.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(a.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(a.rotation=this.rotation),this.polygonOffset===!0&&(a.polygonOffset=!0),this.polygonOffsetFactor!==0&&(a.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(a.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(a.linewidth=this.linewidth),this.dashSize!==void 0&&(a.dashSize=this.dashSize),this.gapSize!==void 0&&(a.gapSize=this.gapSize),this.scale!==void 0&&(a.scale=this.scale),this.dithering===!0&&(a.dithering=!0),this.alphaTest>0&&(a.alphaTest=this.alphaTest),this.alphaHash===!0&&(a.alphaHash=!0),this.alphaToCoverage===!0&&(a.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(a.premultipliedAlpha=!0),this.forceSinglePass===!0&&(a.forceSinglePass=!0),this.allowOverride===!1&&(a.allowOverride=!1),this.wireframe===!0&&(a.wireframe=!0),this.wireframeLinewidth>1&&(a.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(a.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(a.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(a.flatShading=!0),this.visible===!1&&(a.visible=!1),this.toneMapped===!1&&(a.toneMapped=!1),this.fog===!1&&(a.fog=!1),Object.keys(this.userData).length>0&&(a.userData=this.userData);function r(l){const u=[];for(const f in l){const d=l[f];delete d.metadata,u.push(d)}return u}if(n){const l=r(e.textures),u=r(e.images);l.length>0&&(a.textures=l),u.length>0&&(a.images=u)}return a}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const n=e.clippingPlanes;let a=null;if(n!==null){const r=n.length;a=new Array(r);for(let l=0;l!==r;++l)a[l]=n[l].clone()}return this.clippingPlanes=a,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.allowOverride=e.allowOverride,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}}const Wr=new ue,M_=new ue,wh=new ue,Os=new ue,b_=new ue,Dh=new ue,E_=new ue;class p2{constructor(e=new ue,n=new ue(0,0,-1)){this.origin=e,this.direction=n}set(e,n){return this.origin.copy(e),this.direction.copy(n),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,n){return n.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Wr)),this}closestPointToPoint(e,n){n.subVectors(e,this.origin);const a=n.dot(this.direction);return a<0?n.copy(this.origin):n.copy(this.origin).addScaledVector(this.direction,a)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const n=Wr.subVectors(e,this.origin).dot(this.direction);return n<0?this.origin.distanceToSquared(e):(Wr.copy(this.origin).addScaledVector(this.direction,n),Wr.distanceToSquared(e))}distanceSqToSegment(e,n,a,r){M_.copy(e).add(n).multiplyScalar(.5),wh.copy(n).sub(e).normalize(),Os.copy(this.origin).sub(M_);const l=e.distanceTo(n)*.5,u=-this.direction.dot(wh),f=Os.dot(this.direction),d=-Os.dot(wh),p=Os.lengthSq(),_=Math.abs(1-u*u);let v,g,x,M;if(_>0)if(v=u*d-f,g=u*f-d,M=l*_,v>=0)if(g>=-M)if(g<=M){const E=1/_;v*=E,g*=E,x=v*(v+u*g+2*f)+g*(u*v+g+2*d)+p}else g=l,v=Math.max(0,-(u*g+f)),x=-v*v+g*(g+2*d)+p;else g=-l,v=Math.max(0,-(u*g+f)),x=-v*v+g*(g+2*d)+p;else g<=-M?(v=Math.max(0,-(-u*l+f)),g=v>0?-l:Math.min(Math.max(-l,-d),l),x=-v*v+g*(g+2*d)+p):g<=M?(v=0,g=Math.min(Math.max(-l,-d),l),x=g*(g+2*d)+p):(v=Math.max(0,-(u*l+f)),g=v>0?l:Math.min(Math.max(-l,-d),l),x=-v*v+g*(g+2*d)+p);else g=u>0?-l:l,v=Math.max(0,-(u*g+f)),x=-v*v+g*(g+2*d)+p;return a&&a.copy(this.origin).addScaledVector(this.direction,v),r&&r.copy(M_).addScaledVector(wh,g),x}intersectSphere(e,n){Wr.subVectors(e.center,this.origin);const a=Wr.dot(this.direction),r=Wr.dot(Wr)-a*a,l=e.radius*e.radius;if(r>l)return null;const u=Math.sqrt(l-r),f=a-u,d=a+u;return d<0?null:f<0?this.at(d,n):this.at(f,n)}intersectsSphere(e){return e.radius<0?!1:this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const n=e.normal.dot(this.direction);if(n===0)return e.distanceToPoint(this.origin)===0?0:null;const a=-(this.origin.dot(e.normal)+e.constant)/n;return a>=0?a:null}intersectPlane(e,n){const a=this.distanceToPlane(e);return a===null?null:this.at(a,n)}intersectsPlane(e){const n=e.distanceToPoint(this.origin);return n===0||e.normal.dot(this.direction)*n<0}intersectBox(e,n){let a,r,l,u,f,d;const p=1/this.direction.x,_=1/this.direction.y,v=1/this.direction.z,g=this.origin;return p>=0?(a=(e.min.x-g.x)*p,r=(e.max.x-g.x)*p):(a=(e.max.x-g.x)*p,r=(e.min.x-g.x)*p),_>=0?(l=(e.min.y-g.y)*_,u=(e.max.y-g.y)*_):(l=(e.max.y-g.y)*_,u=(e.min.y-g.y)*_),a>u||l>r||((l>a||isNaN(a))&&(a=l),(u<r||isNaN(r))&&(r=u),v>=0?(f=(e.min.z-g.z)*v,d=(e.max.z-g.z)*v):(f=(e.max.z-g.z)*v,d=(e.min.z-g.z)*v),a>d||f>r)||((f>a||a!==a)&&(a=f),(d<r||r!==r)&&(r=d),r<0)?null:this.at(a>=0?a:r,n)}intersectsBox(e){return this.intersectBox(e,Wr)!==null}intersectTriangle(e,n,a,r,l){b_.subVectors(n,e),Dh.subVectors(a,e),E_.crossVectors(b_,Dh);let u=this.direction.dot(E_),f;if(u>0){if(r)return null;f=1}else if(u<0)f=-1,u=-u;else return null;Os.subVectors(this.origin,e);const d=f*this.direction.dot(Dh.crossVectors(Os,Dh));if(d<0)return null;const p=f*this.direction.dot(b_.cross(Os));if(p<0||d+p>u)return null;const _=-f*Os.dot(E_);return _<0?null:this.at(_/u,l)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class eE extends Rd{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new pn(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Wo,this.combine=Nb,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const DM=new ii,yo=new p2,Uh=new Ng,UM=new ue,Nh=new ue,Lh=new ue,Oh=new ue,T_=new ue,Ph=new ue,NM=new ue,Fh=new ue;class nr extends ya{constructor(e=new br,n=new eE){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=n,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()}copy(e,n){return super.copy(e,n),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const n=this.geometry.morphAttributes,a=Object.keys(n);if(a.length>0){const r=n[a[0]];if(r!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let l=0,u=r.length;l<u;l++){const f=r[l].name||String(l);this.morphTargetInfluences.push(0),this.morphTargetDictionary[f]=l}}}}getVertexPosition(e,n){const a=this.geometry,r=a.attributes.position,l=a.morphAttributes.position,u=a.morphTargetsRelative;n.fromBufferAttribute(r,e);const f=this.morphTargetInfluences;if(l&&f){Ph.set(0,0,0);for(let d=0,p=l.length;d<p;d++){const _=f[d],v=l[d];_!==0&&(T_.fromBufferAttribute(v,e),u?Ph.addScaledVector(T_,_):Ph.addScaledVector(T_.sub(n),_))}n.add(Ph)}return n}raycast(e,n){const a=this.geometry,r=this.material,l=this.matrixWorld;r!==void 0&&(a.boundingSphere===null&&a.computeBoundingSphere(),Uh.copy(a.boundingSphere),Uh.applyMatrix4(l),yo.copy(e.ray).recast(e.near),!(Uh.containsPoint(yo.origin)===!1&&(yo.intersectSphere(Uh,UM)===null||yo.origin.distanceToSquared(UM)>(e.far-e.near)**2))&&(DM.copy(l).invert(),yo.copy(e.ray).applyMatrix4(DM),!(a.boundingBox!==null&&yo.intersectsBox(a.boundingBox)===!1)&&this._computeIntersections(e,n,yo)))}_computeIntersections(e,n,a){let r;const l=this.geometry,u=this.material,f=l.index,d=l.attributes.position,p=l.attributes.uv,_=l.attributes.uv1,v=l.attributes.normal,g=l.groups,x=l.drawRange;if(f!==null)if(Array.isArray(u))for(let M=0,E=g.length;M<E;M++){const S=g[M],y=u[S.materialIndex],R=Math.max(S.start,x.start),U=Math.min(f.count,Math.min(S.start+S.count,x.start+x.count));for(let C=R,F=U;C<F;C+=3){const O=f.getX(C),D=f.getX(C+1),T=f.getX(C+2);r=zh(this,y,e,a,p,_,v,O,D,T),r&&(r.faceIndex=Math.floor(C/3),r.face.materialIndex=S.materialIndex,n.push(r))}}else{const M=Math.max(0,x.start),E=Math.min(f.count,x.start+x.count);for(let S=M,y=E;S<y;S+=3){const R=f.getX(S),U=f.getX(S+1),C=f.getX(S+2);r=zh(this,u,e,a,p,_,v,R,U,C),r&&(r.faceIndex=Math.floor(S/3),n.push(r))}}else if(d!==void 0)if(Array.isArray(u))for(let M=0,E=g.length;M<E;M++){const S=g[M],y=u[S.materialIndex],R=Math.max(S.start,x.start),U=Math.min(d.count,Math.min(S.start+S.count,x.start+x.count));for(let C=R,F=U;C<F;C+=3){const O=C,D=C+1,T=C+2;r=zh(this,y,e,a,p,_,v,O,D,T),r&&(r.faceIndex=Math.floor(C/3),r.face.materialIndex=S.materialIndex,n.push(r))}}else{const M=Math.max(0,x.start),E=Math.min(d.count,x.start+x.count);for(let S=M,y=E;S<y;S+=3){const R=S,U=S+1,C=S+2;r=zh(this,u,e,a,p,_,v,R,U,C),r&&(r.faceIndex=Math.floor(S/3),n.push(r))}}}}function m2(o,e,n,a,r,l,u,f){let d;if(e.side===$i?d=a.intersectTriangle(u,l,r,!0,f):d=a.intersectTriangle(r,l,u,e.side===Qs,f),d===null)return null;Fh.copy(f),Fh.applyMatrix4(o.matrixWorld);const p=n.ray.origin.distanceTo(Fh);return p<n.near||p>n.far?null:{distance:p,point:Fh.clone(),object:o}}function zh(o,e,n,a,r,l,u,f,d,p){o.getVertexPosition(f,Nh),o.getVertexPosition(d,Lh),o.getVertexPosition(p,Oh);const _=m2(o,e,n,a,Nh,Lh,Oh,NM);if(_){const v=new ue;$a.getBarycoord(NM,Nh,Lh,Oh,v),r&&(_.uv=$a.getInterpolatedAttribute(r,f,d,p,v,new Jt)),l&&(_.uv1=$a.getInterpolatedAttribute(l,f,d,p,v,new Jt)),u&&(_.normal=$a.getInterpolatedAttribute(u,f,d,p,v,new ue),_.normal.dot(a.direction)>0&&_.normal.multiplyScalar(-1));const g={a:f,b:d,c:p,normal:new ue,materialIndex:0};$a.getNormal(Nh,Lh,Oh,g.normal),_.face=g,_.barycoord=v}return _}class _2 extends Bi{constructor(e=null,n=1,a=1,r,l,u,f,d,p=_i,_=_i,v,g){super(null,u,f,d,p,_,r,l,v,g),this.isDataTexture=!0,this.image={data:e,width:n,height:a},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const A_=new ue,g2=new ue,v2=new Et;class Ao{constructor(e=new ue(1,0,0),n=0){this.isPlane=!0,this.normal=e,this.constant=n}set(e,n){return this.normal.copy(e),this.constant=n,this}setComponents(e,n,a,r){return this.normal.set(e,n,a),this.constant=r,this}setFromNormalAndCoplanarPoint(e,n){return this.normal.copy(e),this.constant=-n.dot(this.normal),this}setFromCoplanarPoints(e,n,a){const r=A_.subVectors(a,n).cross(g2.subVectors(e,n)).normalize();return this.setFromNormalAndCoplanarPoint(r,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,n){return n.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,n,a=!0){const r=e.delta(A_),l=this.normal.dot(r);if(l===0)return this.distanceToPoint(e.start)===0?n.copy(e.start):null;const u=-(e.start.dot(this.normal)+this.constant)/l;return a===!0&&(u<0||u>1)?null:n.copy(e.start).addScaledVector(r,u)}intersectsLine(e){const n=this.distanceToPoint(e.start),a=this.distanceToPoint(e.end);return n<0&&a>0||a<0&&n>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,n){const a=n||v2.getNormalMatrix(e),r=this.coplanarPoint(A_).applyMatrix4(e),l=this.normal.applyMatrix3(a).normalize();return this.constant=-r.dot(l),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const Mo=new Ng,x2=new Jt(.5,.5),Ih=new ue;class tE{constructor(e=new Ao,n=new Ao,a=new Ao,r=new Ao,l=new Ao,u=new Ao){this.planes=[e,n,a,r,l,u]}set(e,n,a,r,l,u){const f=this.planes;return f[0].copy(e),f[1].copy(n),f[2].copy(a),f[3].copy(r),f[4].copy(l),f[5].copy(u),this}copy(e){const n=this.planes;for(let a=0;a<6;a++)n[a].copy(e.planes[a]);return this}setFromProjectionMatrix(e,n=gr,a=!1){const r=this.planes,l=e.elements,u=l[0],f=l[1],d=l[2],p=l[3],_=l[4],v=l[5],g=l[6],x=l[7],M=l[8],E=l[9],S=l[10],y=l[11],R=l[12],U=l[13],C=l[14],F=l[15];if(r[0].setComponents(p-u,x-_,y-M,F-R).normalize(),r[1].setComponents(p+u,x+_,y+M,F+R).normalize(),r[2].setComponents(p+f,x+v,y+E,F+U).normalize(),r[3].setComponents(p-f,x-v,y-E,F-U).normalize(),a)r[4].setComponents(d,g,S,C).normalize(),r[5].setComponents(p-d,x-g,y-S,F-C).normalize();else if(r[4].setComponents(p-d,x-g,y-S,F-C).normalize(),n===gr)r[5].setComponents(p+d,x+g,y+S,F+C).normalize();else if(n===xd)r[5].setComponents(d,g,S,C).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+n);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),Mo.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const n=e.geometry;n.boundingSphere===null&&n.computeBoundingSphere(),Mo.copy(n.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(Mo)}intersectsSprite(e){Mo.center.set(0,0,0);const n=x2.distanceTo(e.center);return Mo.radius=.7071067811865476+n,Mo.applyMatrix4(e.matrixWorld),this.intersectsSphere(Mo)}intersectsSphere(e){const n=this.planes,a=e.center,r=-e.radius;for(let l=0;l<6;l++)if(n[l].distanceToPoint(a)<r)return!1;return!0}intersectsBox(e){const n=this.planes;for(let a=0;a<6;a++){const r=n[a];if(Ih.x=r.normal.x>0?e.max.x:e.min.x,Ih.y=r.normal.y>0?e.max.y:e.min.y,Ih.z=r.normal.z>0?e.max.z:e.min.z,r.distanceToPoint(Ih)<0)return!1}return!0}containsPoint(e){const n=this.planes;for(let a=0;a<6;a++)if(n[a].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class nE extends Bi{constructor(e=[],n=ko,a,r,l,u,f,d,p,_){super(e,n,a,r,l,u,f,d,p,_),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class fc extends Bi{constructor(e,n,a=Mr,r,l,u,f=_i,d=_i,p,_=rs,v=1){if(_!==rs&&_!==No)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");const g={width:e,height:n,depth:v};super(g,r,l,u,f,d,_,a,p),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Ug(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const n=super.toJSON(e);return this.compareFunction!==null&&(n.compareFunction=this.compareFunction),n}}class S2 extends fc{constructor(e,n=Mr,a=ko,r,l,u=_i,f=_i,d,p=rs){const _={width:e,height:e,depth:1},v=[_,_,_,_,_,_];super(e,e,n,a,r,l,u,f,d,p),this.image=v,this.isCubeDepthTexture=!0,this.isCubeTexture=!0}get images(){return this.image}set images(e){this.image=e}}class iE extends Bi{constructor(e=null){super(),this.sourceTexture=e,this.isExternalTexture=!0}copy(e){return super.copy(e),this.sourceTexture=e.sourceTexture,this}}class Qu extends br{constructor(e=1,n=1,a=1,r=1,l=1,u=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:n,depth:a,widthSegments:r,heightSegments:l,depthSegments:u};const f=this;r=Math.floor(r),l=Math.floor(l),u=Math.floor(u);const d=[],p=[],_=[],v=[];let g=0,x=0;M("z","y","x",-1,-1,a,n,e,u,l,0),M("z","y","x",1,-1,a,n,-e,u,l,1),M("x","z","y",1,1,e,a,n,r,u,2),M("x","z","y",1,-1,e,a,-n,r,u,3),M("x","y","z",1,-1,e,n,a,r,l,4),M("x","y","z",-1,-1,e,n,-a,r,l,5),this.setIndex(d),this.setAttribute("position",new ts(p,3)),this.setAttribute("normal",new ts(_,3)),this.setAttribute("uv",new ts(v,2));function M(E,S,y,R,U,C,F,O,D,T,L){const H=C/D,V=F/T,k=C/2,te=F/2,ie=O/2,W=D+1,z=T+1;let B=0,J=0;const fe=new ue;for(let G=0;G<z;G++){const I=G*V-te;for(let K=0;K<W;K++){const Se=K*H-k;fe[E]=Se*R,fe[S]=I*U,fe[y]=ie,p.push(fe.x,fe.y,fe.z),fe[E]=0,fe[S]=0,fe[y]=O>0?1:-1,_.push(fe.x,fe.y,fe.z),v.push(K/D),v.push(1-G/T),B+=1}}for(let G=0;G<T;G++)for(let I=0;I<D;I++){const K=g+I+W*G,Se=g+I+W*(G+1),be=g+(I+1)+W*(G+1),Ue=g+(I+1)+W*G;d.push(K,Se,Ue),d.push(Se,be,Ue),J+=6}f.addGroup(x,J,L),x+=J,g+=B}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Qu(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}class Cd extends br{constructor(e=1,n=1,a=1,r=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:n,widthSegments:a,heightSegments:r};const l=e/2,u=n/2,f=Math.floor(a),d=Math.floor(r),p=f+1,_=d+1,v=e/f,g=n/d,x=[],M=[],E=[],S=[];for(let y=0;y<_;y++){const R=y*g-u;for(let U=0;U<p;U++){const C=U*v-l;M.push(C,-R,0),E.push(0,0,1),S.push(U/f),S.push(1-y/d)}}for(let y=0;y<d;y++)for(let R=0;R<f;R++){const U=R+p*y,C=R+p*(y+1),F=R+1+p*(y+1),O=R+1+p*y;x.push(U,C,O),x.push(C,F,O)}this.setIndex(x),this.setAttribute("position",new ts(M,3)),this.setAttribute("normal",new ts(E,3)),this.setAttribute("uv",new ts(S,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Cd(e.width,e.height,e.widthSegments,e.heightSegments)}}function hc(o){const e={};for(const n in o){e[n]={};for(const a in o[n]){const r=o[n][a];if(LM(r))r.isRenderTargetTexture?(_t("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[n][a]=null):e[n][a]=r.clone();else if(Array.isArray(r))if(LM(r[0])){const l=[];for(let u=0,f=r.length;u<f;u++)l[u]=r[u].clone();e[n][a]=l}else e[n][a]=r.slice();else e[n][a]=r}}return e}function Oi(o){const e={};for(let n=0;n<o.length;n++){const a=hc(o[n]);for(const r in a)e[r]=a[r]}return e}function LM(o){return o&&(o.isColor||o.isMatrix3||o.isMatrix4||o.isVector2||o.isVector3||o.isVector4||o.isTexture||o.isQuaternion)}function y2(o){const e=[];for(let n=0;n<o.length;n++)e.push(o[n].clone());return e}function aE(o){const e=o.getRenderTarget();return e===null?o.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:Xt.workingColorSpace}const M2={clone:hc,merge:Oi};var b2=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,E2=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class Va extends Rd{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=b2,this.fragmentShader=E2,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=hc(e.uniforms),this.uniformsGroups=y2(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this.defaultAttributeValues=Object.assign({},e.defaultAttributeValues),this.index0AttributeName=e.index0AttributeName,this.uniformsNeedUpdate=e.uniformsNeedUpdate,this}toJSON(e){const n=super.toJSON(e);n.glslVersion=this.glslVersion,n.uniforms={};for(const r in this.uniforms){const u=this.uniforms[r].value;u&&u.isTexture?n.uniforms[r]={type:"t",value:u.toJSON(e).uuid}:u&&u.isColor?n.uniforms[r]={type:"c",value:u.getHex()}:u&&u.isVector2?n.uniforms[r]={type:"v2",value:u.toArray()}:u&&u.isVector3?n.uniforms[r]={type:"v3",value:u.toArray()}:u&&u.isVector4?n.uniforms[r]={type:"v4",value:u.toArray()}:u&&u.isMatrix3?n.uniforms[r]={type:"m3",value:u.toArray()}:u&&u.isMatrix4?n.uniforms[r]={type:"m4",value:u.toArray()}:n.uniforms[r]={value:u}}Object.keys(this.defines).length>0&&(n.defines=this.defines),n.vertexShader=this.vertexShader,n.fragmentShader=this.fragmentShader,n.lights=this.lights,n.clipping=this.clipping;const a={};for(const r in this.extensions)this.extensions[r]===!0&&(a[r]=!0);return Object.keys(a).length>0&&(n.extensions=a),n}}class T2 extends Va{constructor(e){super(e),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"}}class A2 extends Rd{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=IC,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class R2 extends Rd{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}const Bh=new ue,Hh=new dc,lr=new ue;class rE extends ya{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new ii,this.projectionMatrix=new ii,this.projectionMatrixInverse=new ii,this.coordinateSystem=gr,this._reversedDepth=!1}get reversedDepth(){return this._reversedDepth}copy(e,n){return super.copy(e,n),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorld.decompose(Bh,Hh,lr),lr.x===1&&lr.y===1&&lr.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Bh,Hh,lr.set(1,1,1)).invert()}updateWorldMatrix(e,n){super.updateWorldMatrix(e,n),this.matrixWorld.decompose(Bh,Hh,lr),lr.x===1&&lr.y===1&&lr.z===1?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(Bh,Hh,lr.set(1,1,1)).invert()}clone(){return new this.constructor().copy(this)}}const Ps=new ue,OM=new Jt,PM=new Jt;class Ja extends rE{constructor(e=50,n=1,a=.1,r=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=a,this.far=r,this.focus=10,this.aspect=n,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,n){return super.copy(e,n),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const n=.5*this.getFilmHeight()/e;this.fov=q0*2*Math.atan(n),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(i_*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return q0*2*Math.atan(Math.tan(i_*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,n,a){Ps.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Ps.x,Ps.y).multiplyScalar(-e/Ps.z),Ps.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),a.set(Ps.x,Ps.y).multiplyScalar(-e/Ps.z)}getViewSize(e,n){return this.getViewBounds(e,OM,PM),n.subVectors(PM,OM)}setViewOffset(e,n,a,r,l,u){this.aspect=e/n,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=n,this.view.offsetX=a,this.view.offsetY=r,this.view.width=l,this.view.height=u,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let n=e*Math.tan(i_*.5*this.fov)/this.zoom,a=2*n,r=this.aspect*a,l=-.5*r;const u=this.view;if(this.view!==null&&this.view.enabled){const d=u.fullWidth,p=u.fullHeight;l+=u.offsetX*r/d,n-=u.offsetY*a/p,r*=u.width/d,a*=u.height/p}const f=this.filmOffset;f!==0&&(l+=e*f/this.getFilmWidth()),this.projectionMatrix.makePerspective(l,l+r,n,n-a,e,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const n=super.toJSON(e);return n.object.fov=this.fov,n.object.zoom=this.zoom,n.object.near=this.near,n.object.far=this.far,n.object.focus=this.focus,n.object.aspect=this.aspect,this.view!==null&&(n.object.view=Object.assign({},this.view)),n.object.filmGauge=this.filmGauge,n.object.filmOffset=this.filmOffset,n}}class Lg extends rE{constructor(e=-1,n=1,a=1,r=-1,l=.1,u=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=n,this.top=a,this.bottom=r,this.near=l,this.far=u,this.updateProjectionMatrix()}copy(e,n){return super.copy(e,n),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,n,a,r,l,u){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=n,this.view.offsetX=a,this.view.offsetY=r,this.view.width=l,this.view.height=u,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),n=(this.top-this.bottom)/(2*this.zoom),a=(this.right+this.left)/2,r=(this.top+this.bottom)/2;let l=a-e,u=a+e,f=r+n,d=r-n;if(this.view!==null&&this.view.enabled){const p=(this.right-this.left)/this.view.fullWidth/this.zoom,_=(this.top-this.bottom)/this.view.fullHeight/this.zoom;l+=p*this.view.offsetX,u=l+p*this.view.width,f-=_*this.view.offsetY,d=f-_*this.view.height}this.projectionMatrix.makeOrthographic(l,u,f,d,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const n=super.toJSON(e);return n.object.zoom=this.zoom,n.object.left=this.left,n.object.right=this.right,n.object.top=this.top,n.object.bottom=this.bottom,n.object.near=this.near,n.object.far=this.far,this.view!==null&&(n.object.view=Object.assign({},this.view)),n}}const Hl=-90,Gl=1;class C2 extends ya{constructor(e,n,a){super(),this.type="CubeCamera",this.renderTarget=a,this.coordinateSystem=null,this.activeMipmapLevel=0;const r=new Ja(Hl,Gl,e,n);r.layers=this.layers,this.add(r);const l=new Ja(Hl,Gl,e,n);l.layers=this.layers,this.add(l);const u=new Ja(Hl,Gl,e,n);u.layers=this.layers,this.add(u);const f=new Ja(Hl,Gl,e,n);f.layers=this.layers,this.add(f);const d=new Ja(Hl,Gl,e,n);d.layers=this.layers,this.add(d);const p=new Ja(Hl,Gl,e,n);p.layers=this.layers,this.add(p)}updateCoordinateSystem(){const e=this.coordinateSystem,n=this.children.concat(),[a,r,l,u,f,d]=n;for(const p of n)this.remove(p);if(e===gr)a.up.set(0,1,0),a.lookAt(1,0,0),r.up.set(0,1,0),r.lookAt(-1,0,0),l.up.set(0,0,-1),l.lookAt(0,1,0),u.up.set(0,0,1),u.lookAt(0,-1,0),f.up.set(0,1,0),f.lookAt(0,0,1),d.up.set(0,1,0),d.lookAt(0,0,-1);else if(e===xd)a.up.set(0,-1,0),a.lookAt(-1,0,0),r.up.set(0,-1,0),r.lookAt(1,0,0),l.up.set(0,0,1),l.lookAt(0,1,0),u.up.set(0,0,-1),u.lookAt(0,-1,0),f.up.set(0,-1,0),f.lookAt(0,0,1),d.up.set(0,-1,0),d.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const p of n)this.add(p),p.updateMatrixWorld()}update(e,n){this.parent===null&&this.updateMatrixWorld();const{renderTarget:a,activeMipmapLevel:r}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[l,u,f,d,p,_]=this.children,v=e.getRenderTarget(),g=e.getActiveCubeFace(),x=e.getActiveMipmapLevel(),M=e.xr.enabled;e.xr.enabled=!1;const E=a.texture.generateMipmaps;a.texture.generateMipmaps=!1;let S=!1;e.isWebGLRenderer===!0?S=e.state.buffers.depth.getReversed():S=e.reversedDepthBuffer,e.setRenderTarget(a,0,r),S&&e.autoClear===!1&&e.clearDepth(),e.render(n,l),e.setRenderTarget(a,1,r),S&&e.autoClear===!1&&e.clearDepth(),e.render(n,u),e.setRenderTarget(a,2,r),S&&e.autoClear===!1&&e.clearDepth(),e.render(n,f),e.setRenderTarget(a,3,r),S&&e.autoClear===!1&&e.clearDepth(),e.render(n,d),e.setRenderTarget(a,4,r),S&&e.autoClear===!1&&e.clearDepth(),e.render(n,p),a.texture.generateMipmaps=E,e.setRenderTarget(a,5,r),S&&e.autoClear===!1&&e.clearDepth(),e.render(n,_),e.setRenderTarget(v,g,x),e.xr.enabled=M,a.texture.needsPMREMUpdate=!0}}class w2 extends Ja{constructor(e=[]){super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=e}}const Ig=class Ig{constructor(e,n,a,r){this.elements=[1,0,0,1],e!==void 0&&this.set(e,n,a,r)}identity(){return this.set(1,0,0,1),this}fromArray(e,n=0){for(let a=0;a<4;a++)this.elements[a]=e[a+n];return this}set(e,n,a,r){const l=this.elements;return l[0]=e,l[2]=n,l[1]=a,l[3]=r,this}};Ig.prototype.isMatrix2=!0;let FM=Ig;function zM(o,e,n,a){const r=D2(a);switch(n){case Wb:return o*e;case Yb:return o*e/r.components*r.byteLength;case Ag:return o*e/r.components*r.byteLength;case Xo:return o*e*2/r.components*r.byteLength;case Rg:return o*e*2/r.components*r.byteLength;case qb:return o*e*3/r.components*r.byteLength;case er:return o*e*4/r.components*r.byteLength;case Cg:return o*e*4/r.components*r.byteLength;case $h:case ed:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*8;case td:case nd:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*16;case _0:case v0:return Math.max(o,16)*Math.max(e,8)/4;case m0:case g0:return Math.max(o,8)*Math.max(e,8)/2;case x0:case S0:case M0:case b0:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*8;case y0:case md:case E0:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*16;case T0:return Math.floor((o+3)/4)*Math.floor((e+3)/4)*16;case A0:return Math.floor((o+4)/5)*Math.floor((e+3)/4)*16;case R0:return Math.floor((o+4)/5)*Math.floor((e+4)/5)*16;case C0:return Math.floor((o+5)/6)*Math.floor((e+4)/5)*16;case w0:return Math.floor((o+5)/6)*Math.floor((e+5)/6)*16;case D0:return Math.floor((o+7)/8)*Math.floor((e+4)/5)*16;case U0:return Math.floor((o+7)/8)*Math.floor((e+5)/6)*16;case N0:return Math.floor((o+7)/8)*Math.floor((e+7)/8)*16;case L0:return Math.floor((o+9)/10)*Math.floor((e+4)/5)*16;case O0:return Math.floor((o+9)/10)*Math.floor((e+5)/6)*16;case P0:return Math.floor((o+9)/10)*Math.floor((e+7)/8)*16;case F0:return Math.floor((o+9)/10)*Math.floor((e+9)/10)*16;case z0:return Math.floor((o+11)/12)*Math.floor((e+9)/10)*16;case I0:return Math.floor((o+11)/12)*Math.floor((e+11)/12)*16;case B0:case H0:case G0:return Math.ceil(o/4)*Math.ceil(e/4)*16;case V0:case k0:return Math.ceil(o/4)*Math.ceil(e/4)*8;case _d:case X0:return Math.ceil(o/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${n} format.`)}function D2(o){switch(o){case Ia:case Gb:return{byteLength:1,components:1};case qu:case Vb:case as:return{byteLength:2,components:1};case Eg:case Tg:return{byteLength:2,components:4};case Mr:case bg:case _r:return{byteLength:4,components:1};case kb:case Xb:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${o}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:Mg}}));typeof window<"u"&&(window.__THREE__?_t("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=Mg);function sE(){let o=null,e=!1,n=null,a=null;function r(l,u){n(l,u),a=o.requestAnimationFrame(r)}return{start:function(){e!==!0&&n!==null&&o!==null&&(a=o.requestAnimationFrame(r),e=!0)},stop:function(){o!==null&&o.cancelAnimationFrame(a),e=!1},setAnimationLoop:function(l){n=l},setContext:function(l){o=l}}}function U2(o){const e=new WeakMap;function n(f,d){const p=f.array,_=f.usage,v=p.byteLength,g=o.createBuffer();o.bindBuffer(d,g),o.bufferData(d,p,_),f.onUploadCallback();let x;if(p instanceof Float32Array)x=o.FLOAT;else if(typeof Float16Array<"u"&&p instanceof Float16Array)x=o.HALF_FLOAT;else if(p instanceof Uint16Array)f.isFloat16BufferAttribute?x=o.HALF_FLOAT:x=o.UNSIGNED_SHORT;else if(p instanceof Int16Array)x=o.SHORT;else if(p instanceof Uint32Array)x=o.UNSIGNED_INT;else if(p instanceof Int32Array)x=o.INT;else if(p instanceof Int8Array)x=o.BYTE;else if(p instanceof Uint8Array)x=o.UNSIGNED_BYTE;else if(p instanceof Uint8ClampedArray)x=o.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+p);return{buffer:g,type:x,bytesPerElement:p.BYTES_PER_ELEMENT,version:f.version,size:v}}function a(f,d,p){const _=d.array,v=d.updateRanges;if(o.bindBuffer(p,f),v.length===0)o.bufferSubData(p,0,_);else{v.sort((x,M)=>x.start-M.start);let g=0;for(let x=1;x<v.length;x++){const M=v[g],E=v[x];E.start<=M.start+M.count+1?M.count=Math.max(M.count,E.start+E.count-M.start):(++g,v[g]=E)}v.length=g+1;for(let x=0,M=v.length;x<M;x++){const E=v[x];o.bufferSubData(p,E.start*_.BYTES_PER_ELEMENT,_,E.start,E.count)}d.clearUpdateRanges()}d.onUploadCallback()}function r(f){return f.isInterleavedBufferAttribute&&(f=f.data),e.get(f)}function l(f){f.isInterleavedBufferAttribute&&(f=f.data);const d=e.get(f);d&&(o.deleteBuffer(d.buffer),e.delete(f))}function u(f,d){if(f.isInterleavedBufferAttribute&&(f=f.data),f.isGLBufferAttribute){const _=e.get(f);(!_||_.version<f.version)&&e.set(f,{buffer:f.buffer,type:f.type,bytesPerElement:f.elementSize,version:f.version});return}const p=e.get(f);if(p===void 0)e.set(f,n(f,d));else if(p.version<f.version){if(p.size!==f.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");a(p.buffer,f,d),p.version=f.version}}return{get:r,remove:l,update:u}}var N2=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,L2=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,O2=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,P2=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,F2=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,z2=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,I2=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,B2=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,H2=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec4 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );
	}
#endif`,G2=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,V2=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,k2=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,X2=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,W2=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,q2=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Y2=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,j2=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Z2=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,K2=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Q2=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#endif`,J2=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#endif`,$2=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec4 vColor;
#endif`,e3=`#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec4( 1.0 );
#endif
#ifdef USE_COLOR_ALPHA
	vColor *= color;
#elif defined( USE_COLOR )
	vColor.rgb *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.rgb *= instanceColor.rgb;
#endif
#ifdef USE_BATCHING_COLOR
	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );
#endif`,t3=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,n3=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,i3=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,a3=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,r3=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,s3=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,o3=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,l3="gl_FragColor = linearToOutputTexel( gl_FragColor );",c3=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,u3=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );
		#ifdef ENVMAP_BLENDING_MULTIPLY
			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_MIX )
			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
		#elif defined( ENVMAP_BLENDING_ADD )
			outgoingLight += envColor.xyz * specularStrength * reflectivity;
		#endif
	#endif
#endif`,f3=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
#endif`,h3=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,d3=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,p3=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,m3=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,_3=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,g3=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,v3=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,x3=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,S3=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,y3=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,M3=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,b3=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif
#include <lightprobes_pars_fragment>`,E3=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,T3=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,A3=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,R3=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,C3=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,w3=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );
material.metalness = metalnessFactor;
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = vec3( 0.04 );
	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,D3=`uniform sampler2D dfgLUT;
struct PhysicalMaterial {
	vec3 diffuseColor;
	vec3 diffuseContribution;
	vec3 specularColor;
	vec3 specularColorBlended;
	float roughness;
	float metalness;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
		vec3 iridescenceFresnelDielectric;
		vec3 iridescenceFresnelMetallic;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		return 0.5 / max( gv + gl, EPSILON );
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColorBlended;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float rInv = 1.0 / ( roughness + 0.1 );
	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;
	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;
	float DG = exp( a * dotNV + b );
	return saturate( DG );
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
vec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;
	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;
	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;
	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;
	float Ess_V = dfgV.x + dfgV.y;
	float Ess_L = dfgL.x + dfgL.y;
	float Ems_V = 1.0 - Ess_V;
	float Ems_L = 1.0 - Ess_L;
	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;
	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );
	float compensationFactor = Ems_V * Ems_L;
	vec3 multiScatter = Fms * compensationFactor;
	return singleScatter + multiScatter;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
		#ifdef USE_CLEARCOAT
			vec3 Ncc = geometryClearcoatNormal;
			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );
			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );
			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );
			mat3 mInvClearcoat = mat3(
				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),
				vec3(             0, 1,             0 ),
				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )
			);
			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;
			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );
		#endif
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
 
 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
 
 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );
 
 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );
 
 		irradiance *= sheenEnergyComp;
 
 	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		diffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectDiffuse += diffuse;
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;
 	#endif
	vec3 singleScatteringDielectric = vec3( 0.0 );
	vec3 multiScatteringDielectric = vec3( 0.0 );
	vec3 singleScatteringMetallic = vec3( 0.0 );
	vec3 multiScatteringMetallic = vec3( 0.0 );
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );
		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );
	#endif
	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );
	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );
	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;
	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	vec3 indirectSpecular = radiance * singleScattering;
	indirectSpecular += multiScattering * cosineWeightedIrradiance;
	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;
	#ifdef USE_SHEEN
		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;
		indirectSpecular *= sheenEnergyComp;
		indirectDiffuse *= sheenEnergyComp;
	#endif
	reflectedLight.indirectSpecular += indirectSpecular;
	reflectedLight.indirectDiffuse += indirectDiffuse;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,U3=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );
		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
	#ifdef USE_LIGHT_PROBES_GRID
		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;
		vec3 probeWorldNormal = inverseTransformDirection( geometryNormal, viewMatrix );
		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,N3=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )
		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )
			iblIrradiance += getIBLIrradiance( geometryNormal );
		#endif
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,L3=`#if defined( RE_IndirectDiffuse )
	#if defined( LAMBERT ) || defined( PHONG )
		irradiance += iblIrradiance;
	#endif
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,O3=`#ifdef USE_LIGHT_PROBES_GRID
uniform highp sampler3D probesSH;
uniform vec3 probesMin;
uniform vec3 probesMax;
uniform vec3 probesResolution;
vec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {
	vec3 res = probesResolution;
	vec3 gridRange = probesMax - probesMin;
	vec3 resMinusOne = res - 1.0;
	vec3 probeSpacing = gridRange / resMinusOne;
	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;
	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );
	uvw = uvw * resMinusOne / res + 0.5 / res;
	float nz          = res.z;
	float paddedSlices = nz + 2.0;
	float atlasDepth  = 7.0 * paddedSlices;
	float uvZBase     = uvw.z * nz + 1.0;
	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );
	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );
	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );
	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );
	vec3 c0 = s0.xyz;
	vec3 c1 = vec3( s0.w, s1.xy );
	vec3 c2 = vec3( s1.zw, s2.x );
	vec3 c3 = s2.yzw;
	vec3 c4 = s3.xyz;
	vec3 c5 = vec3( s3.w, s4.xy );
	vec3 c6 = vec3( s4.zw, s5.x );
	vec3 c7 = s5.yzw;
	vec3 c8 = s6.xyz;
	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;
	vec3 result = c0 * 0.886227;
	result += c1 * 2.0 * 0.511664 * y;
	result += c2 * 2.0 * 0.511664 * z;
	result += c3 * 2.0 * 0.511664 * x;
	result += c4 * 2.0 * 0.429043 * x * y;
	result += c5 * 2.0 * 0.429043 * y * z;
	result += c6 * ( 0.743125 * z * z - 0.247708 );
	result += c7 * 2.0 * 0.429043 * x * z;
	result += c8 * 0.429043 * ( x * x - y * y );
	return max( result, vec3( 0.0 ) );
}
#endif`,P3=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,F3=`#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,z3=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,I3=`#ifdef USE_LOGARITHMIC_DEPTH_BUFFER
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,B3=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,H3=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,G3=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,V3=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,k3=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,X3=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,W3=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,q3=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,Y3=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,j3=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,Z3=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,K3=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,Q3=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#if defined( USE_PACKED_NORMALMAP )
		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );
	#endif
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,J3=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,$3=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,ew=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,tw=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,nw=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,iw=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,aw=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,rw=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,sw=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,ow=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	#ifdef USE_REVERSED_DEPTH_BUFFER
	
		return depth * ( far - near ) - far;
	#else
		return depth * ( near - far ) - near;
	#endif
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	
	#ifdef USE_REVERSED_DEPTH_BUFFER
		return ( near * far ) / ( ( near - far ) * depth - near );
	#else
		return ( near * far ) / ( ( far - near ) * depth - far );
	#endif
}`,lw=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,cw=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,uw=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,fw=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,hw=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,dw=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,pw=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#else
			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		#endif
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#else
			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		#endif
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#if defined( SHADOWMAP_TYPE_PCF )
			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#elif defined( SHADOWMAP_TYPE_BASIC )
			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		#endif
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float interleavedGradientNoise( vec2 position ) {
			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );
		}
		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {
			const float goldenAngle = 2.399963229728653;
			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );
			float theta = float( sampleIndex ) * goldenAngle + phi;
			return vec2( cos( theta ), sin( theta ) ) * r;
		}
	#endif
	#if defined( SHADOWMAP_TYPE_PCF )
		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			shadowCoord.z += shadowBias;
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
				float radius = shadowRadius * texelSize.x;
				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
				shadow = (
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +
					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )
				) * 0.2;
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#elif defined( SHADOWMAP_TYPE_VSM )
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;
				float mean = distribution.x;
				float variance = distribution.y * distribution.y;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					float hard_shadow = step( mean, shadowCoord.z );
				#else
					float hard_shadow = step( shadowCoord.z, mean );
				#endif
				
				if ( hard_shadow == 1.0 ) {
					shadow = 1.0;
				} else {
					variance = max( variance, 0.0000001 );
					float d = shadowCoord.z - mean;
					float p_max = variance / ( variance + d * d );
					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );
					shadow = max( hard_shadow, p_max );
				}
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#else
		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
			float shadow = 1.0;
			shadowCoord.xyz /= shadowCoord.w;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				shadowCoord.z -= shadowBias;
			#else
				shadowCoord.z += shadowBias;
			#endif
			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
			if ( frustumTest ) {
				float depth = texture2D( shadowMap, shadowCoord.xy ).r;
				#ifdef USE_REVERSED_DEPTH_BUFFER
					shadow = step( depth, shadowCoord.z );
				#else
					shadow = step( shadowCoord.z, depth );
				#endif
			}
			return mix( 1.0, shadow, shadowIntensity );
		}
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	#if defined( SHADOWMAP_TYPE_PCF )
	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 bd3D = normalize( lightToPosition );
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			#ifdef USE_REVERSED_DEPTH_BUFFER
				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp -= shadowBias;
			#else
				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
				dp += shadowBias;
			#endif
			float texelSize = shadowRadius / shadowMapSize.x;
			vec3 absDir = abs( bd3D );
			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );
			tangent = normalize( cross( bd3D, tangent ) );
			vec3 bitangent = cross( bd3D, tangent );
			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;
			vec2 sample0 = vogelDiskSample( 0, 5, phi );
			vec2 sample1 = vogelDiskSample( 1, 5, phi );
			vec2 sample2 = vogelDiskSample( 2, 5, phi );
			vec2 sample3 = vogelDiskSample( 3, 5, phi );
			vec2 sample4 = vogelDiskSample( 4, 5, phi );
			shadow = (
				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +
				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )
			) * 0.2;
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#elif defined( SHADOWMAP_TYPE_BASIC )
	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		vec3 absVec = abs( lightToPosition );
		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );
		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {
			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );
			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			float depth = textureCube( shadowMap, bd3D ).r;
			#ifdef USE_REVERSED_DEPTH_BUFFER
				depth = 1.0 - depth;
			#endif
			shadow = step( dp, depth );
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	#endif
	#endif
#endif`,mw=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,_w=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	#ifdef HAS_NORMAL
		vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	#else
		vec3 shadowWorldNormal = vec3( 0.0 );
	#endif
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,gw=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,vw=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,xw=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,Sw=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,yw=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,Mw=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,bw=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,Ew=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,Tw=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,Aw=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,Rw=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,Cw=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,ww=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,Dw=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,Uw=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const Nw=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,Lw=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Ow=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,Pw=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Fw=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,zw=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Iw=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,Bw=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	#ifdef USE_REVERSED_DEPTH_BUFFER
		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];
	#else
		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;
	#endif
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,Hw=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,Gw=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );
}`,Vw=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,kw=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,Xw=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,Ww=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,qw=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,Yw=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,jw=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,Zw=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Kw=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,Qw=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Jw=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,$w=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,eD=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,tD=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,nD=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,iD=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
 
		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;
 
 	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,aD=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,rD=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,sD=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,oD=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,lD=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,cD=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,uD=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,fD=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,Nt={alphahash_fragment:N2,alphahash_pars_fragment:L2,alphamap_fragment:O2,alphamap_pars_fragment:P2,alphatest_fragment:F2,alphatest_pars_fragment:z2,aomap_fragment:I2,aomap_pars_fragment:B2,batching_pars_vertex:H2,batching_vertex:G2,begin_vertex:V2,beginnormal_vertex:k2,bsdfs:X2,iridescence_fragment:W2,bumpmap_pars_fragment:q2,clipping_planes_fragment:Y2,clipping_planes_pars_fragment:j2,clipping_planes_pars_vertex:Z2,clipping_planes_vertex:K2,color_fragment:Q2,color_pars_fragment:J2,color_pars_vertex:$2,color_vertex:e3,common:t3,cube_uv_reflection_fragment:n3,defaultnormal_vertex:i3,displacementmap_pars_vertex:a3,displacementmap_vertex:r3,emissivemap_fragment:s3,emissivemap_pars_fragment:o3,colorspace_fragment:l3,colorspace_pars_fragment:c3,envmap_fragment:u3,envmap_common_pars_fragment:f3,envmap_pars_fragment:h3,envmap_pars_vertex:d3,envmap_physical_pars_fragment:E3,envmap_vertex:p3,fog_vertex:m3,fog_pars_vertex:_3,fog_fragment:g3,fog_pars_fragment:v3,gradientmap_pars_fragment:x3,lightmap_pars_fragment:S3,lights_lambert_fragment:y3,lights_lambert_pars_fragment:M3,lights_pars_begin:b3,lights_toon_fragment:T3,lights_toon_pars_fragment:A3,lights_phong_fragment:R3,lights_phong_pars_fragment:C3,lights_physical_fragment:w3,lights_physical_pars_fragment:D3,lights_fragment_begin:U3,lights_fragment_maps:N3,lights_fragment_end:L3,lightprobes_pars_fragment:O3,logdepthbuf_fragment:P3,logdepthbuf_pars_fragment:F3,logdepthbuf_pars_vertex:z3,logdepthbuf_vertex:I3,map_fragment:B3,map_pars_fragment:H3,map_particle_fragment:G3,map_particle_pars_fragment:V3,metalnessmap_fragment:k3,metalnessmap_pars_fragment:X3,morphinstance_vertex:W3,morphcolor_vertex:q3,morphnormal_vertex:Y3,morphtarget_pars_vertex:j3,morphtarget_vertex:Z3,normal_fragment_begin:K3,normal_fragment_maps:Q3,normal_pars_fragment:J3,normal_pars_vertex:$3,normal_vertex:ew,normalmap_pars_fragment:tw,clearcoat_normal_fragment_begin:nw,clearcoat_normal_fragment_maps:iw,clearcoat_pars_fragment:aw,iridescence_pars_fragment:rw,opaque_fragment:sw,packing:ow,premultiplied_alpha_fragment:lw,project_vertex:cw,dithering_fragment:uw,dithering_pars_fragment:fw,roughnessmap_fragment:hw,roughnessmap_pars_fragment:dw,shadowmap_pars_fragment:pw,shadowmap_pars_vertex:mw,shadowmap_vertex:_w,shadowmask_pars_fragment:gw,skinbase_vertex:vw,skinning_pars_vertex:xw,skinning_vertex:Sw,skinnormal_vertex:yw,specularmap_fragment:Mw,specularmap_pars_fragment:bw,tonemapping_fragment:Ew,tonemapping_pars_fragment:Tw,transmission_fragment:Aw,transmission_pars_fragment:Rw,uv_pars_fragment:Cw,uv_pars_vertex:ww,uv_vertex:Dw,worldpos_vertex:Uw,background_vert:Nw,background_frag:Lw,backgroundCube_vert:Ow,backgroundCube_frag:Pw,cube_vert:Fw,cube_frag:zw,depth_vert:Iw,depth_frag:Bw,distance_vert:Hw,distance_frag:Gw,equirect_vert:Vw,equirect_frag:kw,linedashed_vert:Xw,linedashed_frag:Ww,meshbasic_vert:qw,meshbasic_frag:Yw,meshlambert_vert:jw,meshlambert_frag:Zw,meshmatcap_vert:Kw,meshmatcap_frag:Qw,meshnormal_vert:Jw,meshnormal_frag:$w,meshphong_vert:eD,meshphong_frag:tD,meshphysical_vert:nD,meshphysical_frag:iD,meshtoon_vert:aD,meshtoon_frag:rD,points_vert:sD,points_frag:oD,shadow_vert:lD,shadow_frag:cD,sprite_vert:uD,sprite_frag:fD},qe={common:{diffuse:{value:new pn(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new Et},alphaMap:{value:null},alphaMapTransform:{value:new Et},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new Et}},envmap:{envMap:{value:null},envMapRotation:{value:new Et},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new Et}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new Et}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new Et},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new Et},normalScale:{value:new Jt(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new Et},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new Et}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new Et}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new Et}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new pn(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new ue},probesMax:{value:new ue},probesResolution:{value:new ue}},points:{diffuse:{value:new pn(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new Et},alphaTest:{value:0},uvTransform:{value:new Et}},sprite:{diffuse:{value:new pn(16777215)},opacity:{value:1},center:{value:new Jt(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new Et},alphaMap:{value:null},alphaMapTransform:{value:new Et},alphaTest:{value:0}}},hr={basic:{uniforms:Oi([qe.common,qe.specularmap,qe.envmap,qe.aomap,qe.lightmap,qe.fog]),vertexShader:Nt.meshbasic_vert,fragmentShader:Nt.meshbasic_frag},lambert:{uniforms:Oi([qe.common,qe.specularmap,qe.envmap,qe.aomap,qe.lightmap,qe.emissivemap,qe.bumpmap,qe.normalmap,qe.displacementmap,qe.fog,qe.lights,{emissive:{value:new pn(0)},envMapIntensity:{value:1}}]),vertexShader:Nt.meshlambert_vert,fragmentShader:Nt.meshlambert_frag},phong:{uniforms:Oi([qe.common,qe.specularmap,qe.envmap,qe.aomap,qe.lightmap,qe.emissivemap,qe.bumpmap,qe.normalmap,qe.displacementmap,qe.fog,qe.lights,{emissive:{value:new pn(0)},specular:{value:new pn(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:Nt.meshphong_vert,fragmentShader:Nt.meshphong_frag},standard:{uniforms:Oi([qe.common,qe.envmap,qe.aomap,qe.lightmap,qe.emissivemap,qe.bumpmap,qe.normalmap,qe.displacementmap,qe.roughnessmap,qe.metalnessmap,qe.fog,qe.lights,{emissive:{value:new pn(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Nt.meshphysical_vert,fragmentShader:Nt.meshphysical_frag},toon:{uniforms:Oi([qe.common,qe.aomap,qe.lightmap,qe.emissivemap,qe.bumpmap,qe.normalmap,qe.displacementmap,qe.gradientmap,qe.fog,qe.lights,{emissive:{value:new pn(0)}}]),vertexShader:Nt.meshtoon_vert,fragmentShader:Nt.meshtoon_frag},matcap:{uniforms:Oi([qe.common,qe.bumpmap,qe.normalmap,qe.displacementmap,qe.fog,{matcap:{value:null}}]),vertexShader:Nt.meshmatcap_vert,fragmentShader:Nt.meshmatcap_frag},points:{uniforms:Oi([qe.points,qe.fog]),vertexShader:Nt.points_vert,fragmentShader:Nt.points_frag},dashed:{uniforms:Oi([qe.common,qe.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Nt.linedashed_vert,fragmentShader:Nt.linedashed_frag},depth:{uniforms:Oi([qe.common,qe.displacementmap]),vertexShader:Nt.depth_vert,fragmentShader:Nt.depth_frag},normal:{uniforms:Oi([qe.common,qe.bumpmap,qe.normalmap,qe.displacementmap,{opacity:{value:1}}]),vertexShader:Nt.meshnormal_vert,fragmentShader:Nt.meshnormal_frag},sprite:{uniforms:Oi([qe.sprite,qe.fog]),vertexShader:Nt.sprite_vert,fragmentShader:Nt.sprite_frag},background:{uniforms:{uvTransform:{value:new Et},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Nt.background_vert,fragmentShader:Nt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new Et}},vertexShader:Nt.backgroundCube_vert,fragmentShader:Nt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Nt.cube_vert,fragmentShader:Nt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Nt.equirect_vert,fragmentShader:Nt.equirect_frag},distance:{uniforms:Oi([qe.common,qe.displacementmap,{referencePosition:{value:new ue},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Nt.distance_vert,fragmentShader:Nt.distance_frag},shadow:{uniforms:Oi([qe.lights,qe.fog,{color:{value:new pn(0)},opacity:{value:1}}]),vertexShader:Nt.shadow_vert,fragmentShader:Nt.shadow_frag}};hr.physical={uniforms:Oi([hr.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new Et},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new Et},clearcoatNormalScale:{value:new Jt(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new Et},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new Et},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new Et},sheen:{value:0},sheenColor:{value:new pn(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new Et},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new Et},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new Et},transmissionSamplerSize:{value:new Jt},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new Et},attenuationDistance:{value:0},attenuationColor:{value:new pn(0)},specularColor:{value:new pn(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new Et},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new Et},anisotropyVector:{value:new Jt},anisotropyMap:{value:null},anisotropyMapTransform:{value:new Et}}]),vertexShader:Nt.meshphysical_vert,fragmentShader:Nt.meshphysical_frag};const Gh={r:0,b:0,g:0},hD=new ii,oE=new Et;oE.set(-1,0,0,0,1,0,0,0,1);function dD(o,e,n,a,r,l){const u=new pn(0);let f=r===!0?0:1,d,p,_=null,v=0,g=null;function x(R){let U=R.isScene===!0?R.background:null;if(U&&U.isTexture){const C=R.backgroundBlurriness>0;U=e.get(U,C)}return U}function M(R){let U=!1;const C=x(R);C===null?S(u,f):C&&C.isColor&&(S(C,1),U=!0);const F=o.xr.getEnvironmentBlendMode();F==="additive"?n.buffers.color.setClear(0,0,0,1,l):F==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,l),(o.autoClear||U)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),o.clear(o.autoClearColor,o.autoClearDepth,o.autoClearStencil))}function E(R,U){const C=x(U);C&&(C.isCubeTexture||C.mapping===Ad)?(p===void 0&&(p=new nr(new Qu(1,1,1),new Va({name:"BackgroundCubeMaterial",uniforms:hc(hr.backgroundCube.uniforms),vertexShader:hr.backgroundCube.vertexShader,fragmentShader:hr.backgroundCube.fragmentShader,side:$i,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),p.geometry.deleteAttribute("normal"),p.geometry.deleteAttribute("uv"),p.onBeforeRender=function(F,O,D){this.matrixWorld.copyPosition(D.matrixWorld)},Object.defineProperty(p.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),a.update(p)),p.material.uniforms.envMap.value=C,p.material.uniforms.backgroundBlurriness.value=U.backgroundBlurriness,p.material.uniforms.backgroundIntensity.value=U.backgroundIntensity,p.material.uniforms.backgroundRotation.value.setFromMatrix4(hD.makeRotationFromEuler(U.backgroundRotation)).transpose(),C.isCubeTexture&&C.isRenderTargetTexture===!1&&p.material.uniforms.backgroundRotation.value.premultiply(oE),p.material.toneMapped=Xt.getTransfer(C.colorSpace)!==cn,(_!==C||v!==C.version||g!==o.toneMapping)&&(p.material.needsUpdate=!0,_=C,v=C.version,g=o.toneMapping),p.layers.enableAll(),R.unshift(p,p.geometry,p.material,0,0,null)):C&&C.isTexture&&(d===void 0&&(d=new nr(new Cd(2,2),new Va({name:"BackgroundMaterial",uniforms:hc(hr.background.uniforms),vertexShader:hr.background.vertexShader,fragmentShader:hr.background.fragmentShader,side:Qs,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1})),d.geometry.deleteAttribute("normal"),Object.defineProperty(d.material,"map",{get:function(){return this.uniforms.t2D.value}}),a.update(d)),d.material.uniforms.t2D.value=C,d.material.uniforms.backgroundIntensity.value=U.backgroundIntensity,d.material.toneMapped=Xt.getTransfer(C.colorSpace)!==cn,C.matrixAutoUpdate===!0&&C.updateMatrix(),d.material.uniforms.uvTransform.value.copy(C.matrix),(_!==C||v!==C.version||g!==o.toneMapping)&&(d.material.needsUpdate=!0,_=C,v=C.version,g=o.toneMapping),d.layers.enableAll(),R.unshift(d,d.geometry,d.material,0,0,null))}function S(R,U){R.getRGB(Gh,aE(o)),n.buffers.color.setClear(Gh.r,Gh.g,Gh.b,U,l)}function y(){p!==void 0&&(p.geometry.dispose(),p.material.dispose(),p=void 0),d!==void 0&&(d.geometry.dispose(),d.material.dispose(),d=void 0)}return{getClearColor:function(){return u},setClearColor:function(R,U=1){u.set(R),f=U,S(u,f)},getClearAlpha:function(){return f},setClearAlpha:function(R){f=R,S(u,f)},render:M,addToRenderList:E,dispose:y}}function pD(o,e){const n=o.getParameter(o.MAX_VERTEX_ATTRIBS),a={},r=g(null);let l=r,u=!1;function f(V,k,te,ie,W){let z=!1;const B=v(V,ie,te,k);l!==B&&(l=B,p(l.object)),z=x(V,ie,te,W),z&&M(V,ie,te,W),W!==null&&e.update(W,o.ELEMENT_ARRAY_BUFFER),(z||u)&&(u=!1,C(V,k,te,ie),W!==null&&o.bindBuffer(o.ELEMENT_ARRAY_BUFFER,e.get(W).buffer))}function d(){return o.createVertexArray()}function p(V){return o.bindVertexArray(V)}function _(V){return o.deleteVertexArray(V)}function v(V,k,te,ie){const W=ie.wireframe===!0;let z=a[k.id];z===void 0&&(z={},a[k.id]=z);const B=V.isInstancedMesh===!0?V.id:0;let J=z[B];J===void 0&&(J={},z[B]=J);let fe=J[te.id];fe===void 0&&(fe={},J[te.id]=fe);let G=fe[W];return G===void 0&&(G=g(d()),fe[W]=G),G}function g(V){const k=[],te=[],ie=[];for(let W=0;W<n;W++)k[W]=0,te[W]=0,ie[W]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:k,enabledAttributes:te,attributeDivisors:ie,object:V,attributes:{},index:null}}function x(V,k,te,ie){const W=l.attributes,z=k.attributes;let B=0;const J=te.getAttributes();for(const fe in J)if(J[fe].location>=0){const I=W[fe];let K=z[fe];if(K===void 0&&(fe==="instanceMatrix"&&V.instanceMatrix&&(K=V.instanceMatrix),fe==="instanceColor"&&V.instanceColor&&(K=V.instanceColor)),I===void 0||I.attribute!==K||K&&I.data!==K.data)return!0;B++}return l.attributesNum!==B||l.index!==ie}function M(V,k,te,ie){const W={},z=k.attributes;let B=0;const J=te.getAttributes();for(const fe in J)if(J[fe].location>=0){let I=z[fe];I===void 0&&(fe==="instanceMatrix"&&V.instanceMatrix&&(I=V.instanceMatrix),fe==="instanceColor"&&V.instanceColor&&(I=V.instanceColor));const K={};K.attribute=I,I&&I.data&&(K.data=I.data),W[fe]=K,B++}l.attributes=W,l.attributesNum=B,l.index=ie}function E(){const V=l.newAttributes;for(let k=0,te=V.length;k<te;k++)V[k]=0}function S(V){y(V,0)}function y(V,k){const te=l.newAttributes,ie=l.enabledAttributes,W=l.attributeDivisors;te[V]=1,ie[V]===0&&(o.enableVertexAttribArray(V),ie[V]=1),W[V]!==k&&(o.vertexAttribDivisor(V,k),W[V]=k)}function R(){const V=l.newAttributes,k=l.enabledAttributes;for(let te=0,ie=k.length;te<ie;te++)k[te]!==V[te]&&(o.disableVertexAttribArray(te),k[te]=0)}function U(V,k,te,ie,W,z,B){B===!0?o.vertexAttribIPointer(V,k,te,W,z):o.vertexAttribPointer(V,k,te,ie,W,z)}function C(V,k,te,ie){E();const W=ie.attributes,z=te.getAttributes(),B=k.defaultAttributeValues;for(const J in z){const fe=z[J];if(fe.location>=0){let G=W[J];if(G===void 0&&(J==="instanceMatrix"&&V.instanceMatrix&&(G=V.instanceMatrix),J==="instanceColor"&&V.instanceColor&&(G=V.instanceColor)),G!==void 0){const I=G.normalized,K=G.itemSize,Se=e.get(G);if(Se===void 0)continue;const be=Se.buffer,Ue=Se.type,ne=Se.bytesPerElement,xe=Ue===o.INT||Ue===o.UNSIGNED_INT||G.gpuType===bg;if(G.isInterleavedBufferAttribute){const Ee=G.data,Ie=Ee.stride,nt=G.offset;if(Ee.isInstancedInterleavedBuffer){for(let Ze=0;Ze<fe.locationSize;Ze++)y(fe.location+Ze,Ee.meshPerAttribute);V.isInstancedMesh!==!0&&ie._maxInstanceCount===void 0&&(ie._maxInstanceCount=Ee.meshPerAttribute*Ee.count)}else for(let Ze=0;Ze<fe.locationSize;Ze++)S(fe.location+Ze);o.bindBuffer(o.ARRAY_BUFFER,be);for(let Ze=0;Ze<fe.locationSize;Ze++)U(fe.location+Ze,K/fe.locationSize,Ue,I,Ie*ne,(nt+K/fe.locationSize*Ze)*ne,xe)}else{if(G.isInstancedBufferAttribute){for(let Ee=0;Ee<fe.locationSize;Ee++)y(fe.location+Ee,G.meshPerAttribute);V.isInstancedMesh!==!0&&ie._maxInstanceCount===void 0&&(ie._maxInstanceCount=G.meshPerAttribute*G.count)}else for(let Ee=0;Ee<fe.locationSize;Ee++)S(fe.location+Ee);o.bindBuffer(o.ARRAY_BUFFER,be);for(let Ee=0;Ee<fe.locationSize;Ee++)U(fe.location+Ee,K/fe.locationSize,Ue,I,K*ne,K/fe.locationSize*Ee*ne,xe)}}else if(B!==void 0){const I=B[J];if(I!==void 0)switch(I.length){case 2:o.vertexAttrib2fv(fe.location,I);break;case 3:o.vertexAttrib3fv(fe.location,I);break;case 4:o.vertexAttrib4fv(fe.location,I);break;default:o.vertexAttrib1fv(fe.location,I)}}}}R()}function F(){L();for(const V in a){const k=a[V];for(const te in k){const ie=k[te];for(const W in ie){const z=ie[W];for(const B in z)_(z[B].object),delete z[B];delete ie[W]}}delete a[V]}}function O(V){if(a[V.id]===void 0)return;const k=a[V.id];for(const te in k){const ie=k[te];for(const W in ie){const z=ie[W];for(const B in z)_(z[B].object),delete z[B];delete ie[W]}}delete a[V.id]}function D(V){for(const k in a){const te=a[k];for(const ie in te){const W=te[ie];if(W[V.id]===void 0)continue;const z=W[V.id];for(const B in z)_(z[B].object),delete z[B];delete W[V.id]}}}function T(V){for(const k in a){const te=a[k],ie=V.isInstancedMesh===!0?V.id:0,W=te[ie];if(W!==void 0){for(const z in W){const B=W[z];for(const J in B)_(B[J].object),delete B[J];delete W[z]}delete te[ie],Object.keys(te).length===0&&delete a[k]}}}function L(){H(),u=!0,l!==r&&(l=r,p(l.object))}function H(){r.geometry=null,r.program=null,r.wireframe=!1}return{setup:f,reset:L,resetDefaultState:H,dispose:F,releaseStatesOfGeometry:O,releaseStatesOfObject:T,releaseStatesOfProgram:D,initAttributes:E,enableAttribute:S,disableUnusedAttributes:R}}function mD(o,e,n){let a;function r(d){a=d}function l(d,p){o.drawArrays(a,d,p),n.update(p,a,1)}function u(d,p,_){_!==0&&(o.drawArraysInstanced(a,d,p,_),n.update(p,a,_))}function f(d,p,_){if(_===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(a,d,0,p,0,_);let g=0;for(let x=0;x<_;x++)g+=p[x];n.update(g,a,1)}this.setMode=r,this.render=l,this.renderInstances=u,this.renderMultiDraw=f}function _D(o,e,n,a){let r;function l(){if(r!==void 0)return r;if(e.has("EXT_texture_filter_anisotropic")===!0){const D=e.get("EXT_texture_filter_anisotropic");r=o.getParameter(D.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else r=0;return r}function u(D){return!(D!==er&&a.convert(D)!==o.getParameter(o.IMPLEMENTATION_COLOR_READ_FORMAT))}function f(D){const T=D===as&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(D!==Ia&&a.convert(D)!==o.getParameter(o.IMPLEMENTATION_COLOR_READ_TYPE)&&D!==_r&&!T)}function d(D){if(D==="highp"){if(o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.HIGH_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.HIGH_FLOAT).precision>0)return"highp";D="mediump"}return D==="mediump"&&o.getShaderPrecisionFormat(o.VERTEX_SHADER,o.MEDIUM_FLOAT).precision>0&&o.getShaderPrecisionFormat(o.FRAGMENT_SHADER,o.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let p=n.precision!==void 0?n.precision:"highp";const _=d(p);_!==p&&(_t("WebGLRenderer:",p,"not supported, using",_,"instead."),p=_);const v=n.logarithmicDepthBuffer===!0,g=n.reversedDepthBuffer===!0&&e.has("EXT_clip_control");n.reversedDepthBuffer===!0&&g===!1&&_t("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer.");const x=o.getParameter(o.MAX_TEXTURE_IMAGE_UNITS),M=o.getParameter(o.MAX_VERTEX_TEXTURE_IMAGE_UNITS),E=o.getParameter(o.MAX_TEXTURE_SIZE),S=o.getParameter(o.MAX_CUBE_MAP_TEXTURE_SIZE),y=o.getParameter(o.MAX_VERTEX_ATTRIBS),R=o.getParameter(o.MAX_VERTEX_UNIFORM_VECTORS),U=o.getParameter(o.MAX_VARYING_VECTORS),C=o.getParameter(o.MAX_FRAGMENT_UNIFORM_VECTORS),F=o.getParameter(o.MAX_SAMPLES),O=o.getParameter(o.SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:l,getMaxPrecision:d,textureFormatReadable:u,textureTypeReadable:f,precision:p,logarithmicDepthBuffer:v,reversedDepthBuffer:g,maxTextures:x,maxVertexTextures:M,maxTextureSize:E,maxCubemapSize:S,maxAttributes:y,maxVertexUniforms:R,maxVaryings:U,maxFragmentUniforms:C,maxSamples:F,samples:O}}function gD(o){const e=this;let n=null,a=0,r=!1,l=!1;const u=new Ao,f=new Et,d={value:null,needsUpdate:!1};this.uniform=d,this.numPlanes=0,this.numIntersection=0,this.init=function(v,g){const x=v.length!==0||g||a!==0||r;return r=g,a=v.length,x},this.beginShadows=function(){l=!0,_(null)},this.endShadows=function(){l=!1},this.setGlobalState=function(v,g){n=_(v,g,0)},this.setState=function(v,g,x){const M=v.clippingPlanes,E=v.clipIntersection,S=v.clipShadows,y=o.get(v);if(!r||M===null||M.length===0||l&&!S)l?_(null):p();else{const R=l?0:a,U=R*4;let C=y.clippingState||null;d.value=C,C=_(M,g,U,x);for(let F=0;F!==U;++F)C[F]=n[F];y.clippingState=C,this.numIntersection=E?this.numPlanes:0,this.numPlanes+=R}};function p(){d.value!==n&&(d.value=n,d.needsUpdate=a>0),e.numPlanes=a,e.numIntersection=0}function _(v,g,x,M){const E=v!==null?v.length:0;let S=null;if(E!==0){if(S=d.value,M!==!0||S===null){const y=x+E*4,R=g.matrixWorldInverse;f.getNormalMatrix(R),(S===null||S.length<y)&&(S=new Float32Array(y));for(let U=0,C=x;U!==E;++U,C+=4)u.copy(v[U]).applyMatrix4(R,f),u.normal.toArray(S,C),S[C+3]=u.constant}d.value=S,d.needsUpdate=!0}return e.numPlanes=E,e.numIntersection=0,S}}const ks=4,IM=[.125,.215,.35,.446,.526,.582],Co=20,vD=256,hu=new Lg,BM=new pn;let R_=null,C_=0,w_=0,D_=!1;const xD=new ue;class HM{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null}fromScene(e,n=0,a=.1,r=100,l={}){const{size:u=256,position:f=xD}=l;R_=this._renderer.getRenderTarget(),C_=this._renderer.getActiveCubeFace(),w_=this._renderer.getActiveMipmapLevel(),D_=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(u);const d=this._allocateTargets();return d.depthBuffer=!0,this._sceneToCubeUV(e,a,r,d,f),n>0&&this._blur(d,0,0,n),this._applyPMREM(d),this._cleanup(d),d}fromEquirectangular(e,n=null){return this._fromTexture(e,n)}fromCubemap(e,n=null){return this._fromTexture(e,n)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=kM(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=VM(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose(),this._backgroundBox!==null&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._ggxMaterial!==null&&this._ggxMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodMeshes.length;e++)this._lodMeshes[e].geometry.dispose()}_cleanup(e){this._renderer.setRenderTarget(R_,C_,w_),this._renderer.xr.enabled=D_,e.scissorTest=!1,Vl(e,0,0,e.width,e.height)}_fromTexture(e,n){e.mapping===ko||e.mapping===uc?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),R_=this._renderer.getRenderTarget(),C_=this._renderer.getActiveCubeFace(),w_=this._renderer.getActiveMipmapLevel(),D_=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const a=n||this._allocateTargets();return this._textureToCubeUV(e,a),this._applyPMREM(a),this._cleanup(a),a}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),n=4*this._cubeSize,a={magFilter:Ci,minFilter:Ci,generateMipmaps:!1,type:as,format:er,colorSpace:gd,depthBuffer:!1},r=GM(e,n,a);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==n){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=GM(e,n,a);const{_lodMax:l}=this;({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=SD(l)),this._blurMaterial=MD(l,e,n),this._ggxMaterial=yD(l,e,n)}return r}_compileMaterial(e){const n=new nr(new br,e);this._renderer.compile(n,hu)}_sceneToCubeUV(e,n,a,r,l){const d=new Ja(90,1,n,a),p=[1,-1,1,1,1,1],_=[1,1,1,-1,-1,-1],v=this._renderer,g=v.autoClear,x=v.toneMapping;v.getClearColor(BM),v.toneMapping=xr,v.autoClear=!1,v.state.buffers.depth.getReversed()&&(v.setRenderTarget(r),v.clearDepth(),v.setRenderTarget(null)),this._backgroundBox===null&&(this._backgroundBox=new nr(new Qu,new eE({name:"PMREM.Background",side:$i,depthWrite:!1,depthTest:!1})));const E=this._backgroundBox,S=E.material;let y=!1;const R=e.background;R?R.isColor&&(S.color.copy(R),e.background=null,y=!0):(S.color.copy(BM),y=!0);for(let U=0;U<6;U++){const C=U%3;C===0?(d.up.set(0,p[U],0),d.position.set(l.x,l.y,l.z),d.lookAt(l.x+_[U],l.y,l.z)):C===1?(d.up.set(0,0,p[U]),d.position.set(l.x,l.y,l.z),d.lookAt(l.x,l.y+_[U],l.z)):(d.up.set(0,p[U],0),d.position.set(l.x,l.y,l.z),d.lookAt(l.x,l.y,l.z+_[U]));const F=this._cubeSize;Vl(r,C*F,U>2?F:0,F,F),v.setRenderTarget(r),y&&v.render(E,d),v.render(e,d)}v.toneMapping=x,v.autoClear=g,e.background=R}_textureToCubeUV(e,n){const a=this._renderer,r=e.mapping===ko||e.mapping===uc;r?(this._cubemapMaterial===null&&(this._cubemapMaterial=kM()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=VM());const l=r?this._cubemapMaterial:this._equirectMaterial,u=this._lodMeshes[0];u.material=l;const f=l.uniforms;f.envMap.value=e;const d=this._cubeSize;Vl(n,0,0,3*d,2*d),a.setRenderTarget(n),a.render(u,hu)}_applyPMREM(e){const n=this._renderer,a=n.autoClear;n.autoClear=!1;const r=this._lodMeshes.length;for(let l=1;l<r;l++)this._applyGGXFilter(e,l-1,l);n.autoClear=a}_applyGGXFilter(e,n,a){const r=this._renderer,l=this._pingPongRenderTarget,u=this._ggxMaterial,f=this._lodMeshes[a];f.material=u;const d=u.uniforms,p=a/(this._lodMeshes.length-1),_=n/(this._lodMeshes.length-1),v=Math.sqrt(p*p-_*_),g=0+p*1.25,x=v*g,{_lodMax:M}=this,E=this._sizeLods[a],S=3*E*(a>M-ks?a-M+ks:0),y=4*(this._cubeSize-E);d.envMap.value=e.texture,d.roughness.value=x,d.mipInt.value=M-n,Vl(l,S,y,3*E,2*E),r.setRenderTarget(l),r.render(f,hu),d.envMap.value=l.texture,d.roughness.value=0,d.mipInt.value=M-a,Vl(e,S,y,3*E,2*E),r.setRenderTarget(e),r.render(f,hu)}_blur(e,n,a,r,l){const u=this._pingPongRenderTarget;this._halfBlur(e,u,n,a,r,"latitudinal",l),this._halfBlur(u,e,a,a,r,"longitudinal",l)}_halfBlur(e,n,a,r,l,u,f){const d=this._renderer,p=this._blurMaterial;u!=="latitudinal"&&u!=="longitudinal"&&jt("blur direction must be either latitudinal or longitudinal!");const _=3,v=this._lodMeshes[r];v.material=p;const g=p.uniforms,x=this._sizeLods[a]-1,M=isFinite(l)?Math.PI/(2*x):2*Math.PI/(2*Co-1),E=l/M,S=isFinite(l)?1+Math.floor(_*E):Co;S>Co&&_t(`sigmaRadians, ${l}, is too large and will clip, as it requested ${S} samples when the maximum is set to ${Co}`);const y=[];let R=0;for(let D=0;D<Co;++D){const T=D/E,L=Math.exp(-T*T/2);y.push(L),D===0?R+=L:D<S&&(R+=2*L)}for(let D=0;D<y.length;D++)y[D]=y[D]/R;g.envMap.value=e.texture,g.samples.value=S,g.weights.value=y,g.latitudinal.value=u==="latitudinal",f&&(g.poleAxis.value=f);const{_lodMax:U}=this;g.dTheta.value=M,g.mipInt.value=U-a;const C=this._sizeLods[r],F=3*C*(r>U-ks?r-U+ks:0),O=4*(this._cubeSize-C);Vl(n,F,O,3*C,2*C),d.setRenderTarget(n),d.render(v,hu)}}function SD(o){const e=[],n=[],a=[];let r=o;const l=o-ks+1+IM.length;for(let u=0;u<l;u++){const f=Math.pow(2,r);e.push(f);let d=1/f;u>o-ks?d=IM[u-o+ks-1]:u===0&&(d=0),n.push(d);const p=1/(f-2),_=-p,v=1+p,g=[_,_,v,_,v,v,_,_,v,v,_,v],x=6,M=6,E=3,S=2,y=1,R=new Float32Array(E*M*x),U=new Float32Array(S*M*x),C=new Float32Array(y*M*x);for(let O=0;O<x;O++){const D=O%3*2/3-1,T=O>2?0:-1,L=[D,T,0,D+2/3,T,0,D+2/3,T+1,0,D,T,0,D+2/3,T+1,0,D,T+1,0];R.set(L,E*M*O),U.set(g,S*M*O);const H=[O,O,O,O,O,O];C.set(H,y*M*O)}const F=new br;F.setAttribute("position",new tr(R,E)),F.setAttribute("uv",new tr(U,S)),F.setAttribute("faceIndex",new tr(C,y)),a.push(new nr(F,null)),r>ks&&r--}return{lodMeshes:a,sizeLods:e,sigmas:n}}function GM(o,e,n){const a=new Sr(o,e,n);return a.texture.mapping=Ad,a.texture.name="PMREM.cubeUv",a.scissorTest=!0,a}function Vl(o,e,n,a,r){o.viewport.set(e,n,a,r),o.scissor.set(e,n,a,r)}function yD(o,e,n){return new Va({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:vD,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${o}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:wd(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:$r,depthTest:!1,depthWrite:!1})}function MD(o,e,n){const a=new Float32Array(Co),r=new ue(0,1,0);return new Va({name:"SphericalGaussianBlur",defines:{n:Co,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/n,CUBEUV_MAX_MIP:`${o}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:a},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:r}},vertexShader:wd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:$r,depthTest:!1,depthWrite:!1})}function VM(){return new Va({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:wd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:$r,depthTest:!1,depthWrite:!1})}function kM(){return new Va({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:wd(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:$r,depthTest:!1,depthWrite:!1})}function wd(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}class lE extends Sr{constructor(e=1,n={}){super(e,e,n),this.isWebGLCubeRenderTarget=!0;const a={width:e,height:e,depth:1},r=[a,a,a,a,a,a];this.texture=new nE(r),this._setTextureOptions(n),this.texture.isRenderTargetTexture=!0}fromEquirectangularTexture(e,n){this.texture.type=n.type,this.texture.colorSpace=n.colorSpace,this.texture.generateMipmaps=n.generateMipmaps,this.texture.minFilter=n.minFilter,this.texture.magFilter=n.magFilter;const a={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},r=new Qu(5,5,5),l=new Va({name:"CubemapFromEquirect",uniforms:hc(a.uniforms),vertexShader:a.vertexShader,fragmentShader:a.fragmentShader,side:$i,blending:$r});l.uniforms.tEquirect.value=n;const u=new nr(r,l),f=n.minFilter;return n.minFilter===Uo&&(n.minFilter=Ci),new C2(1,10,this).update(e,u),n.minFilter=f,u.geometry.dispose(),u.material.dispose(),this}clear(e,n=!0,a=!0,r=!0){const l=e.getRenderTarget();for(let u=0;u<6;u++)e.setRenderTarget(this,u),e.clear(n,a,r);e.setRenderTarget(l)}}function bD(o){let e=new WeakMap,n=new WeakMap,a=null;function r(g,x=!1){return g==null?null:x?u(g):l(g)}function l(g){if(g&&g.isTexture){const x=g.mapping;if(x===e_||x===t_)if(e.has(g)){const M=e.get(g).texture;return f(M,g.mapping)}else{const M=g.image;if(M&&M.height>0){const E=new lE(M.height);return E.fromEquirectangularTexture(o,g),e.set(g,E),g.addEventListener("dispose",p),f(E.texture,g.mapping)}else return null}}return g}function u(g){if(g&&g.isTexture){const x=g.mapping,M=x===e_||x===t_,E=x===ko||x===uc;if(M||E){let S=n.get(g);const y=S!==void 0?S.texture.pmremVersion:0;if(g.isRenderTargetTexture&&g.pmremVersion!==y)return a===null&&(a=new HM(o)),S=M?a.fromEquirectangular(g,S):a.fromCubemap(g,S),S.texture.pmremVersion=g.pmremVersion,n.set(g,S),S.texture;if(S!==void 0)return S.texture;{const R=g.image;return M&&R&&R.height>0||E&&R&&d(R)?(a===null&&(a=new HM(o)),S=M?a.fromEquirectangular(g):a.fromCubemap(g),S.texture.pmremVersion=g.pmremVersion,n.set(g,S),g.addEventListener("dispose",_),S.texture):null}}}return g}function f(g,x){return x===e_?g.mapping=ko:x===t_&&(g.mapping=uc),g}function d(g){let x=0;const M=6;for(let E=0;E<M;E++)g[E]!==void 0&&x++;return x===M}function p(g){const x=g.target;x.removeEventListener("dispose",p);const M=e.get(x);M!==void 0&&(e.delete(x),M.dispose())}function _(g){const x=g.target;x.removeEventListener("dispose",_);const M=n.get(x);M!==void 0&&(n.delete(x),M.dispose())}function v(){e=new WeakMap,n=new WeakMap,a!==null&&(a.dispose(),a=null)}return{get:r,dispose:v}}function ED(o){const e={};function n(a){if(e[a]!==void 0)return e[a];const r=o.getExtension(a);return e[a]=r,r}return{has:function(a){return n(a)!==null},init:function(){n("EXT_color_buffer_float"),n("WEBGL_clip_cull_distance"),n("OES_texture_float_linear"),n("EXT_color_buffer_half_float"),n("WEBGL_multisampled_render_to_texture"),n("WEBGL_render_shared_exponent")},get:function(a){const r=n(a);return r===null&&W0("WebGLRenderer: "+a+" extension not supported."),r}}}function TD(o,e,n,a){const r={},l=new WeakMap;function u(v){const g=v.target;g.index!==null&&e.remove(g.index);for(const M in g.attributes)e.remove(g.attributes[M]);g.removeEventListener("dispose",u),delete r[g.id];const x=l.get(g);x&&(e.remove(x),l.delete(g)),a.releaseStatesOfGeometry(g),g.isInstancedBufferGeometry===!0&&delete g._maxInstanceCount,n.memory.geometries--}function f(v,g){return r[g.id]===!0||(g.addEventListener("dispose",u),r[g.id]=!0,n.memory.geometries++),g}function d(v){const g=v.attributes;for(const x in g)e.update(g[x],o.ARRAY_BUFFER)}function p(v){const g=[],x=v.index,M=v.attributes.position;let E=0;if(M===void 0)return;if(x!==null){const R=x.array;E=x.version;for(let U=0,C=R.length;U<C;U+=3){const F=R[U+0],O=R[U+1],D=R[U+2];g.push(F,O,O,D,D,F)}}else{const R=M.array;E=M.version;for(let U=0,C=R.length/3-1;U<C;U+=3){const F=U+0,O=U+1,D=U+2;g.push(F,O,O,D,D,F)}}const S=new(M.count>=65535?$b:Jb)(g,1);S.version=E;const y=l.get(v);y&&e.remove(y),l.set(v,S)}function _(v){const g=l.get(v);if(g){const x=v.index;x!==null&&g.version<x.version&&p(v)}else p(v);return l.get(v)}return{get:f,update:d,getWireframeAttribute:_}}function AD(o,e,n){let a;function r(v){a=v}let l,u;function f(v){l=v.type,u=v.bytesPerElement}function d(v,g){o.drawElements(a,g,l,v*u),n.update(g,a,1)}function p(v,g,x){x!==0&&(o.drawElementsInstanced(a,g,l,v*u,x),n.update(g,a,x))}function _(v,g,x){if(x===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(a,g,0,l,v,0,x);let E=0;for(let S=0;S<x;S++)E+=g[S];n.update(E,a,1)}this.setMode=r,this.setIndex=f,this.render=d,this.renderInstances=p,this.renderMultiDraw=_}function RD(o){const e={geometries:0,textures:0},n={frame:0,calls:0,triangles:0,points:0,lines:0};function a(l,u,f){switch(n.calls++,u){case o.TRIANGLES:n.triangles+=f*(l/3);break;case o.LINES:n.lines+=f*(l/2);break;case o.LINE_STRIP:n.lines+=f*(l-1);break;case o.LINE_LOOP:n.lines+=f*l;break;case o.POINTS:n.points+=f*l;break;default:jt("WebGLInfo: Unknown draw mode:",u);break}}function r(){n.calls=0,n.triangles=0,n.points=0,n.lines=0}return{memory:e,render:n,programs:null,autoReset:!0,reset:r,update:a}}function CD(o,e,n){const a=new WeakMap,r=new Vn;function l(u,f,d){const p=u.morphTargetInfluences,_=f.morphAttributes.position||f.morphAttributes.normal||f.morphAttributes.color,v=_!==void 0?_.length:0;let g=a.get(f);if(g===void 0||g.count!==v){let H=function(){T.dispose(),a.delete(f),f.removeEventListener("dispose",H)};var x=H;g!==void 0&&g.texture.dispose();const M=f.morphAttributes.position!==void 0,E=f.morphAttributes.normal!==void 0,S=f.morphAttributes.color!==void 0,y=f.morphAttributes.position||[],R=f.morphAttributes.normal||[],U=f.morphAttributes.color||[];let C=0;M===!0&&(C=1),E===!0&&(C=2),S===!0&&(C=3);let F=f.attributes.position.count*C,O=1;F>e.maxTextureSize&&(O=Math.ceil(F/e.maxTextureSize),F=e.maxTextureSize);const D=new Float32Array(F*O*4*v),T=new Zb(D,F,O,v);T.type=_r,T.needsUpdate=!0;const L=C*4;for(let V=0;V<v;V++){const k=y[V],te=R[V],ie=U[V],W=F*O*4*V;for(let z=0;z<k.count;z++){const B=z*L;M===!0&&(r.fromBufferAttribute(k,z),D[W+B+0]=r.x,D[W+B+1]=r.y,D[W+B+2]=r.z,D[W+B+3]=0),E===!0&&(r.fromBufferAttribute(te,z),D[W+B+4]=r.x,D[W+B+5]=r.y,D[W+B+6]=r.z,D[W+B+7]=0),S===!0&&(r.fromBufferAttribute(ie,z),D[W+B+8]=r.x,D[W+B+9]=r.y,D[W+B+10]=r.z,D[W+B+11]=ie.itemSize===4?r.w:1)}}g={count:v,texture:T,size:new Jt(F,O)},a.set(f,g),f.addEventListener("dispose",H)}if(u.isInstancedMesh===!0&&u.morphTexture!==null)d.getUniforms().setValue(o,"morphTexture",u.morphTexture,n);else{let M=0;for(let S=0;S<p.length;S++)M+=p[S];const E=f.morphTargetsRelative?1:1-M;d.getUniforms().setValue(o,"morphTargetBaseInfluence",E),d.getUniforms().setValue(o,"morphTargetInfluences",p)}d.getUniforms().setValue(o,"morphTargetsTexture",g.texture,n),d.getUniforms().setValue(o,"morphTargetsTextureSize",g.size)}return{update:l}}function wD(o,e,n,a,r){let l=new WeakMap;function u(p){const _=r.render.frame,v=p.geometry,g=e.get(p,v);if(l.get(g)!==_&&(e.update(g),l.set(g,_)),p.isInstancedMesh&&(p.hasEventListener("dispose",d)===!1&&p.addEventListener("dispose",d),l.get(p)!==_&&(n.update(p.instanceMatrix,o.ARRAY_BUFFER),p.instanceColor!==null&&n.update(p.instanceColor,o.ARRAY_BUFFER),l.set(p,_))),p.isSkinnedMesh){const x=p.skeleton;l.get(x)!==_&&(x.update(),l.set(x,_))}return g}function f(){l=new WeakMap}function d(p){const _=p.target;_.removeEventListener("dispose",d),a.releaseStatesOfObject(_),n.remove(_.instanceMatrix),_.instanceColor!==null&&n.remove(_.instanceColor)}return{update:u,dispose:f}}const DD={[Lb]:"LINEAR_TONE_MAPPING",[Ob]:"REINHARD_TONE_MAPPING",[Pb]:"CINEON_TONE_MAPPING",[Fb]:"ACES_FILMIC_TONE_MAPPING",[Ib]:"AGX_TONE_MAPPING",[Bb]:"NEUTRAL_TONE_MAPPING",[zb]:"CUSTOM_TONE_MAPPING"};function UD(o,e,n,a,r){const l=new Sr(e,n,{type:o,depthBuffer:a,stencilBuffer:r,depthTexture:a?new fc(e,n):void 0}),u=new Sr(e,n,{type:as,depthBuffer:!1,stencilBuffer:!1}),f=new br;f.setAttribute("position",new ts([-1,3,0,-1,-1,0,3,-1,0],3)),f.setAttribute("uv",new ts([0,2,0,0,2,0],2));const d=new T2({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),p=new nr(f,d),_=new Lg(-1,1,1,-1,0,1);let v=null,g=null,x=!1,M,E=null,S=[],y=!1;this.setSize=function(R,U){l.setSize(R,U),u.setSize(R,U);for(let C=0;C<S.length;C++){const F=S[C];F.setSize&&F.setSize(R,U)}},this.setEffects=function(R){S=R,y=S.length>0&&S[0].isRenderPass===!0;const U=l.width,C=l.height;for(let F=0;F<S.length;F++){const O=S[F];O.setSize&&O.setSize(U,C)}},this.begin=function(R,U){if(x||R.toneMapping===xr&&S.length===0)return!1;if(E=U,U!==null){const C=U.width,F=U.height;(l.width!==C||l.height!==F)&&this.setSize(C,F)}return y===!1&&R.setRenderTarget(l),M=R.toneMapping,R.toneMapping=xr,!0},this.hasRenderPass=function(){return y},this.end=function(R,U){R.toneMapping=M,x=!0;let C=l,F=u;for(let O=0;O<S.length;O++){const D=S[O];if(D.enabled!==!1&&(D.render(R,F,C,U),D.needsSwap!==!1)){const T=C;C=F,F=T}}if(v!==R.outputColorSpace||g!==R.toneMapping){v=R.outputColorSpace,g=R.toneMapping,d.defines={},Xt.getTransfer(v)===cn&&(d.defines.SRGB_TRANSFER="");const O=DD[g];O&&(d.defines[O]=""),d.needsUpdate=!0}d.uniforms.tDiffuse.value=C.texture,R.setRenderTarget(E),R.render(p,_),E=null,x=!1},this.isCompositing=function(){return x},this.dispose=function(){l.depthTexture&&l.depthTexture.dispose(),l.dispose(),u.dispose(),f.dispose(),d.dispose()}}const cE=new Bi,Y0=new fc(1,1),uE=new Zb,fE=new n2,hE=new nE,XM=[],WM=[],qM=new Float32Array(16),YM=new Float32Array(9),jM=new Float32Array(4);function pc(o,e,n){const a=o[0];if(a<=0||a>0)return o;const r=e*n;let l=XM[r];if(l===void 0&&(l=new Float32Array(r),XM[r]=l),e!==0){a.toArray(l,0);for(let u=1,f=0;u!==e;++u)f+=n,o[u].toArray(l,f)}return l}function ai(o,e){if(o.length!==e.length)return!1;for(let n=0,a=o.length;n<a;n++)if(o[n]!==e[n])return!1;return!0}function ri(o,e){for(let n=0,a=e.length;n<a;n++)o[n]=e[n]}function Dd(o,e){let n=WM[e];n===void 0&&(n=new Int32Array(e),WM[e]=n);for(let a=0;a!==e;++a)n[a]=o.allocateTextureUnit();return n}function ND(o,e){const n=this.cache;n[0]!==e&&(o.uniform1f(this.addr,e),n[0]=e)}function LD(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(o.uniform2f(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if(ai(n,e))return;o.uniform2fv(this.addr,e),ri(n,e)}}function OD(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(o.uniform3f(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else if(e.r!==void 0)(n[0]!==e.r||n[1]!==e.g||n[2]!==e.b)&&(o.uniform3f(this.addr,e.r,e.g,e.b),n[0]=e.r,n[1]=e.g,n[2]=e.b);else{if(ai(n,e))return;o.uniform3fv(this.addr,e),ri(n,e)}}function PD(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(o.uniform4f(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if(ai(n,e))return;o.uniform4fv(this.addr,e),ri(n,e)}}function FD(o,e){const n=this.cache,a=e.elements;if(a===void 0){if(ai(n,e))return;o.uniformMatrix2fv(this.addr,!1,e),ri(n,e)}else{if(ai(n,a))return;jM.set(a),o.uniformMatrix2fv(this.addr,!1,jM),ri(n,a)}}function zD(o,e){const n=this.cache,a=e.elements;if(a===void 0){if(ai(n,e))return;o.uniformMatrix3fv(this.addr,!1,e),ri(n,e)}else{if(ai(n,a))return;YM.set(a),o.uniformMatrix3fv(this.addr,!1,YM),ri(n,a)}}function ID(o,e){const n=this.cache,a=e.elements;if(a===void 0){if(ai(n,e))return;o.uniformMatrix4fv(this.addr,!1,e),ri(n,e)}else{if(ai(n,a))return;qM.set(a),o.uniformMatrix4fv(this.addr,!1,qM),ri(n,a)}}function BD(o,e){const n=this.cache;n[0]!==e&&(o.uniform1i(this.addr,e),n[0]=e)}function HD(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(o.uniform2i(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if(ai(n,e))return;o.uniform2iv(this.addr,e),ri(n,e)}}function GD(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(o.uniform3i(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else{if(ai(n,e))return;o.uniform3iv(this.addr,e),ri(n,e)}}function VD(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(o.uniform4i(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if(ai(n,e))return;o.uniform4iv(this.addr,e),ri(n,e)}}function kD(o,e){const n=this.cache;n[0]!==e&&(o.uniform1ui(this.addr,e),n[0]=e)}function XD(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y)&&(o.uniform2ui(this.addr,e.x,e.y),n[0]=e.x,n[1]=e.y);else{if(ai(n,e))return;o.uniform2uiv(this.addr,e),ri(n,e)}}function WD(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z)&&(o.uniform3ui(this.addr,e.x,e.y,e.z),n[0]=e.x,n[1]=e.y,n[2]=e.z);else{if(ai(n,e))return;o.uniform3uiv(this.addr,e),ri(n,e)}}function qD(o,e){const n=this.cache;if(e.x!==void 0)(n[0]!==e.x||n[1]!==e.y||n[2]!==e.z||n[3]!==e.w)&&(o.uniform4ui(this.addr,e.x,e.y,e.z,e.w),n[0]=e.x,n[1]=e.y,n[2]=e.z,n[3]=e.w);else{if(ai(n,e))return;o.uniform4uiv(this.addr,e),ri(n,e)}}function YD(o,e,n){const a=this.cache,r=n.allocateTextureUnit();a[0]!==r&&(o.uniform1i(this.addr,r),a[0]=r);let l;this.type===o.SAMPLER_2D_SHADOW?(Y0.compareFunction=n.isReversedDepthBuffer()?Dg:wg,l=Y0):l=cE,n.setTexture2D(e||l,r)}function jD(o,e,n){const a=this.cache,r=n.allocateTextureUnit();a[0]!==r&&(o.uniform1i(this.addr,r),a[0]=r),n.setTexture3D(e||fE,r)}function ZD(o,e,n){const a=this.cache,r=n.allocateTextureUnit();a[0]!==r&&(o.uniform1i(this.addr,r),a[0]=r),n.setTextureCube(e||hE,r)}function KD(o,e,n){const a=this.cache,r=n.allocateTextureUnit();a[0]!==r&&(o.uniform1i(this.addr,r),a[0]=r),n.setTexture2DArray(e||uE,r)}function QD(o){switch(o){case 5126:return ND;case 35664:return LD;case 35665:return OD;case 35666:return PD;case 35674:return FD;case 35675:return zD;case 35676:return ID;case 5124:case 35670:return BD;case 35667:case 35671:return HD;case 35668:case 35672:return GD;case 35669:case 35673:return VD;case 5125:return kD;case 36294:return XD;case 36295:return WD;case 36296:return qD;case 35678:case 36198:case 36298:case 36306:case 35682:return YD;case 35679:case 36299:case 36307:return jD;case 35680:case 36300:case 36308:case 36293:return ZD;case 36289:case 36303:case 36311:case 36292:return KD}}function JD(o,e){o.uniform1fv(this.addr,e)}function $D(o,e){const n=pc(e,this.size,2);o.uniform2fv(this.addr,n)}function eU(o,e){const n=pc(e,this.size,3);o.uniform3fv(this.addr,n)}function tU(o,e){const n=pc(e,this.size,4);o.uniform4fv(this.addr,n)}function nU(o,e){const n=pc(e,this.size,4);o.uniformMatrix2fv(this.addr,!1,n)}function iU(o,e){const n=pc(e,this.size,9);o.uniformMatrix3fv(this.addr,!1,n)}function aU(o,e){const n=pc(e,this.size,16);o.uniformMatrix4fv(this.addr,!1,n)}function rU(o,e){o.uniform1iv(this.addr,e)}function sU(o,e){o.uniform2iv(this.addr,e)}function oU(o,e){o.uniform3iv(this.addr,e)}function lU(o,e){o.uniform4iv(this.addr,e)}function cU(o,e){o.uniform1uiv(this.addr,e)}function uU(o,e){o.uniform2uiv(this.addr,e)}function fU(o,e){o.uniform3uiv(this.addr,e)}function hU(o,e){o.uniform4uiv(this.addr,e)}function dU(o,e,n){const a=this.cache,r=e.length,l=Dd(n,r);ai(a,l)||(o.uniform1iv(this.addr,l),ri(a,l));let u;this.type===o.SAMPLER_2D_SHADOW?u=Y0:u=cE;for(let f=0;f!==r;++f)n.setTexture2D(e[f]||u,l[f])}function pU(o,e,n){const a=this.cache,r=e.length,l=Dd(n,r);ai(a,l)||(o.uniform1iv(this.addr,l),ri(a,l));for(let u=0;u!==r;++u)n.setTexture3D(e[u]||fE,l[u])}function mU(o,e,n){const a=this.cache,r=e.length,l=Dd(n,r);ai(a,l)||(o.uniform1iv(this.addr,l),ri(a,l));for(let u=0;u!==r;++u)n.setTextureCube(e[u]||hE,l[u])}function _U(o,e,n){const a=this.cache,r=e.length,l=Dd(n,r);ai(a,l)||(o.uniform1iv(this.addr,l),ri(a,l));for(let u=0;u!==r;++u)n.setTexture2DArray(e[u]||uE,l[u])}function gU(o){switch(o){case 5126:return JD;case 35664:return $D;case 35665:return eU;case 35666:return tU;case 35674:return nU;case 35675:return iU;case 35676:return aU;case 5124:case 35670:return rU;case 35667:case 35671:return sU;case 35668:case 35672:return oU;case 35669:case 35673:return lU;case 5125:return cU;case 36294:return uU;case 36295:return fU;case 36296:return hU;case 35678:case 36198:case 36298:case 36306:case 35682:return dU;case 35679:case 36299:case 36307:return pU;case 35680:case 36300:case 36308:case 36293:return mU;case 36289:case 36303:case 36311:case 36292:return _U}}class vU{constructor(e,n,a){this.id=e,this.addr=a,this.cache=[],this.type=n.type,this.setValue=QD(n.type)}}class xU{constructor(e,n,a){this.id=e,this.addr=a,this.cache=[],this.type=n.type,this.size=n.size,this.setValue=gU(n.type)}}class SU{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,n,a){const r=this.seq;for(let l=0,u=r.length;l!==u;++l){const f=r[l];f.setValue(e,n[f.id],a)}}}const U_=/(\w+)(\])?(\[|\.)?/g;function ZM(o,e){o.seq.push(e),o.map[e.id]=e}function yU(o,e,n){const a=o.name,r=a.length;for(U_.lastIndex=0;;){const l=U_.exec(a),u=U_.lastIndex;let f=l[1];const d=l[2]==="]",p=l[3];if(d&&(f=f|0),p===void 0||p==="["&&u+2===r){ZM(n,p===void 0?new vU(f,o,e):new xU(f,o,e));break}else{let v=n.map[f];v===void 0&&(v=new SU(f),ZM(n,v)),n=v}}}class id{constructor(e,n){this.seq=[],this.map={};const a=e.getProgramParameter(n,e.ACTIVE_UNIFORMS);for(let u=0;u<a;++u){const f=e.getActiveUniform(n,u),d=e.getUniformLocation(n,f.name);yU(f,d,this)}const r=[],l=[];for(const u of this.seq)u.type===e.SAMPLER_2D_SHADOW||u.type===e.SAMPLER_CUBE_SHADOW||u.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(u):l.push(u);r.length>0&&(this.seq=r.concat(l))}setValue(e,n,a,r){const l=this.map[n];l!==void 0&&l.setValue(e,a,r)}setOptional(e,n,a){const r=n[a];r!==void 0&&this.setValue(e,a,r)}static upload(e,n,a,r){for(let l=0,u=n.length;l!==u;++l){const f=n[l],d=a[f.id];d.needsUpdate!==!1&&f.setValue(e,d.value,r)}}static seqWithValue(e,n){const a=[];for(let r=0,l=e.length;r!==l;++r){const u=e[r];u.id in n&&a.push(u)}return a}}function KM(o,e,n){const a=o.createShader(e);return o.shaderSource(a,n),o.compileShader(a),a}const MU=37297;let bU=0;function EU(o,e){const n=o.split(`
`),a=[],r=Math.max(e-6,0),l=Math.min(e+6,n.length);for(let u=r;u<l;u++){const f=u+1;a.push(`${f===e?">":" "} ${f}: ${n[u]}`)}return a.join(`
`)}const QM=new Et;function TU(o){Xt._getMatrix(QM,Xt.workingColorSpace,o);const e=`mat3( ${QM.elements.map(n=>n.toFixed(4))} )`;switch(Xt.getTransfer(o)){case vd:return[e,"LinearTransferOETF"];case cn:return[e,"sRGBTransferOETF"];default:return _t("WebGLProgram: Unsupported color space: ",o),[e,"LinearTransferOETF"]}}function JM(o,e,n){const a=o.getShaderParameter(e,o.COMPILE_STATUS),l=(o.getShaderInfoLog(e)||"").trim();if(a&&l==="")return"";const u=/ERROR: 0:(\d+)/.exec(l);if(u){const f=parseInt(u[1]);return n.toUpperCase()+`

`+l+`

`+EU(o.getShaderSource(e),f)}else return l}function AU(o,e){const n=TU(e);return[`vec4 ${o}( vec4 value ) {`,`	return ${n[1]}( vec4( value.rgb * ${n[0]}, value.a ) );`,"}"].join(`
`)}const RU={[Lb]:"Linear",[Ob]:"Reinhard",[Pb]:"Cineon",[Fb]:"ACESFilmic",[Ib]:"AgX",[Bb]:"Neutral",[zb]:"Custom"};function CU(o,e){const n=RU[e];return n===void 0?(_t("WebGLProgram: Unsupported toneMapping:",e),"vec3 "+o+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+o+"( vec3 color ) { return "+n+"ToneMapping( color ); }"}const Vh=new ue;function wU(){Xt.getLuminanceCoefficients(Vh);const o=Vh.x.toFixed(4),e=Vh.y.toFixed(4),n=Vh.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${o}, ${e}, ${n} );`,"	return dot( weights, rgb );","}"].join(`
`)}function DU(o){return[o.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",o.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(bu).join(`
`)}function UU(o){const e=[];for(const n in o){const a=o[n];a!==!1&&e.push("#define "+n+" "+a)}return e.join(`
`)}function NU(o,e){const n={},a=o.getProgramParameter(e,o.ACTIVE_ATTRIBUTES);for(let r=0;r<a;r++){const l=o.getActiveAttrib(e,r),u=l.name;let f=1;l.type===o.FLOAT_MAT2&&(f=2),l.type===o.FLOAT_MAT3&&(f=3),l.type===o.FLOAT_MAT4&&(f=4),n[u]={type:l.type,location:o.getAttribLocation(e,u),locationSize:f}}return n}function bu(o){return o!==""}function $M(o,e){const n=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return o.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,n).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function e1(o,e){return o.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const LU=/^[ \t]*#include +<([\w\d./]+)>/gm;function j0(o){return o.replace(LU,PU)}const OU=new Map;function PU(o,e){let n=Nt[e];if(n===void 0){const a=OU.get(e);if(a!==void 0)n=Nt[a],_t('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,a);else throw new Error("Can not resolve #include <"+e+">")}return j0(n)}const FU=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function t1(o){return o.replace(FU,zU)}function zU(o,e,n,a){let r="";for(let l=parseInt(e);l<parseInt(n);l++)r+=a.replace(/\[\s*i\s*\]/g,"[ "+l+" ]").replace(/UNROLLED_LOOP_INDEX/g,l);return r}function n1(o){let e=`precision ${o.precision} float;
	precision ${o.precision} int;
	precision ${o.precision} sampler2D;
	precision ${o.precision} samplerCube;
	precision ${o.precision} sampler3D;
	precision ${o.precision} sampler2DArray;
	precision ${o.precision} sampler2DShadow;
	precision ${o.precision} samplerCubeShadow;
	precision ${o.precision} sampler2DArrayShadow;
	precision ${o.precision} isampler2D;
	precision ${o.precision} isampler3D;
	precision ${o.precision} isamplerCube;
	precision ${o.precision} isampler2DArray;
	precision ${o.precision} usampler2D;
	precision ${o.precision} usampler3D;
	precision ${o.precision} usamplerCube;
	precision ${o.precision} usampler2DArray;
	`;return o.precision==="highp"?e+=`
#define HIGH_PRECISION`:o.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:o.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}const IU={[Jh]:"SHADOWMAP_TYPE_PCF",[Mu]:"SHADOWMAP_TYPE_VSM"};function BU(o){return IU[o.shadowMapType]||"SHADOWMAP_TYPE_BASIC"}const HU={[ko]:"ENVMAP_TYPE_CUBE",[uc]:"ENVMAP_TYPE_CUBE",[Ad]:"ENVMAP_TYPE_CUBE_UV"};function GU(o){return o.envMap===!1?"ENVMAP_TYPE_CUBE":HU[o.envMapMode]||"ENVMAP_TYPE_CUBE"}const VU={[uc]:"ENVMAP_MODE_REFRACTION"};function kU(o){return o.envMap===!1?"ENVMAP_MODE_REFLECTION":VU[o.envMapMode]||"ENVMAP_MODE_REFLECTION"}const XU={[Nb]:"ENVMAP_BLENDING_MULTIPLY",[PC]:"ENVMAP_BLENDING_MIX",[FC]:"ENVMAP_BLENDING_ADD"};function WU(o){return o.envMap===!1?"ENVMAP_BLENDING_NONE":XU[o.combine]||"ENVMAP_BLENDING_NONE"}function qU(o){const e=o.envMapCubeUVHeight;if(e===null)return null;const n=Math.log2(e)-2,a=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,n),112)),texelHeight:a,maxMip:n}}function YU(o,e,n,a){const r=o.getContext(),l=n.defines;let u=n.vertexShader,f=n.fragmentShader;const d=BU(n),p=GU(n),_=kU(n),v=WU(n),g=qU(n),x=DU(n),M=UU(l),E=r.createProgram();let S,y,R=n.glslVersion?"#version "+n.glslVersion+`
`:"";n.isRawShaderMaterial?(S=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,M].filter(bu).join(`
`),S.length>0&&(S+=`
`),y=["#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,M].filter(bu).join(`
`),y.length>0&&(y+=`
`)):(S=[n1(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,M,n.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",n.batching?"#define USE_BATCHING":"",n.batchingColor?"#define USE_BATCHING_COLOR":"",n.instancing?"#define USE_INSTANCING":"",n.instancingColor?"#define USE_INSTANCING_COLOR":"",n.instancingMorph?"#define USE_INSTANCING_MORPH":"",n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.map?"#define USE_MAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+_:"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.displacementMap?"#define USE_DISPLACEMENTMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.mapUv?"#define MAP_UV "+n.mapUv:"",n.alphaMapUv?"#define ALPHAMAP_UV "+n.alphaMapUv:"",n.lightMapUv?"#define LIGHTMAP_UV "+n.lightMapUv:"",n.aoMapUv?"#define AOMAP_UV "+n.aoMapUv:"",n.emissiveMapUv?"#define EMISSIVEMAP_UV "+n.emissiveMapUv:"",n.bumpMapUv?"#define BUMPMAP_UV "+n.bumpMapUv:"",n.normalMapUv?"#define NORMALMAP_UV "+n.normalMapUv:"",n.displacementMapUv?"#define DISPLACEMENTMAP_UV "+n.displacementMapUv:"",n.metalnessMapUv?"#define METALNESSMAP_UV "+n.metalnessMapUv:"",n.roughnessMapUv?"#define ROUGHNESSMAP_UV "+n.roughnessMapUv:"",n.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+n.anisotropyMapUv:"",n.clearcoatMapUv?"#define CLEARCOATMAP_UV "+n.clearcoatMapUv:"",n.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+n.clearcoatNormalMapUv:"",n.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+n.clearcoatRoughnessMapUv:"",n.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+n.iridescenceMapUv:"",n.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+n.iridescenceThicknessMapUv:"",n.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+n.sheenColorMapUv:"",n.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+n.sheenRoughnessMapUv:"",n.specularMapUv?"#define SPECULARMAP_UV "+n.specularMapUv:"",n.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+n.specularColorMapUv:"",n.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+n.specularIntensityMapUv:"",n.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+n.transmissionMapUv:"",n.thicknessMapUv?"#define THICKNESSMAP_UV "+n.thicknessMapUv:"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexNormals?"#define HAS_NORMAL":"",n.vertexColors?"#define USE_COLOR":"",n.vertexAlphas?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.flatShading?"#define FLAT_SHADED":"",n.skinning?"#define USE_SKINNING":"",n.morphTargets?"#define USE_MORPHTARGETS":"",n.morphNormals&&n.flatShading===!1?"#define USE_MORPHNORMALS":"",n.morphColors?"#define USE_MORPHCOLORS":"",n.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+n.morphTextureStride:"",n.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+n.morphTargetsCount:"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+d:"",n.sizeAttenuation?"#define USE_SIZEATTENUATION":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(bu).join(`
`),y=[n1(n),"#define SHADER_TYPE "+n.shaderType,"#define SHADER_NAME "+n.shaderName,M,n.useFog&&n.fog?"#define USE_FOG":"",n.useFog&&n.fogExp2?"#define FOG_EXP2":"",n.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",n.map?"#define USE_MAP":"",n.matcap?"#define USE_MATCAP":"",n.envMap?"#define USE_ENVMAP":"",n.envMap?"#define "+p:"",n.envMap?"#define "+_:"",n.envMap?"#define "+v:"",g?"#define CUBEUV_TEXEL_WIDTH "+g.texelWidth:"",g?"#define CUBEUV_TEXEL_HEIGHT "+g.texelHeight:"",g?"#define CUBEUV_MAX_MIP "+g.maxMip+".0":"",n.lightMap?"#define USE_LIGHTMAP":"",n.aoMap?"#define USE_AOMAP":"",n.bumpMap?"#define USE_BUMPMAP":"",n.normalMap?"#define USE_NORMALMAP":"",n.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",n.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",n.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",n.emissiveMap?"#define USE_EMISSIVEMAP":"",n.anisotropy?"#define USE_ANISOTROPY":"",n.anisotropyMap?"#define USE_ANISOTROPYMAP":"",n.clearcoat?"#define USE_CLEARCOAT":"",n.clearcoatMap?"#define USE_CLEARCOATMAP":"",n.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",n.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",n.dispersion?"#define USE_DISPERSION":"",n.iridescence?"#define USE_IRIDESCENCE":"",n.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",n.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",n.specularMap?"#define USE_SPECULARMAP":"",n.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",n.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",n.roughnessMap?"#define USE_ROUGHNESSMAP":"",n.metalnessMap?"#define USE_METALNESSMAP":"",n.alphaMap?"#define USE_ALPHAMAP":"",n.alphaTest?"#define USE_ALPHATEST":"",n.alphaHash?"#define USE_ALPHAHASH":"",n.sheen?"#define USE_SHEEN":"",n.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",n.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",n.transmission?"#define USE_TRANSMISSION":"",n.transmissionMap?"#define USE_TRANSMISSIONMAP":"",n.thicknessMap?"#define USE_THICKNESSMAP":"",n.vertexTangents&&n.flatShading===!1?"#define USE_TANGENT":"",n.vertexColors||n.instancingColor?"#define USE_COLOR":"",n.vertexAlphas||n.batchingColor?"#define USE_COLOR_ALPHA":"",n.vertexUv1s?"#define USE_UV1":"",n.vertexUv2s?"#define USE_UV2":"",n.vertexUv3s?"#define USE_UV3":"",n.pointsUvs?"#define USE_POINTS_UV":"",n.gradientMap?"#define USE_GRADIENTMAP":"",n.flatShading?"#define FLAT_SHADED":"",n.doubleSided?"#define DOUBLE_SIDED":"",n.flipSided?"#define FLIP_SIDED":"",n.shadowMapEnabled?"#define USE_SHADOWMAP":"",n.shadowMapEnabled?"#define "+d:"",n.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",n.numLightProbes>0?"#define USE_LIGHT_PROBES":"",n.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",n.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",n.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",n.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",n.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",n.toneMapping!==xr?"#define TONE_MAPPING":"",n.toneMapping!==xr?Nt.tonemapping_pars_fragment:"",n.toneMapping!==xr?CU("toneMapping",n.toneMapping):"",n.dithering?"#define DITHERING":"",n.opaque?"#define OPAQUE":"",Nt.colorspace_pars_fragment,AU("linearToOutputTexel",n.outputColorSpace),wU(),n.useDepthPacking?"#define DEPTH_PACKING "+n.depthPacking:"",`
`].filter(bu).join(`
`)),u=j0(u),u=$M(u,n),u=e1(u,n),f=j0(f),f=$M(f,n),f=e1(f,n),u=t1(u),f=t1(f),n.isRawShaderMaterial!==!0&&(R=`#version 300 es
`,S=[x,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+S,y=["#define varying in",n.glslVersion===mM?"":"layout(location = 0) out highp vec4 pc_fragColor;",n.glslVersion===mM?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+y);const U=R+S+u,C=R+y+f,F=KM(r,r.VERTEX_SHADER,U),O=KM(r,r.FRAGMENT_SHADER,C);r.attachShader(E,F),r.attachShader(E,O),n.index0AttributeName!==void 0?r.bindAttribLocation(E,0,n.index0AttributeName):n.morphTargets===!0&&r.bindAttribLocation(E,0,"position"),r.linkProgram(E);function D(V){if(o.debug.checkShaderErrors){const k=r.getProgramInfoLog(E)||"",te=r.getShaderInfoLog(F)||"",ie=r.getShaderInfoLog(O)||"",W=k.trim(),z=te.trim(),B=ie.trim();let J=!0,fe=!0;if(r.getProgramParameter(E,r.LINK_STATUS)===!1)if(J=!1,typeof o.debug.onShaderError=="function")o.debug.onShaderError(r,E,F,O);else{const G=JM(r,F,"vertex"),I=JM(r,O,"fragment");jt("THREE.WebGLProgram: Shader Error "+r.getError()+" - VALIDATE_STATUS "+r.getProgramParameter(E,r.VALIDATE_STATUS)+`

Material Name: `+V.name+`
Material Type: `+V.type+`

Program Info Log: `+W+`
`+G+`
`+I)}else W!==""?_t("WebGLProgram: Program Info Log:",W):(z===""||B==="")&&(fe=!1);fe&&(V.diagnostics={runnable:J,programLog:W,vertexShader:{log:z,prefix:S},fragmentShader:{log:B,prefix:y}})}r.deleteShader(F),r.deleteShader(O),T=new id(r,E),L=NU(r,E)}let T;this.getUniforms=function(){return T===void 0&&D(this),T};let L;this.getAttributes=function(){return L===void 0&&D(this),L};let H=n.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return H===!1&&(H=r.getProgramParameter(E,MU)),H},this.destroy=function(){a.releaseStatesOfProgram(this),r.deleteProgram(E),this.program=void 0},this.type=n.shaderType,this.name=n.shaderName,this.id=bU++,this.cacheKey=e,this.usedTimes=1,this.program=E,this.vertexShader=F,this.fragmentShader=O,this}let jU=0;class ZU{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const n=e.vertexShader,a=e.fragmentShader,r=this._getShaderStage(n),l=this._getShaderStage(a),u=this._getShaderCacheForMaterial(e);return u.has(r)===!1&&(u.add(r),r.usedTimes++),u.has(l)===!1&&(u.add(l),l.usedTimes++),this}remove(e){const n=this.materialCache.get(e);for(const a of n)a.usedTimes--,a.usedTimes===0&&this.shaderCache.delete(a.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const n=this.materialCache;let a=n.get(e);return a===void 0&&(a=new Set,n.set(e,a)),a}_getShaderStage(e){const n=this.shaderCache;let a=n.get(e);return a===void 0&&(a=new KU(e),n.set(e,a)),a}}class KU{constructor(e){this.id=jU++,this.code=e,this.usedTimes=0}}function QU(o){return o===Xo||o===md||o===_d}function JU(o,e,n,a,r,l){const u=new Kb,f=new ZU,d=new Set,p=[],_=new Map,v=a.logarithmicDepthBuffer;let g=a.precision;const x={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function M(T){return d.add(T),T===0?"uv":`uv${T}`}function E(T,L,H,V,k,te){const ie=V.fog,W=k.geometry,z=T.isMeshStandardMaterial||T.isMeshLambertMaterial||T.isMeshPhongMaterial?V.environment:null,B=T.isMeshStandardMaterial||T.isMeshLambertMaterial&&!T.envMap||T.isMeshPhongMaterial&&!T.envMap,J=e.get(T.envMap||z,B),fe=J&&J.mapping===Ad?J.image.height:null,G=x[T.type];T.precision!==null&&(g=a.getMaxPrecision(T.precision),g!==T.precision&&_t("WebGLProgram.getParameters:",T.precision,"not supported, using",g,"instead."));const I=W.morphAttributes.position||W.morphAttributes.normal||W.morphAttributes.color,K=I!==void 0?I.length:0;let Se=0;W.morphAttributes.position!==void 0&&(Se=1),W.morphAttributes.normal!==void 0&&(Se=2),W.morphAttributes.color!==void 0&&(Se=3);let be,Ue,ne,xe;if(G){const Ne=hr[G];be=Ne.vertexShader,Ue=Ne.fragmentShader}else be=T.vertexShader,Ue=T.fragmentShader,f.update(T),ne=f.getVertexShaderID(T),xe=f.getFragmentShaderID(T);const Ee=o.getRenderTarget(),Ie=o.state.buffers.depth.getReversed(),nt=k.isInstancedMesh===!0,Ze=k.isBatchedMesh===!0,Mt=!!T.map,Ye=!!T.matcap,it=!!J,xt=!!T.aoMap,st=!!T.lightMap,le=!!T.bumpMap,Dt=!!T.normalMap,mn=!!T.displacementMap,j=!!T.emissiveMap,gt=!!T.metalnessMap,mt=!!T.roughnessMap,Ft=T.anisotropy>0,Le=T.clearcoat>0,bt=T.dispersion>0,P=T.iridescence>0,A=T.sheen>0,Q=T.transmission>0,_e=Ft&&!!T.anisotropyMap,Te=Le&&!!T.clearcoatMap,Fe=Le&&!!T.clearcoatNormalMap,De=Le&&!!T.clearcoatRoughnessMap,de=P&&!!T.iridescenceMap,pe=P&&!!T.iridescenceThicknessMap,Be=A&&!!T.sheenColorMap,He=A&&!!T.sheenRoughnessMap,ze=!!T.specularMap,Oe=!!T.specularColorMap,Ge=!!T.specularIntensityMap,ut=Q&&!!T.transmissionMap,dt=Q&&!!T.thicknessMap,q=!!T.gradientMap,Re=!!T.alphaMap,me=T.alphaTest>0,Ve=!!T.alphaHash,Pe=!!T.extensions;let Ae=xr;T.toneMapped&&(Ee===null||Ee.isXRRenderTarget===!0)&&(Ae=o.toneMapping);const Ce={shaderID:G,shaderType:T.type,shaderName:T.name,vertexShader:be,fragmentShader:Ue,defines:T.defines,customVertexShaderID:ne,customFragmentShaderID:xe,isRawShaderMaterial:T.isRawShaderMaterial===!0,glslVersion:T.glslVersion,precision:g,batching:Ze,batchingColor:Ze&&k._colorsTexture!==null,instancing:nt,instancingColor:nt&&k.instanceColor!==null,instancingMorph:nt&&k.morphTexture!==null,outputColorSpace:Ee===null?o.outputColorSpace:Ee.isXRRenderTarget===!0?Ee.texture.colorSpace:Xt.workingColorSpace,alphaToCoverage:!!T.alphaToCoverage,map:Mt,matcap:Ye,envMap:it,envMapMode:it&&J.mapping,envMapCubeUVHeight:fe,aoMap:xt,lightMap:st,bumpMap:le,normalMap:Dt,displacementMap:mn,emissiveMap:j,normalMapObjectSpace:Dt&&T.normalMapType===BC,normalMapTangentSpace:Dt&&T.normalMapType===hM,packedNormalMap:Dt&&T.normalMapType===hM&&QU(T.normalMap.format),metalnessMap:gt,roughnessMap:mt,anisotropy:Ft,anisotropyMap:_e,clearcoat:Le,clearcoatMap:Te,clearcoatNormalMap:Fe,clearcoatRoughnessMap:De,dispersion:bt,iridescence:P,iridescenceMap:de,iridescenceThicknessMap:pe,sheen:A,sheenColorMap:Be,sheenRoughnessMap:He,specularMap:ze,specularColorMap:Oe,specularIntensityMap:Ge,transmission:Q,transmissionMap:ut,thicknessMap:dt,gradientMap:q,opaque:T.transparent===!1&&T.blending===tc&&T.alphaToCoverage===!1,alphaMap:Re,alphaTest:me,alphaHash:Ve,combine:T.combine,mapUv:Mt&&M(T.map.channel),aoMapUv:xt&&M(T.aoMap.channel),lightMapUv:st&&M(T.lightMap.channel),bumpMapUv:le&&M(T.bumpMap.channel),normalMapUv:Dt&&M(T.normalMap.channel),displacementMapUv:mn&&M(T.displacementMap.channel),emissiveMapUv:j&&M(T.emissiveMap.channel),metalnessMapUv:gt&&M(T.metalnessMap.channel),roughnessMapUv:mt&&M(T.roughnessMap.channel),anisotropyMapUv:_e&&M(T.anisotropyMap.channel),clearcoatMapUv:Te&&M(T.clearcoatMap.channel),clearcoatNormalMapUv:Fe&&M(T.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:De&&M(T.clearcoatRoughnessMap.channel),iridescenceMapUv:de&&M(T.iridescenceMap.channel),iridescenceThicknessMapUv:pe&&M(T.iridescenceThicknessMap.channel),sheenColorMapUv:Be&&M(T.sheenColorMap.channel),sheenRoughnessMapUv:He&&M(T.sheenRoughnessMap.channel),specularMapUv:ze&&M(T.specularMap.channel),specularColorMapUv:Oe&&M(T.specularColorMap.channel),specularIntensityMapUv:Ge&&M(T.specularIntensityMap.channel),transmissionMapUv:ut&&M(T.transmissionMap.channel),thicknessMapUv:dt&&M(T.thicknessMap.channel),alphaMapUv:Re&&M(T.alphaMap.channel),vertexTangents:!!W.attributes.tangent&&(Dt||Ft),vertexNormals:!!W.attributes.normal,vertexColors:T.vertexColors,vertexAlphas:T.vertexColors===!0&&!!W.attributes.color&&W.attributes.color.itemSize===4,pointsUvs:k.isPoints===!0&&!!W.attributes.uv&&(Mt||Re),fog:!!ie,useFog:T.fog===!0,fogExp2:!!ie&&ie.isFogExp2,flatShading:T.wireframe===!1&&(T.flatShading===!0||W.attributes.normal===void 0&&Dt===!1&&(T.isMeshLambertMaterial||T.isMeshPhongMaterial||T.isMeshStandardMaterial||T.isMeshPhysicalMaterial)),sizeAttenuation:T.sizeAttenuation===!0,logarithmicDepthBuffer:v,reversedDepthBuffer:Ie,skinning:k.isSkinnedMesh===!0,morphTargets:W.morphAttributes.position!==void 0,morphNormals:W.morphAttributes.normal!==void 0,morphColors:W.morphAttributes.color!==void 0,morphTargetsCount:K,morphTextureStride:Se,numDirLights:L.directional.length,numPointLights:L.point.length,numSpotLights:L.spot.length,numSpotLightMaps:L.spotLightMap.length,numRectAreaLights:L.rectArea.length,numHemiLights:L.hemi.length,numDirLightShadows:L.directionalShadowMap.length,numPointLightShadows:L.pointShadowMap.length,numSpotLightShadows:L.spotShadowMap.length,numSpotLightShadowsWithMaps:L.numSpotLightShadowsWithMaps,numLightProbes:L.numLightProbes,numLightProbeGrids:te.length,numClippingPlanes:l.numPlanes,numClipIntersection:l.numIntersection,dithering:T.dithering,shadowMapEnabled:o.shadowMap.enabled&&H.length>0,shadowMapType:o.shadowMap.type,toneMapping:Ae,decodeVideoTexture:Mt&&T.map.isVideoTexture===!0&&Xt.getTransfer(T.map.colorSpace)===cn,decodeVideoTextureEmissive:j&&T.emissiveMap.isVideoTexture===!0&&Xt.getTransfer(T.emissiveMap.colorSpace)===cn,premultipliedAlpha:T.premultipliedAlpha,doubleSided:T.side===Zr,flipSided:T.side===$i,useDepthPacking:T.depthPacking>=0,depthPacking:T.depthPacking||0,index0AttributeName:T.index0AttributeName,extensionClipCullDistance:Pe&&T.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(Pe&&T.extensions.multiDraw===!0||Ze)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:T.customProgramCacheKey()};return Ce.vertexUv1s=d.has(1),Ce.vertexUv2s=d.has(2),Ce.vertexUv3s=d.has(3),d.clear(),Ce}function S(T){const L=[];if(T.shaderID?L.push(T.shaderID):(L.push(T.customVertexShaderID),L.push(T.customFragmentShaderID)),T.defines!==void 0)for(const H in T.defines)L.push(H),L.push(T.defines[H]);return T.isRawShaderMaterial===!1&&(y(L,T),R(L,T),L.push(o.outputColorSpace)),L.push(T.customProgramCacheKey),L.join()}function y(T,L){T.push(L.precision),T.push(L.outputColorSpace),T.push(L.envMapMode),T.push(L.envMapCubeUVHeight),T.push(L.mapUv),T.push(L.alphaMapUv),T.push(L.lightMapUv),T.push(L.aoMapUv),T.push(L.bumpMapUv),T.push(L.normalMapUv),T.push(L.displacementMapUv),T.push(L.emissiveMapUv),T.push(L.metalnessMapUv),T.push(L.roughnessMapUv),T.push(L.anisotropyMapUv),T.push(L.clearcoatMapUv),T.push(L.clearcoatNormalMapUv),T.push(L.clearcoatRoughnessMapUv),T.push(L.iridescenceMapUv),T.push(L.iridescenceThicknessMapUv),T.push(L.sheenColorMapUv),T.push(L.sheenRoughnessMapUv),T.push(L.specularMapUv),T.push(L.specularColorMapUv),T.push(L.specularIntensityMapUv),T.push(L.transmissionMapUv),T.push(L.thicknessMapUv),T.push(L.combine),T.push(L.fogExp2),T.push(L.sizeAttenuation),T.push(L.morphTargetsCount),T.push(L.morphAttributeCount),T.push(L.numDirLights),T.push(L.numPointLights),T.push(L.numSpotLights),T.push(L.numSpotLightMaps),T.push(L.numHemiLights),T.push(L.numRectAreaLights),T.push(L.numDirLightShadows),T.push(L.numPointLightShadows),T.push(L.numSpotLightShadows),T.push(L.numSpotLightShadowsWithMaps),T.push(L.numLightProbes),T.push(L.shadowMapType),T.push(L.toneMapping),T.push(L.numClippingPlanes),T.push(L.numClipIntersection),T.push(L.depthPacking)}function R(T,L){u.disableAll(),L.instancing&&u.enable(0),L.instancingColor&&u.enable(1),L.instancingMorph&&u.enable(2),L.matcap&&u.enable(3),L.envMap&&u.enable(4),L.normalMapObjectSpace&&u.enable(5),L.normalMapTangentSpace&&u.enable(6),L.clearcoat&&u.enable(7),L.iridescence&&u.enable(8),L.alphaTest&&u.enable(9),L.vertexColors&&u.enable(10),L.vertexAlphas&&u.enable(11),L.vertexUv1s&&u.enable(12),L.vertexUv2s&&u.enable(13),L.vertexUv3s&&u.enable(14),L.vertexTangents&&u.enable(15),L.anisotropy&&u.enable(16),L.alphaHash&&u.enable(17),L.batching&&u.enable(18),L.dispersion&&u.enable(19),L.batchingColor&&u.enable(20),L.gradientMap&&u.enable(21),L.packedNormalMap&&u.enable(22),L.vertexNormals&&u.enable(23),T.push(u.mask),u.disableAll(),L.fog&&u.enable(0),L.useFog&&u.enable(1),L.flatShading&&u.enable(2),L.logarithmicDepthBuffer&&u.enable(3),L.reversedDepthBuffer&&u.enable(4),L.skinning&&u.enable(5),L.morphTargets&&u.enable(6),L.morphNormals&&u.enable(7),L.morphColors&&u.enable(8),L.premultipliedAlpha&&u.enable(9),L.shadowMapEnabled&&u.enable(10),L.doubleSided&&u.enable(11),L.flipSided&&u.enable(12),L.useDepthPacking&&u.enable(13),L.dithering&&u.enable(14),L.transmission&&u.enable(15),L.sheen&&u.enable(16),L.opaque&&u.enable(17),L.pointsUvs&&u.enable(18),L.decodeVideoTexture&&u.enable(19),L.decodeVideoTextureEmissive&&u.enable(20),L.alphaToCoverage&&u.enable(21),L.numLightProbeGrids>0&&u.enable(22),T.push(u.mask)}function U(T){const L=x[T.type];let H;if(L){const V=hr[L];H=M2.clone(V.uniforms)}else H=T.uniforms;return H}function C(T,L){let H=_.get(L);return H!==void 0?++H.usedTimes:(H=new YU(o,L,T,r),p.push(H),_.set(L,H)),H}function F(T){if(--T.usedTimes===0){const L=p.indexOf(T);p[L]=p[p.length-1],p.pop(),_.delete(T.cacheKey),T.destroy()}}function O(T){f.remove(T)}function D(){f.dispose()}return{getParameters:E,getProgramCacheKey:S,getUniforms:U,acquireProgram:C,releaseProgram:F,releaseShaderCache:O,programs:p,dispose:D}}function $U(){let o=new WeakMap;function e(u){return o.has(u)}function n(u){let f=o.get(u);return f===void 0&&(f={},o.set(u,f)),f}function a(u){o.delete(u)}function r(u,f,d){o.get(u)[f]=d}function l(){o=new WeakMap}return{has:e,get:n,remove:a,update:r,dispose:l}}function eN(o,e){return o.groupOrder!==e.groupOrder?o.groupOrder-e.groupOrder:o.renderOrder!==e.renderOrder?o.renderOrder-e.renderOrder:o.material.id!==e.material.id?o.material.id-e.material.id:o.materialVariant!==e.materialVariant?o.materialVariant-e.materialVariant:o.z!==e.z?o.z-e.z:o.id-e.id}function i1(o,e){return o.groupOrder!==e.groupOrder?o.groupOrder-e.groupOrder:o.renderOrder!==e.renderOrder?o.renderOrder-e.renderOrder:o.z!==e.z?e.z-o.z:o.id-e.id}function a1(){const o=[];let e=0;const n=[],a=[],r=[];function l(){e=0,n.length=0,a.length=0,r.length=0}function u(g){let x=0;return g.isInstancedMesh&&(x+=2),g.isSkinnedMesh&&(x+=1),x}function f(g,x,M,E,S,y){let R=o[e];return R===void 0?(R={id:g.id,object:g,geometry:x,material:M,materialVariant:u(g),groupOrder:E,renderOrder:g.renderOrder,z:S,group:y},o[e]=R):(R.id=g.id,R.object=g,R.geometry=x,R.material=M,R.materialVariant=u(g),R.groupOrder=E,R.renderOrder=g.renderOrder,R.z=S,R.group=y),e++,R}function d(g,x,M,E,S,y){const R=f(g,x,M,E,S,y);M.transmission>0?a.push(R):M.transparent===!0?r.push(R):n.push(R)}function p(g,x,M,E,S,y){const R=f(g,x,M,E,S,y);M.transmission>0?a.unshift(R):M.transparent===!0?r.unshift(R):n.unshift(R)}function _(g,x){n.length>1&&n.sort(g||eN),a.length>1&&a.sort(x||i1),r.length>1&&r.sort(x||i1)}function v(){for(let g=e,x=o.length;g<x;g++){const M=o[g];if(M.id===null)break;M.id=null,M.object=null,M.geometry=null,M.material=null,M.group=null}}return{opaque:n,transmissive:a,transparent:r,init:l,push:d,unshift:p,finish:v,sort:_}}function tN(){let o=new WeakMap;function e(a,r){const l=o.get(a);let u;return l===void 0?(u=new a1,o.set(a,[u])):r>=l.length?(u=new a1,l.push(u)):u=l[r],u}function n(){o=new WeakMap}return{get:e,dispose:n}}function nN(){const o={};return{get:function(e){if(o[e.id]!==void 0)return o[e.id];let n;switch(e.type){case"DirectionalLight":n={direction:new ue,color:new pn};break;case"SpotLight":n={position:new ue,direction:new ue,color:new pn,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":n={position:new ue,color:new pn,distance:0,decay:0};break;case"HemisphereLight":n={direction:new ue,skyColor:new pn,groundColor:new pn};break;case"RectAreaLight":n={color:new pn,position:new ue,halfWidth:new ue,halfHeight:new ue};break}return o[e.id]=n,n}}}function iN(){const o={};return{get:function(e){if(o[e.id]!==void 0)return o[e.id];let n;switch(e.type){case"DirectionalLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Jt};break;case"SpotLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Jt};break;case"PointLight":n={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new Jt,shadowCameraNear:1,shadowCameraFar:1e3};break}return o[e.id]=n,n}}}let aN=0;function rN(o,e){return(e.castShadow?2:0)-(o.castShadow?2:0)+(e.map?1:0)-(o.map?1:0)}function sN(o){const e=new nN,n=iN(),a={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let p=0;p<9;p++)a.probe.push(new ue);const r=new ue,l=new ii,u=new ii;function f(p){let _=0,v=0,g=0;for(let L=0;L<9;L++)a.probe[L].set(0,0,0);let x=0,M=0,E=0,S=0,y=0,R=0,U=0,C=0,F=0,O=0,D=0;p.sort(rN);for(let L=0,H=p.length;L<H;L++){const V=p[L],k=V.color,te=V.intensity,ie=V.distance;let W=null;if(V.shadow&&V.shadow.map&&(V.shadow.map.texture.format===Xo?W=V.shadow.map.texture:W=V.shadow.map.depthTexture||V.shadow.map.texture),V.isAmbientLight)_+=k.r*te,v+=k.g*te,g+=k.b*te;else if(V.isLightProbe){for(let z=0;z<9;z++)a.probe[z].addScaledVector(V.sh.coefficients[z],te);D++}else if(V.isDirectionalLight){const z=e.get(V);if(z.color.copy(V.color).multiplyScalar(V.intensity),V.castShadow){const B=V.shadow,J=n.get(V);J.shadowIntensity=B.intensity,J.shadowBias=B.bias,J.shadowNormalBias=B.normalBias,J.shadowRadius=B.radius,J.shadowMapSize=B.mapSize,a.directionalShadow[x]=J,a.directionalShadowMap[x]=W,a.directionalShadowMatrix[x]=V.shadow.matrix,R++}a.directional[x]=z,x++}else if(V.isSpotLight){const z=e.get(V);z.position.setFromMatrixPosition(V.matrixWorld),z.color.copy(k).multiplyScalar(te),z.distance=ie,z.coneCos=Math.cos(V.angle),z.penumbraCos=Math.cos(V.angle*(1-V.penumbra)),z.decay=V.decay,a.spot[E]=z;const B=V.shadow;if(V.map&&(a.spotLightMap[F]=V.map,F++,B.updateMatrices(V),V.castShadow&&O++),a.spotLightMatrix[E]=B.matrix,V.castShadow){const J=n.get(V);J.shadowIntensity=B.intensity,J.shadowBias=B.bias,J.shadowNormalBias=B.normalBias,J.shadowRadius=B.radius,J.shadowMapSize=B.mapSize,a.spotShadow[E]=J,a.spotShadowMap[E]=W,C++}E++}else if(V.isRectAreaLight){const z=e.get(V);z.color.copy(k).multiplyScalar(te),z.halfWidth.set(V.width*.5,0,0),z.halfHeight.set(0,V.height*.5,0),a.rectArea[S]=z,S++}else if(V.isPointLight){const z=e.get(V);if(z.color.copy(V.color).multiplyScalar(V.intensity),z.distance=V.distance,z.decay=V.decay,V.castShadow){const B=V.shadow,J=n.get(V);J.shadowIntensity=B.intensity,J.shadowBias=B.bias,J.shadowNormalBias=B.normalBias,J.shadowRadius=B.radius,J.shadowMapSize=B.mapSize,J.shadowCameraNear=B.camera.near,J.shadowCameraFar=B.camera.far,a.pointShadow[M]=J,a.pointShadowMap[M]=W,a.pointShadowMatrix[M]=V.shadow.matrix,U++}a.point[M]=z,M++}else if(V.isHemisphereLight){const z=e.get(V);z.skyColor.copy(V.color).multiplyScalar(te),z.groundColor.copy(V.groundColor).multiplyScalar(te),a.hemi[y]=z,y++}}S>0&&(o.has("OES_texture_float_linear")===!0?(a.rectAreaLTC1=qe.LTC_FLOAT_1,a.rectAreaLTC2=qe.LTC_FLOAT_2):(a.rectAreaLTC1=qe.LTC_HALF_1,a.rectAreaLTC2=qe.LTC_HALF_2)),a.ambient[0]=_,a.ambient[1]=v,a.ambient[2]=g;const T=a.hash;(T.directionalLength!==x||T.pointLength!==M||T.spotLength!==E||T.rectAreaLength!==S||T.hemiLength!==y||T.numDirectionalShadows!==R||T.numPointShadows!==U||T.numSpotShadows!==C||T.numSpotMaps!==F||T.numLightProbes!==D)&&(a.directional.length=x,a.spot.length=E,a.rectArea.length=S,a.point.length=M,a.hemi.length=y,a.directionalShadow.length=R,a.directionalShadowMap.length=R,a.pointShadow.length=U,a.pointShadowMap.length=U,a.spotShadow.length=C,a.spotShadowMap.length=C,a.directionalShadowMatrix.length=R,a.pointShadowMatrix.length=U,a.spotLightMatrix.length=C+F-O,a.spotLightMap.length=F,a.numSpotLightShadowsWithMaps=O,a.numLightProbes=D,T.directionalLength=x,T.pointLength=M,T.spotLength=E,T.rectAreaLength=S,T.hemiLength=y,T.numDirectionalShadows=R,T.numPointShadows=U,T.numSpotShadows=C,T.numSpotMaps=F,T.numLightProbes=D,a.version=aN++)}function d(p,_){let v=0,g=0,x=0,M=0,E=0;const S=_.matrixWorldInverse;for(let y=0,R=p.length;y<R;y++){const U=p[y];if(U.isDirectionalLight){const C=a.directional[v];C.direction.setFromMatrixPosition(U.matrixWorld),r.setFromMatrixPosition(U.target.matrixWorld),C.direction.sub(r),C.direction.transformDirection(S),v++}else if(U.isSpotLight){const C=a.spot[x];C.position.setFromMatrixPosition(U.matrixWorld),C.position.applyMatrix4(S),C.direction.setFromMatrixPosition(U.matrixWorld),r.setFromMatrixPosition(U.target.matrixWorld),C.direction.sub(r),C.direction.transformDirection(S),x++}else if(U.isRectAreaLight){const C=a.rectArea[M];C.position.setFromMatrixPosition(U.matrixWorld),C.position.applyMatrix4(S),u.identity(),l.copy(U.matrixWorld),l.premultiply(S),u.extractRotation(l),C.halfWidth.set(U.width*.5,0,0),C.halfHeight.set(0,U.height*.5,0),C.halfWidth.applyMatrix4(u),C.halfHeight.applyMatrix4(u),M++}else if(U.isPointLight){const C=a.point[g];C.position.setFromMatrixPosition(U.matrixWorld),C.position.applyMatrix4(S),g++}else if(U.isHemisphereLight){const C=a.hemi[E];C.direction.setFromMatrixPosition(U.matrixWorld),C.direction.transformDirection(S),E++}}}return{setup:f,setupView:d,state:a}}function r1(o){const e=new sN(o),n=[],a=[],r=[];function l(g){v.camera=g,n.length=0,a.length=0,r.length=0}function u(g){n.push(g)}function f(g){a.push(g)}function d(g){r.push(g)}function p(){e.setup(n)}function _(g){e.setupView(n,g)}const v={lightsArray:n,shadowsArray:a,lightProbeGridArray:r,camera:null,lights:e,transmissionRenderTarget:{},textureUnits:0};return{init:l,state:v,setupLights:p,setupLightsView:_,pushLight:u,pushShadow:f,pushLightProbeGrid:d}}function oN(o){let e=new WeakMap;function n(r,l=0){const u=e.get(r);let f;return u===void 0?(f=new r1(o),e.set(r,[f])):l>=u.length?(f=new r1(o),u.push(f)):f=u[l],f}function a(){e=new WeakMap}return{get:n,dispose:a}}const lN=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,cN=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );
	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );
}`,uN=[new ue(1,0,0),new ue(-1,0,0),new ue(0,1,0),new ue(0,-1,0),new ue(0,0,1),new ue(0,0,-1)],fN=[new ue(0,-1,0),new ue(0,-1,0),new ue(0,0,1),new ue(0,0,-1),new ue(0,-1,0),new ue(0,-1,0)],s1=new ii,du=new ue,N_=new ue;function hN(o,e,n){let a=new tE;const r=new Jt,l=new Jt,u=new Vn,f=new A2,d=new R2,p={},_=n.maxTextureSize,v={[Qs]:$i,[$i]:Qs,[Zr]:Zr},g=new Va({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new Jt},radius:{value:4}},vertexShader:lN,fragmentShader:cN}),x=g.clone();x.defines.HORIZONTAL_PASS=1;const M=new br;M.setAttribute("position",new tr(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const E=new nr(M,g),S=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Jh;let y=this.type;this.render=function(O,D,T){if(S.enabled===!1||S.autoUpdate===!1&&S.needsUpdate===!1||O.length===0)return;this.type===_C&&(_t("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=Jh);const L=o.getRenderTarget(),H=o.getActiveCubeFace(),V=o.getActiveMipmapLevel(),k=o.state;k.setBlending($r),k.buffers.depth.getReversed()===!0?k.buffers.color.setClear(0,0,0,0):k.buffers.color.setClear(1,1,1,1),k.buffers.depth.setTest(!0),k.setScissorTest(!1);const te=y!==this.type;te&&D.traverse(function(ie){ie.material&&(Array.isArray(ie.material)?ie.material.forEach(W=>W.needsUpdate=!0):ie.material.needsUpdate=!0)});for(let ie=0,W=O.length;ie<W;ie++){const z=O[ie],B=z.shadow;if(B===void 0){_t("WebGLShadowMap:",z,"has no shadow.");continue}if(B.autoUpdate===!1&&B.needsUpdate===!1)continue;r.copy(B.mapSize);const J=B.getFrameExtents();r.multiply(J),l.copy(B.mapSize),(r.x>_||r.y>_)&&(r.x>_&&(l.x=Math.floor(_/J.x),r.x=l.x*J.x,B.mapSize.x=l.x),r.y>_&&(l.y=Math.floor(_/J.y),r.y=l.y*J.y,B.mapSize.y=l.y));const fe=o.state.buffers.depth.getReversed();if(B.camera._reversedDepth=fe,B.map===null||te===!0){if(B.map!==null&&(B.map.depthTexture!==null&&(B.map.depthTexture.dispose(),B.map.depthTexture=null),B.map.dispose()),this.type===Mu){if(z.isPointLight){_t("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");continue}B.map=new Sr(r.x,r.y,{format:Xo,type:as,minFilter:Ci,magFilter:Ci,generateMipmaps:!1}),B.map.texture.name=z.name+".shadowMap",B.map.depthTexture=new fc(r.x,r.y,_r),B.map.depthTexture.name=z.name+".shadowMapDepth",B.map.depthTexture.format=rs,B.map.depthTexture.compareFunction=null,B.map.depthTexture.minFilter=_i,B.map.depthTexture.magFilter=_i}else z.isPointLight?(B.map=new lE(r.x),B.map.depthTexture=new S2(r.x,Mr)):(B.map=new Sr(r.x,r.y),B.map.depthTexture=new fc(r.x,r.y,Mr)),B.map.depthTexture.name=z.name+".shadowMap",B.map.depthTexture.format=rs,this.type===Jh?(B.map.depthTexture.compareFunction=fe?Dg:wg,B.map.depthTexture.minFilter=Ci,B.map.depthTexture.magFilter=Ci):(B.map.depthTexture.compareFunction=null,B.map.depthTexture.minFilter=_i,B.map.depthTexture.magFilter=_i);B.camera.updateProjectionMatrix()}const G=B.map.isWebGLCubeRenderTarget?6:1;for(let I=0;I<G;I++){if(B.map.isWebGLCubeRenderTarget)o.setRenderTarget(B.map,I),o.clear();else{I===0&&(o.setRenderTarget(B.map),o.clear());const K=B.getViewport(I);u.set(l.x*K.x,l.y*K.y,l.x*K.z,l.y*K.w),k.viewport(u)}if(z.isPointLight){const K=B.camera,Se=B.matrix,be=z.distance||K.far;be!==K.far&&(K.far=be,K.updateProjectionMatrix()),du.setFromMatrixPosition(z.matrixWorld),K.position.copy(du),N_.copy(K.position),N_.add(uN[I]),K.up.copy(fN[I]),K.lookAt(N_),K.updateMatrixWorld(),Se.makeTranslation(-du.x,-du.y,-du.z),s1.multiplyMatrices(K.projectionMatrix,K.matrixWorldInverse),B._frustum.setFromProjectionMatrix(s1,K.coordinateSystem,K.reversedDepth)}else B.updateMatrices(z);a=B.getFrustum(),C(D,T,B.camera,z,this.type)}B.isPointLightShadow!==!0&&this.type===Mu&&R(B,T),B.needsUpdate=!1}y=this.type,S.needsUpdate=!1,o.setRenderTarget(L,H,V)};function R(O,D){const T=e.update(E);g.defines.VSM_SAMPLES!==O.blurSamples&&(g.defines.VSM_SAMPLES=O.blurSamples,x.defines.VSM_SAMPLES=O.blurSamples,g.needsUpdate=!0,x.needsUpdate=!0),O.mapPass===null&&(O.mapPass=new Sr(r.x,r.y,{format:Xo,type:as})),g.uniforms.shadow_pass.value=O.map.depthTexture,g.uniforms.resolution.value=O.mapSize,g.uniforms.radius.value=O.radius,o.setRenderTarget(O.mapPass),o.clear(),o.renderBufferDirect(D,null,T,g,E,null),x.uniforms.shadow_pass.value=O.mapPass.texture,x.uniforms.resolution.value=O.mapSize,x.uniforms.radius.value=O.radius,o.setRenderTarget(O.map),o.clear(),o.renderBufferDirect(D,null,T,x,E,null)}function U(O,D,T,L){let H=null;const V=T.isPointLight===!0?O.customDistanceMaterial:O.customDepthMaterial;if(V!==void 0)H=V;else if(H=T.isPointLight===!0?d:f,o.localClippingEnabled&&D.clipShadows===!0&&Array.isArray(D.clippingPlanes)&&D.clippingPlanes.length!==0||D.displacementMap&&D.displacementScale!==0||D.alphaMap&&D.alphaTest>0||D.map&&D.alphaTest>0||D.alphaToCoverage===!0){const k=H.uuid,te=D.uuid;let ie=p[k];ie===void 0&&(ie={},p[k]=ie);let W=ie[te];W===void 0&&(W=H.clone(),ie[te]=W,D.addEventListener("dispose",F)),H=W}if(H.visible=D.visible,H.wireframe=D.wireframe,L===Mu?H.side=D.shadowSide!==null?D.shadowSide:D.side:H.side=D.shadowSide!==null?D.shadowSide:v[D.side],H.alphaMap=D.alphaMap,H.alphaTest=D.alphaToCoverage===!0?.5:D.alphaTest,H.map=D.map,H.clipShadows=D.clipShadows,H.clippingPlanes=D.clippingPlanes,H.clipIntersection=D.clipIntersection,H.displacementMap=D.displacementMap,H.displacementScale=D.displacementScale,H.displacementBias=D.displacementBias,H.wireframeLinewidth=D.wireframeLinewidth,H.linewidth=D.linewidth,T.isPointLight===!0&&H.isMeshDistanceMaterial===!0){const k=o.properties.get(H);k.light=T}return H}function C(O,D,T,L,H){if(O.visible===!1)return;if(O.layers.test(D.layers)&&(O.isMesh||O.isLine||O.isPoints)&&(O.castShadow||O.receiveShadow&&H===Mu)&&(!O.frustumCulled||a.intersectsObject(O))){O.modelViewMatrix.multiplyMatrices(T.matrixWorldInverse,O.matrixWorld);const te=e.update(O),ie=O.material;if(Array.isArray(ie)){const W=te.groups;for(let z=0,B=W.length;z<B;z++){const J=W[z],fe=ie[J.materialIndex];if(fe&&fe.visible){const G=U(O,fe,L,H);O.onBeforeShadow(o,O,D,T,te,G,J),o.renderBufferDirect(T,null,te,G,O,J),O.onAfterShadow(o,O,D,T,te,G,J)}}}else if(ie.visible){const W=U(O,ie,L,H);O.onBeforeShadow(o,O,D,T,te,W,null),o.renderBufferDirect(T,null,te,W,O,null),O.onAfterShadow(o,O,D,T,te,W,null)}}const k=O.children;for(let te=0,ie=k.length;te<ie;te++)C(k[te],D,T,L,H)}function F(O){O.target.removeEventListener("dispose",F);for(const T in p){const L=p[T],H=O.target.uuid;H in L&&(L[H].dispose(),delete L[H])}}}function dN(o,e){function n(){let q=!1;const Re=new Vn;let me=null;const Ve=new Vn(0,0,0,0);return{setMask:function(Pe){me!==Pe&&!q&&(o.colorMask(Pe,Pe,Pe,Pe),me=Pe)},setLocked:function(Pe){q=Pe},setClear:function(Pe,Ae,Ce,Ne,ot){ot===!0&&(Pe*=Ne,Ae*=Ne,Ce*=Ne),Re.set(Pe,Ae,Ce,Ne),Ve.equals(Re)===!1&&(o.clearColor(Pe,Ae,Ce,Ne),Ve.copy(Re))},reset:function(){q=!1,me=null,Ve.set(-1,0,0,0)}}}function a(){let q=!1,Re=!1,me=null,Ve=null,Pe=null;return{setReversed:function(Ae){if(Re!==Ae){const Ce=e.get("EXT_clip_control");Ae?Ce.clipControlEXT(Ce.LOWER_LEFT_EXT,Ce.ZERO_TO_ONE_EXT):Ce.clipControlEXT(Ce.LOWER_LEFT_EXT,Ce.NEGATIVE_ONE_TO_ONE_EXT),Re=Ae;const Ne=Pe;Pe=null,this.setClear(Ne)}},getReversed:function(){return Re},setTest:function(Ae){Ae?Ee(o.DEPTH_TEST):Ie(o.DEPTH_TEST)},setMask:function(Ae){me!==Ae&&!q&&(o.depthMask(Ae),me=Ae)},setFunc:function(Ae){if(Re&&(Ae=ZC[Ae]),Ve!==Ae){switch(Ae){case s0:o.depthFunc(o.NEVER);break;case o0:o.depthFunc(o.ALWAYS);break;case l0:o.depthFunc(o.LESS);break;case cc:o.depthFunc(o.LEQUAL);break;case c0:o.depthFunc(o.EQUAL);break;case u0:o.depthFunc(o.GEQUAL);break;case f0:o.depthFunc(o.GREATER);break;case h0:o.depthFunc(o.NOTEQUAL);break;default:o.depthFunc(o.LEQUAL)}Ve=Ae}},setLocked:function(Ae){q=Ae},setClear:function(Ae){Pe!==Ae&&(Pe=Ae,Re&&(Ae=1-Ae),o.clearDepth(Ae))},reset:function(){q=!1,me=null,Ve=null,Pe=null,Re=!1}}}function r(){let q=!1,Re=null,me=null,Ve=null,Pe=null,Ae=null,Ce=null,Ne=null,ot=null;return{setTest:function(we){q||(we?Ee(o.STENCIL_TEST):Ie(o.STENCIL_TEST))},setMask:function(we){Re!==we&&!q&&(o.stencilMask(we),Re=we)},setFunc:function(we,rt,Qe){(me!==we||Ve!==rt||Pe!==Qe)&&(o.stencilFunc(we,rt,Qe),me=we,Ve=rt,Pe=Qe)},setOp:function(we,rt,Qe){(Ae!==we||Ce!==rt||Ne!==Qe)&&(o.stencilOp(we,rt,Qe),Ae=we,Ce=rt,Ne=Qe)},setLocked:function(we){q=we},setClear:function(we){ot!==we&&(o.clearStencil(we),ot=we)},reset:function(){q=!1,Re=null,me=null,Ve=null,Pe=null,Ae=null,Ce=null,Ne=null,ot=null}}}const l=new n,u=new a,f=new r,d=new WeakMap,p=new WeakMap;let _={},v={},g={},x=new WeakMap,M=[],E=null,S=!1,y=null,R=null,U=null,C=null,F=null,O=null,D=null,T=new pn(0,0,0),L=0,H=!1,V=null,k=null,te=null,ie=null,W=null;const z=o.getParameter(o.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let B=!1,J=0;const fe=o.getParameter(o.VERSION);fe.indexOf("WebGL")!==-1?(J=parseFloat(/^WebGL (\d)/.exec(fe)[1]),B=J>=1):fe.indexOf("OpenGL ES")!==-1&&(J=parseFloat(/^OpenGL ES (\d)/.exec(fe)[1]),B=J>=2);let G=null,I={};const K=o.getParameter(o.SCISSOR_BOX),Se=o.getParameter(o.VIEWPORT),be=new Vn().fromArray(K),Ue=new Vn().fromArray(Se);function ne(q,Re,me,Ve){const Pe=new Uint8Array(4),Ae=o.createTexture();o.bindTexture(q,Ae),o.texParameteri(q,o.TEXTURE_MIN_FILTER,o.NEAREST),o.texParameteri(q,o.TEXTURE_MAG_FILTER,o.NEAREST);for(let Ce=0;Ce<me;Ce++)q===o.TEXTURE_3D||q===o.TEXTURE_2D_ARRAY?o.texImage3D(Re,0,o.RGBA,1,1,Ve,0,o.RGBA,o.UNSIGNED_BYTE,Pe):o.texImage2D(Re+Ce,0,o.RGBA,1,1,0,o.RGBA,o.UNSIGNED_BYTE,Pe);return Ae}const xe={};xe[o.TEXTURE_2D]=ne(o.TEXTURE_2D,o.TEXTURE_2D,1),xe[o.TEXTURE_CUBE_MAP]=ne(o.TEXTURE_CUBE_MAP,o.TEXTURE_CUBE_MAP_POSITIVE_X,6),xe[o.TEXTURE_2D_ARRAY]=ne(o.TEXTURE_2D_ARRAY,o.TEXTURE_2D_ARRAY,1,1),xe[o.TEXTURE_3D]=ne(o.TEXTURE_3D,o.TEXTURE_3D,1,1),l.setClear(0,0,0,1),u.setClear(1),f.setClear(0),Ee(o.DEPTH_TEST),u.setFunc(cc),le(!1),Dt(cM),Ee(o.CULL_FACE),xt($r);function Ee(q){_[q]!==!0&&(o.enable(q),_[q]=!0)}function Ie(q){_[q]!==!1&&(o.disable(q),_[q]=!1)}function nt(q,Re){return g[q]!==Re?(o.bindFramebuffer(q,Re),g[q]=Re,q===o.DRAW_FRAMEBUFFER&&(g[o.FRAMEBUFFER]=Re),q===o.FRAMEBUFFER&&(g[o.DRAW_FRAMEBUFFER]=Re),!0):!1}function Ze(q,Re){let me=M,Ve=!1;if(q){me=x.get(Re),me===void 0&&(me=[],x.set(Re,me));const Pe=q.textures;if(me.length!==Pe.length||me[0]!==o.COLOR_ATTACHMENT0){for(let Ae=0,Ce=Pe.length;Ae<Ce;Ae++)me[Ae]=o.COLOR_ATTACHMENT0+Ae;me.length=Pe.length,Ve=!0}}else me[0]!==o.BACK&&(me[0]=o.BACK,Ve=!0);Ve&&o.drawBuffers(me)}function Mt(q){return E!==q?(o.useProgram(q),E=q,!0):!1}const Ye={[Ro]:o.FUNC_ADD,[vC]:o.FUNC_SUBTRACT,[xC]:o.FUNC_REVERSE_SUBTRACT};Ye[SC]=o.MIN,Ye[yC]=o.MAX;const it={[MC]:o.ZERO,[bC]:o.ONE,[EC]:o.SRC_COLOR,[a0]:o.SRC_ALPHA,[DC]:o.SRC_ALPHA_SATURATE,[CC]:o.DST_COLOR,[AC]:o.DST_ALPHA,[TC]:o.ONE_MINUS_SRC_COLOR,[r0]:o.ONE_MINUS_SRC_ALPHA,[wC]:o.ONE_MINUS_DST_COLOR,[RC]:o.ONE_MINUS_DST_ALPHA,[UC]:o.CONSTANT_COLOR,[NC]:o.ONE_MINUS_CONSTANT_COLOR,[LC]:o.CONSTANT_ALPHA,[OC]:o.ONE_MINUS_CONSTANT_ALPHA};function xt(q,Re,me,Ve,Pe,Ae,Ce,Ne,ot,we){if(q===$r){S===!0&&(Ie(o.BLEND),S=!1);return}if(S===!1&&(Ee(o.BLEND),S=!0),q!==gC){if(q!==y||we!==H){if((R!==Ro||F!==Ro)&&(o.blendEquation(o.FUNC_ADD),R=Ro,F=Ro),we)switch(q){case tc:o.blendFuncSeparate(o.ONE,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case i0:o.blendFunc(o.ONE,o.ONE);break;case uM:o.blendFuncSeparate(o.ZERO,o.ONE_MINUS_SRC_COLOR,o.ZERO,o.ONE);break;case fM:o.blendFuncSeparate(o.DST_COLOR,o.ONE_MINUS_SRC_ALPHA,o.ZERO,o.ONE);break;default:jt("WebGLState: Invalid blending: ",q);break}else switch(q){case tc:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE_MINUS_SRC_ALPHA,o.ONE,o.ONE_MINUS_SRC_ALPHA);break;case i0:o.blendFuncSeparate(o.SRC_ALPHA,o.ONE,o.ONE,o.ONE);break;case uM:jt("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");break;case fM:jt("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");break;default:jt("WebGLState: Invalid blending: ",q);break}U=null,C=null,O=null,D=null,T.set(0,0,0),L=0,y=q,H=we}return}Pe=Pe||Re,Ae=Ae||me,Ce=Ce||Ve,(Re!==R||Pe!==F)&&(o.blendEquationSeparate(Ye[Re],Ye[Pe]),R=Re,F=Pe),(me!==U||Ve!==C||Ae!==O||Ce!==D)&&(o.blendFuncSeparate(it[me],it[Ve],it[Ae],it[Ce]),U=me,C=Ve,O=Ae,D=Ce),(Ne.equals(T)===!1||ot!==L)&&(o.blendColor(Ne.r,Ne.g,Ne.b,ot),T.copy(Ne),L=ot),y=q,H=!1}function st(q,Re){q.side===Zr?Ie(o.CULL_FACE):Ee(o.CULL_FACE);let me=q.side===$i;Re&&(me=!me),le(me),q.blending===tc&&q.transparent===!1?xt($r):xt(q.blending,q.blendEquation,q.blendSrc,q.blendDst,q.blendEquationAlpha,q.blendSrcAlpha,q.blendDstAlpha,q.blendColor,q.blendAlpha,q.premultipliedAlpha),u.setFunc(q.depthFunc),u.setTest(q.depthTest),u.setMask(q.depthWrite),l.setMask(q.colorWrite);const Ve=q.stencilWrite;f.setTest(Ve),Ve&&(f.setMask(q.stencilWriteMask),f.setFunc(q.stencilFunc,q.stencilRef,q.stencilFuncMask),f.setOp(q.stencilFail,q.stencilZFail,q.stencilZPass)),j(q.polygonOffset,q.polygonOffsetFactor,q.polygonOffsetUnits),q.alphaToCoverage===!0?Ee(o.SAMPLE_ALPHA_TO_COVERAGE):Ie(o.SAMPLE_ALPHA_TO_COVERAGE)}function le(q){V!==q&&(q?o.frontFace(o.CW):o.frontFace(o.CCW),V=q)}function Dt(q){q!==pC?(Ee(o.CULL_FACE),q!==k&&(q===cM?o.cullFace(o.BACK):q===mC?o.cullFace(o.FRONT):o.cullFace(o.FRONT_AND_BACK))):Ie(o.CULL_FACE),k=q}function mn(q){q!==te&&(B&&o.lineWidth(q),te=q)}function j(q,Re,me){q?(Ee(o.POLYGON_OFFSET_FILL),(ie!==Re||W!==me)&&(ie=Re,W=me,u.getReversed()&&(Re=-Re),o.polygonOffset(Re,me))):Ie(o.POLYGON_OFFSET_FILL)}function gt(q){q?Ee(o.SCISSOR_TEST):Ie(o.SCISSOR_TEST)}function mt(q){q===void 0&&(q=o.TEXTURE0+z-1),G!==q&&(o.activeTexture(q),G=q)}function Ft(q,Re,me){me===void 0&&(G===null?me=o.TEXTURE0+z-1:me=G);let Ve=I[me];Ve===void 0&&(Ve={type:void 0,texture:void 0},I[me]=Ve),(Ve.type!==q||Ve.texture!==Re)&&(G!==me&&(o.activeTexture(me),G=me),o.bindTexture(q,Re||xe[q]),Ve.type=q,Ve.texture=Re)}function Le(){const q=I[G];q!==void 0&&q.type!==void 0&&(o.bindTexture(q.type,null),q.type=void 0,q.texture=void 0)}function bt(){try{o.compressedTexImage2D(...arguments)}catch(q){jt("WebGLState:",q)}}function P(){try{o.compressedTexImage3D(...arguments)}catch(q){jt("WebGLState:",q)}}function A(){try{o.texSubImage2D(...arguments)}catch(q){jt("WebGLState:",q)}}function Q(){try{o.texSubImage3D(...arguments)}catch(q){jt("WebGLState:",q)}}function _e(){try{o.compressedTexSubImage2D(...arguments)}catch(q){jt("WebGLState:",q)}}function Te(){try{o.compressedTexSubImage3D(...arguments)}catch(q){jt("WebGLState:",q)}}function Fe(){try{o.texStorage2D(...arguments)}catch(q){jt("WebGLState:",q)}}function De(){try{o.texStorage3D(...arguments)}catch(q){jt("WebGLState:",q)}}function de(){try{o.texImage2D(...arguments)}catch(q){jt("WebGLState:",q)}}function pe(){try{o.texImage3D(...arguments)}catch(q){jt("WebGLState:",q)}}function Be(q){return v[q]!==void 0?v[q]:o.getParameter(q)}function He(q,Re){v[q]!==Re&&(o.pixelStorei(q,Re),v[q]=Re)}function ze(q){be.equals(q)===!1&&(o.scissor(q.x,q.y,q.z,q.w),be.copy(q))}function Oe(q){Ue.equals(q)===!1&&(o.viewport(q.x,q.y,q.z,q.w),Ue.copy(q))}function Ge(q,Re){let me=p.get(Re);me===void 0&&(me=new WeakMap,p.set(Re,me));let Ve=me.get(q);Ve===void 0&&(Ve=o.getUniformBlockIndex(Re,q.name),me.set(q,Ve))}function ut(q,Re){const Ve=p.get(Re).get(q);d.get(Re)!==Ve&&(o.uniformBlockBinding(Re,Ve,q.__bindingPointIndex),d.set(Re,Ve))}function dt(){o.disable(o.BLEND),o.disable(o.CULL_FACE),o.disable(o.DEPTH_TEST),o.disable(o.POLYGON_OFFSET_FILL),o.disable(o.SCISSOR_TEST),o.disable(o.STENCIL_TEST),o.disable(o.SAMPLE_ALPHA_TO_COVERAGE),o.blendEquation(o.FUNC_ADD),o.blendFunc(o.ONE,o.ZERO),o.blendFuncSeparate(o.ONE,o.ZERO,o.ONE,o.ZERO),o.blendColor(0,0,0,0),o.colorMask(!0,!0,!0,!0),o.clearColor(0,0,0,0),o.depthMask(!0),o.depthFunc(o.LESS),u.setReversed(!1),o.clearDepth(1),o.stencilMask(4294967295),o.stencilFunc(o.ALWAYS,0,4294967295),o.stencilOp(o.KEEP,o.KEEP,o.KEEP),o.clearStencil(0),o.cullFace(o.BACK),o.frontFace(o.CCW),o.polygonOffset(0,0),o.activeTexture(o.TEXTURE0),o.bindFramebuffer(o.FRAMEBUFFER,null),o.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),o.bindFramebuffer(o.READ_FRAMEBUFFER,null),o.useProgram(null),o.lineWidth(1),o.scissor(0,0,o.canvas.width,o.canvas.height),o.viewport(0,0,o.canvas.width,o.canvas.height),o.pixelStorei(o.PACK_ALIGNMENT,4),o.pixelStorei(o.UNPACK_ALIGNMENT,4),o.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,!1),o.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),o.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,o.BROWSER_DEFAULT_WEBGL),o.pixelStorei(o.PACK_ROW_LENGTH,0),o.pixelStorei(o.PACK_SKIP_PIXELS,0),o.pixelStorei(o.PACK_SKIP_ROWS,0),o.pixelStorei(o.UNPACK_ROW_LENGTH,0),o.pixelStorei(o.UNPACK_IMAGE_HEIGHT,0),o.pixelStorei(o.UNPACK_SKIP_PIXELS,0),o.pixelStorei(o.UNPACK_SKIP_ROWS,0),o.pixelStorei(o.UNPACK_SKIP_IMAGES,0),_={},v={},G=null,I={},g={},x=new WeakMap,M=[],E=null,S=!1,y=null,R=null,U=null,C=null,F=null,O=null,D=null,T=new pn(0,0,0),L=0,H=!1,V=null,k=null,te=null,ie=null,W=null,be.set(0,0,o.canvas.width,o.canvas.height),Ue.set(0,0,o.canvas.width,o.canvas.height),l.reset(),u.reset(),f.reset()}return{buffers:{color:l,depth:u,stencil:f},enable:Ee,disable:Ie,bindFramebuffer:nt,drawBuffers:Ze,useProgram:Mt,setBlending:xt,setMaterial:st,setFlipSided:le,setCullFace:Dt,setLineWidth:mn,setPolygonOffset:j,setScissorTest:gt,activeTexture:mt,bindTexture:Ft,unbindTexture:Le,compressedTexImage2D:bt,compressedTexImage3D:P,texImage2D:de,texImage3D:pe,pixelStorei:He,getParameter:Be,updateUBOMapping:Ge,uniformBlockBinding:ut,texStorage2D:Fe,texStorage3D:De,texSubImage2D:A,texSubImage3D:Q,compressedTexSubImage2D:_e,compressedTexSubImage3D:Te,scissor:ze,viewport:Oe,reset:dt}}function pN(o,e,n,a,r,l,u){const f=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,d=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),p=new Jt,_=new WeakMap,v=new Set;let g;const x=new WeakMap;let M=!1;try{M=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function E(P,A){return M?new OffscreenCanvas(P,A):Sd("canvas")}function S(P,A,Q){let _e=1;const Te=bt(P);if((Te.width>Q||Te.height>Q)&&(_e=Q/Math.max(Te.width,Te.height)),_e<1)if(typeof HTMLImageElement<"u"&&P instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&P instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&P instanceof ImageBitmap||typeof VideoFrame<"u"&&P instanceof VideoFrame){const Fe=Math.floor(_e*Te.width),De=Math.floor(_e*Te.height);g===void 0&&(g=E(Fe,De));const de=A?E(Fe,De):g;return de.width=Fe,de.height=De,de.getContext("2d").drawImage(P,0,0,Fe,De),_t("WebGLRenderer: Texture has been resized from ("+Te.width+"x"+Te.height+") to ("+Fe+"x"+De+")."),de}else return"data"in P&&_t("WebGLRenderer: Image in DataTexture is too big ("+Te.width+"x"+Te.height+")."),P;return P}function y(P){return P.generateMipmaps}function R(P){o.generateMipmap(P)}function U(P){return P.isWebGLCubeRenderTarget?o.TEXTURE_CUBE_MAP:P.isWebGL3DRenderTarget?o.TEXTURE_3D:P.isWebGLArrayRenderTarget||P.isCompressedArrayTexture?o.TEXTURE_2D_ARRAY:o.TEXTURE_2D}function C(P,A,Q,_e,Te,Fe=!1){if(P!==null){if(o[P]!==void 0)return o[P];_t("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+P+"'")}let De;_e&&(De=e.get("EXT_texture_norm16"),De||_t("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));let de=A;if(A===o.RED&&(Q===o.FLOAT&&(de=o.R32F),Q===o.HALF_FLOAT&&(de=o.R16F),Q===o.UNSIGNED_BYTE&&(de=o.R8),Q===o.UNSIGNED_SHORT&&De&&(de=De.R16_EXT),Q===o.SHORT&&De&&(de=De.R16_SNORM_EXT)),A===o.RED_INTEGER&&(Q===o.UNSIGNED_BYTE&&(de=o.R8UI),Q===o.UNSIGNED_SHORT&&(de=o.R16UI),Q===o.UNSIGNED_INT&&(de=o.R32UI),Q===o.BYTE&&(de=o.R8I),Q===o.SHORT&&(de=o.R16I),Q===o.INT&&(de=o.R32I)),A===o.RG&&(Q===o.FLOAT&&(de=o.RG32F),Q===o.HALF_FLOAT&&(de=o.RG16F),Q===o.UNSIGNED_BYTE&&(de=o.RG8),Q===o.UNSIGNED_SHORT&&De&&(de=De.RG16_EXT),Q===o.SHORT&&De&&(de=De.RG16_SNORM_EXT)),A===o.RG_INTEGER&&(Q===o.UNSIGNED_BYTE&&(de=o.RG8UI),Q===o.UNSIGNED_SHORT&&(de=o.RG16UI),Q===o.UNSIGNED_INT&&(de=o.RG32UI),Q===o.BYTE&&(de=o.RG8I),Q===o.SHORT&&(de=o.RG16I),Q===o.INT&&(de=o.RG32I)),A===o.RGB_INTEGER&&(Q===o.UNSIGNED_BYTE&&(de=o.RGB8UI),Q===o.UNSIGNED_SHORT&&(de=o.RGB16UI),Q===o.UNSIGNED_INT&&(de=o.RGB32UI),Q===o.BYTE&&(de=o.RGB8I),Q===o.SHORT&&(de=o.RGB16I),Q===o.INT&&(de=o.RGB32I)),A===o.RGBA_INTEGER&&(Q===o.UNSIGNED_BYTE&&(de=o.RGBA8UI),Q===o.UNSIGNED_SHORT&&(de=o.RGBA16UI),Q===o.UNSIGNED_INT&&(de=o.RGBA32UI),Q===o.BYTE&&(de=o.RGBA8I),Q===o.SHORT&&(de=o.RGBA16I),Q===o.INT&&(de=o.RGBA32I)),A===o.RGB&&(Q===o.UNSIGNED_SHORT&&De&&(de=De.RGB16_EXT),Q===o.SHORT&&De&&(de=De.RGB16_SNORM_EXT),Q===o.UNSIGNED_INT_5_9_9_9_REV&&(de=o.RGB9_E5),Q===o.UNSIGNED_INT_10F_11F_11F_REV&&(de=o.R11F_G11F_B10F)),A===o.RGBA){const pe=Fe?vd:Xt.getTransfer(Te);Q===o.FLOAT&&(de=o.RGBA32F),Q===o.HALF_FLOAT&&(de=o.RGBA16F),Q===o.UNSIGNED_BYTE&&(de=pe===cn?o.SRGB8_ALPHA8:o.RGBA8),Q===o.UNSIGNED_SHORT&&De&&(de=De.RGBA16_EXT),Q===o.SHORT&&De&&(de=De.RGBA16_SNORM_EXT),Q===o.UNSIGNED_SHORT_4_4_4_4&&(de=o.RGBA4),Q===o.UNSIGNED_SHORT_5_5_5_1&&(de=o.RGB5_A1)}return(de===o.R16F||de===o.R32F||de===o.RG16F||de===o.RG32F||de===o.RGBA16F||de===o.RGBA32F)&&e.get("EXT_color_buffer_float"),de}function F(P,A){let Q;return P?A===null||A===Mr||A===Yu?Q=o.DEPTH24_STENCIL8:A===_r?Q=o.DEPTH32F_STENCIL8:A===qu&&(Q=o.DEPTH24_STENCIL8,_t("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):A===null||A===Mr||A===Yu?Q=o.DEPTH_COMPONENT24:A===_r?Q=o.DEPTH_COMPONENT32F:A===qu&&(Q=o.DEPTH_COMPONENT16),Q}function O(P,A){return y(P)===!0||P.isFramebufferTexture&&P.minFilter!==_i&&P.minFilter!==Ci?Math.log2(Math.max(A.width,A.height))+1:P.mipmaps!==void 0&&P.mipmaps.length>0?P.mipmaps.length:P.isCompressedTexture&&Array.isArray(P.image)?A.mipmaps.length:1}function D(P){const A=P.target;A.removeEventListener("dispose",D),L(A),A.isVideoTexture&&_.delete(A),A.isHTMLTexture&&v.delete(A)}function T(P){const A=P.target;A.removeEventListener("dispose",T),V(A)}function L(P){const A=a.get(P);if(A.__webglInit===void 0)return;const Q=P.source,_e=x.get(Q);if(_e){const Te=_e[A.__cacheKey];Te.usedTimes--,Te.usedTimes===0&&H(P),Object.keys(_e).length===0&&x.delete(Q)}a.remove(P)}function H(P){const A=a.get(P);o.deleteTexture(A.__webglTexture);const Q=P.source,_e=x.get(Q);delete _e[A.__cacheKey],u.memory.textures--}function V(P){const A=a.get(P);if(P.depthTexture&&(P.depthTexture.dispose(),a.remove(P.depthTexture)),P.isWebGLCubeRenderTarget)for(let _e=0;_e<6;_e++){if(Array.isArray(A.__webglFramebuffer[_e]))for(let Te=0;Te<A.__webglFramebuffer[_e].length;Te++)o.deleteFramebuffer(A.__webglFramebuffer[_e][Te]);else o.deleteFramebuffer(A.__webglFramebuffer[_e]);A.__webglDepthbuffer&&o.deleteRenderbuffer(A.__webglDepthbuffer[_e])}else{if(Array.isArray(A.__webglFramebuffer))for(let _e=0;_e<A.__webglFramebuffer.length;_e++)o.deleteFramebuffer(A.__webglFramebuffer[_e]);else o.deleteFramebuffer(A.__webglFramebuffer);if(A.__webglDepthbuffer&&o.deleteRenderbuffer(A.__webglDepthbuffer),A.__webglMultisampledFramebuffer&&o.deleteFramebuffer(A.__webglMultisampledFramebuffer),A.__webglColorRenderbuffer)for(let _e=0;_e<A.__webglColorRenderbuffer.length;_e++)A.__webglColorRenderbuffer[_e]&&o.deleteRenderbuffer(A.__webglColorRenderbuffer[_e]);A.__webglDepthRenderbuffer&&o.deleteRenderbuffer(A.__webglDepthRenderbuffer)}const Q=P.textures;for(let _e=0,Te=Q.length;_e<Te;_e++){const Fe=a.get(Q[_e]);Fe.__webglTexture&&(o.deleteTexture(Fe.__webglTexture),u.memory.textures--),a.remove(Q[_e])}a.remove(P)}let k=0;function te(){k=0}function ie(){return k}function W(P){k=P}function z(){const P=k;return P>=r.maxTextures&&_t("WebGLTextures: Trying to use "+P+" texture units while this GPU supports only "+r.maxTextures),k+=1,P}function B(P){const A=[];return A.push(P.wrapS),A.push(P.wrapT),A.push(P.wrapR||0),A.push(P.magFilter),A.push(P.minFilter),A.push(P.anisotropy),A.push(P.internalFormat),A.push(P.format),A.push(P.type),A.push(P.generateMipmaps),A.push(P.premultiplyAlpha),A.push(P.flipY),A.push(P.unpackAlignment),A.push(P.colorSpace),A.join()}function J(P,A){const Q=a.get(P);if(P.isVideoTexture&&Ft(P),P.isRenderTargetTexture===!1&&P.isExternalTexture!==!0&&P.version>0&&Q.__version!==P.version){const _e=P.image;if(_e===null)_t("WebGLRenderer: Texture marked for update but no image data found.");else if(_e.complete===!1)_t("WebGLRenderer: Texture marked for update but image is incomplete");else{Ie(Q,P,A);return}}else P.isExternalTexture&&(Q.__webglTexture=P.sourceTexture?P.sourceTexture:null);n.bindTexture(o.TEXTURE_2D,Q.__webglTexture,o.TEXTURE0+A)}function fe(P,A){const Q=a.get(P);if(P.isRenderTargetTexture===!1&&P.version>0&&Q.__version!==P.version){Ie(Q,P,A);return}else P.isExternalTexture&&(Q.__webglTexture=P.sourceTexture?P.sourceTexture:null);n.bindTexture(o.TEXTURE_2D_ARRAY,Q.__webglTexture,o.TEXTURE0+A)}function G(P,A){const Q=a.get(P);if(P.isRenderTargetTexture===!1&&P.version>0&&Q.__version!==P.version){Ie(Q,P,A);return}n.bindTexture(o.TEXTURE_3D,Q.__webglTexture,o.TEXTURE0+A)}function I(P,A){const Q=a.get(P);if(P.isCubeDepthTexture!==!0&&P.version>0&&Q.__version!==P.version){nt(Q,P,A);return}n.bindTexture(o.TEXTURE_CUBE_MAP,Q.__webglTexture,o.TEXTURE0+A)}const K={[d0]:o.REPEAT,[Qr]:o.CLAMP_TO_EDGE,[p0]:o.MIRRORED_REPEAT},Se={[_i]:o.NEAREST,[zC]:o.NEAREST_MIPMAP_NEAREST,[Sh]:o.NEAREST_MIPMAP_LINEAR,[Ci]:o.LINEAR,[n_]:o.LINEAR_MIPMAP_NEAREST,[Uo]:o.LINEAR_MIPMAP_LINEAR},be={[HC]:o.NEVER,[WC]:o.ALWAYS,[GC]:o.LESS,[wg]:o.LEQUAL,[VC]:o.EQUAL,[Dg]:o.GEQUAL,[kC]:o.GREATER,[XC]:o.NOTEQUAL};function Ue(P,A){if(A.type===_r&&e.has("OES_texture_float_linear")===!1&&(A.magFilter===Ci||A.magFilter===n_||A.magFilter===Sh||A.magFilter===Uo||A.minFilter===Ci||A.minFilter===n_||A.minFilter===Sh||A.minFilter===Uo)&&_t("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),o.texParameteri(P,o.TEXTURE_WRAP_S,K[A.wrapS]),o.texParameteri(P,o.TEXTURE_WRAP_T,K[A.wrapT]),(P===o.TEXTURE_3D||P===o.TEXTURE_2D_ARRAY)&&o.texParameteri(P,o.TEXTURE_WRAP_R,K[A.wrapR]),o.texParameteri(P,o.TEXTURE_MAG_FILTER,Se[A.magFilter]),o.texParameteri(P,o.TEXTURE_MIN_FILTER,Se[A.minFilter]),A.compareFunction&&(o.texParameteri(P,o.TEXTURE_COMPARE_MODE,o.COMPARE_REF_TO_TEXTURE),o.texParameteri(P,o.TEXTURE_COMPARE_FUNC,be[A.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(A.magFilter===_i||A.minFilter!==Sh&&A.minFilter!==Uo||A.type===_r&&e.has("OES_texture_float_linear")===!1)return;if(A.anisotropy>1||a.get(A).__currentAnisotropy){const Q=e.get("EXT_texture_filter_anisotropic");o.texParameterf(P,Q.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(A.anisotropy,r.getMaxAnisotropy())),a.get(A).__currentAnisotropy=A.anisotropy}}}function ne(P,A){let Q=!1;P.__webglInit===void 0&&(P.__webglInit=!0,A.addEventListener("dispose",D));const _e=A.source;let Te=x.get(_e);Te===void 0&&(Te={},x.set(_e,Te));const Fe=B(A);if(Fe!==P.__cacheKey){Te[Fe]===void 0&&(Te[Fe]={texture:o.createTexture(),usedTimes:0},u.memory.textures++,Q=!0),Te[Fe].usedTimes++;const De=Te[P.__cacheKey];De!==void 0&&(Te[P.__cacheKey].usedTimes--,De.usedTimes===0&&H(A)),P.__cacheKey=Fe,P.__webglTexture=Te[Fe].texture}return Q}function xe(P,A,Q){return Math.floor(Math.floor(P/Q)/A)}function Ee(P,A,Q,_e){const Fe=P.updateRanges;if(Fe.length===0)n.texSubImage2D(o.TEXTURE_2D,0,0,0,A.width,A.height,Q,_e,A.data);else{Fe.sort((He,ze)=>He.start-ze.start);let De=0;for(let He=1;He<Fe.length;He++){const ze=Fe[De],Oe=Fe[He],Ge=ze.start+ze.count,ut=xe(Oe.start,A.width,4),dt=xe(ze.start,A.width,4);Oe.start<=Ge+1&&ut===dt&&xe(Oe.start+Oe.count-1,A.width,4)===ut?ze.count=Math.max(ze.count,Oe.start+Oe.count-ze.start):(++De,Fe[De]=Oe)}Fe.length=De+1;const de=n.getParameter(o.UNPACK_ROW_LENGTH),pe=n.getParameter(o.UNPACK_SKIP_PIXELS),Be=n.getParameter(o.UNPACK_SKIP_ROWS);n.pixelStorei(o.UNPACK_ROW_LENGTH,A.width);for(let He=0,ze=Fe.length;He<ze;He++){const Oe=Fe[He],Ge=Math.floor(Oe.start/4),ut=Math.ceil(Oe.count/4),dt=Ge%A.width,q=Math.floor(Ge/A.width),Re=ut,me=1;n.pixelStorei(o.UNPACK_SKIP_PIXELS,dt),n.pixelStorei(o.UNPACK_SKIP_ROWS,q),n.texSubImage2D(o.TEXTURE_2D,0,dt,q,Re,me,Q,_e,A.data)}P.clearUpdateRanges(),n.pixelStorei(o.UNPACK_ROW_LENGTH,de),n.pixelStorei(o.UNPACK_SKIP_PIXELS,pe),n.pixelStorei(o.UNPACK_SKIP_ROWS,Be)}}function Ie(P,A,Q){let _e=o.TEXTURE_2D;(A.isDataArrayTexture||A.isCompressedArrayTexture)&&(_e=o.TEXTURE_2D_ARRAY),A.isData3DTexture&&(_e=o.TEXTURE_3D);const Te=ne(P,A),Fe=A.source;n.bindTexture(_e,P.__webglTexture,o.TEXTURE0+Q);const De=a.get(Fe);if(Fe.version!==De.__version||Te===!0){if(n.activeTexture(o.TEXTURE0+Q),(typeof ImageBitmap<"u"&&A.image instanceof ImageBitmap)===!1){const me=Xt.getPrimaries(Xt.workingColorSpace),Ve=A.colorSpace===zs?null:Xt.getPrimaries(A.colorSpace),Pe=A.colorSpace===zs||me===Ve?o.NONE:o.BROWSER_DEFAULT_WEBGL;n.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,A.flipY),n.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),n.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,Pe)}n.pixelStorei(o.UNPACK_ALIGNMENT,A.unpackAlignment);let pe=S(A.image,!1,r.maxTextureSize);pe=Le(A,pe);const Be=l.convert(A.format,A.colorSpace),He=l.convert(A.type);let ze=C(A.internalFormat,Be,He,A.normalized,A.colorSpace,A.isVideoTexture);Ue(_e,A);let Oe;const Ge=A.mipmaps,ut=A.isVideoTexture!==!0,dt=De.__version===void 0||Te===!0,q=Fe.dataReady,Re=O(A,pe);if(A.isDepthTexture)ze=F(A.format===No,A.type),dt&&(ut?n.texStorage2D(o.TEXTURE_2D,1,ze,pe.width,pe.height):n.texImage2D(o.TEXTURE_2D,0,ze,pe.width,pe.height,0,Be,He,null));else if(A.isDataTexture)if(Ge.length>0){ut&&dt&&n.texStorage2D(o.TEXTURE_2D,Re,ze,Ge[0].width,Ge[0].height);for(let me=0,Ve=Ge.length;me<Ve;me++)Oe=Ge[me],ut?q&&n.texSubImage2D(o.TEXTURE_2D,me,0,0,Oe.width,Oe.height,Be,He,Oe.data):n.texImage2D(o.TEXTURE_2D,me,ze,Oe.width,Oe.height,0,Be,He,Oe.data);A.generateMipmaps=!1}else ut?(dt&&n.texStorage2D(o.TEXTURE_2D,Re,ze,pe.width,pe.height),q&&Ee(A,pe,Be,He)):n.texImage2D(o.TEXTURE_2D,0,ze,pe.width,pe.height,0,Be,He,pe.data);else if(A.isCompressedTexture)if(A.isCompressedArrayTexture){ut&&dt&&n.texStorage3D(o.TEXTURE_2D_ARRAY,Re,ze,Ge[0].width,Ge[0].height,pe.depth);for(let me=0,Ve=Ge.length;me<Ve;me++)if(Oe=Ge[me],A.format!==er)if(Be!==null)if(ut){if(q)if(A.layerUpdates.size>0){const Pe=zM(Oe.width,Oe.height,A.format,A.type);for(const Ae of A.layerUpdates){const Ce=Oe.data.subarray(Ae*Pe/Oe.data.BYTES_PER_ELEMENT,(Ae+1)*Pe/Oe.data.BYTES_PER_ELEMENT);n.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,me,0,0,Ae,Oe.width,Oe.height,1,Be,Ce)}A.clearLayerUpdates()}else n.compressedTexSubImage3D(o.TEXTURE_2D_ARRAY,me,0,0,0,Oe.width,Oe.height,pe.depth,Be,Oe.data)}else n.compressedTexImage3D(o.TEXTURE_2D_ARRAY,me,ze,Oe.width,Oe.height,pe.depth,0,Oe.data,0,0);else _t("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else ut?q&&n.texSubImage3D(o.TEXTURE_2D_ARRAY,me,0,0,0,Oe.width,Oe.height,pe.depth,Be,He,Oe.data):n.texImage3D(o.TEXTURE_2D_ARRAY,me,ze,Oe.width,Oe.height,pe.depth,0,Be,He,Oe.data)}else{ut&&dt&&n.texStorage2D(o.TEXTURE_2D,Re,ze,Ge[0].width,Ge[0].height);for(let me=0,Ve=Ge.length;me<Ve;me++)Oe=Ge[me],A.format!==er?Be!==null?ut?q&&n.compressedTexSubImage2D(o.TEXTURE_2D,me,0,0,Oe.width,Oe.height,Be,Oe.data):n.compressedTexImage2D(o.TEXTURE_2D,me,ze,Oe.width,Oe.height,0,Oe.data):_t("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):ut?q&&n.texSubImage2D(o.TEXTURE_2D,me,0,0,Oe.width,Oe.height,Be,He,Oe.data):n.texImage2D(o.TEXTURE_2D,me,ze,Oe.width,Oe.height,0,Be,He,Oe.data)}else if(A.isDataArrayTexture)if(ut){if(dt&&n.texStorage3D(o.TEXTURE_2D_ARRAY,Re,ze,pe.width,pe.height,pe.depth),q)if(A.layerUpdates.size>0){const me=zM(pe.width,pe.height,A.format,A.type);for(const Ve of A.layerUpdates){const Pe=pe.data.subarray(Ve*me/pe.data.BYTES_PER_ELEMENT,(Ve+1)*me/pe.data.BYTES_PER_ELEMENT);n.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,Ve,pe.width,pe.height,1,Be,He,Pe)}A.clearLayerUpdates()}else n.texSubImage3D(o.TEXTURE_2D_ARRAY,0,0,0,0,pe.width,pe.height,pe.depth,Be,He,pe.data)}else n.texImage3D(o.TEXTURE_2D_ARRAY,0,ze,pe.width,pe.height,pe.depth,0,Be,He,pe.data);else if(A.isData3DTexture)ut?(dt&&n.texStorage3D(o.TEXTURE_3D,Re,ze,pe.width,pe.height,pe.depth),q&&n.texSubImage3D(o.TEXTURE_3D,0,0,0,0,pe.width,pe.height,pe.depth,Be,He,pe.data)):n.texImage3D(o.TEXTURE_3D,0,ze,pe.width,pe.height,pe.depth,0,Be,He,pe.data);else if(A.isFramebufferTexture){if(dt)if(ut)n.texStorage2D(o.TEXTURE_2D,Re,ze,pe.width,pe.height);else{let me=pe.width,Ve=pe.height;for(let Pe=0;Pe<Re;Pe++)n.texImage2D(o.TEXTURE_2D,Pe,ze,me,Ve,0,Be,He,null),me>>=1,Ve>>=1}}else if(A.isHTMLTexture){if("texElementImage2D"in o){const me=o.canvas;if(me.hasAttribute("layoutsubtree")||me.setAttribute("layoutsubtree","true"),pe.parentNode!==me){me.appendChild(pe),v.add(A),me.onpaint=Ne=>{const ot=Ne.changedElements;for(const we of v)ot.includes(we.image)&&(we.needsUpdate=!0)},me.requestPaint();return}const Ve=0,Pe=o.RGBA,Ae=o.RGBA,Ce=o.UNSIGNED_BYTE;o.texElementImage2D(o.TEXTURE_2D,Ve,Pe,Ae,Ce,pe),o.texParameteri(o.TEXTURE_2D,o.TEXTURE_MIN_FILTER,o.LINEAR),o.texParameteri(o.TEXTURE_2D,o.TEXTURE_WRAP_S,o.CLAMP_TO_EDGE),o.texParameteri(o.TEXTURE_2D,o.TEXTURE_WRAP_T,o.CLAMP_TO_EDGE)}}else if(Ge.length>0){if(ut&&dt){const me=bt(Ge[0]);n.texStorage2D(o.TEXTURE_2D,Re,ze,me.width,me.height)}for(let me=0,Ve=Ge.length;me<Ve;me++)Oe=Ge[me],ut?q&&n.texSubImage2D(o.TEXTURE_2D,me,0,0,Be,He,Oe):n.texImage2D(o.TEXTURE_2D,me,ze,Be,He,Oe);A.generateMipmaps=!1}else if(ut){if(dt){const me=bt(pe);n.texStorage2D(o.TEXTURE_2D,Re,ze,me.width,me.height)}q&&n.texSubImage2D(o.TEXTURE_2D,0,0,0,Be,He,pe)}else n.texImage2D(o.TEXTURE_2D,0,ze,Be,He,pe);y(A)&&R(_e),De.__version=Fe.version,A.onUpdate&&A.onUpdate(A)}P.__version=A.version}function nt(P,A,Q){if(A.image.length!==6)return;const _e=ne(P,A),Te=A.source;n.bindTexture(o.TEXTURE_CUBE_MAP,P.__webglTexture,o.TEXTURE0+Q);const Fe=a.get(Te);if(Te.version!==Fe.__version||_e===!0){n.activeTexture(o.TEXTURE0+Q);const De=Xt.getPrimaries(Xt.workingColorSpace),de=A.colorSpace===zs?null:Xt.getPrimaries(A.colorSpace),pe=A.colorSpace===zs||De===de?o.NONE:o.BROWSER_DEFAULT_WEBGL;n.pixelStorei(o.UNPACK_FLIP_Y_WEBGL,A.flipY),n.pixelStorei(o.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),n.pixelStorei(o.UNPACK_ALIGNMENT,A.unpackAlignment),n.pixelStorei(o.UNPACK_COLORSPACE_CONVERSION_WEBGL,pe);const Be=A.isCompressedTexture||A.image[0].isCompressedTexture,He=A.image[0]&&A.image[0].isDataTexture,ze=[];for(let Ae=0;Ae<6;Ae++)!Be&&!He?ze[Ae]=S(A.image[Ae],!0,r.maxCubemapSize):ze[Ae]=He?A.image[Ae].image:A.image[Ae],ze[Ae]=Le(A,ze[Ae]);const Oe=ze[0],Ge=l.convert(A.format,A.colorSpace),ut=l.convert(A.type),dt=C(A.internalFormat,Ge,ut,A.normalized,A.colorSpace),q=A.isVideoTexture!==!0,Re=Fe.__version===void 0||_e===!0,me=Te.dataReady;let Ve=O(A,Oe);Ue(o.TEXTURE_CUBE_MAP,A);let Pe;if(Be){q&&Re&&n.texStorage2D(o.TEXTURE_CUBE_MAP,Ve,dt,Oe.width,Oe.height);for(let Ae=0;Ae<6;Ae++){Pe=ze[Ae].mipmaps;for(let Ce=0;Ce<Pe.length;Ce++){const Ne=Pe[Ce];A.format!==er?Ge!==null?q?me&&n.compressedTexSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ae,Ce,0,0,Ne.width,Ne.height,Ge,Ne.data):n.compressedTexImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ae,Ce,dt,Ne.width,Ne.height,0,Ne.data):_t("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):q?me&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ae,Ce,0,0,Ne.width,Ne.height,Ge,ut,Ne.data):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ae,Ce,dt,Ne.width,Ne.height,0,Ge,ut,Ne.data)}}}else{if(Pe=A.mipmaps,q&&Re){Pe.length>0&&Ve++;const Ae=bt(ze[0]);n.texStorage2D(o.TEXTURE_CUBE_MAP,Ve,dt,Ae.width,Ae.height)}for(let Ae=0;Ae<6;Ae++)if(He){q?me&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ae,0,0,0,ze[Ae].width,ze[Ae].height,Ge,ut,ze[Ae].data):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ae,0,dt,ze[Ae].width,ze[Ae].height,0,Ge,ut,ze[Ae].data);for(let Ce=0;Ce<Pe.length;Ce++){const ot=Pe[Ce].image[Ae].image;q?me&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ae,Ce+1,0,0,ot.width,ot.height,Ge,ut,ot.data):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ae,Ce+1,dt,ot.width,ot.height,0,Ge,ut,ot.data)}}else{q?me&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ae,0,0,0,Ge,ut,ze[Ae]):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ae,0,dt,Ge,ut,ze[Ae]);for(let Ce=0;Ce<Pe.length;Ce++){const Ne=Pe[Ce];q?me&&n.texSubImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ae,Ce+1,0,0,Ge,ut,Ne.image[Ae]):n.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Ae,Ce+1,dt,Ge,ut,Ne.image[Ae])}}}y(A)&&R(o.TEXTURE_CUBE_MAP),Fe.__version=Te.version,A.onUpdate&&A.onUpdate(A)}P.__version=A.version}function Ze(P,A,Q,_e,Te,Fe){const De=l.convert(Q.format,Q.colorSpace),de=l.convert(Q.type),pe=C(Q.internalFormat,De,de,Q.normalized,Q.colorSpace),Be=a.get(A),He=a.get(Q);if(He.__renderTarget=A,!Be.__hasExternalTextures){const ze=Math.max(1,A.width>>Fe),Oe=Math.max(1,A.height>>Fe);Te===o.TEXTURE_3D||Te===o.TEXTURE_2D_ARRAY?n.texImage3D(Te,Fe,pe,ze,Oe,A.depth,0,De,de,null):n.texImage2D(Te,Fe,pe,ze,Oe,0,De,de,null)}n.bindFramebuffer(o.FRAMEBUFFER,P),mt(A)?f.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,_e,Te,He.__webglTexture,0,gt(A)):(Te===o.TEXTURE_2D||Te>=o.TEXTURE_CUBE_MAP_POSITIVE_X&&Te<=o.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&o.framebufferTexture2D(o.FRAMEBUFFER,_e,Te,He.__webglTexture,Fe),n.bindFramebuffer(o.FRAMEBUFFER,null)}function Mt(P,A,Q){if(o.bindRenderbuffer(o.RENDERBUFFER,P),A.depthBuffer){const _e=A.depthTexture,Te=_e&&_e.isDepthTexture?_e.type:null,Fe=F(A.stencilBuffer,Te),De=A.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT;mt(A)?f.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,gt(A),Fe,A.width,A.height):Q?o.renderbufferStorageMultisample(o.RENDERBUFFER,gt(A),Fe,A.width,A.height):o.renderbufferStorage(o.RENDERBUFFER,Fe,A.width,A.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,De,o.RENDERBUFFER,P)}else{const _e=A.textures;for(let Te=0;Te<_e.length;Te++){const Fe=_e[Te],De=l.convert(Fe.format,Fe.colorSpace),de=l.convert(Fe.type),pe=C(Fe.internalFormat,De,de,Fe.normalized,Fe.colorSpace);mt(A)?f.renderbufferStorageMultisampleEXT(o.RENDERBUFFER,gt(A),pe,A.width,A.height):Q?o.renderbufferStorageMultisample(o.RENDERBUFFER,gt(A),pe,A.width,A.height):o.renderbufferStorage(o.RENDERBUFFER,pe,A.width,A.height)}}o.bindRenderbuffer(o.RENDERBUFFER,null)}function Ye(P,A,Q){const _e=A.isWebGLCubeRenderTarget===!0;if(n.bindFramebuffer(o.FRAMEBUFFER,P),!(A.depthTexture&&A.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const Te=a.get(A.depthTexture);if(Te.__renderTarget=A,(!Te.__webglTexture||A.depthTexture.image.width!==A.width||A.depthTexture.image.height!==A.height)&&(A.depthTexture.image.width=A.width,A.depthTexture.image.height=A.height,A.depthTexture.needsUpdate=!0),_e){if(Te.__webglInit===void 0&&(Te.__webglInit=!0,A.depthTexture.addEventListener("dispose",D)),Te.__webglTexture===void 0){Te.__webglTexture=o.createTexture(),n.bindTexture(o.TEXTURE_CUBE_MAP,Te.__webglTexture),Ue(o.TEXTURE_CUBE_MAP,A.depthTexture);const Be=l.convert(A.depthTexture.format),He=l.convert(A.depthTexture.type);let ze;A.depthTexture.format===rs?ze=o.DEPTH_COMPONENT24:A.depthTexture.format===No&&(ze=o.DEPTH24_STENCIL8);for(let Oe=0;Oe<6;Oe++)o.texImage2D(o.TEXTURE_CUBE_MAP_POSITIVE_X+Oe,0,ze,A.width,A.height,0,Be,He,null)}}else J(A.depthTexture,0);const Fe=Te.__webglTexture,De=gt(A),de=_e?o.TEXTURE_CUBE_MAP_POSITIVE_X+Q:o.TEXTURE_2D,pe=A.depthTexture.format===No?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT;if(A.depthTexture.format===rs)mt(A)?f.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,pe,de,Fe,0,De):o.framebufferTexture2D(o.FRAMEBUFFER,pe,de,Fe,0);else if(A.depthTexture.format===No)mt(A)?f.framebufferTexture2DMultisampleEXT(o.FRAMEBUFFER,pe,de,Fe,0,De):o.framebufferTexture2D(o.FRAMEBUFFER,pe,de,Fe,0);else throw new Error("Unknown depthTexture format")}function it(P){const A=a.get(P),Q=P.isWebGLCubeRenderTarget===!0;if(A.__boundDepthTexture!==P.depthTexture){const _e=P.depthTexture;if(A.__depthDisposeCallback&&A.__depthDisposeCallback(),_e){const Te=()=>{delete A.__boundDepthTexture,delete A.__depthDisposeCallback,_e.removeEventListener("dispose",Te)};_e.addEventListener("dispose",Te),A.__depthDisposeCallback=Te}A.__boundDepthTexture=_e}if(P.depthTexture&&!A.__autoAllocateDepthBuffer)if(Q)for(let _e=0;_e<6;_e++)Ye(A.__webglFramebuffer[_e],P,_e);else{const _e=P.texture.mipmaps;_e&&_e.length>0?Ye(A.__webglFramebuffer[0],P,0):Ye(A.__webglFramebuffer,P,0)}else if(Q){A.__webglDepthbuffer=[];for(let _e=0;_e<6;_e++)if(n.bindFramebuffer(o.FRAMEBUFFER,A.__webglFramebuffer[_e]),A.__webglDepthbuffer[_e]===void 0)A.__webglDepthbuffer[_e]=o.createRenderbuffer(),Mt(A.__webglDepthbuffer[_e],P,!1);else{const Te=P.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,Fe=A.__webglDepthbuffer[_e];o.bindRenderbuffer(o.RENDERBUFFER,Fe),o.framebufferRenderbuffer(o.FRAMEBUFFER,Te,o.RENDERBUFFER,Fe)}}else{const _e=P.texture.mipmaps;if(_e&&_e.length>0?n.bindFramebuffer(o.FRAMEBUFFER,A.__webglFramebuffer[0]):n.bindFramebuffer(o.FRAMEBUFFER,A.__webglFramebuffer),A.__webglDepthbuffer===void 0)A.__webglDepthbuffer=o.createRenderbuffer(),Mt(A.__webglDepthbuffer,P,!1);else{const Te=P.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,Fe=A.__webglDepthbuffer;o.bindRenderbuffer(o.RENDERBUFFER,Fe),o.framebufferRenderbuffer(o.FRAMEBUFFER,Te,o.RENDERBUFFER,Fe)}}n.bindFramebuffer(o.FRAMEBUFFER,null)}function xt(P,A,Q){const _e=a.get(P);A!==void 0&&Ze(_e.__webglFramebuffer,P,P.texture,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,0),Q!==void 0&&it(P)}function st(P){const A=P.texture,Q=a.get(P),_e=a.get(A);P.addEventListener("dispose",T);const Te=P.textures,Fe=P.isWebGLCubeRenderTarget===!0,De=Te.length>1;if(De||(_e.__webglTexture===void 0&&(_e.__webglTexture=o.createTexture()),_e.__version=A.version,u.memory.textures++),Fe){Q.__webglFramebuffer=[];for(let de=0;de<6;de++)if(A.mipmaps&&A.mipmaps.length>0){Q.__webglFramebuffer[de]=[];for(let pe=0;pe<A.mipmaps.length;pe++)Q.__webglFramebuffer[de][pe]=o.createFramebuffer()}else Q.__webglFramebuffer[de]=o.createFramebuffer()}else{if(A.mipmaps&&A.mipmaps.length>0){Q.__webglFramebuffer=[];for(let de=0;de<A.mipmaps.length;de++)Q.__webglFramebuffer[de]=o.createFramebuffer()}else Q.__webglFramebuffer=o.createFramebuffer();if(De)for(let de=0,pe=Te.length;de<pe;de++){const Be=a.get(Te[de]);Be.__webglTexture===void 0&&(Be.__webglTexture=o.createTexture(),u.memory.textures++)}if(P.samples>0&&mt(P)===!1){Q.__webglMultisampledFramebuffer=o.createFramebuffer(),Q.__webglColorRenderbuffer=[],n.bindFramebuffer(o.FRAMEBUFFER,Q.__webglMultisampledFramebuffer);for(let de=0;de<Te.length;de++){const pe=Te[de];Q.__webglColorRenderbuffer[de]=o.createRenderbuffer(),o.bindRenderbuffer(o.RENDERBUFFER,Q.__webglColorRenderbuffer[de]);const Be=l.convert(pe.format,pe.colorSpace),He=l.convert(pe.type),ze=C(pe.internalFormat,Be,He,pe.normalized,pe.colorSpace,P.isXRRenderTarget===!0),Oe=gt(P);o.renderbufferStorageMultisample(o.RENDERBUFFER,Oe,ze,P.width,P.height),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+de,o.RENDERBUFFER,Q.__webglColorRenderbuffer[de])}o.bindRenderbuffer(o.RENDERBUFFER,null),P.depthBuffer&&(Q.__webglDepthRenderbuffer=o.createRenderbuffer(),Mt(Q.__webglDepthRenderbuffer,P,!0)),n.bindFramebuffer(o.FRAMEBUFFER,null)}}if(Fe){n.bindTexture(o.TEXTURE_CUBE_MAP,_e.__webglTexture),Ue(o.TEXTURE_CUBE_MAP,A);for(let de=0;de<6;de++)if(A.mipmaps&&A.mipmaps.length>0)for(let pe=0;pe<A.mipmaps.length;pe++)Ze(Q.__webglFramebuffer[de][pe],P,A,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+de,pe);else Ze(Q.__webglFramebuffer[de],P,A,o.COLOR_ATTACHMENT0,o.TEXTURE_CUBE_MAP_POSITIVE_X+de,0);y(A)&&R(o.TEXTURE_CUBE_MAP),n.unbindTexture()}else if(De){for(let de=0,pe=Te.length;de<pe;de++){const Be=Te[de],He=a.get(Be);let ze=o.TEXTURE_2D;(P.isWebGL3DRenderTarget||P.isWebGLArrayRenderTarget)&&(ze=P.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY),n.bindTexture(ze,He.__webglTexture),Ue(ze,Be),Ze(Q.__webglFramebuffer,P,Be,o.COLOR_ATTACHMENT0+de,ze,0),y(Be)&&R(ze)}n.unbindTexture()}else{let de=o.TEXTURE_2D;if((P.isWebGL3DRenderTarget||P.isWebGLArrayRenderTarget)&&(de=P.isWebGL3DRenderTarget?o.TEXTURE_3D:o.TEXTURE_2D_ARRAY),n.bindTexture(de,_e.__webglTexture),Ue(de,A),A.mipmaps&&A.mipmaps.length>0)for(let pe=0;pe<A.mipmaps.length;pe++)Ze(Q.__webglFramebuffer[pe],P,A,o.COLOR_ATTACHMENT0,de,pe);else Ze(Q.__webglFramebuffer,P,A,o.COLOR_ATTACHMENT0,de,0);y(A)&&R(de),n.unbindTexture()}P.depthBuffer&&it(P)}function le(P){const A=P.textures;for(let Q=0,_e=A.length;Q<_e;Q++){const Te=A[Q];if(y(Te)){const Fe=U(P),De=a.get(Te).__webglTexture;n.bindTexture(Fe,De),R(Fe),n.unbindTexture()}}}const Dt=[],mn=[];function j(P){if(P.samples>0){if(mt(P)===!1){const A=P.textures,Q=P.width,_e=P.height;let Te=o.COLOR_BUFFER_BIT;const Fe=P.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT,De=a.get(P),de=A.length>1;if(de)for(let Be=0;Be<A.length;Be++)n.bindFramebuffer(o.FRAMEBUFFER,De.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Be,o.RENDERBUFFER,null),n.bindFramebuffer(o.FRAMEBUFFER,De.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+Be,o.TEXTURE_2D,null,0);n.bindFramebuffer(o.READ_FRAMEBUFFER,De.__webglMultisampledFramebuffer);const pe=P.texture.mipmaps;pe&&pe.length>0?n.bindFramebuffer(o.DRAW_FRAMEBUFFER,De.__webglFramebuffer[0]):n.bindFramebuffer(o.DRAW_FRAMEBUFFER,De.__webglFramebuffer);for(let Be=0;Be<A.length;Be++){if(P.resolveDepthBuffer&&(P.depthBuffer&&(Te|=o.DEPTH_BUFFER_BIT),P.stencilBuffer&&P.resolveStencilBuffer&&(Te|=o.STENCIL_BUFFER_BIT)),de){o.framebufferRenderbuffer(o.READ_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.RENDERBUFFER,De.__webglColorRenderbuffer[Be]);const He=a.get(A[Be]).__webglTexture;o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0,o.TEXTURE_2D,He,0)}o.blitFramebuffer(0,0,Q,_e,0,0,Q,_e,Te,o.NEAREST),d===!0&&(Dt.length=0,mn.length=0,Dt.push(o.COLOR_ATTACHMENT0+Be),P.depthBuffer&&P.resolveDepthBuffer===!1&&(Dt.push(Fe),mn.push(Fe),o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,mn)),o.invalidateFramebuffer(o.READ_FRAMEBUFFER,Dt))}if(n.bindFramebuffer(o.READ_FRAMEBUFFER,null),n.bindFramebuffer(o.DRAW_FRAMEBUFFER,null),de)for(let Be=0;Be<A.length;Be++){n.bindFramebuffer(o.FRAMEBUFFER,De.__webglMultisampledFramebuffer),o.framebufferRenderbuffer(o.FRAMEBUFFER,o.COLOR_ATTACHMENT0+Be,o.RENDERBUFFER,De.__webglColorRenderbuffer[Be]);const He=a.get(A[Be]).__webglTexture;n.bindFramebuffer(o.FRAMEBUFFER,De.__webglFramebuffer),o.framebufferTexture2D(o.DRAW_FRAMEBUFFER,o.COLOR_ATTACHMENT0+Be,o.TEXTURE_2D,He,0)}n.bindFramebuffer(o.DRAW_FRAMEBUFFER,De.__webglMultisampledFramebuffer)}else if(P.depthBuffer&&P.resolveDepthBuffer===!1&&d){const A=P.stencilBuffer?o.DEPTH_STENCIL_ATTACHMENT:o.DEPTH_ATTACHMENT;o.invalidateFramebuffer(o.DRAW_FRAMEBUFFER,[A])}}}function gt(P){return Math.min(r.maxSamples,P.samples)}function mt(P){const A=a.get(P);return P.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&A.__useRenderToTexture!==!1}function Ft(P){const A=u.render.frame;_.get(P)!==A&&(_.set(P,A),P.update())}function Le(P,A){const Q=P.colorSpace,_e=P.format,Te=P.type;return P.isCompressedTexture===!0||P.isVideoTexture===!0||Q!==gd&&Q!==zs&&(Xt.getTransfer(Q)===cn?(_e!==er||Te!==Ia)&&_t("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):jt("WebGLTextures: Unsupported texture color space:",Q)),A}function bt(P){return typeof HTMLImageElement<"u"&&P instanceof HTMLImageElement?(p.width=P.naturalWidth||P.width,p.height=P.naturalHeight||P.height):typeof VideoFrame<"u"&&P instanceof VideoFrame?(p.width=P.displayWidth,p.height=P.displayHeight):(p.width=P.width,p.height=P.height),p}this.allocateTextureUnit=z,this.resetTextureUnits=te,this.getTextureUnits=ie,this.setTextureUnits=W,this.setTexture2D=J,this.setTexture2DArray=fe,this.setTexture3D=G,this.setTextureCube=I,this.rebindTextures=xt,this.setupRenderTarget=st,this.updateRenderTargetMipmap=le,this.updateMultisampleRenderTarget=j,this.setupDepthRenderbuffer=it,this.setupFrameBufferTexture=Ze,this.useMultisampledRTT=mt,this.isReversedDepthBuffer=function(){return n.buffers.depth.getReversed()}}function mN(o,e){function n(a,r=zs){let l;const u=Xt.getTransfer(r);if(a===Ia)return o.UNSIGNED_BYTE;if(a===Eg)return o.UNSIGNED_SHORT_4_4_4_4;if(a===Tg)return o.UNSIGNED_SHORT_5_5_5_1;if(a===kb)return o.UNSIGNED_INT_5_9_9_9_REV;if(a===Xb)return o.UNSIGNED_INT_10F_11F_11F_REV;if(a===Gb)return o.BYTE;if(a===Vb)return o.SHORT;if(a===qu)return o.UNSIGNED_SHORT;if(a===bg)return o.INT;if(a===Mr)return o.UNSIGNED_INT;if(a===_r)return o.FLOAT;if(a===as)return o.HALF_FLOAT;if(a===Wb)return o.ALPHA;if(a===qb)return o.RGB;if(a===er)return o.RGBA;if(a===rs)return o.DEPTH_COMPONENT;if(a===No)return o.DEPTH_STENCIL;if(a===Yb)return o.RED;if(a===Ag)return o.RED_INTEGER;if(a===Xo)return o.RG;if(a===Rg)return o.RG_INTEGER;if(a===Cg)return o.RGBA_INTEGER;if(a===$h||a===ed||a===td||a===nd)if(u===cn)if(l=e.get("WEBGL_compressed_texture_s3tc_srgb"),l!==null){if(a===$h)return l.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(a===ed)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(a===td)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(a===nd)return l.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(l=e.get("WEBGL_compressed_texture_s3tc"),l!==null){if(a===$h)return l.COMPRESSED_RGB_S3TC_DXT1_EXT;if(a===ed)return l.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(a===td)return l.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(a===nd)return l.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(a===m0||a===_0||a===g0||a===v0)if(l=e.get("WEBGL_compressed_texture_pvrtc"),l!==null){if(a===m0)return l.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(a===_0)return l.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(a===g0)return l.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(a===v0)return l.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(a===x0||a===S0||a===y0||a===M0||a===b0||a===md||a===E0)if(l=e.get("WEBGL_compressed_texture_etc"),l!==null){if(a===x0||a===S0)return u===cn?l.COMPRESSED_SRGB8_ETC2:l.COMPRESSED_RGB8_ETC2;if(a===y0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:l.COMPRESSED_RGBA8_ETC2_EAC;if(a===M0)return l.COMPRESSED_R11_EAC;if(a===b0)return l.COMPRESSED_SIGNED_R11_EAC;if(a===md)return l.COMPRESSED_RG11_EAC;if(a===E0)return l.COMPRESSED_SIGNED_RG11_EAC}else return null;if(a===T0||a===A0||a===R0||a===C0||a===w0||a===D0||a===U0||a===N0||a===L0||a===O0||a===P0||a===F0||a===z0||a===I0)if(l=e.get("WEBGL_compressed_texture_astc"),l!==null){if(a===T0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:l.COMPRESSED_RGBA_ASTC_4x4_KHR;if(a===A0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:l.COMPRESSED_RGBA_ASTC_5x4_KHR;if(a===R0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:l.COMPRESSED_RGBA_ASTC_5x5_KHR;if(a===C0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:l.COMPRESSED_RGBA_ASTC_6x5_KHR;if(a===w0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:l.COMPRESSED_RGBA_ASTC_6x6_KHR;if(a===D0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:l.COMPRESSED_RGBA_ASTC_8x5_KHR;if(a===U0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:l.COMPRESSED_RGBA_ASTC_8x6_KHR;if(a===N0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:l.COMPRESSED_RGBA_ASTC_8x8_KHR;if(a===L0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:l.COMPRESSED_RGBA_ASTC_10x5_KHR;if(a===O0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:l.COMPRESSED_RGBA_ASTC_10x6_KHR;if(a===P0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:l.COMPRESSED_RGBA_ASTC_10x8_KHR;if(a===F0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:l.COMPRESSED_RGBA_ASTC_10x10_KHR;if(a===z0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:l.COMPRESSED_RGBA_ASTC_12x10_KHR;if(a===I0)return u===cn?l.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:l.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(a===B0||a===H0||a===G0)if(l=e.get("EXT_texture_compression_bptc"),l!==null){if(a===B0)return u===cn?l.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:l.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(a===H0)return l.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(a===G0)return l.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(a===V0||a===k0||a===_d||a===X0)if(l=e.get("EXT_texture_compression_rgtc"),l!==null){if(a===V0)return l.COMPRESSED_RED_RGTC1_EXT;if(a===k0)return l.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(a===_d)return l.COMPRESSED_RED_GREEN_RGTC2_EXT;if(a===X0)return l.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return a===Yu?o.UNSIGNED_INT_24_8:o[a]!==void 0?o[a]:null}return{convert:n}}const _N=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,gN=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class vN{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,n){if(this.texture===null){const a=new iE(e.texture);(e.depthNear!==n.depthNear||e.depthFar!==n.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=a}}getMesh(e){if(this.texture!==null&&this.mesh===null){const n=e.cameras[0].viewport,a=new Va({vertexShader:_N,fragmentShader:gN,uniforms:{depthColor:{value:this.texture},depthWidth:{value:n.z},depthHeight:{value:n.w}}});this.mesh=new nr(new Cd(20,20),a)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class xN extends Yo{constructor(e,n){super();const a=this;let r=null,l=1,u=null,f="local-floor",d=1,p=null,_=null,v=null,g=null,x=null,M=null;const E=typeof XRWebGLBinding<"u",S=new vN,y={},R=n.getContextAttributes();let U=null,C=null;const F=[],O=[],D=new Jt;let T=null;const L=new Ja;L.viewport=new Vn;const H=new Ja;H.viewport=new Vn;const V=[L,H],k=new w2;let te=null,ie=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(ne){let xe=F[ne];return xe===void 0&&(xe=new u_,F[ne]=xe),xe.getTargetRaySpace()},this.getControllerGrip=function(ne){let xe=F[ne];return xe===void 0&&(xe=new u_,F[ne]=xe),xe.getGripSpace()},this.getHand=function(ne){let xe=F[ne];return xe===void 0&&(xe=new u_,F[ne]=xe),xe.getHandSpace()};function W(ne){const xe=O.indexOf(ne.inputSource);if(xe===-1)return;const Ee=F[xe];Ee!==void 0&&(Ee.update(ne.inputSource,ne.frame,p||u),Ee.dispatchEvent({type:ne.type,data:ne.inputSource}))}function z(){r.removeEventListener("select",W),r.removeEventListener("selectstart",W),r.removeEventListener("selectend",W),r.removeEventListener("squeeze",W),r.removeEventListener("squeezestart",W),r.removeEventListener("squeezeend",W),r.removeEventListener("end",z),r.removeEventListener("inputsourceschange",B);for(let ne=0;ne<F.length;ne++){const xe=O[ne];xe!==null&&(O[ne]=null,F[ne].disconnect(xe))}te=null,ie=null,S.reset();for(const ne in y)delete y[ne];e.setRenderTarget(U),x=null,g=null,v=null,r=null,C=null,Ue.stop(),a.isPresenting=!1,e.setPixelRatio(T),e.setSize(D.width,D.height,!1),a.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(ne){l=ne,a.isPresenting===!0&&_t("WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(ne){f=ne,a.isPresenting===!0&&_t("WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return p||u},this.setReferenceSpace=function(ne){p=ne},this.getBaseLayer=function(){return g!==null?g:x},this.getBinding=function(){return v===null&&E&&(v=new XRWebGLBinding(r,n)),v},this.getFrame=function(){return M},this.getSession=function(){return r},this.setSession=async function(ne){if(r=ne,r!==null){if(U=e.getRenderTarget(),r.addEventListener("select",W),r.addEventListener("selectstart",W),r.addEventListener("selectend",W),r.addEventListener("squeeze",W),r.addEventListener("squeezestart",W),r.addEventListener("squeezeend",W),r.addEventListener("end",z),r.addEventListener("inputsourceschange",B),R.xrCompatible!==!0&&await n.makeXRCompatible(),T=e.getPixelRatio(),e.getSize(D),E&&"createProjectionLayer"in XRWebGLBinding.prototype){let Ee=null,Ie=null,nt=null;R.depth&&(nt=R.stencil?n.DEPTH24_STENCIL8:n.DEPTH_COMPONENT24,Ee=R.stencil?No:rs,Ie=R.stencil?Yu:Mr);const Ze={colorFormat:n.RGBA8,depthFormat:nt,scaleFactor:l};v=this.getBinding(),g=v.createProjectionLayer(Ze),r.updateRenderState({layers:[g]}),e.setPixelRatio(1),e.setSize(g.textureWidth,g.textureHeight,!1),C=new Sr(g.textureWidth,g.textureHeight,{format:er,type:Ia,depthTexture:new fc(g.textureWidth,g.textureHeight,Ie,void 0,void 0,void 0,void 0,void 0,void 0,Ee),stencilBuffer:R.stencil,colorSpace:e.outputColorSpace,samples:R.antialias?4:0,resolveDepthBuffer:g.ignoreDepthValues===!1,resolveStencilBuffer:g.ignoreDepthValues===!1})}else{const Ee={antialias:R.antialias,alpha:!0,depth:R.depth,stencil:R.stencil,framebufferScaleFactor:l};x=new XRWebGLLayer(r,n,Ee),r.updateRenderState({baseLayer:x}),e.setPixelRatio(1),e.setSize(x.framebufferWidth,x.framebufferHeight,!1),C=new Sr(x.framebufferWidth,x.framebufferHeight,{format:er,type:Ia,colorSpace:e.outputColorSpace,stencilBuffer:R.stencil,resolveDepthBuffer:x.ignoreDepthValues===!1,resolveStencilBuffer:x.ignoreDepthValues===!1})}C.isXRRenderTarget=!0,this.setFoveation(d),p=null,u=await r.requestReferenceSpace(f),Ue.setContext(r),Ue.start(),a.isPresenting=!0,a.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(r!==null)return r.environmentBlendMode},this.getDepthTexture=function(){return S.getDepthTexture()};function B(ne){for(let xe=0;xe<ne.removed.length;xe++){const Ee=ne.removed[xe],Ie=O.indexOf(Ee);Ie>=0&&(O[Ie]=null,F[Ie].disconnect(Ee))}for(let xe=0;xe<ne.added.length;xe++){const Ee=ne.added[xe];let Ie=O.indexOf(Ee);if(Ie===-1){for(let Ze=0;Ze<F.length;Ze++)if(Ze>=O.length){O.push(Ee),Ie=Ze;break}else if(O[Ze]===null){O[Ze]=Ee,Ie=Ze;break}if(Ie===-1)break}const nt=F[Ie];nt&&nt.connect(Ee)}}const J=new ue,fe=new ue;function G(ne,xe,Ee){J.setFromMatrixPosition(xe.matrixWorld),fe.setFromMatrixPosition(Ee.matrixWorld);const Ie=J.distanceTo(fe),nt=xe.projectionMatrix.elements,Ze=Ee.projectionMatrix.elements,Mt=nt[14]/(nt[10]-1),Ye=nt[14]/(nt[10]+1),it=(nt[9]+1)/nt[5],xt=(nt[9]-1)/nt[5],st=(nt[8]-1)/nt[0],le=(Ze[8]+1)/Ze[0],Dt=Mt*st,mn=Mt*le,j=Ie/(-st+le),gt=j*-st;if(xe.matrixWorld.decompose(ne.position,ne.quaternion,ne.scale),ne.translateX(gt),ne.translateZ(j),ne.matrixWorld.compose(ne.position,ne.quaternion,ne.scale),ne.matrixWorldInverse.copy(ne.matrixWorld).invert(),nt[10]===-1)ne.projectionMatrix.copy(xe.projectionMatrix),ne.projectionMatrixInverse.copy(xe.projectionMatrixInverse);else{const mt=Mt+j,Ft=Ye+j,Le=Dt-gt,bt=mn+(Ie-gt),P=it*Ye/Ft*mt,A=xt*Ye/Ft*mt;ne.projectionMatrix.makePerspective(Le,bt,P,A,mt,Ft),ne.projectionMatrixInverse.copy(ne.projectionMatrix).invert()}}function I(ne,xe){xe===null?ne.matrixWorld.copy(ne.matrix):ne.matrixWorld.multiplyMatrices(xe.matrixWorld,ne.matrix),ne.matrixWorldInverse.copy(ne.matrixWorld).invert()}this.updateCamera=function(ne){if(r===null)return;let xe=ne.near,Ee=ne.far;S.texture!==null&&(S.depthNear>0&&(xe=S.depthNear),S.depthFar>0&&(Ee=S.depthFar)),k.near=H.near=L.near=xe,k.far=H.far=L.far=Ee,(te!==k.near||ie!==k.far)&&(r.updateRenderState({depthNear:k.near,depthFar:k.far}),te=k.near,ie=k.far),k.layers.mask=ne.layers.mask|6,L.layers.mask=k.layers.mask&-5,H.layers.mask=k.layers.mask&-3;const Ie=ne.parent,nt=k.cameras;I(k,Ie);for(let Ze=0;Ze<nt.length;Ze++)I(nt[Ze],Ie);nt.length===2?G(k,L,H):k.projectionMatrix.copy(L.projectionMatrix),K(ne,k,Ie)};function K(ne,xe,Ee){Ee===null?ne.matrix.copy(xe.matrixWorld):(ne.matrix.copy(Ee.matrixWorld),ne.matrix.invert(),ne.matrix.multiply(xe.matrixWorld)),ne.matrix.decompose(ne.position,ne.quaternion,ne.scale),ne.updateMatrixWorld(!0),ne.projectionMatrix.copy(xe.projectionMatrix),ne.projectionMatrixInverse.copy(xe.projectionMatrixInverse),ne.isPerspectiveCamera&&(ne.fov=q0*2*Math.atan(1/ne.projectionMatrix.elements[5]),ne.zoom=1)}this.getCamera=function(){return k},this.getFoveation=function(){if(!(g===null&&x===null))return d},this.setFoveation=function(ne){d=ne,g!==null&&(g.fixedFoveation=ne),x!==null&&x.fixedFoveation!==void 0&&(x.fixedFoveation=ne)},this.hasDepthSensing=function(){return S.texture!==null},this.getDepthSensingMesh=function(){return S.getMesh(k)},this.getCameraTexture=function(ne){return y[ne]};let Se=null;function be(ne,xe){if(_=xe.getViewerPose(p||u),M=xe,_!==null){const Ee=_.views;x!==null&&(e.setRenderTargetFramebuffer(C,x.framebuffer),e.setRenderTarget(C));let Ie=!1;Ee.length!==k.cameras.length&&(k.cameras.length=0,Ie=!0);for(let Ye=0;Ye<Ee.length;Ye++){const it=Ee[Ye];let xt=null;if(x!==null)xt=x.getViewport(it);else{const le=v.getViewSubImage(g,it);xt=le.viewport,Ye===0&&(e.setRenderTargetTextures(C,le.colorTexture,le.depthStencilTexture),e.setRenderTarget(C))}let st=V[Ye];st===void 0&&(st=new Ja,st.layers.enable(Ye),st.viewport=new Vn,V[Ye]=st),st.matrix.fromArray(it.transform.matrix),st.matrix.decompose(st.position,st.quaternion,st.scale),st.projectionMatrix.fromArray(it.projectionMatrix),st.projectionMatrixInverse.copy(st.projectionMatrix).invert(),st.viewport.set(xt.x,xt.y,xt.width,xt.height),Ye===0&&(k.matrix.copy(st.matrix),k.matrix.decompose(k.position,k.quaternion,k.scale)),Ie===!0&&k.cameras.push(st)}const nt=r.enabledFeatures;if(nt&&nt.includes("depth-sensing")&&r.depthUsage=="gpu-optimized"&&E){v=a.getBinding();const Ye=v.getDepthInformation(Ee[0]);Ye&&Ye.isValid&&Ye.texture&&S.init(Ye,r.renderState)}if(nt&&nt.includes("camera-access")&&E){e.state.unbindTexture(),v=a.getBinding();for(let Ye=0;Ye<Ee.length;Ye++){const it=Ee[Ye].camera;if(it){let xt=y[it];xt||(xt=new iE,y[it]=xt);const st=v.getCameraImage(it);xt.sourceTexture=st}}}}for(let Ee=0;Ee<F.length;Ee++){const Ie=O[Ee],nt=F[Ee];Ie!==null&&nt!==void 0&&nt.update(Ie,xe,p||u)}Se&&Se(ne,xe),xe.detectedPlanes&&a.dispatchEvent({type:"planesdetected",data:xe}),M=null}const Ue=new sE;Ue.setAnimationLoop(be),this.setAnimationLoop=function(ne){Se=ne},this.dispose=function(){}}}const SN=new ii,dE=new Et;dE.set(-1,0,0,0,1,0,0,0,1);function yN(o,e){function n(S,y){S.matrixAutoUpdate===!0&&S.updateMatrix(),y.value.copy(S.matrix)}function a(S,y){y.color.getRGB(S.fogColor.value,aE(o)),y.isFog?(S.fogNear.value=y.near,S.fogFar.value=y.far):y.isFogExp2&&(S.fogDensity.value=y.density)}function r(S,y,R,U,C){y.isNodeMaterial?y.uniformsNeedUpdate=!1:y.isMeshBasicMaterial?l(S,y):y.isMeshLambertMaterial?(l(S,y),y.envMap&&(S.envMapIntensity.value=y.envMapIntensity)):y.isMeshToonMaterial?(l(S,y),v(S,y)):y.isMeshPhongMaterial?(l(S,y),_(S,y),y.envMap&&(S.envMapIntensity.value=y.envMapIntensity)):y.isMeshStandardMaterial?(l(S,y),g(S,y),y.isMeshPhysicalMaterial&&x(S,y,C)):y.isMeshMatcapMaterial?(l(S,y),M(S,y)):y.isMeshDepthMaterial?l(S,y):y.isMeshDistanceMaterial?(l(S,y),E(S,y)):y.isMeshNormalMaterial?l(S,y):y.isLineBasicMaterial?(u(S,y),y.isLineDashedMaterial&&f(S,y)):y.isPointsMaterial?d(S,y,R,U):y.isSpriteMaterial?p(S,y):y.isShadowMaterial?(S.color.value.copy(y.color),S.opacity.value=y.opacity):y.isShaderMaterial&&(y.uniformsNeedUpdate=!1)}function l(S,y){S.opacity.value=y.opacity,y.color&&S.diffuse.value.copy(y.color),y.emissive&&S.emissive.value.copy(y.emissive).multiplyScalar(y.emissiveIntensity),y.map&&(S.map.value=y.map,n(y.map,S.mapTransform)),y.alphaMap&&(S.alphaMap.value=y.alphaMap,n(y.alphaMap,S.alphaMapTransform)),y.bumpMap&&(S.bumpMap.value=y.bumpMap,n(y.bumpMap,S.bumpMapTransform),S.bumpScale.value=y.bumpScale,y.side===$i&&(S.bumpScale.value*=-1)),y.normalMap&&(S.normalMap.value=y.normalMap,n(y.normalMap,S.normalMapTransform),S.normalScale.value.copy(y.normalScale),y.side===$i&&S.normalScale.value.negate()),y.displacementMap&&(S.displacementMap.value=y.displacementMap,n(y.displacementMap,S.displacementMapTransform),S.displacementScale.value=y.displacementScale,S.displacementBias.value=y.displacementBias),y.emissiveMap&&(S.emissiveMap.value=y.emissiveMap,n(y.emissiveMap,S.emissiveMapTransform)),y.specularMap&&(S.specularMap.value=y.specularMap,n(y.specularMap,S.specularMapTransform)),y.alphaTest>0&&(S.alphaTest.value=y.alphaTest);const R=e.get(y),U=R.envMap,C=R.envMapRotation;U&&(S.envMap.value=U,S.envMapRotation.value.setFromMatrix4(SN.makeRotationFromEuler(C)).transpose(),U.isCubeTexture&&U.isRenderTargetTexture===!1&&S.envMapRotation.value.premultiply(dE),S.reflectivity.value=y.reflectivity,S.ior.value=y.ior,S.refractionRatio.value=y.refractionRatio),y.lightMap&&(S.lightMap.value=y.lightMap,S.lightMapIntensity.value=y.lightMapIntensity,n(y.lightMap,S.lightMapTransform)),y.aoMap&&(S.aoMap.value=y.aoMap,S.aoMapIntensity.value=y.aoMapIntensity,n(y.aoMap,S.aoMapTransform))}function u(S,y){S.diffuse.value.copy(y.color),S.opacity.value=y.opacity,y.map&&(S.map.value=y.map,n(y.map,S.mapTransform))}function f(S,y){S.dashSize.value=y.dashSize,S.totalSize.value=y.dashSize+y.gapSize,S.scale.value=y.scale}function d(S,y,R,U){S.diffuse.value.copy(y.color),S.opacity.value=y.opacity,S.size.value=y.size*R,S.scale.value=U*.5,y.map&&(S.map.value=y.map,n(y.map,S.uvTransform)),y.alphaMap&&(S.alphaMap.value=y.alphaMap,n(y.alphaMap,S.alphaMapTransform)),y.alphaTest>0&&(S.alphaTest.value=y.alphaTest)}function p(S,y){S.diffuse.value.copy(y.color),S.opacity.value=y.opacity,S.rotation.value=y.rotation,y.map&&(S.map.value=y.map,n(y.map,S.mapTransform)),y.alphaMap&&(S.alphaMap.value=y.alphaMap,n(y.alphaMap,S.alphaMapTransform)),y.alphaTest>0&&(S.alphaTest.value=y.alphaTest)}function _(S,y){S.specular.value.copy(y.specular),S.shininess.value=Math.max(y.shininess,1e-4)}function v(S,y){y.gradientMap&&(S.gradientMap.value=y.gradientMap)}function g(S,y){S.metalness.value=y.metalness,y.metalnessMap&&(S.metalnessMap.value=y.metalnessMap,n(y.metalnessMap,S.metalnessMapTransform)),S.roughness.value=y.roughness,y.roughnessMap&&(S.roughnessMap.value=y.roughnessMap,n(y.roughnessMap,S.roughnessMapTransform)),y.envMap&&(S.envMapIntensity.value=y.envMapIntensity)}function x(S,y,R){S.ior.value=y.ior,y.sheen>0&&(S.sheenColor.value.copy(y.sheenColor).multiplyScalar(y.sheen),S.sheenRoughness.value=y.sheenRoughness,y.sheenColorMap&&(S.sheenColorMap.value=y.sheenColorMap,n(y.sheenColorMap,S.sheenColorMapTransform)),y.sheenRoughnessMap&&(S.sheenRoughnessMap.value=y.sheenRoughnessMap,n(y.sheenRoughnessMap,S.sheenRoughnessMapTransform))),y.clearcoat>0&&(S.clearcoat.value=y.clearcoat,S.clearcoatRoughness.value=y.clearcoatRoughness,y.clearcoatMap&&(S.clearcoatMap.value=y.clearcoatMap,n(y.clearcoatMap,S.clearcoatMapTransform)),y.clearcoatRoughnessMap&&(S.clearcoatRoughnessMap.value=y.clearcoatRoughnessMap,n(y.clearcoatRoughnessMap,S.clearcoatRoughnessMapTransform)),y.clearcoatNormalMap&&(S.clearcoatNormalMap.value=y.clearcoatNormalMap,n(y.clearcoatNormalMap,S.clearcoatNormalMapTransform),S.clearcoatNormalScale.value.copy(y.clearcoatNormalScale),y.side===$i&&S.clearcoatNormalScale.value.negate())),y.dispersion>0&&(S.dispersion.value=y.dispersion),y.iridescence>0&&(S.iridescence.value=y.iridescence,S.iridescenceIOR.value=y.iridescenceIOR,S.iridescenceThicknessMinimum.value=y.iridescenceThicknessRange[0],S.iridescenceThicknessMaximum.value=y.iridescenceThicknessRange[1],y.iridescenceMap&&(S.iridescenceMap.value=y.iridescenceMap,n(y.iridescenceMap,S.iridescenceMapTransform)),y.iridescenceThicknessMap&&(S.iridescenceThicknessMap.value=y.iridescenceThicknessMap,n(y.iridescenceThicknessMap,S.iridescenceThicknessMapTransform))),y.transmission>0&&(S.transmission.value=y.transmission,S.transmissionSamplerMap.value=R.texture,S.transmissionSamplerSize.value.set(R.width,R.height),y.transmissionMap&&(S.transmissionMap.value=y.transmissionMap,n(y.transmissionMap,S.transmissionMapTransform)),S.thickness.value=y.thickness,y.thicknessMap&&(S.thicknessMap.value=y.thicknessMap,n(y.thicknessMap,S.thicknessMapTransform)),S.attenuationDistance.value=y.attenuationDistance,S.attenuationColor.value.copy(y.attenuationColor)),y.anisotropy>0&&(S.anisotropyVector.value.set(y.anisotropy*Math.cos(y.anisotropyRotation),y.anisotropy*Math.sin(y.anisotropyRotation)),y.anisotropyMap&&(S.anisotropyMap.value=y.anisotropyMap,n(y.anisotropyMap,S.anisotropyMapTransform))),S.specularIntensity.value=y.specularIntensity,S.specularColor.value.copy(y.specularColor),y.specularColorMap&&(S.specularColorMap.value=y.specularColorMap,n(y.specularColorMap,S.specularColorMapTransform)),y.specularIntensityMap&&(S.specularIntensityMap.value=y.specularIntensityMap,n(y.specularIntensityMap,S.specularIntensityMapTransform))}function M(S,y){y.matcap&&(S.matcap.value=y.matcap)}function E(S,y){const R=e.get(y).light;S.referencePosition.value.setFromMatrixPosition(R.matrixWorld),S.nearDistance.value=R.shadow.camera.near,S.farDistance.value=R.shadow.camera.far}return{refreshFogUniforms:a,refreshMaterialUniforms:r}}function MN(o,e,n,a){let r={},l={},u=[];const f=o.getParameter(o.MAX_UNIFORM_BUFFER_BINDINGS);function d(R,U){const C=U.program;a.uniformBlockBinding(R,C)}function p(R,U){let C=r[R.id];C===void 0&&(M(R),C=_(R),r[R.id]=C,R.addEventListener("dispose",S));const F=U.program;a.updateUBOMapping(R,F);const O=e.render.frame;l[R.id]!==O&&(g(R),l[R.id]=O)}function _(R){const U=v();R.__bindingPointIndex=U;const C=o.createBuffer(),F=R.__size,O=R.usage;return o.bindBuffer(o.UNIFORM_BUFFER,C),o.bufferData(o.UNIFORM_BUFFER,F,O),o.bindBuffer(o.UNIFORM_BUFFER,null),o.bindBufferBase(o.UNIFORM_BUFFER,U,C),C}function v(){for(let R=0;R<f;R++)if(u.indexOf(R)===-1)return u.push(R),R;return jt("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function g(R){const U=r[R.id],C=R.uniforms,F=R.__cache;o.bindBuffer(o.UNIFORM_BUFFER,U);for(let O=0,D=C.length;O<D;O++){const T=Array.isArray(C[O])?C[O]:[C[O]];for(let L=0,H=T.length;L<H;L++){const V=T[L];if(x(V,O,L,F)===!0){const k=V.__offset,te=Array.isArray(V.value)?V.value:[V.value];let ie=0;for(let W=0;W<te.length;W++){const z=te[W],B=E(z);typeof z=="number"||typeof z=="boolean"?(V.__data[0]=z,o.bufferSubData(o.UNIFORM_BUFFER,k+ie,V.__data)):z.isMatrix3?(V.__data[0]=z.elements[0],V.__data[1]=z.elements[1],V.__data[2]=z.elements[2],V.__data[3]=0,V.__data[4]=z.elements[3],V.__data[5]=z.elements[4],V.__data[6]=z.elements[5],V.__data[7]=0,V.__data[8]=z.elements[6],V.__data[9]=z.elements[7],V.__data[10]=z.elements[8],V.__data[11]=0):ArrayBuffer.isView(z)?V.__data.set(new z.constructor(z.buffer,z.byteOffset,V.__data.length)):(z.toArray(V.__data,ie),ie+=B.storage/Float32Array.BYTES_PER_ELEMENT)}o.bufferSubData(o.UNIFORM_BUFFER,k,V.__data)}}}o.bindBuffer(o.UNIFORM_BUFFER,null)}function x(R,U,C,F){const O=R.value,D=U+"_"+C;if(F[D]===void 0)return typeof O=="number"||typeof O=="boolean"?F[D]=O:ArrayBuffer.isView(O)?F[D]=O.slice():F[D]=O.clone(),!0;{const T=F[D];if(typeof O=="number"||typeof O=="boolean"){if(T!==O)return F[D]=O,!0}else{if(ArrayBuffer.isView(O))return!0;if(T.equals(O)===!1)return T.copy(O),!0}}return!1}function M(R){const U=R.uniforms;let C=0;const F=16;for(let D=0,T=U.length;D<T;D++){const L=Array.isArray(U[D])?U[D]:[U[D]];for(let H=0,V=L.length;H<V;H++){const k=L[H],te=Array.isArray(k.value)?k.value:[k.value];for(let ie=0,W=te.length;ie<W;ie++){const z=te[ie],B=E(z),J=C%F,fe=J%B.boundary,G=J+fe;C+=fe,G!==0&&F-G<B.storage&&(C+=F-G),k.__data=new Float32Array(B.storage/Float32Array.BYTES_PER_ELEMENT),k.__offset=C,C+=B.storage}}}const O=C%F;return O>0&&(C+=F-O),R.__size=C,R.__cache={},this}function E(R){const U={boundary:0,storage:0};return typeof R=="number"||typeof R=="boolean"?(U.boundary=4,U.storage=4):R.isVector2?(U.boundary=8,U.storage=8):R.isVector3||R.isColor?(U.boundary=16,U.storage=12):R.isVector4?(U.boundary=16,U.storage=16):R.isMatrix3?(U.boundary=48,U.storage=48):R.isMatrix4?(U.boundary=64,U.storage=64):R.isTexture?_t("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(R)?(U.boundary=16,U.storage=R.byteLength):_t("WebGLRenderer: Unsupported uniform value type.",R),U}function S(R){const U=R.target;U.removeEventListener("dispose",S);const C=u.indexOf(U.__bindingPointIndex);u.splice(C,1),o.deleteBuffer(r[U.id]),delete r[U.id],delete l[U.id]}function y(){for(const R in r)o.deleteBuffer(r[R]);u=[],r={},l={}}return{bind:d,update:p,dispose:y}}const bN=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]);let cr=null;function EN(){return cr===null&&(cr=new _2(bN,16,16,Xo,as),cr.name="DFG_LUT",cr.minFilter=Ci,cr.magFilter=Ci,cr.wrapS=Qr,cr.wrapT=Qr,cr.generateMipmaps=!1,cr.needsUpdate=!0),cr}class TN{constructor(e={}){const{canvas:n=YC(),context:a=null,depth:r=!0,stencil:l=!1,alpha:u=!1,antialias:f=!1,premultipliedAlpha:d=!0,preserveDrawingBuffer:p=!1,powerPreference:_="default",failIfMajorPerformanceCaveat:v=!1,reversedDepthBuffer:g=!1,outputBufferType:x=Ia}=e;this.isWebGLRenderer=!0;let M;if(a!==null){if(typeof WebGLRenderingContext<"u"&&a instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");M=a.getContextAttributes().alpha}else M=u;const E=x,S=new Set([Cg,Rg,Ag]),y=new Set([Ia,Mr,qu,Yu,Eg,Tg]),R=new Uint32Array(4),U=new Int32Array(4),C=new ue;let F=null,O=null;const D=[],T=[];let L=null;this.domElement=n,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=xr,this.toneMappingExposure=1,this.transmissionResolutionScale=1;const H=this;let V=!1,k=null;this._outputColorSpace=Pa;let te=0,ie=0,W=null,z=-1,B=null;const J=new Vn,fe=new Vn;let G=null;const I=new pn(0);let K=0,Se=n.width,be=n.height,Ue=1,ne=null,xe=null;const Ee=new Vn(0,0,Se,be),Ie=new Vn(0,0,Se,be);let nt=!1;const Ze=new tE;let Mt=!1,Ye=!1;const it=new ii,xt=new ue,st=new Vn,le={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Dt=!1;function mn(){return W===null?Ue:1}let j=a;function gt(w,Z){return n.getContext(w,Z)}try{const w={alpha:!0,depth:r,stencil:l,antialias:f,premultipliedAlpha:d,preserveDrawingBuffer:p,powerPreference:_,failIfMajorPerformanceCaveat:v};if("setAttribute"in n&&n.setAttribute("data-engine",`three.js r${Mg}`),n.addEventListener("webglcontextlost",Ae,!1),n.addEventListener("webglcontextrestored",Ce,!1),n.addEventListener("webglcontextcreationerror",Ne,!1),j===null){const Z="webgl2";if(j=gt(Z,w),j===null)throw gt(Z)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(w){throw jt("WebGLRenderer: "+w.message),w}let mt,Ft,Le,bt,P,A,Q,_e,Te,Fe,De,de,pe,Be,He,ze,Oe,Ge,ut,dt,q,Re,me;function Ve(){mt=new ED(j),mt.init(),q=new mN(j,mt),Ft=new _D(j,mt,e,q),Le=new dN(j,mt),Ft.reversedDepthBuffer&&g&&Le.buffers.depth.setReversed(!0),bt=new RD(j),P=new $U,A=new pN(j,mt,Le,P,Ft,q,bt),Q=new bD(H),_e=new U2(j),Re=new pD(j,_e),Te=new TD(j,_e,bt,Re),Fe=new wD(j,Te,_e,Re,bt),Ge=new CD(j,Ft,A),He=new gD(P),De=new JU(H,Q,mt,Ft,Re,He),de=new yN(H,P),pe=new tN,Be=new oN(mt),Oe=new dD(H,Q,Le,Fe,M,d),ze=new hN(H,Fe,Ft),me=new MN(j,bt,Ft,Le),ut=new mD(j,mt,bt),dt=new AD(j,mt,bt),bt.programs=De.programs,H.capabilities=Ft,H.extensions=mt,H.properties=P,H.renderLists=pe,H.shadowMap=ze,H.state=Le,H.info=bt}Ve(),E!==Ia&&(L=new UD(E,n.width,n.height,r,l));const Pe=new xN(H,j);this.xr=Pe,this.getContext=function(){return j},this.getContextAttributes=function(){return j.getContextAttributes()},this.forceContextLoss=function(){const w=mt.get("WEBGL_lose_context");w&&w.loseContext()},this.forceContextRestore=function(){const w=mt.get("WEBGL_lose_context");w&&w.restoreContext()},this.getPixelRatio=function(){return Ue},this.setPixelRatio=function(w){w!==void 0&&(Ue=w,this.setSize(Se,be,!1))},this.getSize=function(w){return w.set(Se,be)},this.setSize=function(w,Z,se=!0){if(Pe.isPresenting){_t("WebGLRenderer: Can't change size while VR device is presenting.");return}Se=w,be=Z,n.width=Math.floor(w*Ue),n.height=Math.floor(Z*Ue),se===!0&&(n.style.width=w+"px",n.style.height=Z+"px"),L!==null&&L.setSize(n.width,n.height),this.setViewport(0,0,w,Z)},this.getDrawingBufferSize=function(w){return w.set(Se*Ue,be*Ue).floor()},this.setDrawingBufferSize=function(w,Z,se){Se=w,be=Z,Ue=se,n.width=Math.floor(w*se),n.height=Math.floor(Z*se),this.setViewport(0,0,w,Z)},this.setEffects=function(w){if(E===Ia){jt("THREE.WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");return}if(w){for(let Z=0;Z<w.length;Z++)if(w[Z].isOutputPass===!0){_t("THREE.WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");break}}L.setEffects(w||[])},this.getCurrentViewport=function(w){return w.copy(J)},this.getViewport=function(w){return w.copy(Ee)},this.setViewport=function(w,Z,se,ee){w.isVector4?Ee.set(w.x,w.y,w.z,w.w):Ee.set(w,Z,se,ee),Le.viewport(J.copy(Ee).multiplyScalar(Ue).round())},this.getScissor=function(w){return w.copy(Ie)},this.setScissor=function(w,Z,se,ee){w.isVector4?Ie.set(w.x,w.y,w.z,w.w):Ie.set(w,Z,se,ee),Le.scissor(fe.copy(Ie).multiplyScalar(Ue).round())},this.getScissorTest=function(){return nt},this.setScissorTest=function(w){Le.setScissorTest(nt=w)},this.setOpaqueSort=function(w){ne=w},this.setTransparentSort=function(w){xe=w},this.getClearColor=function(w){return w.copy(Oe.getClearColor())},this.setClearColor=function(){Oe.setClearColor(...arguments)},this.getClearAlpha=function(){return Oe.getClearAlpha()},this.setClearAlpha=function(){Oe.setClearAlpha(...arguments)},this.clear=function(w=!0,Z=!0,se=!0){let ee=0;if(w){let ae=!1;if(W!==null){const ke=W.texture.format;ae=S.has(ke)}if(ae){const ke=W.texture.type,We=y.has(ke),Xe=Oe.getClearColor(),Je=Oe.getClearAlpha(),Ke=Xe.r,lt=Xe.g,At=Xe.b;We?(R[0]=Ke,R[1]=lt,R[2]=At,R[3]=Je,j.clearBufferuiv(j.COLOR,0,R)):(U[0]=Ke,U[1]=lt,U[2]=At,U[3]=Je,j.clearBufferiv(j.COLOR,0,U))}else ee|=j.COLOR_BUFFER_BIT}Z&&(ee|=j.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),se&&(ee|=j.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),ee!==0&&j.clear(ee)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.setNodesHandler=function(w){w.setRenderer(this),k=w},this.dispose=function(){n.removeEventListener("webglcontextlost",Ae,!1),n.removeEventListener("webglcontextrestored",Ce,!1),n.removeEventListener("webglcontextcreationerror",Ne,!1),Oe.dispose(),pe.dispose(),Be.dispose(),P.dispose(),Q.dispose(),Fe.dispose(),Re.dispose(),me.dispose(),De.dispose(),Pe.dispose(),Pe.removeEventListener("sessionstart",Ct),Pe.removeEventListener("sessionend",_n),Yt.stop()};function Ae(w){w.preventDefault(),gM("WebGLRenderer: Context Lost."),V=!0}function Ce(){gM("WebGLRenderer: Context Restored."),V=!1;const w=bt.autoReset,Z=ze.enabled,se=ze.autoUpdate,ee=ze.needsUpdate,ae=ze.type;Ve(),bt.autoReset=w,ze.enabled=Z,ze.autoUpdate=se,ze.needsUpdate=ee,ze.type=ae}function Ne(w){jt("WebGLRenderer: A WebGL context could not be created. Reason: ",w.statusMessage)}function ot(w){const Z=w.target;Z.removeEventListener("dispose",ot),we(Z)}function we(w){rt(w),P.remove(w)}function rt(w){const Z=P.get(w).programs;Z!==void 0&&(Z.forEach(function(se){De.releaseProgram(se)}),w.isShaderMaterial&&De.releaseShaderCache(w))}this.renderBufferDirect=function(w,Z,se,ee,ae,ke){Z===null&&(Z=le);const We=ae.isMesh&&ae.matrixWorld.determinant()<0,Xe=bn(w,Z,se,ee,ae);Le.setMaterial(ee,We);let Je=se.index,Ke=1;if(ee.wireframe===!0){if(Je=Te.getWireframeAttribute(se),Je===void 0)return;Ke=2}const lt=se.drawRange,At=se.attributes.position;let at=lt.start*Ke,Zt=(lt.start+lt.count)*Ke;ke!==null&&(at=Math.max(at,ke.start*Ke),Zt=Math.min(Zt,(ke.start+ke.count)*Ke)),Je!==null?(at=Math.max(at,0),Zt=Math.min(Zt,Je.count)):At!=null&&(at=Math.max(at,0),Zt=Math.min(Zt,At.count));const Cn=Zt-at;if(Cn<0||Cn===1/0)return;Re.setup(ae,ee,Xe,se,Je);let gn,nn=ut;if(Je!==null&&(gn=_e.get(Je),nn=dt,nn.setIndex(gn)),ae.isMesh)ee.wireframe===!0?(Le.setLineWidth(ee.wireframeLinewidth*mn()),nn.setMode(j.LINES)):nn.setMode(j.TRIANGLES);else if(ae.isLine){let an=ee.linewidth;an===void 0&&(an=1),Le.setLineWidth(an*mn()),ae.isLineSegments?nn.setMode(j.LINES):ae.isLineLoop?nn.setMode(j.LINE_LOOP):nn.setMode(j.LINE_STRIP)}else ae.isPoints?nn.setMode(j.POINTS):ae.isSprite&&nn.setMode(j.TRIANGLES);if(ae.isBatchedMesh)if(mt.get("WEBGL_multi_draw"))nn.renderMultiDraw(ae._multiDrawStarts,ae._multiDrawCounts,ae._multiDrawCount);else{const an=ae._multiDrawStarts,je=ae._multiDrawCounts,Si=ae._multiDrawCount,It=Je?_e.get(Je).bytesPerElement:1,$n=P.get(ee).currentProgram.getUniforms();for(let ta=0;ta<Si;ta++)$n.setValue(j,"_gl_DrawID",ta),nn.render(an[ta]/It,je[ta])}else if(ae.isInstancedMesh)nn.renderInstances(at,Cn,ae.count);else if(se.isInstancedBufferGeometry){const an=se._maxInstanceCount!==void 0?se._maxInstanceCount:1/0,je=Math.min(se.instanceCount,an);nn.renderInstances(at,Cn,je)}else nn.render(at,Cn)};function Qe(w,Z,se){w.transparent===!0&&w.side===Zr&&w.forceSinglePass===!1?(w.side=$i,w.needsUpdate=!0,Wn(w,Z,se),w.side=Qs,w.needsUpdate=!0,Wn(w,Z,se),w.side=Zr):Wn(w,Z,se)}this.compile=function(w,Z,se=null){se===null&&(se=w),O=Be.get(se),O.init(Z),T.push(O),se.traverseVisible(function(ae){ae.isLight&&ae.layers.test(Z.layers)&&(O.pushLight(ae),ae.castShadow&&O.pushShadow(ae))}),w!==se&&w.traverseVisible(function(ae){ae.isLight&&ae.layers.test(Z.layers)&&(O.pushLight(ae),ae.castShadow&&O.pushShadow(ae))}),O.setupLights();const ee=new Set;return w.traverse(function(ae){if(!(ae.isMesh||ae.isPoints||ae.isLine||ae.isSprite))return;const ke=ae.material;if(ke)if(Array.isArray(ke))for(let We=0;We<ke.length;We++){const Xe=ke[We];Qe(Xe,se,ae),ee.add(Xe)}else Qe(ke,se,ae),ee.add(ke)}),O=T.pop(),ee},this.compileAsync=function(w,Z,se=null){const ee=this.compile(w,Z,se);return new Promise(ae=>{function ke(){if(ee.forEach(function(We){P.get(We).currentProgram.isReady()&&ee.delete(We)}),ee.size===0){ae(w);return}setTimeout(ke,10)}mt.get("KHR_parallel_shader_compile")!==null?ke():setTimeout(ke,10)})};let ft=null;function Rn(w){ft&&ft(w)}function Ct(){Yt.stop()}function _n(){Yt.start()}const Yt=new sE;Yt.setAnimationLoop(Rn),typeof self<"u"&&Yt.setContext(self),this.setAnimationLoop=function(w){ft=w,Pe.setAnimationLoop(w),w===null?Yt.stop():Yt.start()},Pe.addEventListener("sessionstart",Ct),Pe.addEventListener("sessionend",_n),this.render=function(w,Z){if(Z!==void 0&&Z.isCamera!==!0){jt("WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(V===!0)return;k!==null&&k.renderStart(w,Z);const se=Pe.enabled===!0&&Pe.isPresenting===!0,ee=L!==null&&(W===null||se)&&L.begin(H,W);if(w.matrixWorldAutoUpdate===!0&&w.updateMatrixWorld(),Z.parent===null&&Z.matrixWorldAutoUpdate===!0&&Z.updateMatrixWorld(),Pe.enabled===!0&&Pe.isPresenting===!0&&(L===null||L.isCompositing()===!1)&&(Pe.cameraAutoUpdate===!0&&Pe.updateCamera(Z),Z=Pe.getCamera()),w.isScene===!0&&w.onBeforeRender(H,w,Z,W),O=Be.get(w,T.length),O.init(Z),O.state.textureUnits=A.getTextureUnits(),T.push(O),it.multiplyMatrices(Z.projectionMatrix,Z.matrixWorldInverse),Ze.setFromProjectionMatrix(it,gr,Z.reversedDepth),Ye=this.localClippingEnabled,Mt=He.init(this.clippingPlanes,Ye),F=pe.get(w,D.length),F.init(),D.push(F),Pe.enabled===!0&&Pe.isPresenting===!0){const We=H.xr.getDepthSensingMesh();We!==null&&St(We,Z,-1/0,H.sortObjects)}St(w,Z,0,H.sortObjects),F.finish(),H.sortObjects===!0&&F.sort(ne,xe),Dt=Pe.enabled===!1||Pe.isPresenting===!1||Pe.hasDepthSensing()===!1,Dt&&Oe.addToRenderList(F,w),this.info.render.frame++,Mt===!0&&He.beginShadows();const ae=O.state.shadowsArray;if(ze.render(ae,w,Z),Mt===!0&&He.endShadows(),this.info.autoReset===!0&&this.info.reset(),(ee&&L.hasRenderPass())===!1){const We=F.opaque,Xe=F.transmissive;if(O.setupLights(),Z.isArrayCamera){const Je=Z.cameras;if(Xe.length>0)for(let Ke=0,lt=Je.length;Ke<lt;Ke++){const At=Je[Ke];zt(We,Xe,w,At)}Dt&&Oe.render(w);for(let Ke=0,lt=Je.length;Ke<lt;Ke++){const At=Je[Ke];Tt(F,w,At,At.viewport)}}else Xe.length>0&&zt(We,Xe,w,Z),Dt&&Oe.render(w),Tt(F,w,Z)}W!==null&&ie===0&&(A.updateMultisampleRenderTarget(W),A.updateRenderTargetMipmap(W)),ee&&L.end(H),w.isScene===!0&&w.onAfterRender(H,w,Z),Re.resetDefaultState(),z=-1,B=null,T.pop(),T.length>0?(O=T[T.length-1],A.setTextureUnits(O.state.textureUnits),Mt===!0&&He.setGlobalState(H.clippingPlanes,O.state.camera)):O=null,D.pop(),D.length>0?F=D[D.length-1]:F=null,k!==null&&k.renderEnd()};function St(w,Z,se,ee){if(w.visible===!1)return;if(w.layers.test(Z.layers)){if(w.isGroup)se=w.renderOrder;else if(w.isLOD)w.autoUpdate===!0&&w.update(Z);else if(w.isLightProbeGrid)O.pushLightProbeGrid(w);else if(w.isLight)O.pushLight(w),w.castShadow&&O.pushShadow(w);else if(w.isSprite){if(!w.frustumCulled||Ze.intersectsSprite(w)){ee&&st.setFromMatrixPosition(w.matrixWorld).applyMatrix4(it);const We=Fe.update(w),Xe=w.material;Xe.visible&&F.push(w,We,Xe,se,st.z,null)}}else if((w.isMesh||w.isLine||w.isPoints)&&(!w.frustumCulled||Ze.intersectsObject(w))){const We=Fe.update(w),Xe=w.material;if(ee&&(w.boundingSphere!==void 0?(w.boundingSphere===null&&w.computeBoundingSphere(),st.copy(w.boundingSphere.center)):(We.boundingSphere===null&&We.computeBoundingSphere(),st.copy(We.boundingSphere.center)),st.applyMatrix4(w.matrixWorld).applyMatrix4(it)),Array.isArray(Xe)){const Je=We.groups;for(let Ke=0,lt=Je.length;Ke<lt;Ke++){const At=Je[Ke],at=Xe[At.materialIndex];at&&at.visible&&F.push(w,We,at,se,st.z,At)}}else Xe.visible&&F.push(w,We,Xe,se,st.z,null)}}const ke=w.children;for(let We=0,Xe=ke.length;We<Xe;We++)St(ke[We],Z,se,ee)}function Tt(w,Z,se,ee){const{opaque:ae,transmissive:ke,transparent:We}=w;O.setupLightsView(se),Mt===!0&&He.setGlobalState(H.clippingPlanes,se),ee&&Le.viewport(J.copy(ee)),ae.length>0&&Xn(ae,Z,se),ke.length>0&&Xn(ke,Z,se),We.length>0&&Xn(We,Z,se),Le.buffers.depth.setTest(!0),Le.buffers.depth.setMask(!0),Le.buffers.color.setMask(!0),Le.setPolygonOffset(!1)}function zt(w,Z,se,ee){if((se.isScene===!0?se.overrideMaterial:null)!==null)return;if(O.state.transmissionRenderTarget[ee.id]===void 0){const at=mt.has("EXT_color_buffer_half_float")||mt.has("EXT_color_buffer_float");O.state.transmissionRenderTarget[ee.id]=new Sr(1,1,{generateMipmaps:!0,type:at?as:Ia,minFilter:Uo,samples:Math.max(4,Ft.samples),stencilBuffer:l,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:Xt.workingColorSpace})}const ke=O.state.transmissionRenderTarget[ee.id],We=ee.viewport||J;ke.setSize(We.z*H.transmissionResolutionScale,We.w*H.transmissionResolutionScale);const Xe=H.getRenderTarget(),Je=H.getActiveCubeFace(),Ke=H.getActiveMipmapLevel();H.setRenderTarget(ke),H.getClearColor(I),K=H.getClearAlpha(),K<1&&H.setClearColor(16777215,.5),H.clear(),Dt&&Oe.render(se);const lt=H.toneMapping;H.toneMapping=xr;const At=ee.viewport;if(ee.viewport!==void 0&&(ee.viewport=void 0),O.setupLightsView(ee),Mt===!0&&He.setGlobalState(H.clippingPlanes,ee),Xn(w,se,ee),A.updateMultisampleRenderTarget(ke),A.updateRenderTargetMipmap(ke),mt.has("WEBGL_multisampled_render_to_texture")===!1){let at=!1;for(let Zt=0,Cn=Z.length;Zt<Cn;Zt++){const gn=Z[Zt],{object:nn,geometry:an,material:je,group:Si}=gn;if(je.side===Zr&&nn.layers.test(ee.layers)){const It=je.side;je.side=$i,je.needsUpdate=!0,un(nn,se,ee,an,je,Si),je.side=It,je.needsUpdate=!0,at=!0}}at===!0&&(A.updateMultisampleRenderTarget(ke),A.updateRenderTargetMipmap(ke))}H.setRenderTarget(Xe,Je,Ke),H.setClearColor(I,K),At!==void 0&&(ee.viewport=At),H.toneMapping=lt}function Xn(w,Z,se){const ee=Z.isScene===!0?Z.overrideMaterial:null;for(let ae=0,ke=w.length;ae<ke;ae++){const We=w[ae],{object:Xe,geometry:Je,group:Ke}=We;let lt=We.material;lt.allowOverride===!0&&ee!==null&&(lt=ee),Xe.layers.test(se.layers)&&un(Xe,Z,se,Je,lt,Ke)}}function un(w,Z,se,ee,ae,ke){w.onBeforeRender(H,Z,se,ee,ae,ke),w.modelViewMatrix.multiplyMatrices(se.matrixWorldInverse,w.matrixWorld),w.normalMatrix.getNormalMatrix(w.modelViewMatrix),ae.onBeforeRender(H,Z,se,ee,w,ke),ae.transparent===!0&&ae.side===Zr&&ae.forceSinglePass===!1?(ae.side=$i,ae.needsUpdate=!0,H.renderBufferDirect(se,Z,ee,ae,w,ke),ae.side=Qs,ae.needsUpdate=!0,H.renderBufferDirect(se,Z,ee,ae,w,ke),ae.side=Zr):H.renderBufferDirect(se,Z,ee,ae,w,ke),w.onAfterRender(H,Z,se,ee,ae,ke)}function Wn(w,Z,se){Z.isScene!==!0&&(Z=le);const ee=P.get(w),ae=O.state.lights,ke=O.state.shadowsArray,We=ae.state.version,Xe=De.getParameters(w,ae.state,ke,Z,se,O.state.lightProbeGridArray),Je=De.getProgramCacheKey(Xe);let Ke=ee.programs;ee.environment=w.isMeshStandardMaterial||w.isMeshLambertMaterial||w.isMeshPhongMaterial?Z.environment:null,ee.fog=Z.fog;const lt=w.isMeshStandardMaterial||w.isMeshLambertMaterial&&!w.envMap||w.isMeshPhongMaterial&&!w.envMap;ee.envMap=Q.get(w.envMap||ee.environment,lt),ee.envMapRotation=ee.environment!==null&&w.envMap===null?Z.environmentRotation:w.envMapRotation,Ke===void 0&&(w.addEventListener("dispose",ot),Ke=new Map,ee.programs=Ke);let At=Ke.get(Je);if(At!==void 0){if(ee.currentProgram===At&&ee.lightsStateVersion===We)return Mn(w,Xe),At}else Xe.uniforms=De.getUniforms(w),k!==null&&w.isNodeMaterial&&k.build(w,se,Xe),w.onBeforeCompile(Xe,H),At=De.acquireProgram(Xe,Je),Ke.set(Je,At),ee.uniforms=Xe.uniforms;const at=ee.uniforms;return(!w.isShaderMaterial&&!w.isRawShaderMaterial||w.clipping===!0)&&(at.clippingPlanes=He.uniform),Mn(w,Xe),ee.needsLights=Ea(w),ee.lightsStateVersion=We,ee.needsLights&&(at.ambientLightColor.value=ae.state.ambient,at.lightProbe.value=ae.state.probe,at.directionalLights.value=ae.state.directional,at.directionalLightShadows.value=ae.state.directionalShadow,at.spotLights.value=ae.state.spot,at.spotLightShadows.value=ae.state.spotShadow,at.rectAreaLights.value=ae.state.rectArea,at.ltc_1.value=ae.state.rectAreaLTC1,at.ltc_2.value=ae.state.rectAreaLTC2,at.pointLights.value=ae.state.point,at.pointLightShadows.value=ae.state.pointShadow,at.hemisphereLights.value=ae.state.hemi,at.directionalShadowMatrix.value=ae.state.directionalShadowMatrix,at.spotLightMatrix.value=ae.state.spotLightMatrix,at.spotLightMap.value=ae.state.spotLightMap,at.pointShadowMatrix.value=ae.state.pointShadowMatrix),ee.lightProbeGrid=O.state.lightProbeGridArray.length>0,ee.currentProgram=At,ee.uniformsList=null,At}function vi(w){if(w.uniformsList===null){const Z=w.currentProgram.getUniforms();w.uniformsList=id.seqWithValue(Z.seq,w.uniforms)}return w.uniformsList}function Mn(w,Z){const se=P.get(w);se.outputColorSpace=Z.outputColorSpace,se.batching=Z.batching,se.batchingColor=Z.batchingColor,se.instancing=Z.instancing,se.instancingColor=Z.instancingColor,se.instancingMorph=Z.instancingMorph,se.skinning=Z.skinning,se.morphTargets=Z.morphTargets,se.morphNormals=Z.morphNormals,se.morphColors=Z.morphColors,se.morphTargetsCount=Z.morphTargetsCount,se.numClippingPlanes=Z.numClippingPlanes,se.numIntersection=Z.numClipIntersection,se.vertexAlphas=Z.vertexAlphas,se.vertexTangents=Z.vertexTangents,se.toneMapping=Z.toneMapping}function Nn(w,Z){if(w.length===0)return null;if(w.length===1)return w[0].texture!==null?w[0]:null;C.setFromMatrixPosition(Z.matrixWorld);for(let se=0,ee=w.length;se<ee;se++){const ae=w[se];if(ae.texture!==null&&ae.boundingBox.containsPoint(C))return ae}return null}function bn(w,Z,se,ee,ae){Z.isScene!==!0&&(Z=le),A.resetTextureUnits();const ke=Z.fog,We=ee.isMeshStandardMaterial||ee.isMeshLambertMaterial||ee.isMeshPhongMaterial?Z.environment:null,Xe=W===null?H.outputColorSpace:W.isXRRenderTarget===!0?W.texture.colorSpace:Xt.workingColorSpace,Je=ee.isMeshStandardMaterial||ee.isMeshLambertMaterial&&!ee.envMap||ee.isMeshPhongMaterial&&!ee.envMap,Ke=Q.get(ee.envMap||We,Je),lt=ee.vertexColors===!0&&!!se.attributes.color&&se.attributes.color.itemSize===4,At=!!se.attributes.tangent&&(!!ee.normalMap||ee.anisotropy>0),at=!!se.morphAttributes.position,Zt=!!se.morphAttributes.normal,Cn=!!se.morphAttributes.color;let gn=xr;ee.toneMapped&&(W===null||W.isXRRenderTarget===!0)&&(gn=H.toneMapping);const nn=se.morphAttributes.position||se.morphAttributes.normal||se.morphAttributes.color,an=nn!==void 0?nn.length:0,je=P.get(ee),Si=O.state.lights;if(Mt===!0&&(Ye===!0||w!==B)){const en=w===B&&ee.id===z;He.setState(ee,w,en)}let It=!1;ee.version===je.__version?(je.needsLights&&je.lightsStateVersion!==Si.state.version||je.outputColorSpace!==Xe||ae.isBatchedMesh&&je.batching===!1||!ae.isBatchedMesh&&je.batching===!0||ae.isBatchedMesh&&je.batchingColor===!0&&ae.colorTexture===null||ae.isBatchedMesh&&je.batchingColor===!1&&ae.colorTexture!==null||ae.isInstancedMesh&&je.instancing===!1||!ae.isInstancedMesh&&je.instancing===!0||ae.isSkinnedMesh&&je.skinning===!1||!ae.isSkinnedMesh&&je.skinning===!0||ae.isInstancedMesh&&je.instancingColor===!0&&ae.instanceColor===null||ae.isInstancedMesh&&je.instancingColor===!1&&ae.instanceColor!==null||ae.isInstancedMesh&&je.instancingMorph===!0&&ae.morphTexture===null||ae.isInstancedMesh&&je.instancingMorph===!1&&ae.morphTexture!==null||je.envMap!==Ke||ee.fog===!0&&je.fog!==ke||je.numClippingPlanes!==void 0&&(je.numClippingPlanes!==He.numPlanes||je.numIntersection!==He.numIntersection)||je.vertexAlphas!==lt||je.vertexTangents!==At||je.morphTargets!==at||je.morphNormals!==Zt||je.morphColors!==Cn||je.toneMapping!==gn||je.morphTargetsCount!==an||!!je.lightProbeGrid!=O.state.lightProbeGridArray.length>0)&&(It=!0):(It=!0,je.__version=ee.version);let $n=je.currentProgram;It===!0&&($n=Wn(ee,Z,ae),k&&ee.isNodeMaterial&&k.onUpdateProgram(ee,$n,je));let ta=!1,ka=!1,na=!1;const rn=$n.getUniforms(),wn=je.uniforms;if(Le.useProgram($n.program)&&(ta=!0,ka=!0,na=!0),ee.id!==z&&(z=ee.id,ka=!0),je.needsLights){const en=Nn(O.state.lightProbeGridArray,ae);je.lightProbeGrid!==en&&(je.lightProbeGrid=en,ka=!0)}if(ta||B!==w){Le.buffers.depth.getReversed()&&w.reversedDepth!==!0&&(w._reversedDepth=!0,w.updateProjectionMatrix()),rn.setValue(j,"projectionMatrix",w.projectionMatrix),rn.setValue(j,"viewMatrix",w.matrixWorldInverse);const ir=rn.map.cameraPosition;ir!==void 0&&ir.setValue(j,xt.setFromMatrixPosition(w.matrixWorld)),Ft.logarithmicDepthBuffer&&rn.setValue(j,"logDepthBufFC",2/(Math.log(w.far+1)/Math.LN2)),(ee.isMeshPhongMaterial||ee.isMeshToonMaterial||ee.isMeshLambertMaterial||ee.isMeshBasicMaterial||ee.isMeshStandardMaterial||ee.isShaderMaterial)&&rn.setValue(j,"isOrthographic",w.isOrthographicCamera===!0),B!==w&&(B=w,ka=!0,na=!0)}if(je.needsLights&&(Si.state.directionalShadowMap.length>0&&rn.setValue(j,"directionalShadowMap",Si.state.directionalShadowMap,A),Si.state.spotShadowMap.length>0&&rn.setValue(j,"spotShadowMap",Si.state.spotShadowMap,A),Si.state.pointShadowMap.length>0&&rn.setValue(j,"pointShadowMap",Si.state.pointShadowMap,A)),ae.isSkinnedMesh){rn.setOptional(j,ae,"bindMatrix"),rn.setOptional(j,ae,"bindMatrixInverse");const en=ae.skeleton;en&&(en.boneTexture===null&&en.computeBoneTexture(),rn.setValue(j,"boneTexture",en.boneTexture,A))}ae.isBatchedMesh&&(rn.setOptional(j,ae,"batchingTexture"),rn.setValue(j,"batchingTexture",ae._matricesTexture,A),rn.setOptional(j,ae,"batchingIdTexture"),rn.setValue(j,"batchingIdTexture",ae._indirectTexture,A),rn.setOptional(j,ae,"batchingColorTexture"),ae._colorsTexture!==null&&rn.setValue(j,"batchingColorTexture",ae._colorsTexture,A));const Xa=se.morphAttributes;if((Xa.position!==void 0||Xa.normal!==void 0||Xa.color!==void 0)&&Ge.update(ae,se,$n),(ka||je.receiveShadow!==ae.receiveShadow)&&(je.receiveShadow=ae.receiveShadow,rn.setValue(j,"receiveShadow",ae.receiveShadow)),(ee.isMeshStandardMaterial||ee.isMeshLambertMaterial||ee.isMeshPhongMaterial)&&ee.envMap===null&&Z.environment!==null&&(wn.envMapIntensity.value=Z.environmentIntensity),wn.dfgLUT!==void 0&&(wn.dfgLUT.value=EN()),ka){if(rn.setValue(j,"toneMappingExposure",H.toneMappingExposure),je.needsLights&&xi(wn,na),ke&&ee.fog===!0&&de.refreshFogUniforms(wn,ke),de.refreshMaterialUniforms(wn,ee,Ue,be,O.state.transmissionRenderTarget[w.id]),je.needsLights&&je.lightProbeGrid){const en=je.lightProbeGrid;wn.probesSH.value=en.texture,wn.probesMin.value.copy(en.boundingBox.min),wn.probesMax.value.copy(en.boundingBox.max),wn.probesResolution.value.copy(en.resolution)}id.upload(j,vi(je),wn,A)}if(ee.isShaderMaterial&&ee.uniformsNeedUpdate===!0&&(id.upload(j,vi(je),wn,A),ee.uniformsNeedUpdate=!1),ee.isSpriteMaterial&&rn.setValue(j,"center",ae.center),rn.setValue(j,"modelViewMatrix",ae.modelViewMatrix),rn.setValue(j,"normalMatrix",ae.normalMatrix),rn.setValue(j,"modelMatrix",ae.matrixWorld),ee.uniformsGroups!==void 0){const en=ee.uniformsGroups;for(let ir=0,ss=en.length;ir<ss;ir++){const $s=en[ir];me.update($s,$n),me.bind($s,$n)}}return $n}function xi(w,Z){w.ambientLightColor.needsUpdate=Z,w.lightProbe.needsUpdate=Z,w.directionalLights.needsUpdate=Z,w.directionalLightShadows.needsUpdate=Z,w.pointLights.needsUpdate=Z,w.pointLightShadows.needsUpdate=Z,w.spotLights.needsUpdate=Z,w.spotLightShadows.needsUpdate=Z,w.rectAreaLights.needsUpdate=Z,w.hemisphereLights.needsUpdate=Z}function Ea(w){return w.isMeshLambertMaterial||w.isMeshToonMaterial||w.isMeshPhongMaterial||w.isMeshStandardMaterial||w.isShadowMaterial||w.isShaderMaterial&&w.lights===!0}this.getActiveCubeFace=function(){return te},this.getActiveMipmapLevel=function(){return ie},this.getRenderTarget=function(){return W},this.setRenderTargetTextures=function(w,Z,se){const ee=P.get(w);ee.__autoAllocateDepthBuffer=w.resolveDepthBuffer===!1,ee.__autoAllocateDepthBuffer===!1&&(ee.__useRenderToTexture=!1),P.get(w.texture).__webglTexture=Z,P.get(w.depthTexture).__webglTexture=ee.__autoAllocateDepthBuffer?void 0:se,ee.__hasExternalTextures=!0},this.setRenderTargetFramebuffer=function(w,Z){const se=P.get(w);se.__webglFramebuffer=Z,se.__useDefaultFramebuffer=Z===void 0};const En=j.createFramebuffer();this.setRenderTarget=function(w,Z=0,se=0){W=w,te=Z,ie=se;let ee=null,ae=!1,ke=!1;if(w){const Xe=P.get(w);if(Xe.__useDefaultFramebuffer!==void 0){Le.bindFramebuffer(j.FRAMEBUFFER,Xe.__webglFramebuffer),J.copy(w.viewport),fe.copy(w.scissor),G=w.scissorTest,Le.viewport(J),Le.scissor(fe),Le.setScissorTest(G),z=-1;return}else if(Xe.__webglFramebuffer===void 0)A.setupRenderTarget(w);else if(Xe.__hasExternalTextures)A.rebindTextures(w,P.get(w.texture).__webglTexture,P.get(w.depthTexture).__webglTexture);else if(w.depthBuffer){const lt=w.depthTexture;if(Xe.__boundDepthTexture!==lt){if(lt!==null&&P.has(lt)&&(w.width!==lt.image.width||w.height!==lt.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");A.setupDepthRenderbuffer(w)}}const Je=w.texture;(Je.isData3DTexture||Je.isDataArrayTexture||Je.isCompressedArrayTexture)&&(ke=!0);const Ke=P.get(w).__webglFramebuffer;w.isWebGLCubeRenderTarget?(Array.isArray(Ke[Z])?ee=Ke[Z][se]:ee=Ke[Z],ae=!0):w.samples>0&&A.useMultisampledRTT(w)===!1?ee=P.get(w).__webglMultisampledFramebuffer:Array.isArray(Ke)?ee=Ke[se]:ee=Ke,J.copy(w.viewport),fe.copy(w.scissor),G=w.scissorTest}else J.copy(Ee).multiplyScalar(Ue).floor(),fe.copy(Ie).multiplyScalar(Ue).floor(),G=nt;if(se!==0&&(ee=En),Le.bindFramebuffer(j.FRAMEBUFFER,ee)&&Le.drawBuffers(w,ee),Le.viewport(J),Le.scissor(fe),Le.setScissorTest(G),ae){const Xe=P.get(w.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_CUBE_MAP_POSITIVE_X+Z,Xe.__webglTexture,se)}else if(ke){const Xe=Z;for(let Je=0;Je<w.textures.length;Je++){const Ke=P.get(w.textures[Je]);j.framebufferTextureLayer(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0+Je,Ke.__webglTexture,se,Xe)}}else if(w!==null&&se!==0){const Xe=P.get(w.texture);j.framebufferTexture2D(j.FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,Xe.__webglTexture,se)}z=-1},this.readRenderTargetPixels=function(w,Z,se,ee,ae,ke,We,Xe=0){if(!(w&&w.isWebGLRenderTarget)){jt("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Je=P.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&We!==void 0&&(Je=Je[We]),Je){Le.bindFramebuffer(j.FRAMEBUFFER,Je);try{const Ke=w.textures[Xe],lt=Ke.format,At=Ke.type;if(w.textures.length>1&&j.readBuffer(j.COLOR_ATTACHMENT0+Xe),!Ft.textureFormatReadable(lt)){jt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!Ft.textureTypeReadable(At)){jt("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}Z>=0&&Z<=w.width-ee&&se>=0&&se<=w.height-ae&&j.readPixels(Z,se,ee,ae,q.convert(lt),q.convert(At),ke)}finally{const Ke=W!==null?P.get(W).__webglFramebuffer:null;Le.bindFramebuffer(j.FRAMEBUFFER,Ke)}}},this.readRenderTargetPixelsAsync=async function(w,Z,se,ee,ae,ke,We,Xe=0){if(!(w&&w.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Je=P.get(w).__webglFramebuffer;if(w.isWebGLCubeRenderTarget&&We!==void 0&&(Je=Je[We]),Je)if(Z>=0&&Z<=w.width-ee&&se>=0&&se<=w.height-ae){Le.bindFramebuffer(j.FRAMEBUFFER,Je);const Ke=w.textures[Xe],lt=Ke.format,At=Ke.type;if(w.textures.length>1&&j.readBuffer(j.COLOR_ATTACHMENT0+Xe),!Ft.textureFormatReadable(lt))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!Ft.textureTypeReadable(At))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");const at=j.createBuffer();j.bindBuffer(j.PIXEL_PACK_BUFFER,at),j.bufferData(j.PIXEL_PACK_BUFFER,ke.byteLength,j.STREAM_READ),j.readPixels(Z,se,ee,ae,q.convert(lt),q.convert(At),0);const Zt=W!==null?P.get(W).__webglFramebuffer:null;Le.bindFramebuffer(j.FRAMEBUFFER,Zt);const Cn=j.fenceSync(j.SYNC_GPU_COMMANDS_COMPLETE,0);return j.flush(),await jC(j,Cn,4),j.bindBuffer(j.PIXEL_PACK_BUFFER,at),j.getBufferSubData(j.PIXEL_PACK_BUFFER,0,ke),j.deleteBuffer(at),j.deleteSync(Cn),ke}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")},this.copyFramebufferToTexture=function(w,Z=null,se=0){const ee=Math.pow(2,-se),ae=Math.floor(w.image.width*ee),ke=Math.floor(w.image.height*ee),We=Z!==null?Z.x:0,Xe=Z!==null?Z.y:0;A.setTexture2D(w,0),j.copyTexSubImage2D(j.TEXTURE_2D,se,0,0,We,Xe,ae,ke),Le.unbindTexture()};const Ut=j.createFramebuffer(),Di=j.createFramebuffer();this.copyTextureToTexture=function(w,Z,se=null,ee=null,ae=0,ke=0){let We,Xe,Je,Ke,lt,At,at,Zt,Cn;const gn=w.isCompressedTexture?w.mipmaps[ke]:w.image;if(se!==null)We=se.max.x-se.min.x,Xe=se.max.y-se.min.y,Je=se.isBox3?se.max.z-se.min.z:1,Ke=se.min.x,lt=se.min.y,At=se.isBox3?se.min.z:0;else{const wn=Math.pow(2,-ae);We=Math.floor(gn.width*wn),Xe=Math.floor(gn.height*wn),w.isDataArrayTexture?Je=gn.depth:w.isData3DTexture?Je=Math.floor(gn.depth*wn):Je=1,Ke=0,lt=0,At=0}ee!==null?(at=ee.x,Zt=ee.y,Cn=ee.z):(at=0,Zt=0,Cn=0);const nn=q.convert(Z.format),an=q.convert(Z.type);let je;Z.isData3DTexture?(A.setTexture3D(Z,0),je=j.TEXTURE_3D):Z.isDataArrayTexture||Z.isCompressedArrayTexture?(A.setTexture2DArray(Z,0),je=j.TEXTURE_2D_ARRAY):(A.setTexture2D(Z,0),je=j.TEXTURE_2D),Le.activeTexture(j.TEXTURE0),Le.pixelStorei(j.UNPACK_FLIP_Y_WEBGL,Z.flipY),Le.pixelStorei(j.UNPACK_PREMULTIPLY_ALPHA_WEBGL,Z.premultiplyAlpha),Le.pixelStorei(j.UNPACK_ALIGNMENT,Z.unpackAlignment);const Si=Le.getParameter(j.UNPACK_ROW_LENGTH),It=Le.getParameter(j.UNPACK_IMAGE_HEIGHT),$n=Le.getParameter(j.UNPACK_SKIP_PIXELS),ta=Le.getParameter(j.UNPACK_SKIP_ROWS),ka=Le.getParameter(j.UNPACK_SKIP_IMAGES);Le.pixelStorei(j.UNPACK_ROW_LENGTH,gn.width),Le.pixelStorei(j.UNPACK_IMAGE_HEIGHT,gn.height),Le.pixelStorei(j.UNPACK_SKIP_PIXELS,Ke),Le.pixelStorei(j.UNPACK_SKIP_ROWS,lt),Le.pixelStorei(j.UNPACK_SKIP_IMAGES,At);const na=w.isDataArrayTexture||w.isData3DTexture,rn=Z.isDataArrayTexture||Z.isData3DTexture;if(w.isDepthTexture){const wn=P.get(w),Xa=P.get(Z),en=P.get(wn.__renderTarget),ir=P.get(Xa.__renderTarget);Le.bindFramebuffer(j.READ_FRAMEBUFFER,en.__webglFramebuffer),Le.bindFramebuffer(j.DRAW_FRAMEBUFFER,ir.__webglFramebuffer);for(let ss=0;ss<Je;ss++)na&&(j.framebufferTextureLayer(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,P.get(w).__webglTexture,ae,At+ss),j.framebufferTextureLayer(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,P.get(Z).__webglTexture,ke,Cn+ss)),j.blitFramebuffer(Ke,lt,We,Xe,at,Zt,We,Xe,j.DEPTH_BUFFER_BIT,j.NEAREST);Le.bindFramebuffer(j.READ_FRAMEBUFFER,null),Le.bindFramebuffer(j.DRAW_FRAMEBUFFER,null)}else if(ae!==0||w.isRenderTargetTexture||P.has(w)){const wn=P.get(w),Xa=P.get(Z);Le.bindFramebuffer(j.READ_FRAMEBUFFER,Ut),Le.bindFramebuffer(j.DRAW_FRAMEBUFFER,Di);for(let en=0;en<Je;en++)na?j.framebufferTextureLayer(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,wn.__webglTexture,ae,At+en):j.framebufferTexture2D(j.READ_FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,wn.__webglTexture,ae),rn?j.framebufferTextureLayer(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,Xa.__webglTexture,ke,Cn+en):j.framebufferTexture2D(j.DRAW_FRAMEBUFFER,j.COLOR_ATTACHMENT0,j.TEXTURE_2D,Xa.__webglTexture,ke),ae!==0?j.blitFramebuffer(Ke,lt,We,Xe,at,Zt,We,Xe,j.COLOR_BUFFER_BIT,j.NEAREST):rn?j.copyTexSubImage3D(je,ke,at,Zt,Cn+en,Ke,lt,We,Xe):j.copyTexSubImage2D(je,ke,at,Zt,Ke,lt,We,Xe);Le.bindFramebuffer(j.READ_FRAMEBUFFER,null),Le.bindFramebuffer(j.DRAW_FRAMEBUFFER,null)}else rn?w.isDataTexture||w.isData3DTexture?j.texSubImage3D(je,ke,at,Zt,Cn,We,Xe,Je,nn,an,gn.data):Z.isCompressedArrayTexture?j.compressedTexSubImage3D(je,ke,at,Zt,Cn,We,Xe,Je,nn,gn.data):j.texSubImage3D(je,ke,at,Zt,Cn,We,Xe,Je,nn,an,gn):w.isDataTexture?j.texSubImage2D(j.TEXTURE_2D,ke,at,Zt,We,Xe,nn,an,gn.data):w.isCompressedTexture?j.compressedTexSubImage2D(j.TEXTURE_2D,ke,at,Zt,gn.width,gn.height,nn,gn.data):j.texSubImage2D(j.TEXTURE_2D,ke,at,Zt,We,Xe,nn,an,gn);Le.pixelStorei(j.UNPACK_ROW_LENGTH,Si),Le.pixelStorei(j.UNPACK_IMAGE_HEIGHT,It),Le.pixelStorei(j.UNPACK_SKIP_PIXELS,$n),Le.pixelStorei(j.UNPACK_SKIP_ROWS,ta),Le.pixelStorei(j.UNPACK_SKIP_IMAGES,ka),ke===0&&Z.generateMipmaps&&j.generateMipmap(je),Le.unbindTexture()},this.initRenderTarget=function(w){P.get(w).__webglFramebuffer===void 0&&A.setupRenderTarget(w)},this.initTexture=function(w){w.isCubeTexture?A.setTextureCube(w,0):w.isData3DTexture?A.setTexture3D(w,0):w.isDataArrayTexture||w.isCompressedArrayTexture?A.setTexture2DArray(w,0):A.setTexture2D(w,0),Le.unbindTexture()},this.resetState=function(){te=0,ie=0,W=null,Le.reset(),Re.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return gr}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const n=this.getContext();n.drawingBufferColorSpace=Xt._getDrawingBufferColorSpace(e),n.unpackColorSpace=Xt._getUnpackColorSpace()}}const o1=`
  attribute vec2 a_pos;
  void main() {
    gl_Position = vec4(a_pos, 0.0, 1.0);
  }
`,l1=`
  precision highp float;
  uniform float u_time;
  uniform vec2 u_res;
  uniform float u_waveSpeed;
  uniform float u_waveIntensity;
  uniform vec2 u_mouse;

  #define PI 3.14159265359
  #define MAX_STEPS 6

  float hash(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
  }

  float vnoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = hash(i);
    float b = hash(i + vec2(1.0, 0.0));
    float c = hash(i + vec2(0.0, 1.0));
    float d = hash(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
  }

  vec2 domainWarp(vec2 p, float t) {
    vec2 q = vec2(0.0);
    vec2 r = vec2(0.0);
    float scale = 1.0;
    for (int i = 0; i < MAX_STEPS; i++) {
      float fi = float(i);
      q += vnoise(p * scale + t * 0.15 + fi) / scale;
      r += vnoise(p * scale * 1.3 + t * 0.12 + fi + 50.0) / scale;
      scale *= 2.1;
    }
    return vec2(q, r);
  }

  float rd(vec2 p, float t) {
    vec2 wp = domainWarp(p * 2.0, t);
    return vnoise(p * 3.0 + wp + t * 0.2) * 0.5 + vnoise(p * 6.0 - wp * 0.5 + t * 0.15) * 0.3 + vnoise(p * 12.0 + t * 0.1) * 0.2;
  }

  float waveFn(vec2 p, float t, float spd) {
    float t1 = t * spd;
    float t2 = t * spd * 0.7 + 100.0;
    float t3 = t * spd * 1.3 + 200.0;
    vec2 mOff = u_mouse * 3.0;
    float d1 = rd(p + mOff, t1);
    float d2 = rd(p * 1.2 + vec2(5.0) - mOff * 0.5, t2);
    float d3 = rd(p * 0.8 + vec2(10.0) + mOff * 0.3, t3);
    return d1 * 0.5 + d2 * 0.3 + d3 * 0.2;
  }

  void main() {
    vec2 uv = gl_FragCoord.xy / u_res;
    vec2 p = (gl_FragCoord.xy - u_res * 0.5) / min(u_res.x, u_res.y);
    float t = u_time;
    float spd = u_waveSpeed;
    float intensity = u_waveIntensity;

    float w1 = waveFn(p, t, spd);
    float w2 = waveFn(p + vec2(50.0), t + 30.0, spd * 0.8);

    vec3 baseColors[6];
    baseColors[0] = vec3(0.23, 0.12, 0.04);
    baseColors[1] = vec3(0.76, 0.50, 0.14);
    baseColors[2] = vec3(0.91, 0.66, 0.22);
    baseColors[3] = vec3(0.99, 0.89, 0.70);
    baseColors[4] = vec3(0.65, 0.49, 0.32);
    baseColors[5] = vec3(0.91, 0.66, 0.22);

    float bm = (w1 * 0.5 + 0.5) * 5.0;
    float bidx = floor(bm);
    float bf = fract(bm);
    float fi = clamp(bidx, 0.0, 4.0);
    float ci = clamp(bidx + 1.0, 0.0, 5.0);
    bf = bf * bf * (3.0 - 2.0 * bf);
    vec3 baseColor = mix(baseColors[int(fi)], baseColors[int(ci)], bf);

    float h1 = (w2 * 0.5 + 0.5) * 0.7;
    float h2 = pow(h1, 2.0);
    vec3 hColor = mix(vec3(1.0, 0.85, 0.5), vec3(1.0, 0.94, 0.85), h2);

    float hMask = smoothstep(0.3, 0.7, h1);
    vec3 col = mix(baseColor, hColor, hMask * 0.4) * (0.7 + h1 * 0.6);

    float sparkle = pow(h1 * hMask, 3.0) * 0.5;
    col += vec3(1.0, 0.92, 0.75) * sparkle;

    col *= 0.7 + (1.0 - length(p) * 0.8) * 0.3;

    float vig = 1.0 - dot(uv - 0.5, uv - 0.5) * 0.8;
    col *= 0.5 + vig * 0.5;

    gl_FragColor = vec4(pow(col, vec3(0.92)), 1.0);
  }
`;function AN(o){const n=window.innerWidth<768?Math.min(window.devicePixelRatio*.5,1):Math.min(window.devicePixelRatio,2),a=new TN({canvas:o,alpha:!0,antialias:!1});a.setPixelRatio(n),a.setSize(window.innerWidth,window.innerHeight),a.domElement.style.width="100%",a.domElement.style.height="100%",a.domElement.style.display="block";const r=new Lg(-1,1,1,-1,0,1),l=new br,u=new Float32Array([-1,-1,0,3,-1,0,-1,3,0]);l.setAttribute("position",new tr(u,3));const f=new Va({vertexShader:o1,fragmentShader:l1,uniforms:{u_time:{value:0},u_res:{value:new Jt(window.innerWidth,window.innerHeight)},u_waveSpeed:{value:.4},u_waveIntensity:{value:.7},u_mouse:{value:new Jt(0,0)}}}),d=new Va({vertexShader:o1,fragmentShader:l1,uniforms:{u_time:{value:0},u_res:{value:new Jt(window.innerWidth,window.innerHeight)},u_waveSpeed:{value:.4},u_waveIntensity:{value:.7},u_mouse:{value:new Jt(0,0)}},transparent:!0,blending:i0}),p=new nr(l,f),_=new nr(l,d);_.position.z=-.1;const v=new CM,g=new CM;v.add(p),g.add(_);let x=null,M=0,E=0,S=0,y=0,R=null;const U=L=>{M=L.clientX/window.innerWidth*2-1,E=L.clientY/window.innerHeight*2-1},C=()=>{R&&clearTimeout(R),R=setTimeout(()=>{const L=window.innerWidth,H=window.innerHeight;a.setSize(L,H),f.uniforms.u_res.value.set(L,H),d.uniforms.u_res.value.set(L,H)},200)},F=()=>{x=requestAnimationFrame(F),S+=(M-S)*.03,y+=(E-y)*.03;const L=performance.now()*.001,H=L*.7+30;f.uniforms.u_time.value=L,f.uniforms.u_mouse.value.set(S,y),d.uniforms.u_time.value=H,d.uniforms.u_mouse.value.set(S*.7,y*.7),a.autoClear=!0,a.render(g,r),a.autoClear=!1,a.render(v,r)};return window.addEventListener("mousemove",U),window.addEventListener("resize",C),f.opacity=0,d.opacity=0,{start:()=>{F()},fadeIn:()=>{const k=performance.now(),te=()=>{const ie=performance.now()-k,W=Math.min(ie/3e3,1),B=0+1*(1-Math.pow(1-W,3));f.opacity=B,d.opacity=B*.6,W<1&&requestAnimationFrame(te)};te()},dispose:()=>{x&&cancelAnimationFrame(x),window.removeEventListener("mousemove",U),window.removeEventListener("resize",C),a.dispose(),f.dispose(),d.dispose(),l.dispose()},materialA:f,materialB:d}}function RN(){const o=pt.useRef(null),e=pt.useRef(null);return pt.useEffect(()=>{if(!o.current)return;const n=window.matchMedia("(prefers-reduced-motion: reduce)").matches;return e.current=AN(o.current),n&&(e.current.materialA.uniforms.u_waveSpeed.value=0,e.current.materialB.uniforms.u_waveSpeed.value=0),e.current.start(),e.current.fadeIn(),()=>{e.current?.dispose()}},[]),ge.jsx("canvas",{"code-path":"src/components/FoodColorWave.tsx:291:5",ref:o,style:{position:"absolute",top:0,left:0,width:"100%",height:"100%",zIndex:0,pointerEvents:"none"}})}yn.registerPlugin(vt);function CN(){const o=pt.useRef(null),e=pt.useRef(null),n=pt.useRef(null),a=pt.useRef(null),r=pt.useRef(null),l=pt.useRef(null);pt.useEffect(()=>{const d=yn.timeline({delay:.5});if(n.current){const p=n.current.textContent?.split("")||[];n.current.innerHTML=p.map(v=>`<span class="hero-char inline-block" style="opacity:0;transform:translateY(60px)">${v===" "?"&nbsp;":v}</span>`).join("");const _=n.current.querySelectorAll(".hero-char");d.to(_,{opacity:1,y:0,stagger:.02,duration:1.2,ease:"power3.out"})}if(a.current){const p=a.current.textContent?.split("")||[];a.current.innerHTML=p.map(v=>`<span class="hero-char inline-block" style="opacity:0;transform:translateY(60px)">${v===" "?"&nbsp;":v}</span>`).join("");const _=a.current.querySelectorAll(".hero-char");d.to(_,{opacity:1,y:0,stagger:.02,duration:1.2,ease:"power3.out"},"-=1.0")}return r.current&&d.to(r.current,{opacity:1,y:0,duration:.8,ease:"power2.out"},"-=0.6"),l.current&&d.to(l.current,{opacity:1,y:0,duration:.6,ease:"power2.out"},"-=0.4"),o.current&&vt.create({trigger:o.current,start:"top top",end:"+=500",pin:!0,pinSpacing:!0}),()=>{vt.getAll().forEach(p=>p.kill())}},[]);const u=()=>{const d=document.getElementById("cestas");d&&d.scrollIntoView({behavior:"smooth"})},f=()=>{const d=document.getElementById("contato");d&&d.scrollIntoView({behavior:"smooth"})};return ge.jsxs("section",{"code-path":"src/sections/Hero.tsx:100:5",ref:o,className:"relative w-full overflow-hidden",style:{height:"100vh"},children:[ge.jsx(RN,{"code-path":"src/sections/Hero.tsx:106:7"}),ge.jsx("div",{"code-path":"src/sections/Hero.tsx:109:7",className:"relative z-10 flex flex-col justify-center h-full px-6 lg:px-12",style:{pointerEvents:"none"},children:ge.jsxs("div",{"code-path":"src/sections/Hero.tsx:113:9",className:"max-w-[1400px] mx-auto w-full",children:[ge.jsx("p",{"code-path":"src/sections/Hero.tsx:115:11",ref:e,className:"font-label text-milk/80 mb-6",style:{textShadow:"0 2px 20px rgba(59,31,11,0.25)"},children:"Cestas Artesanais • São Paulo"}),ge.jsxs("h1",{"code-path":"src/sections/Hero.tsx:124:11",className:"mb-6",children:[ge.jsx("span",{"code-path":"src/sections/Hero.tsx:125:13",ref:n,className:"block font-display text-milk leading-[0.88] tracking-tight",style:{fontSize:"clamp(56px, 10vw, 168px)",textShadow:"0 4px 40px rgba(59,31,11,0.3)"},children:"Petit"}),ge.jsx("span",{"code-path":"src/sections/Hero.tsx:135:13",ref:a,className:"block font-display text-milk leading-[0.88] tracking-tight",style:{fontSize:"clamp(56px, 10vw, 168px)",textShadow:"0 4px 40px rgba(59,31,11,0.3)"},children:"Pauly"})]}),ge.jsx("p",{"code-path":"src/sections/Hero.tsx:148:11",ref:r,className:"font-body text-lg md:text-xl text-milk max-w-[480px] mb-8 opacity-0 translate-y-[30px]",style:{textShadow:"0 2px 20px rgba(59,31,11,0.25)"},children:"Presentes feitos à mão com ingredientes selecionados e muito amor. Cestas personalizadas para cada ocasião especial."}),ge.jsxs("div",{"code-path":"src/sections/Hero.tsx:158:11",ref:l,className:"flex items-center gap-6 opacity-0 translate-y-[20px]",style:{pointerEvents:"auto"},children:[ge.jsx("button",{"code-path":"src/sections/Hero.tsx:163:13",onClick:f,className:"font-menu text-milk bg-chocolate hover:bg-caramel px-8 py-4 rounded-full transition-colors duration-300 cursor-pointer",children:"Encomendar Agora"}),ge.jsx("button",{"code-path":"src/sections/Hero.tsx:169:13",onClick:u,className:"font-menu text-milk hover:text-caramel transition-colors duration-300 cursor-pointer",children:"Ver Cestas →"})]})]})})]})}yn.registerPlugin(vt);const wN=[{tag:"Mais Pedida",title:"Café da Manhã",description:"Cesta completa com bolo caseiro, cookies artesanais, pães de queijo e coffee drip premium.",image:"/images/cesta-cafe-da-manha.jpg"},{tag:"Aniversário",title:"Aniversário",description:"Bolo red velvet, brownies, doces em vidro e uma caneca exclusiva. Tudo em uma linda caixa de madeira.",image:"/images/cesta-birthday.jpg"},{tag:"Para Chocólatras",title:"Chocolate Lover",description:"Para os apaixonados por chocolate: bolo de chocolate, cookies recheados e bombons artesanais.",image:"/images/cesta-chocolate.jpg"},{tag:"Edição Limitada",title:"Edição Limitada",description:"Nossa cesta especial com brownie, bolos, pães de queijo e granola artesanal Harmony Blend.",image:"/images/cesta-harmony.jpg"},{tag:"Frescor",title:"Coco & Limão",description:"Bolo de coco com cobertura de limão, cookies decorados e doces em pote. Frescura em cada mordida.",image:"/images/cesta-bolo-coco.jpg"},{tag:"Eventos",title:"Catering & Eventos",description:"Buffet completo para suas celebrações: quiches, sanduíches gourmet, mini folhados e doces finos.",image:"/images/evento-catering.jpg"}];function DN(){const o=pt.useRef(null),e=pt.useRef(null),n=pt.useRef(null),a=pt.useRef(null);return pt.useEffect(()=>{if(o.current){if(e.current){const r=e.current.textContent?.split("")||[];e.current.innerHTML=r.map(l=>`<span class="inline-block" style="opacity:0;transform:translateY(20px)">${l===" "?"&nbsp;":l}</span>`).join(""),yn.to(e.current.querySelectorAll("span"),{opacity:1,y:0,stagger:.015,duration:.6,ease:"power2.out",scrollTrigger:{trigger:e.current,start:"top 80%",toggleActions:"play none none none"}})}if(n.current){const r=n.current.textContent?.split(" ")||[];n.current.innerHTML=r.map(l=>`<span class="inline-block" style="opacity:0;transform:translateY(40px)">${l}</span>`).join(" "),yn.to(n.current.querySelectorAll("span"),{opacity:1,y:0,stagger:.08,duration:.8,ease:"power3.out",scrollTrigger:{trigger:n.current,start:"top 75%",toggleActions:"play none none none"}})}if(a.current){const r=a.current.querySelectorAll(".product-card");yn.fromTo(r,{opacity:0,y:60},{opacity:1,y:0,stagger:.12,duration:.9,ease:"power3.out",scrollTrigger:{trigger:a.current,start:"top 70%",toggleActions:"play none none none"}})}}},[]),ge.jsx("section",{"code-path":"src/sections/Produtos.tsx:124:5",ref:o,id:"cestas",className:"bg-milk relative z-10",style:{padding:"120px 24px"},children:ge.jsxs("div",{"code-path":"src/sections/Produtos.tsx:130:7",className:"max-w-[1200px] mx-auto",children:[ge.jsx("p",{"code-path":"src/sections/Produtos.tsx:132:9",ref:e,className:"font-label text-caramel mb-4",children:"NOSSAS CESTAS"}),ge.jsx("h2",{"code-path":"src/sections/Produtos.tsx:140:9",ref:n,className:"font-display text-chocolate text-[40px] md:text-[56px] leading-[1.1] mb-4",children:"Cada cesta é uma experiência única"}),ge.jsx("p",{"code-path":"src/sections/Produtos.tsx:148:9",className:"font-body text-text-secondary max-w-[560px] mb-16",children:"Desde o café da manhã perfeito até presentes de aniversário inesquecíveis. Tudo feito artesanalmente com ingredientes premium."}),ge.jsx("div",{"code-path":"src/sections/Produtos.tsx:154:9",ref:a,className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8",children:wN.map(r=>ge.jsxs("div",{"code-path":"src/sections/Produtos.tsx:156:13",className:"product-card group cursor-pointer",children:[ge.jsx("span",{"code-path":"src/sections/Produtos.tsx:158:15",className:"inline-block font-body text-sm text-chocolate bg-cream px-3 py-1.5 rounded-full mb-3",children:r.tag}),ge.jsx("div",{"code-path":"src/sections/Produtos.tsx:163:15",className:"relative overflow-hidden rounded-2xl mb-4 aspect-[4/3]",children:ge.jsx("img",{"code-path":"src/sections/Produtos.tsx:164:17",src:r.image,alt:r.title,loading:"lazy",className:"w-full h-full object-cover transition-transform duration-600 group-hover:scale-105"})}),ge.jsx("h3",{"code-path":"src/sections/Produtos.tsx:173:15",className:"font-body font-medium text-2xl text-chocolate group-hover:text-caramel transition-colors duration-300 mb-2",children:r.title}),ge.jsx("p",{"code-path":"src/sections/Produtos.tsx:178:15",className:"font-body text-sm text-text-secondary mb-3",children:r.description}),ge.jsx("span",{"code-path":"src/sections/Produtos.tsx:183:15",className:"font-body text-sm text-caramel group-hover:underline",children:"Saiba mais →"})]},r.title))})]})})}yn.registerPlugin(vt);function UN(){const o=pt.useRef(null),e=pt.useRef(null),n=pt.useRef(null);return pt.useEffect(()=>{if(o.current){if(e.current){const a=e.current.querySelectorAll(".animate-in");yn.fromTo(a,{opacity:0,y:40},{opacity:1,y:0,stagger:.1,duration:.8,ease:"power3.out",scrollTrigger:{trigger:o.current,start:"top 70%",toggleActions:"play none none none"}})}n.current&&yn.fromTo(n.current,{opacity:0,scale:.95},{opacity:1,scale:1,duration:1,ease:"power3.out",scrollTrigger:{trigger:o.current,start:"top 70%",toggleActions:"play none none none"}})}},[]),ge.jsx("section",{"code-path":"src/sections/Sobre.tsx:57:5",ref:o,id:"sobre",className:"bg-cream relative z-10",style:{padding:"120px 24px"},children:ge.jsx("div",{"code-path":"src/sections/Sobre.tsx:63:7",className:"max-w-[1200px] mx-auto",children:ge.jsxs("div",{"code-path":"src/sections/Sobre.tsx:64:9",className:"grid grid-cols-1 lg:grid-cols-[55%_45%] gap-12 lg:gap-16 items-center",children:[ge.jsxs("div",{"code-path":"src/sections/Sobre.tsx:66:11",ref:e,children:[ge.jsx("p",{"code-path":"src/sections/Sobre.tsx:67:13",className:"animate-in font-label text-caramel mb-4",children:"SOBRE NÓS"}),ge.jsx("h2",{"code-path":"src/sections/Sobre.tsx:71:13",className:"animate-in font-display text-chocolate text-[40px] md:text-[56px] leading-[1.1] mb-6",children:"Uma paixão transformada em arte"}),ge.jsx("p",{"code-path":"src/sections/Sobre.tsx:75:13",className:"animate-in font-body text-text-secondary leading-relaxed mb-8",children:"A Petit Pauly nasceu do amor pela gastronomia e pela arte de presentear. Cada cesta é montada à mão, com atenção a cada detalhe — desde a seleção dos ingredientes frescos até a decoração com flores secas e etiquetas personalizadas. Nossa chef, Pauly, traz anos de experiência na confeitaria artesanal para criar presentes que encantam todos os sentidos."}),ge.jsx("p",{"code-path":"src/sections/Sobre.tsx:84:13",className:"animate-in font-accent text-2xl text-caramel mb-8",children:'"Cada cesta conta uma história de amor e dedicação."'}),ge.jsx("span",{"code-path":"src/sections/Sobre.tsx:88:13",className:"animate-in inline-block font-body text-chocolate hover:text-caramel transition-colors duration-300 cursor-pointer",children:"Conheça Nossa História →"})]}),ge.jsxs("div",{"code-path":"src/sections/Sobre.tsx:94:11",ref:n,className:"relative",children:[ge.jsx("div",{"code-path":"src/sections/Sobre.tsx:95:13",className:"relative overflow-hidden rounded-2xl aspect-[3/4]",children:ge.jsx("img",{"code-path":"src/sections/Sobre.tsx:96:15",src:"/images/chef-pauly.jpg",alt:"Chef Pauly segurando um bolo decorado",loading:"lazy",className:"w-full h-full object-cover"})}),ge.jsxs("div",{"code-path":"src/sections/Sobre.tsx:105:13",className:"absolute -bottom-6 -left-6 bg-white rounded-xl p-6 shadow-soft",children:[ge.jsx("p",{"code-path":"src/sections/Sobre.tsx:106:15",className:"font-display text-caramel text-4xl mb-1",children:"+500"}),ge.jsx("p",{"code-path":"src/sections/Sobre.tsx:107:15",className:"font-body text-sm text-text-secondary",children:"Cestas entregues com amor"})]})]})]})})})}const NN=o=>o.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),LN=o=>o.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,n,a)=>a?a.toUpperCase():n.toLowerCase()),c1=o=>{const e=LN(o);return e.charAt(0).toUpperCase()+e.slice(1)},pE=(...o)=>o.filter((e,n,a)=>!!e&&e.trim()!==""&&a.indexOf(e)===n).join(" ").trim(),ON=o=>{for(const e in o)if(e.startsWith("aria-")||e==="role"||e==="title")return!0};var PN={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};const FN=pt.forwardRef(({color:o="currentColor",size:e=24,strokeWidth:n=2,absoluteStrokeWidth:a,className:r="",children:l,iconNode:u,...f},d)=>pt.createElement("svg",{ref:d,...PN,width:e,height:e,stroke:o,strokeWidth:a?Number(n)*24/Number(e):n,className:pE("lucide",r),...!l&&!ON(f)&&{"aria-hidden":"true"},...f},[...u.map(([p,_])=>pt.createElement(p,_)),...Array.isArray(l)?l:[l]]));const mE=(o,e)=>{const n=pt.forwardRef(({className:a,...r},l)=>pt.createElement(FN,{ref:l,iconNode:e,className:pE(`lucide-${NN(c1(o))}`,`lucide-${o}`,a),...r}));return n.displayName=c1(o),n};const zN=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],IN=mE("chevron-left",zN);const BN=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],HN=mE("chevron-right",BN);yn.registerPlugin(vt);const pu=[{quote:"A cesta de aniversário que enviei para minha mãe foi simplesmente perfeita. Ela chorou de emoção! A atenção aos detalhes é impressionante.",author:"Mariana S.",role:"Cliente desde 2023"},{quote:"Encomendei o catering para meu casamento e foi um sucesso absoluto. Os convidados não paravam de elogiar a comida.",author:"Ricardo & Ana",role:"Noivos"},{quote:"O café da manhã na cesta foi a melhor surpresa que já recebi. Cada item parecia feito com tanto carinho.",author:"Fernanda L.",role:"Cliente"}];function GN(){const o=pt.useRef(null),[e,n]=pt.useState(0);pt.useEffect(()=>{if(!o.current)return;const u=o.current.querySelectorAll(".depo-animate");yn.fromTo(u,{opacity:0,y:30},{opacity:1,y:0,duration:.8,ease:"power2.out",scrollTrigger:{trigger:o.current,start:"top 70%",toggleActions:"play none none none"}})},[]);const a=()=>n(u=>(u+1)%pu.length),r=()=>n(u=>(u-1+pu.length)%pu.length),l=pu[e];return ge.jsx("section",{"code-path":"src/sections/Depoimentos.tsx:61:5",ref:o,id:"depoimentos",className:"bg-espresso relative z-10",style:{padding:"120px 24px"},children:ge.jsxs("div",{"code-path":"src/sections/Depoimentos.tsx:67:7",className:"max-w-[800px] mx-auto text-center",children:[ge.jsx("p",{"code-path":"src/sections/Depoimentos.tsx:68:9",className:"depo-animate font-label text-honey mb-4",children:"DEPOIMENTOS"}),ge.jsx("h2",{"code-path":"src/sections/Depoimentos.tsx:70:9",className:"depo-animate font-display text-milk text-[40px] md:text-[56px] leading-[1.1] mb-16",children:"O que nossos clientes dizem"}),ge.jsxs("div",{"code-path":"src/sections/Depoimentos.tsx:75:9",className:"depo-animate relative",role:"region","aria-roledescription":"carousel",children:[ge.jsx("span",{"code-path":"src/sections/Depoimentos.tsx:81:11",className:"absolute -top-8 left-1/2 -translate-x-1/2 font-display text-honey opacity-30",style:{fontSize:120,lineHeight:1},children:'"'}),ge.jsx("p",{"code-path":"src/sections/Depoimentos.tsx:88:11",className:"font-display text-milk text-xl md:text-[32px] leading-snug mb-8 px-4",children:l.quote}),ge.jsxs("div",{"code-path":"src/sections/Depoimentos.tsx:92:11",children:[ge.jsx("p",{"code-path":"src/sections/Depoimentos.tsx:93:13",className:"font-body font-semibold text-lg text-milk",children:l.author}),ge.jsx("p",{"code-path":"src/sections/Depoimentos.tsx:96:13",className:"font-body text-sm text-milk/50",children:l.role})]})]}),ge.jsxs("div",{"code-path":"src/sections/Depoimentos.tsx:101:9",className:"depo-animate flex items-center justify-center gap-4 mt-12",children:[ge.jsx("button",{"code-path":"src/sections/Depoimentos.tsx:102:11",onClick:r,className:"w-12 h-12 rounded-full border border-milk/20 flex items-center justify-center text-milk hover:bg-caramel hover:border-caramel transition-all duration-300 cursor-pointer","aria-label":"Depoimento anterior",children:ge.jsx(IN,{"code-path":"src/sections/Depoimentos.tsx:107:13",size:20})}),ge.jsx("div",{"code-path":"src/sections/Depoimentos.tsx:111:11",className:"flex gap-2",children:pu.map((u,f)=>ge.jsx("button",{"code-path":"src/sections/Depoimentos.tsx:113:15",onClick:()=>n(f),className:`w-2 h-2 rounded-full transition-all duration-300 cursor-pointer ${f===e?"bg-caramel w-6":"bg-milk/30 hover:bg-milk/50"}`,"aria-label":`Ir para depoimento ${f+1}`},f))}),ge.jsx("button",{"code-path":"src/sections/Depoimentos.tsx:126:11",onClick:a,className:"w-12 h-12 rounded-full border border-milk/20 flex items-center justify-center text-milk hover:bg-caramel hover:border-caramel transition-all duration-300 cursor-pointer","aria-label":"Próximo depoimento",children:ge.jsx(HN,{"code-path":"src/sections/Depoimentos.tsx:131:13",size:20})})]})]})})}yn.registerPlugin(vt);const VN=[{src:"/images/cesta-red-velvet.jpg",alt:"Red velvet birthday set"},{src:"/images/buffet-salgados.jpg",alt:"Savory catering spread"},{src:"/images/cookies-gourmet.jpg",alt:"Gourmet cookies collection"},{src:"/images/cesta-bolo-coco.jpg",alt:"Coconut cake gift box"},{src:"/images/jar-doces.jpg",alt:"Sweets in glass jar"},{src:"/images/happy-day.jpg",alt:"Happy Day gift jars"},{src:"/images/evento-catering.jpg",alt:"Event catering display"},{src:"/images/cesta-cafe-da-manha.jpg",alt:"Breakfast basket"}];function kN(){const o=pt.useRef(null),e=pt.useRef(null),n=pt.useRef(null),a=pt.useRef(null),r=pt.useRef(null);return pt.useEffect(()=>{if(!o.current||!e.current||!n.current)return;if(a.current&&yn.fromTo(a.current,{opacity:0,y:20},{opacity:1,y:0,duration:.6,ease:"power2.out",scrollTrigger:{trigger:a.current,start:"top 80%",toggleActions:"play none none none"}}),r.current){const p=r.current.textContent?.split(" ")||[];r.current.innerHTML=p.map(_=>`<span class="inline-block" style="opacity:0;transform:translateY(40px)">${_}</span>`).join(" "),yn.to(r.current.querySelectorAll("span"),{opacity:1,y:0,stagger:.08,duration:.8,ease:"power3.out",scrollTrigger:{trigger:r.current,start:"top 75%",toggleActions:"play none none none"}})}const l=e.current,u=n.current,f=l.scrollWidth,d=u.offsetWidth;yn.to(l,{x:-(f-d),ease:"none",scrollTrigger:{trigger:u,start:"top 20%",end:()=>`+=${f-d}`,scrub:1.5,pin:!0,anticipatePin:1}})},[]),ge.jsxs("section",{"code-path":"src/sections/Galeria.tsx:88:5",ref:o,id:"galeria",className:"bg-milk relative z-10 pt-20",children:[ge.jsxs("div",{"code-path":"src/sections/Galeria.tsx:94:7",className:"px-6 lg:px-12 mb-12 max-w-[1200px] mx-auto",children:[ge.jsx("p",{"code-path":"src/sections/Galeria.tsx:95:9",ref:a,className:"font-label text-caramel mb-4",children:"GALERIA"}),ge.jsx("h2",{"code-path":"src/sections/Galeria.tsx:98:9",ref:r,className:"font-display text-chocolate text-[40px] md:text-[56px] leading-[1.1]",children:"Momentos de carinho"})]}),ge.jsx("div",{"code-path":"src/sections/Galeria.tsx:107:7",ref:n,className:"overflow-hidden",children:ge.jsx("div",{"code-path":"src/sections/Galeria.tsx:108:9",ref:e,className:"flex gap-6 px-6 lg:px-12 will-change-transform",style:{width:"max-content"},children:VN.map((l,u)=>ge.jsx("div",{"code-path":"src/sections/Galeria.tsx:114:13",className:"flex-shrink-0 w-[300px] md:w-[400px] overflow-hidden rounded-xl",children:ge.jsx("img",{"code-path":"src/sections/Galeria.tsx:118:15",src:l.src,alt:l.alt,loading:"lazy",className:"w-full h-full object-cover aspect-[4/3]"})},u))})})]})}yn.registerPlugin(vt);const u1=[{number:"01",title:"Escolha",description:"Selecione uma de nossas cestas ou monte uma personalizada com seus itens favoritos."},{number:"02",title:"Personalize",description:"Adicione uma mensagem especial, escolha a decoração e defina a data de entrega."},{number:"03",title:"Presenteie",description:"Receba em São Paulo/SP ou envie diretamente para quem você ama com todo o nosso carinho."}];function XN(){const o=pt.useRef(null),e=pt.useRef(null),n=pt.useRef(null),a=pt.useRef(null);return pt.useEffect(()=>{if(o.current){if(e.current&&yn.fromTo(e.current,{opacity:0,y:20},{opacity:1,y:0,duration:.6,ease:"power2.out",scrollTrigger:{trigger:e.current,start:"top 80%",toggleActions:"play none none none"}}),n.current){const r=n.current.textContent?.split(" ")||[];n.current.innerHTML=r.map(l=>`<span class="inline-block" style="opacity:0;transform:translateY(40px)">${l}</span>`).join(" "),yn.to(n.current.querySelectorAll("span"),{opacity:1,y:0,stagger:.08,duration:.8,ease:"power3.out",scrollTrigger:{trigger:n.current,start:"top 75%",toggleActions:"play none none none"}})}if(a.current){const r=a.current.querySelectorAll(".step-card");yn.fromTo(r,{opacity:0,y:50},{opacity:1,y:0,stagger:.15,duration:.8,ease:"power3.out",scrollTrigger:{trigger:a.current,start:"top 70%",toggleActions:"play none none none"}})}}},[]),ge.jsx("section",{"code-path":"src/sections/ComoFunciona.tsx:99:5",ref:o,className:"bg-cream relative z-10",style:{padding:"120px 24px"},children:ge.jsxs("div",{"code-path":"src/sections/ComoFunciona.tsx:104:7",className:"max-w-[1200px] mx-auto",children:[ge.jsx("p",{"code-path":"src/sections/ComoFunciona.tsx:105:9",ref:e,className:"font-label text-caramel mb-4",children:"COMO FUNCIONA"}),ge.jsx("h2",{"code-path":"src/sections/ComoFunciona.tsx:109:9",ref:n,className:"font-display text-chocolate text-[40px] md:text-[56px] leading-[1.1] mb-16",children:"Sua cesta artesanal em 3 passos"}),ge.jsx("div",{"code-path":"src/sections/ComoFunciona.tsx:116:9",ref:a,className:"grid grid-cols-1 md:grid-cols-3 gap-12 relative",children:u1.map((r,l)=>ge.jsxs("div",{"code-path":"src/sections/ComoFunciona.tsx:121:13",className:"step-card relative",children:[l<u1.length-1&&ge.jsx("div",{"code-path":"src/sections/ComoFunciona.tsx:124:17",className:"hidden md:block absolute right-0 top-0 w-px bg-rose",style:{height:"60%",transform:"translateX(50%)"}}),ge.jsx("p",{"code-path":"src/sections/ComoFunciona.tsx:130:15",className:"font-display text-caramel text-[72px] leading-none opacity-40 mb-4",children:r.number}),ge.jsx("h3",{"code-path":"src/sections/ComoFunciona.tsx:134:15",className:"font-body font-medium text-2xl text-chocolate mb-3",children:r.title}),ge.jsx("p",{"code-path":"src/sections/ComoFunciona.tsx:138:15",className:"font-body text-text-secondary leading-relaxed",children:r.description})]},r.number))})]})})}yn.registerPlugin(vt);function WN(){const o=pt.useRef(null),e=pt.useRef(null),n=pt.useRef(null),a=pt.useRef(null);return pt.useEffect(()=>{if(o.current){if(e.current){const r=e.current.textContent?.split(" ")||[];e.current.innerHTML=r.map(l=>`<span class="inline-block" style="opacity:0;transform:translateY(40px)">${l}</span>`).join(" "),yn.to(e.current.querySelectorAll("span"),{opacity:1,y:0,stagger:.06,duration:.8,ease:"power3.out",scrollTrigger:{trigger:o.current,start:"top 75%",toggleActions:"play none none none"}})}n.current&&yn.fromTo(n.current,{opacity:0,y:20},{opacity:1,y:0,duration:.6,delay:.2,ease:"power2.out",scrollTrigger:{trigger:o.current,start:"top 75%",toggleActions:"play none none none"}}),a.current&&yn.fromTo(a.current,{opacity:0,scale:.9},{opacity:1,scale:1,duration:.6,delay:.3,ease:"power2.out",scrollTrigger:{trigger:o.current,start:"top 75%",toggleActions:"play none none none"}})}},[]),ge.jsx("section",{"code-path":"src/sections/CTA.tsx:78:5",ref:o,id:"contato",className:"bg-chocolate relative z-10 text-center",style:{padding:"120px 24px"},children:ge.jsxs("div",{"code-path":"src/sections/CTA.tsx:84:7",className:"max-w-[600px] mx-auto",children:[ge.jsx("h2",{"code-path":"src/sections/CTA.tsx:85:9",ref:e,className:"font-display text-milk text-[40px] md:text-[56px] leading-[1.1] mb-6",children:"Pronta para surpreender alguém especial?"}),ge.jsx("p",{"code-path":"src/sections/CTA.tsx:92:9",ref:n,className:"font-body text-milk/50 max-w-[480px] mx-auto mb-10 opacity-0",children:"Entre em contato pelo WhatsApp e montamos a cesta perfeita para sua ocasião."}),ge.jsxs("div",{"code-path":"src/sections/CTA.tsx:100:9",ref:a,className:"opacity-0",style:{transform:"scale(0.9)"},children:[ge.jsx("a",{"code-path":"src/sections/CTA.tsx:101:11",href:"https://wa.me/5511999999999",target:"_blank",rel:"noopener noreferrer",className:"inline-block font-menu text-sm bg-caramel text-espresso px-10 py-4 rounded-full hover:bg-honey transition-colors duration-300 cursor-pointer",children:"Pedir pelo WhatsApp"}),ge.jsx("p",{"code-path":"src/sections/CTA.tsx:110:11",className:"mt-6",children:ge.jsx("a",{"code-path":"src/sections/CTA.tsx:111:13",href:"https://instagram.com/petitpauly",target:"_blank",rel:"noopener noreferrer",className:"font-accent text-xl text-milk/50 hover:text-honey transition-colors duration-300",children:"ou siga no Instagram @petitpauly"})})]})]})})}function qN(){return ge.jsxs(ge.Fragment,{children:[ge.jsx(YR,{"code-path":"src/pages/Home.tsx:14:7"}),ge.jsxs("main",{"code-path":"src/pages/Home.tsx:15:7",children:[ge.jsx(CN,{"code-path":"src/pages/Home.tsx:16:9"}),ge.jsx(DN,{"code-path":"src/pages/Home.tsx:17:9"}),ge.jsx(UN,{"code-path":"src/pages/Home.tsx:18:9"}),ge.jsx(GN,{"code-path":"src/pages/Home.tsx:19:9"}),ge.jsx(kN,{"code-path":"src/pages/Home.tsx:20:9"}),ge.jsx(XN,{"code-path":"src/pages/Home.tsx:21:9"}),ge.jsx(WN,{"code-path":"src/pages/Home.tsx:22:9"})]}),ge.jsx(dC,{"code-path":"src/pages/Home.tsx:24:7"})]})}function YN(){return ge.jsx(qN,{"code-path":"src/App.tsx:4:10"})}RA.createRoot(document.getElementById("root")).render(ge.jsx(YN,{"code-path":"src/main.tsx:5:53"}));
